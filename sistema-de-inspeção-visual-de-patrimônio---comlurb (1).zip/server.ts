import express from 'express';
import path from 'path';
import fs from 'fs';

const app = express();
const PORT = 3000;

// Support large payloads (inspection reports, photos, signatures)
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

const DATA_DIR = path.join(process.cwd(), 'data');
const CLOUD_STORE_FILE = path.join(DATA_DIR, 'cloud_store.json');
const SEED_FILE = path.join(DATA_DIR, 'seed_comlurb_database.json');

// Ensure data directory exists
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

// Helper: load store with fallback to seed
function getCloudData(): any {
  if (fs.existsSync(CLOUD_STORE_FILE)) {
    try {
      const content = fs.readFileSync(CLOUD_STORE_FILE, 'utf-8');
      const parsed = JSON.parse(content);
      if (parsed && Array.isArray(parsed.assets) && parsed.assets.length > 0) {
        return parsed;
      }
    } catch (e) {
      console.error('Erro ao ler cloud_store.json:', e);
    }
  }

  // Fallback to seed file if cloud_store is empty or doesn't exist
  if (fs.existsSync(SEED_FILE)) {
    try {
      const seedContent = fs.readFileSync(SEED_FILE, 'utf-8');
      const seedParsed = JSON.parse(seedContent);
      if (seedParsed && Array.isArray(seedParsed.assets) && seedParsed.assets.length > 0) {
        fs.writeFileSync(CLOUD_STORE_FILE, JSON.stringify(seedParsed, null, 2), 'utf-8');
        return seedParsed;
      }
    } catch (e) {
      console.error('Erro ao ler seed_comlurb_database.json:', e);
    }
  }

  return null;
}

// Health check endpoint
app.get('/api/health', (_req, res) => {
  const data = getCloudData();
  res.json({
    status: 'ok',
    hasCloudData: !!data,
    assetCount: data?.assets?.length || 0,
    inspectionCount: Object.keys(data?.inspections || {}).length,
    lastModified: data?.lastModified || null,
    environment: process.env.NODE_ENV || 'development',
  });
});

// Google Sheet fetch proxy to avoid browser CORS
app.get('/api/fetch-google-sheet', async (req, res) => {
  res.setHeader('Content-Type', 'application/json');
  try {
    const sheetId = (req.query.id as string) || '1ZsoXBfn-wTR3gb52vjaE6cOvAWL6DiF5';
    const gid = (req.query.gid as string) || '1407549722';

    const exportUrls = [
      `https://docs.google.com/spreadsheets/d/${sheetId}/export?format=csv&gid=${gid}`,
      `https://docs.google.com/spreadsheets/d/${sheetId}/export?format=csv`,
      `https://docs.google.com/spreadsheets/d/${sheetId}/gviz/tq?tqx=out:csv`,
    ];

    let csvData = '';
    for (const u of exportUrls) {
      try {
        const resp = await fetch(u);
        if (resp.ok) {
          const text = await resp.text();
          if (text && !text.includes('<!doctype') && !text.includes('Sign in to your Google Account')) {
            csvData = text;
            break;
          }
        }
      } catch {
        // try next
      }
    }

    if (csvData) {
      res.json({
        success: true,
        sheetId,
        gid,
        csv: csvData,
        timestamp: new Date().toISOString(),
      });
    } else {
      res.status(404).json({
        success: false,
        error: 'Não foi possível baixar o CSV da planilha. Verifique se o compartilhamento está público (Qualquer pessoa com o link: Leitor).',
      });
    }
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Cloud Sync Status (Lightweight polling endpoint for multi-account sync)
app.get('/api/cloud-status', (_req, res) => {
  try {
    const data = getCloudData();
    if (data) {
      const baixadosCount = (data.assets || []).filter((a: any) => a.situacao === 'baixado').length;
      const photosCount = Object.keys(data.disposalPhotos || {}).length;
      return res.json({
        success: true,
        hasData: true,
        timestamp: data.lastModified || '2026-01-01T00:00:00.000Z',
        modifiedBy: data.modifiedBy || 'Sistema COMLURB',
        assetsCount: (data.assets || []).length,
        baixadosCount,
        photosCount,
        inspectionsCount: Object.keys(data.inspections || {}).length,
      });
    }
    return res.json({
      success: true,
      hasData: false,
      timestamp: '2026-01-01T00:00:00.000Z',
      modifiedBy: 'Nenhum',
      assetsCount: 0,
      baixadosCount: 0,
      photosCount: 0,
      inspectionsCount: 0,
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// Cloud Sync GET
app.get('/api/cloud-sync', (_req, res) => {
  try {
    const data = getCloudData();
    if (data) {
      return res.json({
        success: true,
        source: 'cloud',
        data,
        timestamp: data.lastModified || new Date().toISOString(),
      });
    }
    return res.json({
      success: true,
      source: 'initial',
      data: null,
      message: 'Nenhum dado na nuvem ainda',
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

// Cloud Sync POST with Intelligent Multi-Account Merge Logic
app.post('/api/cloud-sync', (req, res) => {
  try {
    const payload = req.body;
    if (!payload || typeof payload !== 'object') {
      return res.status(400).json({ success: false, error: 'Payload inválido' });
    }

    const existing = getCloudData() || {};

    // Intelligent Non-Destructive Asset Reconciliation
    // Prevents an account with stale active assets from wiping baixas or photos recorded by another account
    let mergedAssets: any[] = [];
    const incomingAssets: any[] = Array.isArray(payload.assets) ? payload.assets : [];
    const existingAssets: any[] = Array.isArray(existing.assets) ? existing.assets : [];

    if (existingAssets.length === 0) {
      mergedAssets = incomingAssets;
    } else if (incomingAssets.length === 0) {
      mergedAssets = existingAssets;
    } else {
      const incomingMap = new Map<string, any>();
      incomingAssets.forEach((item) => {
        if (item.id) incomingMap.set(String(item.id), item);
        if (item.patrimonio) incomingMap.set(`pat_${item.patrimonio}`, item);
      });

      const processedIds = new Set<string>();

      // Reconcile each existing asset with incoming asset
      mergedAssets = existingAssets.map((existingItem: any) => {
        const keyId = String(existingItem.id);
        const incomingItem = incomingMap.get(keyId) || incomingMap.get(`pat_${existingItem.patrimonio}`);

        if (!incomingItem) {
          return existingItem;
        }

        processedIds.add(keyId);
        if (existingItem.patrimonio) processedIds.add(`pat_${existingItem.patrimonio}`);

        // If existing asset is baixado, keep baixado status unless incoming explicitly reactivated it
        const isExistingBaixado = existingItem.situacao === 'baixado';
        const isIncomingBaixado = incomingItem.situacao === 'baixado';
        const isExplicitReactivation = incomingItem.wasReactivated === true;

        let finalSituacao = incomingItem.situacao || existingItem.situacao;
        let finalMotivo = incomingItem.motivoBaixa || existingItem.motivoBaixa;
        let finalDtBaixa = incomingItem.dtBaixa || existingItem.dtBaixa;

        if (isExistingBaixado && !isIncomingBaixado && !isExplicitReactivation) {
          // Keep existing baixa so another account does not wipe it
          finalSituacao = 'baixado';
          finalMotivo = existingItem.motivoBaixa;
          finalDtBaixa = existingItem.dtBaixa;
        }

        // Photo preservation: if existing or incoming has a photo, keep the non-empty one
        const finalFotoUrl = incomingItem.fotoUrl || existingItem.fotoUrl;

        return {
          ...existingItem,
          ...incomingItem,
          situacao: finalSituacao,
          motivoBaixa: finalMotivo,
          dtBaixa: finalDtBaixa,
          fotoUrl: finalFotoUrl,
        };
      });

      // Append any brand new assets introduced in incomingAssets
      incomingAssets.forEach((incomingItem: any) => {
        const keyId = String(incomingItem.id);
        if (!processedIds.has(keyId) && (!incomingItem.patrimonio || !processedIds.has(`pat_${incomingItem.patrimonio}`))) {
          mergedAssets.push(incomingItem);
        }
      });
    }

    // Merge photos dictionary (so photos uploaded on any account are preserved)
    const mergedPhotos = {
      ...(existing.disposalPhotos || {}),
      ...(payload.disposalPhotos || {}),
    };

    // Merge disposal batch metadata overrides
    const mergedBatchMeta = {
      ...(existing.disposalBatchMeta || {}),
      ...(payload.disposalBatchMeta || {}),
    };

    // Merge inspections dictionary
    const mergedInspections = {
      ...(existing.inspections || {}),
      ...(payload.inspections || {}),
    };

    // Merge department managers
    const mergedDeptManagers = {
      ...(existing.departmentManagers || {}),
      ...(payload.departmentManagers || {}),
    };

    const updated = {
      ...existing,
      ...payload,
      assets: mergedAssets,
      disposalPhotos: mergedPhotos,
      disposalBatchMeta: mergedBatchMeta,
      inspections: mergedInspections,
      departmentManagers: mergedDeptManagers,
      lastModified: new Date().toISOString(),
      modifiedBy: payload.modifiedBy || 'Wagner J. Jardim (COMLURB)',
    };

    // Atomic write to cloud_store.json
    const tempFile = `${CLOUD_STORE_FILE}.tmp`;
    fs.writeFileSync(tempFile, JSON.stringify(updated, null, 2), 'utf-8');
    fs.renameSync(tempFile, CLOUD_STORE_FILE);

    // Also persist to seed file so data is kept across environment reboots
    try {
      fs.writeFileSync(SEED_FILE, JSON.stringify(updated, null, 2), 'utf-8');
    } catch {
      // ignore
    }

    const baixadosCount = (updated.assets || []).filter((a: any) => a.situacao === 'baixado').length;
    const photosCount = Object.keys(updated.disposalPhotos || {}).length;

    return res.json({
      success: true,
      timestamp: updated.lastModified,
      modifiedBy: updated.modifiedBy,
      assetsSaved: updated.assets?.length || 0,
      baixadosSaved: baixadosCount,
      disposalPhotosSaved: photosCount,
      inspectionsSaved: Object.keys(updated.inspections || {}).length,
    });
  } catch (err: any) {
    console.error('Erro em POST /api/cloud-sync:', err);
    return res.status(500).json({ success: false, error: err.message });
  }
});

// Cloud Clear POST
app.post('/api/cloud-clear', (_req, res) => {
  try {
    if (fs.existsSync(CLOUD_STORE_FILE)) {
      fs.unlinkSync(CLOUD_STORE_FILE);
    }
    return res.json({
      success: true,
      message: 'Base de dados em nuvem limpa com sucesso',
      timestamp: new Date().toISOString(),
    });
  } catch (err: any) {
    return res.status(500).json({ success: false, error: err.message });
  }
});

async function startServer() {
  // Mount Vite middleware or production static handler
  if (process.env.NODE_ENV === 'production') {
    // Production mode: serve built static assets from dist/
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath, {
      index: false,
      maxAge: '1d',
    }));

    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
    console.log('Servidor em modo de PRODUÇÃO servindo arquivos de:', distPath);
  } else {
    // Development mode: standard Vite middleware
    try {
      const { createServer: createViteServer } = await import('vite');
      const vite = await createViteServer({
        server: { middlewareMode: true, hmr: false },
        appType: 'spa',
      });
      app.use(vite.middlewares);
      console.log('Vite middleware configurado com sucesso para desenvolvimento');
    } catch (e) {
      console.error('Erro ao inicializar Vite middleware:', e);
    }
  }

  // Start listening on port 3000
  const server = app.listen(PORT, '0.0.0.0', () => {
    console.log(`COMLURB Full-Stack Server rodando com sucesso na porta ${PORT} [${process.env.NODE_ENV || 'development'}]`);
  });

  server.on('error', (err: any) => {
    if (err.code === 'EADDRINUSE') {
      console.warn(`Porta ${PORT} em uso. Tentando novamente em 1 segundo...`);
      setTimeout(() => {
        try {
          server.close();
        } catch {}
        server.listen(PORT, '0.0.0.0');
      }, 1000);
    } else {
      console.error('Erro no servidor HTTP:', err);
    }
  });

  // Graceful shutdown
  const shutdown = () => {
    console.log('Encerrando servidor de forma graciosa...');
    server.close(() => {
      process.exit(0);
    });
  };
  process.on('SIGTERM', shutdown);
  process.on('SIGINT', shutdown);
}

startServer();
