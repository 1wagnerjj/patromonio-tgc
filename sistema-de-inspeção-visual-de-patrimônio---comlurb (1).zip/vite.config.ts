import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import fs from 'fs';
import { defineConfig, type Plugin } from 'vite';

function cloudSyncPlugin(): Plugin {
  const DATA_DIR = path.join(process.cwd(), 'data');
  const CLOUD_STORE_FILE = path.join(DATA_DIR, 'cloud_store.json');

  if (!fs.existsSync(DATA_DIR)) {
    try {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    } catch {
      // ignore
    }
  }

  return {
    name: 'cloud-sync-plugin',
    configureServer(server) {
      server.middlewares.use('/api/health', (_req, res) => {
        res.setHeader('Content-Type', 'application/json');
        const hasData = fs.existsSync(CLOUD_STORE_FILE);
        res.end(JSON.stringify({
          status: 'ok',
          cloud: 'connected',
          storage: 'persistent_disk',
          hasCloudData: hasData,
          timestamp: new Date().toISOString(),
        }));
      });

      server.middlewares.use('/api/fetch-google-sheet', async (req, res) => {
        res.setHeader('Content-Type', 'application/json');
        try {
          const urlObj = new URL(req.url || '', 'http://localhost:3000');
          const sheetId = urlObj.searchParams.get('id') || '1ZsoXBfn-wTR3gb52vjaE6cOvAWL6DiF5';
          const gid = urlObj.searchParams.get('gid') || '1407549722';

          const exportUrls = [
            `https://docs.google.com/spreadsheets/d/${sheetId}/export?format=csv&gid=${gid}`,
            `https://docs.google.com/spreadsheets/d/${sheetId}/export?format=csv`,
            `https://docs.google.com/spreadsheets/d/${sheetId}/gviz/tq?tqx=out:csv`,
          ];

          let csvData = '';
          for (const u of exportUrls) {
            try {
              const resp = await fetch(u);
              if (resp.ok) {
                const text = await resp.text();
                if (text && !text.includes('<!doctype') && !text.includes('Sign in to your Google Account')) {
                  csvData = text;
                  break;
                }
              }
            } catch {
              // continue
            }
          }

          if (csvData) {
            res.end(JSON.stringify({
              success: true,
              sheetId,
              gid,
              csv: csvData,
              timestamp: new Date().toISOString(),
            }));
          } else {
            res.statusCode = 404;
            res.end(JSON.stringify({
              success: false,
              error: 'Não foi possível baixar o CSV da planilha. Verifique se o compartilhamento está público (Qualquer pessoa com o link).',
            }));
          }
        } catch (err: any) {
          res.statusCode = 500;
          res.end(JSON.stringify({ success: false, error: err.message }));
        }
      });

      server.middlewares.use('/api/cloud-clear', (req, res) => {
        res.setHeader('Content-Type', 'application/json');
        if (req.method === 'POST') {
          try {
            if (fs.existsSync(CLOUD_STORE_FILE)) {
              fs.unlinkSync(CLOUD_STORE_FILE);
            }
            res.end(JSON.stringify({
              success: true,
              message: 'Base de dados em nuvem limpa com sucesso',
              timestamp: new Date().toISOString(),
            }));
          } catch (err: any) {
            res.statusCode = 500;
            res.end(JSON.stringify({ success: false, error: err.message }));
          }
          return;
        }
        res.statusCode = 405;
        res.end(JSON.stringify({ error: 'Method not allowed' }));
      });

      server.middlewares.use('/api/cloud-sync', (req, res) => {
        res.setHeader('Content-Type', 'application/json');

        if (req.method === 'GET') {
          try {
            if (fs.existsSync(CLOUD_STORE_FILE)) {
              const fileContent = fs.readFileSync(CLOUD_STORE_FILE, 'utf-8');
              const parsed = JSON.parse(fileContent);
              res.end(JSON.stringify({
                success: true,
                source: 'cloud',
                data: parsed,
                timestamp: parsed.lastModified || new Date().toISOString(),
              }));
              return;
            }
            res.end(JSON.stringify({
              success: true,
              source: 'initial',
              data: null,
              message: 'No cloud database initialized yet',
            }));
          } catch (err: any) {
            res.statusCode = 500;
            res.end(JSON.stringify({ success: false, error: err.message }));
          }
          return;
        }

        if (req.method === 'POST') {
          let body = '';
          req.on('data', (chunk) => {
            body += chunk;
          });
          req.on('end', () => {
            try {
              const payload = JSON.parse(body || '{}');
              const cloudData = {
                assets: payload.assets || [],
                inspections: payload.inspections || {},
                disposalPhotos: payload.disposalPhotos || {},
                disposalBatchMeta: payload.disposalBatchMeta || {},
                departmentManagers: payload.departmentManagers || {},
                selectedYear: payload.selectedYear || 2024,
                lastModified: new Date().toISOString(),
                modifiedBy: payload.modifiedBy || 'Sistema COMLURB Nuvem',
                itemCount: payload.assets?.length || 0,
              };

              const tempFile = `${CLOUD_STORE_FILE}.tmp`;
              fs.writeFileSync(tempFile, JSON.stringify(cloudData, null, 2), 'utf-8');
              fs.renameSync(tempFile, CLOUD_STORE_FILE);

              res.end(JSON.stringify({
                success: true,
                message: 'Dados sincronizados com sucesso na nuvem',
                timestamp: cloudData.lastModified,
                itemCount: cloudData.itemCount,
              }));
            } catch (err: any) {
              res.statusCode = 500;
              res.end(JSON.stringify({ success: false, error: err.message }));
            }
          });
          return;
        }

        res.statusCode = 405;
        res.end(JSON.stringify({ error: 'Method not allowed' }));
      });
    },
  };
}

export default defineConfig(() => {
  return {
    plugins: [react(), tailwindcss(), cloudSyncPlugin()],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    server: {
      port: 3000,
      host: '0.0.0.0',
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      // Do not modify - file watching is disabled to prevent flickering during agent edits.
      hmr: process.env.DISABLE_HMR !== 'true',
      // Disable file watching when DISABLE_HMR is true to save CPU during agent edits.
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
