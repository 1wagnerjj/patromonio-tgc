import JsBarcode from 'jsbarcode';
import QRCode from 'qrcode';
import { AssetItem, InspectionRecord } from '../types';
import { formatBRL, formatDateBR } from './formatters';

// In-memory cache to prevent re-rendering identical barcodes
const barcodeCache = new Map<string, string>();
const qrCache = new Map<string, string>();

/**
 * Builds a comprehensive, well-structured text representation of an asset
 * for embedding into QR Codes. When scanned by any smartphone camera or QR reader,
 * it displays all official asset and inspection details clearly.
 */
export function buildAssetQRCodeContent(asset: AssetItem, _inspection?: InspectionRecord): string {
  const lines: string[] = [
    `Nº PATRIMÔNIO: ${asset.patrimonio}`,
    `DESCRIÇÃO: ${asset.descricao}`,
  ];

  if (asset.complemento) {
    lines.push(`COMPLEMENTO: ${asset.complemento}`);
  }

  if (asset.unidade) {
    lines.push(`UNIDADE: ${asset.unidade}`);
  }

  if (asset.dtAquisicao) {
    lines.push(`DATA AQUISIÇÃO: ${formatDateBR(asset.dtAquisicao)}`);
  }

  if (asset.vlBase !== undefined && asset.vlBase !== null) {
    lines.push(`VALOR BASE: ${formatBRL(asset.vlBase)}`);
  }

  return lines.join('\n');
}

/**
 * Generates a high-contrast, crisp PNG Data URL for Code 128 barcode
 */
export function generateBarcodeDataUrl(
  text: string,
  width: number = 1.3,
  height: number = 32
): string {
  const cacheKey = `${text}-${width}-${height}`;
  if (barcodeCache.has(cacheKey)) {
    return barcodeCache.get(cacheKey)!;
  }

  try {
    const canvas = document.createElement('canvas');
    JsBarcode(canvas, text, {
      format: 'CODE128',
      width: width,
      height: height,
      displayValue: false,
      margin: 0,
      background: '#ffffff',
      lineColor: '#000000',
    });
    const dataUrl = canvas.toDataURL('image/png');
    barcodeCache.set(cacheKey, dataUrl);
    return dataUrl;
  } catch (err) {
    console.error('Error generating barcode for:', text, err);
    return '';
  }
}

/**
 * Generates a PNG Data URL for QR Code with comprehensive payload
 */
export async function generateQRCodeDataUrl(
  text: string,
  options?: { width?: number; margin?: number; errorCorrectionLevel?: 'L' | 'M' | 'Q' | 'H' }
): Promise<string> {
  const width = options?.width ?? 256;
  const margin = options?.margin ?? 0;
  const errorCorrectionLevel = options?.errorCorrectionLevel ?? 'M';
  const cacheKey = `${text}-${width}-${margin}-${errorCorrectionLevel}`;

  if (qrCache.has(cacheKey)) {
    return qrCache.get(cacheKey)!;
  }

  try {
    const dataUrl = await QRCode.toDataURL(text, {
      margin,
      width,
      errorCorrectionLevel,
      color: {
        dark: '#000000',
        light: '#ffffff',
      },
    });
    qrCache.set(cacheKey, dataUrl);
    return dataUrl;
  } catch (err) {
    console.error('Error generating QR code for:', text, err);
    return '';
  }
}
