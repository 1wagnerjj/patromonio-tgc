import { AssetItem, InspectionRecord, DepartmentManagerInfo } from '../types';

export interface CloudPayload {
  assets: AssetItem[];
  inspections?: Record<string, InspectionRecord>;
  disposalPhotos?: Record<string, string>;
  disposalBatchMeta?: Record<string, any>;
  departmentManagers?: Record<string, DepartmentManagerInfo>;
  selectedYear?: number;
  lastModified?: string;
  modifiedBy?: string;
}

export interface CloudSyncResult {
  success: boolean;
  data?: CloudPayload | null;
  source?: 'cloud' | 'initial' | 'cache';
  timestamp?: string;
  error?: string;
}

export interface CloudStatusInfo {
  success: boolean;
  hasData: boolean;
  timestamp: string;
  modifiedBy: string;
  assetsCount: number;
  baixadosCount: number;
  photosCount: number;
  inspectionsCount: number;
}

/**
 * Fast lightweight poll check for cloud state updates
 */
export async function checkCloudStatus(): Promise<CloudStatusInfo | null> {
  try {
    const response = await fetch('/api/cloud-status', {
      method: 'GET',
      headers: { Accept: 'application/json' },
      cache: 'no-store',
    });
    if (!response.ok) return null;
    return await response.json();
  } catch {
    return null;
  }
}

/**
 * Fetch the latest cloud state from the server database
 */
export async function fetchFromCloud(): Promise<CloudSyncResult> {
  try {
    const response = await fetch('/api/cloud-sync', {
      method: 'GET',
      headers: {
        'Accept': 'application/json',
      },
      cache: 'no-store',
    });

    if (!response.ok) {
      throw new Error(`HTTP error ${response.status}`);
    }

    const json = await response.json();
    return {
      success: true,
      data: json.data || null,
      source: json.source || 'cloud',
      timestamp: json.timestamp || new Date().toISOString(),
    };
  } catch (err: any) {
    console.warn('[CloudSync] Falha ao carregar dados da nuvem:', err.message);
    return {
      success: false,
      error: err.message,
    };
  }
}

/**
 * Push local state to the cloud database
 */
export async function pushToCloud(payload: CloudPayload): Promise<{
  success: boolean;
  timestamp?: string;
  assetsSaved?: number;
  baixadosSaved?: number;
  disposalPhotosSaved?: number;
  inspectionsSaved?: number;
  error?: string;
}> {
  try {
    const response = await fetch('/api/cloud-sync', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      },
      body: JSON.stringify(payload),
    });

    if (!response.ok) {
      throw new Error(`HTTP error ${response.status}`);
    }

    const json = await response.json();
    return {
      success: true,
      timestamp: json.timestamp || new Date().toISOString(),
      assetsSaved: json.assetsSaved,
      baixadosSaved: json.baixadosSaved,
      disposalPhotosSaved: json.disposalPhotosSaved,
      inspectionsSaved: json.inspectionsSaved,
    };
  } catch (err: any) {
    console.warn('[CloudSync] Falha ao sincronizar com a nuvem:', err.message);
    return {
      success: false,
      error: err.message,
    };
  }
}

/**
 * Clear cloud database completely
 */
export async function clearCloudDatabase(): Promise<{ success: boolean; error?: string }> {
  try {
    const res = await fetch('/api/cloud-clear', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const data = await res.json();
    return { success: !!data.success };
  } catch (err: any) {
    console.warn('[CloudSync] Falha ao limpar nuvem:', err.message);
    return { success: false, error: err.message };
  }
}

export async function checkCloudHealth(): Promise<{ ok: boolean; hasCloudData: boolean }> {
  try {
    const res = await fetch('/api/health', { cache: 'no-store' });
    if (!res.ok) return { ok: false, hasCloudData: false };
    const data = await res.json();
    return { ok: data.status === 'ok', hasCloudData: !!data.hasCloudData };
  } catch {
    return { ok: false, hasCloudData: false };
  }
}
