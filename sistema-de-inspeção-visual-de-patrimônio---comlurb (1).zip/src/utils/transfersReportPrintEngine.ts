import { AssetItem, InspectionRecord, DepartmentInfo, AuditSession, DepartmentManagerInfo } from '../types';
import { formatBRL, formatDateBR } from './formatters';

export interface TransfersReportPrintOptions {
  assets: AssetItem[];
  inspections: Record<string, InspectionRecord>;
  departments: DepartmentInfo[];
  selectedYear: number;
  selectedGerencia: string;
  auditSession: AuditSession;
  filterType: 'all' | 'transfers' | 'disposals';
  searchTerm?: string;
  departmentManagers?: Record<string, DepartmentManagerInfo>;
}

export interface MovementItem {
  asset: AssetItem;
  type: 'baixa' | 'transferencia';
  date: string;
  destinationOrReason: string;
  originDeptCode: string;
  originDeptName: string;
  costCenter: string;
  vlBase: number;
  observation: string;
  fiscal: string;
}

/**
 * Extracts and prepares all movements (baixas and transferencias) based on filters.
 */
export function extractMovements(
  assets: AssetItem[],
  inspections: Record<string, InspectionRecord>,
  selectedYear: number,
  selectedGerencia: string,
  filterType: 'all' | 'transfers' | 'disposals',
  searchTerm: string = ''
): MovementItem[] {
  const movements: MovementItem[] = [];
  const searchLower = searchTerm.toLowerCase().trim();

  assets.forEach((asset) => {
    // If filtered by origin department
    if (selectedGerencia !== 'ALL' && asset.gerenciaCode !== selectedGerencia) {
      return;
    }

    const inspKey = `${asset.id}-${selectedYear}`;
    const insp = inspections[inspKey];

    // Check if it is a Baixa
    const isBaixa = asset.situacao === 'baixado' || insp?.status === 'baixado';
    if (isBaixa && (filterType === 'all' || filterType === 'disposals')) {
      const date = asset.dtBaixa || (insp?.inspectedAt ? insp.inspectedAt.slice(0, 10) : 'Não informada');
      const reason = asset.motivoBaixa || insp?.observacao || 'Baixa do Acervo Patrimonial';
      
      const matchesSearch =
        !searchLower ||
        asset.patrimonio.toLowerCase().includes(searchLower) ||
        asset.descricao.toLowerCase().includes(searchLower) ||
        asset.complemento.toLowerCase().includes(searchLower) ||
        reason.toLowerCase().includes(searchLower) ||
        asset.gerenciaCode.toLowerCase().includes(searchLower);

      if (matchesSearch) {
        movements.push({
          asset,
          type: 'baixa',
          date,
          destinationOrReason: reason,
          originDeptCode: asset.gerenciaCode,
          originDeptName: asset.gerenciaName,
          costCenter: asset.centroCusto,
          vlBase: asset.vlBase || 0,
          observation: insp?.observacao || reason,
          fiscal: insp?.inspectedBy || 'Fiscal de Patrimônio',
        });
      }
    }

    // Check if it is a Transferência
    const isTransf = insp?.status === 'transferido' || Boolean(insp?.transferidoPara);
    if (isTransf && (filterType === 'all' || filterType === 'transfers')) {
      const date = insp?.dtTransf || (insp?.inspectedAt ? insp.inspectedAt.slice(0, 10) : 'Não informada');
      const dest = insp?.transferidoPara || 'Gerência Não Especificada';

      const matchesSearch =
        !searchLower ||
        asset.patrimonio.toLowerCase().includes(searchLower) ||
        asset.descricao.toLowerCase().includes(searchLower) ||
        asset.complemento.toLowerCase().includes(searchLower) ||
        dest.toLowerCase().includes(searchLower) ||
        (insp?.observacao && insp.observacao.toLowerCase().includes(searchLower)) ||
        asset.gerenciaCode.toLowerCase().includes(searchLower);

      if (matchesSearch) {
        movements.push({
          asset,
          type: 'transferencia',
          date,
          destinationOrReason: dest,
          originDeptCode: asset.gerenciaCode,
          originDeptName: asset.gerenciaName,
          costCenter: asset.centroCusto,
          vlBase: asset.vlBase || 0,
          observation: insp?.observacao || 'Transferência entre setores',
          fiscal: insp?.inspectedBy || 'Fiscal de Patrimônio',
        });
      }
    }
  });

  return movements;
}

function escapeHtml(str: string | undefined | null): string {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

/**
 * Builds standalone HTML for official printing of the Transfers & Disposals report.
 */
export function generateTransfersReportHtml(options: TransfersReportPrintOptions): string {
  const {
    assets,
    inspections,
    departments,
    selectedYear,
    selectedGerencia,
    auditSession,
    filterType,
    searchTerm,
    departmentManagers = {},
  } = options;

  const movements = extractMovements(
    assets,
    inspections,
    selectedYear,
    selectedGerencia,
    filterType,
    searchTerm
  );

  const totalCount = movements.length;
  const totalValue = movements.reduce((sum, m) => sum + m.vlBase, 0);

  const baixasCount = movements.filter((m) => m.type === 'baixa').length;
  const baixasValue = movements
    .filter((m) => m.type === 'baixa')
    .reduce((sum, m) => sum + m.vlBase, 0);

  const transfCount = movements.filter((m) => m.type === 'transferencia').length;
  const transfValue = movements
    .filter((m) => m.type === 'transferencia')
    .reduce((sum, m) => sum + m.vlBase, 0);

  const targetDept = departments.find((d) => d.code === selectedGerencia);
  const deptTitle =
    selectedGerencia === 'ALL'
      ? 'Todas as Unidades e Divisões Operacionais'
      : `${targetDept?.name || selectedGerencia} (CC: ${targetDept?.costCenter || 'N/A'})`;

  const rowsHtml =
    movements.length === 0
      ? `
      <tr>
        <td colspan="9" style="text-align: center; padding: 24px; color: #64748b; font-style: italic; border: 1px solid #000;">
          Nenhum registro de baixa ou transferência localizado para os filtros selecionados no exercício ${selectedYear}.
        </td>
      </tr>
    `
      : movements
          .map((m, idx) => {
            const isBaixa = m.type === 'baixa';
            const typeBadge = isBaixa
              ? `<span style="display:inline-block; padding: 2px 6px; background: #fee2e2; color: #991b1b; font-weight: bold; border-radius: 3px; border: 1px solid #fca5a5; font-size: 7pt;">⚠️ BAIXA</span>`
              : `<span style="display:inline-block; padding: 2px 6px; background: #ffedd5; color: #9a3412; font-weight: bold; border-radius: 3px; border: 1px solid #fdba74; font-size: 7pt;">⇄ TRANSFERÊNCIA</span>`;

            return `
            <tr style="background: ${idx % 2 === 0 ? '#ffffff' : '#f8fafc'};">
              <td style="border: 1px solid #000; padding: 4px 6px; text-align: center; font-family: monospace; font-weight: bold;">
                ${escapeHtml(m.asset.patrimonio)}
              </td>
              <td style="border: 1px solid #000; padding: 4px 6px; text-align: center;">
                ${typeBadge}
              </td>
              <td style="border: 1px solid #000; padding: 4px 6px; font-weight: 600;">
                ${escapeHtml(m.asset.descricao)}
                <div style="font-size: 7pt; color: #475569; font-weight: normal; font-family: monospace;">
                  ${escapeHtml(m.asset.complemento)}
                </div>
              </td>
              <td style="border: 1px solid #000; padding: 4px 6px; text-align: center; font-size: 7.5pt; font-weight: 600;">
                ${escapeHtml(m.originDeptCode)}
                <div style="font-size: 6.5pt; color: #64748b;">CC: ${escapeHtml(m.costCenter)}</div>
              </td>
              <td style="border: 1px solid #000; padding: 4px 6px; font-weight: bold; color: ${isBaixa ? '#991b1b' : '#1e3a8a'};">
                ${isBaixa ? 'Motivo/Processo: ' : 'Destino: '}
                <span style="font-weight: 600; color: #0f172a;">${escapeHtml(m.destinationOrReason)}</span>
              </td>
              <td style="border: 1px solid #000; padding: 4px 6px; text-align: center; white-space: nowrap; font-weight: bold; font-family: monospace;">
                ${formatDateBR(m.date)}
              </td>
              <td style="border: 1px solid #000; padding: 4px 6px; text-align: right; white-space: nowrap; font-family: monospace; font-weight: bold;">
                ${formatBRL(m.vlBase)}
              </td>
              <td style="border: 1px solid #000; padding: 4px 6px; font-size: 7pt; color: #334155;">
                ${escapeHtml(m.observation)}
              </td>
            </tr>
          `;
          })
          .join('');

  // Primary fiscal and manager for signature block
  const activeMgr = departmentManagers[selectedGerencia] || {
    gerenteNome: auditSession.gerenteResponsavel || 'Gerente da Divisão',
    gerenteMatricula: 'Matr. Titular',
    gerenteCargo: 'Gerente Responsável',
    fiscalNome: auditSession.fiscalResponsavel || 'Wagner J. Jardim',
    fiscalMatricula: auditSession.matriculaFiscal || 'Matr. 892.410-3',
  };

  return `<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8"/>
  <title>Relatório Geral de Baixas e Transferências - COMLURB (${selectedYear})</title>
  <style>
    @page {
      size: A4 landscape;
      margin: 8mm 8mm 8mm 8mm;
    }
    *, *:before, *:after {
      box-sizing: border-box;
      -webkit-print-color-adjust: exact !important;
      print-color-adjust: exact !important;
    }
    body {
      font-family: Arial, "Helvetica Neue", Helvetica, sans-serif;
      font-size: 8pt;
      line-height: 1.25;
      color: #000000;
      background: #ffffff;
      margin: 0;
      padding: 0;
    }
    .report-container {
      width: 100%;
      max-width: 100%;
      margin: 0 auto;
    }
    .header-box {
      border: 1.5px solid #000000;
      padding: 6px 10px;
      margin-bottom: 8px;
      background-color: #f8fafc;
    }
    .header-top {
      display: flex;
      justify-content: space-between;
      align-items: center;
      border-bottom: 1px solid #000000;
      padding-bottom: 4px;
      margin-bottom: 4px;
      font-size: 8.5pt;
      font-weight: bold;
    }
    .header-title {
      text-align: center;
      font-size: 11pt;
      font-weight: 900;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      padding: 4px 0;
    }
    .header-meta {
      display: flex;
      justify-content: space-between;
      font-size: 8pt;
      border-top: 1px solid #000000;
      padding-top: 4px;
    }
    .summary-cards {
      display: flex;
      gap: 8px;
      margin-bottom: 8px;
    }
    .card {
      flex: 1;
      border: 1px solid #000000;
      padding: 5px 8px;
      background: #ffffff;
    }
    .card-title {
      font-size: 6.5pt;
      text-transform: uppercase;
      font-weight: bold;
      color: #475569;
    }
    .card-val {
      font-size: 10pt;
      font-weight: bold;
      font-family: monospace;
      margin-top: 2px;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      border: 1.5px solid #000000;
      font-size: 7.5pt;
      margin-bottom: 10px;
    }
    th {
      border: 1px solid #000000;
      background-color: #e2e8f0 !important;
      color: #000000;
      font-weight: bold;
      text-align: left;
      padding: 5px 6px;
      font-size: 7.5pt;
    }
    tfoot td {
      border-top: 2px solid #000000;
      background-color: #f1f5f9 !important;
      font-weight: bold;
      padding: 5px 6px;
    }
    .term-box {
      border: 1.5px solid #000000;
      padding: 8px 10px;
      background-color: #ffffff;
      page-break-inside: avoid;
    }
    .term-title {
      font-weight: bold;
      font-size: 8.5pt;
      text-transform: uppercase;
      border-bottom: 1px solid #000000;
      padding-bottom: 3px;
      margin-bottom: 4px;
    }
    .signatures-grid {
      display: flex;
      justify-content: space-around;
      gap: 20px;
      margin-top: 14px;
      text-align: center;
    }
    .sig-col {
      flex: 1;
      max-width: 320px;
    }
    .sig-line {
      border-bottom: 1px solid #000000;
      margin-bottom: 4px;
      height: 1px;
    }
    .sig-name {
      font-weight: bold;
      font-size: 8pt;
    }
    .sig-matr {
      font-size: 7pt;
      color: #334155;
    }
    .sig-role {
      font-size: 6.5pt;
      color: #64748b;
      text-transform: uppercase;
      margin-top: 1px;
    }
    .print-button-bar {
      position: fixed;
      top: 10px;
      right: 10px;
      display: flex;
      gap: 8px;
      z-index: 9999;
      background: white;
      padding: 6px;
      border-radius: 8px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.15);
      border: 1px solid #cbd5e1;
    }
    .btn {
      background: #ea580c;
      color: white;
      border: none;
      padding: 6px 12px;
      border-radius: 6px;
      font-weight: bold;
      font-size: 11px;
      cursor: pointer;
    }
    .btn:hover {
      background: #c2410c;
    }
    @media print {
      .print-button-bar {
        display: none !important;
      }
    }
  </style>
</head>
<body>
  <div class="print-button-bar">
    <button class="btn" onclick="window.print()">🖨️ Imprimir Documento (A4 Paisagem)</button>
    <button class="btn" style="background:#0f172a;" onclick="window.close()">Fechar</button>
  </div>

  <div class="report-container">
    <!-- Header Box -->
    <div class="header-box">
      <div class="header-top">
        <span>COMLURB - Companhia Municipal de Limpeza Urbana</span>
        <span>Código do Documento: <strong>COML02.2.3.12 / MOV</strong></span>
      </div>
      
      <div class="header-title">
        Relatório Geral de Movimentação Patrimonial - Baixas e Transferências
      </div>

      <div class="header-meta">
        <div><strong>Unidade / Gerência:</strong> ${escapeHtml(deptTitle)}</div>
        <div><strong>Exercício Fiscal:</strong> ${selectedYear}</div>
        <div><strong>Data de Emissão:</strong> ${auditSession.dataEmissao || new Date().toLocaleDateString('pt-BR')}</div>
      </div>
    </div>

    <!-- Summary KPI Cards -->
    <div class="summary-cards">
      <div class="card">
        <div class="card-title">Total de Movimentações</div>
        <div class="card-val">${totalCount} bens</div>
      </div>
      <div class="card" style="border-left: 3px solid #ef4444;">
        <div class="card-title">Baixas / Desincorporações</div>
        <div class="card-val" style="color: #991b1b;">${baixasCount} bens (${formatBRL(baixasValue)})</div>
      </div>
      <div class="card" style="border-left: 3px solid #f97316;">
        <div class="card-title">Transferências Entre Unidades</div>
        <div class="card-val" style="color: #9a3412;">${transfCount} bens (${formatBRL(transfValue)})</div>
      </div>
      <div class="card">
        <div class="card-title">Valor Total Movimentado</div>
        <div class="card-val" style="color: #0f172a;">${formatBRL(totalValue)}</div>
      </div>
    </div>

    <!-- Movement Records Table -->
    <table>
      <thead>
        <tr>
          <th style="width: 75px; text-align: center;">Nº Patrimônio</th>
          <th style="width: 95px; text-align: center;">Tipo</th>
          <th>Descrição do Bem & Especificação</th>
          <th style="width: 95px; text-align: center;">Origem / CC</th>
          <th style="width: 220px;">Destino (Transferência) / Motivo (Baixa)</th>
          <th style="width: 85px; text-align: center;">Data Evento</th>
          <th style="width: 90px; text-align: right;">Valor Base</th>
          <th style="width: 140px;">Observações / Laudo</th>
        </tr>
      </thead>
      <tbody>
        ${rowsHtml}
      </tbody>
      <tfoot>
        <tr>
          <td colspan="3">
            Total Geral de Movimentações: <strong>${totalCount}</strong> registro(s)
            (Baixas: <strong>${baixasCount}</strong> | Transferências: <strong>${transfCount}</strong>)
          </td>
          <td colspan="3" style="text-align: right;">Subtotal Contábil Movimentado:</td>
          <td style="text-align: right; font-family: monospace;">${formatBRL(totalValue)}</td>
          <td>Exercício ${selectedYear}</td>
        </tr>
      </tfoot>
    </table>

    <!-- Official Term & Signature Block -->
    <div class="term-box">
      <div class="term-title">Termo de Ratificação de Movimentação e Regularização Patrimonial</div>
      <p style="margin: 0 0 6px 0; font-size: 7.5pt; line-height: 1.35; color: #1e293b;">
        Declaramos que as baixas e transferências de bens patrimoniais acima discriminadas foram devidamente conferidas e registradas no inventário físico anual de <strong>${selectedYear}</strong>, constando as respectivas datas de movimentação e gerências de destino para a atualização tempestiva dos registros contábeis e da carga patrimonial na COMLURB.
      </p>

      <div class="signatures-grid">
        <div class="sig-col">
          <div class="sig-line"></div>
          <div class="sig-name">${escapeHtml(activeMgr.fiscalNome || 'Wagner J. Jardim')}</div>
          <div class="sig-matr">${escapeHtml(activeMgr.fiscalMatricula || 'Matr. 892.410-3')}</div>
          <div class="sig-role">Fiscal de Patrimônio / Vistoriador</div>
        </div>

        <div class="sig-col">
          <div class="sig-line"></div>
          <div class="sig-name">${escapeHtml(activeMgr.gerenteNome || 'Gerente da Divisão')}</div>
          <div class="sig-matr">${escapeHtml(activeMgr.gerenteMatricula || 'Matr. Titular')}</div>
          <div class="sig-role">${escapeHtml(activeMgr.gerenteCargo || 'Gerente Responsável')} • COMLURB</div>
        </div>
      </div>
    </div>
  </div>
</body>
</html>`;
}

/**
 * Opens print preview window for the Transfers & Disposals report.
 */
export function openTransfersReportPrintWindow(options: TransfersReportPrintOptions): boolean {
  try {
    const html = generateTransfersReportHtml(options);
    const printWindow = window.open('', '_blank');

    if (!printWindow) {
      return false;
    }

    printWindow.document.open();
    printWindow.document.write(html);
    printWindow.document.close();

    printWindow.onload = () => {
      try {
        printWindow.focus();
        printWindow.print();
      } catch (e) {
        console.error('Auto print failed', e);
      }
    };

    return true;
  } catch (err) {
    console.error('Error opening transfers report print window:', err);
    return false;
  }
}

/**
 * Downloads the HTML file directly.
 */
export function downloadTransfersReportHtml(options: TransfersReportPrintOptions): void {
  const html = generateTransfersReportHtml(options);
  const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `Relatorio_Baixas_Transferencias_COMLURB_${options.selectedGerencia}_${options.selectedYear}.html`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

/**
 * Exports data to CSV with full UTF-8 formatting for Excel.
 */
export function exportMovementsToCsv(options: TransfersReportPrintOptions): void {
  const {
    assets,
    inspections,
    selectedYear,
    selectedGerencia,
    filterType,
    searchTerm,
  } = options;

  const movements = extractMovements(
    assets,
    inspections,
    selectedYear,
    selectedGerencia,
    filterType,
    searchTerm
  );

  const headers = [
    'Patrimonio',
    'Tipo_Movimentacao',
    'Descricao',
    'Complemento',
    'Gerencia_Origem',
    'Centro_Custo_Origem',
    'Gerencia_Destino_Ou_Motivo_Baixa',
    'Data_Evento',
    'Valor_Base_BRL',
    'Exercicio',
    'Observacoes',
    'Fiscal_Responsavel',
  ];

  const rows = movements.map((m) => [
    `"${m.asset.patrimonio}"`,
    `"${m.type === 'baixa' ? 'BAIXA' : 'TRANSFERÊNCIA'}"`,
    `"${(m.asset.descricao || '').replace(/"/g, '""')}"`,
    `"${(m.asset.complemento || '').replace(/"/g, '""')}"`,
    `"${m.originDeptCode}"`,
    `"${m.costCenter}"`,
    `"${(m.destinationOrReason || '').replace(/"/g, '""')}"`,
    `"${m.date}"`,
    `"${m.vlBase.toFixed(2).replace('.', ',')}"`,
    `"${selectedYear}"`,
    `"${(m.observation || '').replace(/"/g, '""')}"`,
    `"${(m.fiscal || '').replace(/"/g, '""')}"`,
  ]);

  const csvContent = '\uFEFF' + [headers.join(';'), ...rows.map((r) => r.join(';'))].join('\r\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `Baixas_Transferencias_COMLURB_${selectedGerencia}_${selectedYear}.csv`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
