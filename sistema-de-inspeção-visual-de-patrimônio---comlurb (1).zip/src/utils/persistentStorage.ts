/**
 * Robust IndexedDB & localStorage persistence for COMLURB Patrimônio.
 * Handles large datasets, high-resolution photo dossiers, and inspection records
 * without running into browser localStorage 5MB quota limitations.
 */

import { AssetItem, InspectionRecord, AuditSession, DepartmentManagerInfo } from '../types';

const DB_NAME = 'comlurb_patrimonio_v3';
const DB_VERSION = 1;
const STORE_NAME = 'keyval';

export interface FullAppState {
  assets: AssetItem[];
  inspections: Record<string, InspectionRecord>;
  disposalPhotos: Record<string, string>;
  disposalBatchMeta: Record<string, any>;
  departmentManagers?: Record<string, DepartmentManagerInfo>;
  selectedYear: number;
  lastSaved?: string;
  modifiedBy?: string;
}

let dbInstance: IDBDatabase | null = null;

/**
 * Initialize or get open IndexedDB database
 */
function getDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (dbInstance) {
      resolve(dbInstance);
      return;
    }

    if (typeof window === 'undefined' || !window.indexedDB) {
      reject(new Error('IndexedDB não suportado neste navegador'));
      return;
    }

    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = (event: IDBVersionChangeEvent) => {
      const db = (event.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME);
      }
    };

    request.onsuccess = () => {
      dbInstance = request.result;
      resolve(dbInstance);
    };

    request.onerror = () => {
      reject(request.error || new Error('Erro ao abrir IndexedDB'));
    };
  });
}

/**
 * Get a value from IndexedDB by key
 */
export async function idbGet<T = any>(key: string): Promise<T | null> {
  try {
    const db = await getDb();
    return new Promise((resolve) => {
      const tx = db.transaction(STORE_NAME, 'readonly');
      const store = tx.objectStore(STORE_NAME);
      const req = store.get(key);
      req.onsuccess = () => resolve(req.result ?? null);
      req.onerror = () => resolve(null);
    });
  } catch (err) {
    console.warn(`[IndexedDB] Falha ao ler chave "${key}":`, err);
    return null;
  }
}

/**
 * Set a value in IndexedDB by key
 */
export async function idbSet<T = any>(key: string, value: T): Promise<boolean> {
  try {
    const db = await getDb();
    return new Promise((resolve) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      const store = tx.objectStore(STORE_NAME);
      const req = store.put(value, key);
      req.onsuccess = () => resolve(true);
      req.onerror = () => resolve(false);
    });
  } catch (err) {
    console.warn(`[IndexedDB] Falha ao gravar chave "${key}":`, err);
    return false;
  }
}

/**
 * Save complete application state to IndexedDB and mirror safe subset to localStorage
 */
export async function saveLocalDatabase(state: FullAppState): Promise<{ success: boolean; timestamp: string }> {
  const timestamp = new Date().toISOString();
  const fullPayload = {
    ...state,
    lastSaved: timestamp,
  };

  // 1. Save all objects in IndexedDB (immune to 5MB quota)
  try {
    await idbSet('app_state', fullPayload);
    await idbSet('assets', fullPayload.assets);
    await idbSet('inspections', fullPayload.inspections);
    await idbSet('disposalPhotos', fullPayload.disposalPhotos);
    await idbSet('disposalBatchMeta', fullPayload.disposalBatchMeta);
    await idbSet('lastSaved', timestamp);
  } catch (err) {
    console.error('[IndexedDB] Erro ao salvar estado completo:', err);
  }

  // 2. Mirror to localStorage safely (catch quota exceptions gracefully)
  try {
    // Save lightweight assets (avoid base64 duplicates that blow quota)
    const lightweightAssets = fullPayload.assets.map((a) => {
      if (a.fotoUrl && a.fotoUrl.length > 500) {
        // Strip out huge inline base64 in localStorage copy to avoid QuotaExceededError;
        // IndexedDB already has the full high-res photo.
        return { ...a, fotoUrl: undefined };
      }
      return a;
    });

    localStorage.setItem('comlurb_assets_clean_v2', JSON.stringify(lightweightAssets));
    localStorage.setItem('comlurb_inspections_clean_v2', JSON.stringify(fullPayload.inspections));
    localStorage.setItem('comlurb_selected_year_clean_v2', fullPayload.selectedYear.toString());
    localStorage.setItem('comlurb_last_saved_time', timestamp);
  } catch (e) {
    console.warn('[LocalStorage] Quota atingida ao espelhar dados leves, mas IndexedDB gravou com sucesso:', e);
  }

  return { success: true, timestamp };
}

/**
 * Load complete application state: tries IndexedDB first, falls back to localStorage
 */
export async function loadLocalDatabase(): Promise<Partial<FullAppState> | null> {
  // 1. Try IndexedDB
  try {
    const idbState = await idbGet<FullAppState>('app_state');
    if (idbState && Array.isArray(idbState.assets) && idbState.assets.length > 0) {
      return idbState;
    }
  } catch (err) {
    console.warn('[IndexedDB] Falha ao carregar app_state:', err);
  }

  // 2. Fallback to localStorage
  try {
    const rawAssets = localStorage.getItem('comlurb_assets_clean_v2');
    const rawInspections = localStorage.getItem('comlurb_inspections_clean_v2');
    const rawPhotos = localStorage.getItem('comlurb_disposal_photos_v2');
    const rawMeta = localStorage.getItem('comlurb_disposal_batch_meta_v2');
    const rawYear = localStorage.getItem('comlurb_selected_year_clean_v2');

    if (rawAssets) {
      const parsedAssets = JSON.parse(rawAssets);
      if (Array.isArray(parsedAssets) && parsedAssets.length > 0) {
        return {
          assets: parsedAssets,
          inspections: rawInspections ? JSON.parse(rawInspections) : {},
          disposalPhotos: rawPhotos ? JSON.parse(rawPhotos) : {},
          disposalBatchMeta: rawMeta ? JSON.parse(rawMeta) : {},
          selectedYear: rawYear ? Number(rawYear) : 2025,
        };
      }
    }
  } catch (e) {
    console.error('[LocalStorage] Falha ao ler dados de fallback:', e);
  }

  return null;
}
