import { DisposalBatch, DisposalPhotoItem } from '../types';

/**
 * Resizes and compresses an image to max dimensions to keep localStorage fast
 * and prevent quota exceeded errors, while maintaining high print fidelity.
 */
export async function compressAndResizeImage(
  fileOrBlob: File | Blob,
  maxWidth = 800,
  maxHeight = 800,
  quality = 0.75
): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        let width = img.width;
        let height = img.height;

        if (width > maxWidth || height > maxHeight) {
          if (width > height) {
            height = Math.round((height * maxWidth) / width);
            width = maxWidth;
          } else {
            width = Math.round((width * maxHeight) / height);
            height = maxHeight;
          }
        }

        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(e.target?.result as string);
          return;
        }

        ctx.fillStyle = '#ffffff';
        ctx.fillRect(0, 0, width, height);
        ctx.drawImage(img, 0, 0, width, height);

        const dataUrl = canvas.toDataURL('image/jpeg', quality);
        resolve(dataUrl);
      };
      img.onerror = () => reject(new Error('Erro ao carregar imagem para compressão'));
      img.src = e.target?.result as string;
    };
    reader.onerror = () => reject(new Error('Erro ao ler arquivo de imagem'));
    reader.readAsDataURL(fileOrBlob);
  });
}

/**
 * Helper to generate vector SVG data URIs representing tools or assets for photo dossier
 */
export function createAssetSvgPlaceholder(
  name: string,
  pat: string,
  bg: string = '#f8fafc',
  iconType: string = 'general',
  gerenciaText: string = 'COMLURB • LAUDO DE BAIXA DE PATRIMÔNIO'
): string {
  let iconSvg = `<rect x="-50" y="-40" width="100" height="80" rx="8" fill="#475569" stroke="#1e293b" stroke-width="4"/><circle cx="0" cy="0" r="25" fill="#e2e8f0"/>`;

  if (iconType === 'drill') {
    iconSvg = `
      <path d="M-45 -20 L25 -20 L38 -10 L38 10 L-20 10 L-20 48 L-45 48 Z" fill="#334155" stroke="#0f172a" stroke-width="4"/>
      <rect x="38" y="-6" width="30" height="12" fill="#94a3b8" stroke="#0f172a" stroke-width="2"/>
      <line x1="68" y1="0" x2="98" y2="0" stroke="#ea580c" stroke-width="6" stroke-linecap="round"/>
      <rect x="-18" y="20" width="22" height="12" rx="3" fill="#ea580c"/>
    `;
  } else if (iconType === 'sander') {
    iconSvg = `
      <rect x="-55" y="-15" width="110" height="40" rx="6" fill="#334155" stroke="#0f172a" stroke-width="4"/>
      <rect x="-65" y="25" width="130" height="16" rx="3" fill="#0f172a"/>
      <path d="M-25 -15 C-25 -45 25 -45 25 -15 Z" fill="#64748b" stroke="#0f172a" stroke-width="3"/>
      <circle cx="20" cy="5" r="8" fill="#ea580c"/>
    `;
  } else if (iconType === 'ac') {
    iconSvg = `
      <rect x="-70" y="-38" width="140" height="76" rx="6" fill="#ffffff" stroke="#334155" stroke-width="4"/>
      <line x1="-55" y1="-18" x2="55" y2="-18" stroke="#94a3b8" stroke-width="3"/>
      <line x1="-55" y1="-2" x2="55" y2="-2" stroke="#94a3b8" stroke-width="3"/>
      <line x1="-55" y1="14" x2="55" y2="14" stroke="#94a3b8" stroke-width="3"/>
      <circle cx="45" cy="-25" r="4" fill="#22c55e"/>
    `;
  } else if (iconType === 'chair') {
    iconSvg = `
      <rect x="-30" y="-45" width="60" height="45" rx="6" fill="#475569" stroke="#0f172a" stroke-width="3"/>
      <rect x="-35" y="0" width="70" height="14" rx="3" fill="#1e293b"/>
      <line x1="-25" y1="14" x2="-30" y2="50" stroke="#0f172a" stroke-width="4"/>
      <line x1="25" y1="14" x2="30" y2="50" stroke="#0f172a" stroke-width="4"/>
      <line x1="0" y1="14" x2="0" y2="40" stroke="#0f172a" stroke-width="4"/>
    `;
  } else if (iconType === 'desk') {
    iconSvg = `
      <rect x="-65" y="-15" width="130" height="16" rx="3" fill="#334155" stroke="#0f172a" stroke-width="3"/>
      <line x1="-55" y1="1" x2="-55" y2="50" stroke="#0f172a" stroke-width="4"/>
      <line x1="55" y1="1" x2="55" y2="50" stroke="#0f172a" stroke-width="4"/>
      <rect x="15" y="1" width="35" height="38" fill="#e2e8f0" stroke="#0f172a" stroke-width="3"/>
      <line x1="20" y1="14" x2="45" y2="14" stroke="#475569" stroke-width="2"/>
      <line x1="20" y1="26" x2="45" y2="26" stroke="#475569" stroke-width="2"/>
    `;
  } else if (iconType === 'cabinet' || iconType === 'shelf') {
    iconSvg = `
      <rect x="-45" y="-50" width="90" height="100" rx="4" fill="#334155" stroke="#0f172a" stroke-width="4"/>
      <line x1="0" y1="-50" x2="0" y2="50" stroke="#0f172a" stroke-width="3"/>
      <circle cx="-12" cy="0" r="4" fill="#fbbf24"/>
      <circle cx="12" cy="0" r="4" fill="#fbbf24"/>
    `;
  } else if (iconType === 'water_cooler') {
    iconSvg = `
      <path d="M-22 -45 C-22 -55 22 -55 22 -45 L20 -15 L-20 -15 Z" fill="#38bdf8" stroke="#0284c7" stroke-width="3"/>
      <rect x="-26" y="-15" width="52" height="65" rx="5" fill="#f8fafc" stroke="#0f172a" stroke-width="4"/>
      <circle cx="-10" cy="5" r="3" fill="#ef4444"/>
      <circle cx="10" cy="5" r="3" fill="#3b82f6"/>
      <rect x="-18" y="20" width="36" height="20" rx="3" fill="#cbd5e1"/>
    `;
  } else if (iconType === 'motor' || iconType === 'pump') {
    iconSvg = `
      <rect x="-45" y="-35" width="70" height="70" rx="10" fill="#334155" stroke="#0f172a" stroke-width="4"/>
      <rect x="25" y="-15" width="25" height="30" rx="4" fill="#64748b" stroke="#0f172a" stroke-width="3"/>
      <circle cx="-10" cy="0" r="18" fill="#e2e8f0" stroke="#0f172a" stroke-width="3"/>
      <line x1="-45" y1="35" x2="-45" y2="48" stroke="#0f172a" stroke-width="5"/>
      <line x1="25" y1="35" x2="25" y2="48" stroke="#0f172a" stroke-width="5"/>
      <line x1="-55" y1="48" x2="35" y2="48" stroke="#0f172a" stroke-width="5"/>
    `;
  }

  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="600" height="480" viewBox="0 0 600 480">
    <rect width="600" height="480" fill="${bg}"/>
    <rect x="20" y="20" width="560" height="440" fill="#f8fafc" stroke="#cbd5e1" stroke-width="2" rx="8"/>
    <g transform="translate(300, 200)">
      <circle cx="0" cy="0" r="85" fill="#e2e8f0" stroke="#94a3b8" stroke-width="3"/>
      ${iconSvg}
    </g>
    <text x="300" y="340" font-family="Arial, sans-serif" font-size="20" font-weight="bold" fill="#0f172a" text-anchor="middle">${name.length > 34 ? name.substring(0, 32) + '...' : name}</text>
    <text x="300" y="375" font-family="Courier, monospace" font-size="18" font-weight="900" fill="#ea580c" text-anchor="middle">PAT: ${pat}</text>
    <text x="300" y="415" font-family="Arial, sans-serif" font-size="12" font-weight="bold" fill="#64748b" text-anchor="middle">${gerenciaText}</text>
  </svg>`;
  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
}

export function getIconTypeForAsset(descricao: string, categoria?: string): string {
  const d = (descricao || '').toUpperCase();
  if (d.includes('FURADEIRA') || d.includes('PARAFUSADEIRA') || d.includes('MARTELETE')) return 'drill';
  if (d.includes('LIXADEIRA') || d.includes('ESMERILHADEIRA')) return 'sander';
  if (d.includes('CONDICIONADOR') || d.includes('AR') || d.includes('COMPRESSOR')) return 'ac';
  if (d.includes('CADEIRA')) return 'chair';
  if (d.includes('MESA')) return 'desk';
  if (d.includes('ARMARIO')) return 'cabinet';
  if (d.includes('ESTANTE')) return 'shelf';
  if (d.includes('BEBEDOURO')) return 'water_cooler';
  if (d.includes('MOTOR') || d.includes('BOMBA') || d.includes('PRENSA')) return 'motor';
  return 'general';
}

/**
 * Returns the best photo for an asset: custom captured/uploaded photo > asset.fotoUrl > SVG illustration
 */
export function getAssetDisposalPhoto(
  asset: { id: string; patrimonio: string; descricao: string; gerenciaCode?: string; fotoUrl?: string; categoria?: string },
  customPhotos?: Record<string, string>
): string {
  if (customPhotos) {
    if (customPhotos[asset.id]) return customPhotos[asset.id];
    if (customPhotos[asset.patrimonio]) return customPhotos[asset.patrimonio];
  }
  if (asset.fotoUrl) return asset.fotoUrl;

  const iconType = getIconTypeForAsset(asset.descricao, asset.categoria);
  const gerenciaLabel = `COMLURB • LAUDO DE BAIXA • ${asset.gerenciaCode || 'GERÊNCIA'}`;
  return createAssetSvgPlaceholder(asset.descricao, asset.patrimonio, '#f1f5f9', iconType, gerenciaLabel);
}

function createToolSvgPlaceholder(name: string, pat: string, bg: string, iconType: string): string {
  return createAssetSvgPlaceholder(name, pat, bg, iconType, 'COMLURB • LAUDO DE BAIXA DE FERRAMENTAS');
}

/**
 * Default initial lot matching the exact 6 items from the user's document photo
 */
export const DEFAULT_DISPOSAL_BATCH: DisposalBatch = {
  id: 'lote-001-default',
  loteNumero: '001',
  processoNumero: '01/500.184/2024',
  tituloDocumento: 'Fotos das ferramentas selecionadas para baixa do Lote: 001',
  departamento: 'TDM - DIVISÃO DE MANUTENÇÃO',
  dataAssinatura: '01/11/2024 às 08:38:01',
  responsavelAssinatura: 'LUCIANO NELVO SILVA',
  matriculaResponsavel: 'Matr. 892.410-3',
  documentoNumero: '83deb14.63215849-7374',
  urlAutenticidade: 'https://processos.rio.rj.gov.br/autenticidade',
  items: [
    {
      id: 'item-1',
      patrimonio: '46.128',
      descricao: 'Lixadeira Orbital',
      motivoBaixa: 'Inservível / Desgaste de rotor',
      fotoUrl: createToolSvgPlaceholder('Lixadeira Orbital', '46.128', '#f1f5f9', 'sander'),
      dataFoto: '2024-11-01',
    },
    {
      id: 'item-2',
      patrimonio: '48954',
      descricao: 'Furadeira de Impacto',
      motivoBaixa: 'Mecanismo de impacto quebrado',
      fotoUrl: createToolSvgPlaceholder('Furadeira de Impacto', '48954', '#f8fafc', 'drill'),
      dataFoto: '2024-11-01',
    },
    {
      id: 'item-3',
      patrimonio: '46.118',
      descricao: 'Parafusadeira Bosch',
      motivoBaixa: 'Bateria esgotada / Mandril travado',
      fotoUrl: createToolSvgPlaceholder('Parafusadeira Bosch', '46.118', '#f1f5f9', 'drill'),
      dataFoto: '2024-11-01',
    },
    {
      id: 'item-4',
      patrimonio: '02.793',
      descricao: 'Lixadeira Manual Holder',
      motivoBaixa: 'Carcaça rompida',
      fotoUrl: createToolSvgPlaceholder('Lixadeira Manual Holder', '02.793', '#f8fafc', 'sander'),
      dataFoto: '2024-11-01',
    },
    {
      id: 'item-5',
      patrimonio: '40.468',
      descricao: 'Máquina de Furar Cinto',
      motivoBaixa: 'Inservível / Sem peças de reposição',
      fotoUrl: createToolSvgPlaceholder('Máquina de Furar Cinto', '40.468', '#f1f5f9', 'drill'),
      dataFoto: '2024-11-01',
    },
    {
      id: 'item-6',
      patrimonio: '14.362',
      descricao: 'Condicionador de Ar Springer',
      motivoBaixa: 'Compressor queimado / Sucata',
      fotoUrl: createToolSvgPlaceholder('Condicionador de Ar Springer', '14.362', '#f8fafc', 'ac'),
      dataFoto: '2024-11-01',
    },
  ],
};

/**
 * Generates standalone printable HTML matching the exact document page
 */
export function generateDisposalDossierHtml(batch: DisposalBatch): string {
  const itemsPerPage = 6;
  const pages: DisposalPhotoItem[][] = [];

  for (let i = 0; i < batch.items.length; i += itemsPerPage) {
    pages.push(batch.items.slice(i, i + itemsPerPage));
  }

  if (pages.length === 0) {
    pages.push([]);
  }

  const pagesHtml = pages
    .map((pageItems, pageIdx) => {
      const startIndex = pageIdx * itemsPerPage;

      const itemsGridHtml = pageItems
        .map((item, idx) => {
          const itemNumber = startIndex + idx + 1;
          return `
          <div class="photo-card">
            <div class="photo-frame">
              <img src="${item.fotoUrl}" alt="Item ${itemNumber} - ${item.descricao}" class="photo-img" />
            </div>
            <div class="photo-caption">
              <div class="item-desc">Item: ${itemNumber} - ${item.descricao}</div>
              <div class="item-patr">Pat: ${item.patrimonio}</div>
            </div>
          </div>
        `;
        })
        .join('');

      return `
      <div class="document-page ${pageIdx > 0 ? 'page-break' : ''}">
        <!-- Top Institutional Header -->
        <div class="official-header">
          <div class="logo-area">
            <div class="city-seal">
              <div class="seal-icon">
                <svg viewBox="0 0 24 24" width="28" height="28" fill="none" stroke="#0f172a" stroke-width="2">
                  <path d="M3 21h18M5 21V7l7-4 7 4v14M9 10h6M9 14h6M9 18h6"/>
                </svg>
              </div>
              <div class="seal-text">
                <span class="rio-title">Rio</span>
                <span class="pref-sub">PREFEITURA</span>
              </div>
            </div>
            <div class="comlurb-badge">
              <span>COMLURB</span>
            </div>
          </div>

          <div class="company-address-block">
            <div class="comp-title">Companhia Municipal de Limpeza Urbana - COMLURB</div>
            <div class="comp-address">Rua Major Ávila, 358 - Tijuca - CEP: 20511-010 Rio de Janeiro / RJ Brasil</div>
            <div class="comp-contact">Central de Atendimento: 1746 - www.rio.rj.gov.br/comlurb</div>
          </div>
        </div>

        <!-- Document Main Title -->
        <h1 class="document-title">
          ${batch.tituloDocumento || `Fotos das ferramentas selecionadas para baixa do Lote: ${batch.loteNumero}`}
        </h1>

        <!-- 2-Column Photo Grid (Up to 6 items per page) -->
        <div class="photos-grid">
          ${itemsGridHtml}
        </div>

        <!-- Official Signature & Verification Footer -->
        <div class="official-footer">
          <div class="footer-left">
            <div class="sig-line">
              Assinado digitalmente por <strong>${batch.responsavelAssinatura || 'LUCIANO NELVO SILVA'}</strong> - ${batch.dataAssinatura || '01/11/2024 às 08:38:01'}
            </div>
            <div class="doc-line">
              Documento Nº: <strong>${batch.documentoNumero || '83deb14.63215849-7374'}</strong> - consulte a autenticidade em
            </div>
            <div class="proc-line">
              Acesso processo no: <span>${batch.urlAutenticidade || 'https://processos.rio.rj.gov.br/autenticidade'}?n=${batch.documentoNumero || '83deb14.63215849-7374'}</span>
            </div>
          </div>

          <div class="footer-rubric">
            <div class="rubric-mark">+ R</div>
            <div class="rubric-label">Rubrica</div>
          </div>
        </div>
      </div>
    `;
    })
    .join('');

  return `<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <title>${batch.tituloDocumento || `Fotos para Baixa - Lote ${batch.loteNumero}`} - COMLURB</title>
  <style>
    @page {
      size: A4 portrait;
      margin: 10mm 14mm 10mm 14mm;
    }
    *, *:before, *:after {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif;
      background-color: #f1f5f9;
      color: #000000;
      line-height: 1.25;
      -webkit-print-color-adjust: exact;
      print-color-adjust: exact;
    }
    .screen-toolbar {
      position: sticky;
      top: 0;
      background: #0f172a;
      color: #ffffff;
      padding: 12px 24px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      z-index: 100;
      box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    }
    .screen-toolbar button {
      background: #ea580c;
      color: #ffffff;
      border: none;
      padding: 8px 18px;
      font-size: 14px;
      font-weight: bold;
      border-radius: 6px;
      cursor: pointer;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .screen-toolbar button:hover {
      background: #c2410c;
    }
    .document-page {
      width: 210mm;
      min-height: 297mm;
      margin: 20px auto;
      padding: 14mm 16mm 12mm 16mm;
      background: #ffffff;
      box-shadow: 0 4px 20px rgba(0,0,0,0.12);
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      position: relative;
    }
    .page-break {
      page-break-before: always;
      break-before: page;
    }

    /* Official Header */
    .official-header {
      display: flex;
      align-items: center;
      gap: 16px;
      padding-bottom: 12px;
      border-bottom: 1px solid #cbd5e1;
      margin-bottom: 16px;
    }
    .logo-area {
      display: flex;
      align-items: center;
      gap: 10px;
    }
    .city-seal {
      display: flex;
      align-items: center;
      gap: 6px;
    }
    .seal-text {
      display: flex;
      flex-direction: column;
      line-height: 1;
    }
    .rio-title {
      font-size: 20px;
      font-weight: 900;
      color: #0f172a;
      letter-spacing: -0.5px;
    }
    .pref-sub {
      font-size: 7.5px;
      font-weight: 800;
      color: #475569;
      letter-spacing: 1px;
    }
    .comlurb-badge {
      background: #0f172a;
      color: #ffffff;
      font-size: 11px;
      font-weight: 900;
      padding: 4px 8px;
      border-radius: 4px;
      letter-spacing: 0.5px;
    }
    .company-address-block {
      flex: 1;
      font-size: 8pt;
      color: #334155;
      line-height: 1.35;
      padding-left: 8px;
      border-left: 1px solid #e2e8f0;
    }
    .comp-title {
      font-weight: 700;
      color: #0f172a;
      font-size: 8.5pt;
    }

    /* Document Title */
    .document-title {
      text-align: center;
      font-size: 11pt;
      font-weight: 900;
      color: #000000;
      margin: 6px 0 16px 0;
      letter-spacing: -0.2px;
    }

    /* Photo Grid: 2 columns, 3 rows */
    .photos-grid {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      grid-template-rows: repeat(3, 1fr);
      gap: 16px 24px;
      flex: 1;
      margin-bottom: 14px;
    }
    .photo-card {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: flex-start;
      page-break-inside: avoid;
    }
    .photo-frame {
      width: 100%;
      height: 62mm;
      background: #f8fafc;
      border: 1px solid #94a3b8;
      border-radius: 3px;
      overflow: hidden;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .photo-img {
      width: 100%;
      height: 100%;
      object-fit: contain;
      background-color: #ffffff;
      display: block;
    }
    .photo-caption {
      margin-top: 6px;
      text-align: center;
      font-size: 9pt;
      line-height: 1.25;
      width: 100%;
    }
    .item-desc {
      font-weight: 700;
      color: #000000;
    }
    .item-patr {
      font-weight: 800;
      color: #000000;
      font-size: 9pt;
    }

    /* Official Footer */
    .official-footer {
      border-top: 1px solid #cbd5e1;
      padding-top: 10px;
      margin-top: auto;
      display: flex;
      justify-content: space-between;
      align-items: flex-end;
      font-size: 7.5pt;
      color: #334155;
      line-height: 1.35;
    }
    .footer-left {
      flex: 1;
      padding-right: 16px;
    }
    .footer-left strong {
      color: #000000;
    }
    .proc-line span {
      color: #0284c7;
      text-decoration: underline;
      word-break: break-all;
    }
    .footer-rubric {
      width: 32mm;
      text-align: center;
      border: 1px dashed #cbd5e1;
      border-radius: 4px;
      padding: 4px;
      background: #fafafa;
    }
    .rubric-mark {
      font-family: cursive, sans-serif;
      font-size: 14pt;
      color: #334155;
      line-height: 1;
      height: 18px;
    }
    .rubric-label {
      font-size: 6.5pt;
      text-transform: uppercase;
      color: #64748b;
      font-weight: bold;
    }

    @media print {
      body {
        background: #ffffff;
      }
      .screen-toolbar {
        display: none !important;
      }
      .document-page {
        margin: 0;
        padding: 0;
        box-shadow: none;
        width: 100%;
        min-height: 270mm;
      }
      .photo-frame {
        border-color: #000000;
      }
    }
  </style>
</head>
<body>
  <div class="screen-toolbar">
    <div>
      <strong>COMLURB • Dossiê Fotográfico de Baixa</strong> — ${batch.items.length} itens no ${batch.tituloDocumento || `Lote ${batch.loteNumero}`}
    </div>
    <button onclick="window.print()">
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 9V2h12v7M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><path d="M6 14h12v8H6z"/></svg>
      Imprimir / Salvar PDF
    </button>
  </div>

  ${pagesHtml}
</body>
</html>`;
}

/**
 * Opens print preview window for the disposal dossier
 */
export function openDisposalDossierPrintWindow(batch: DisposalBatch): void {
  const html = generateDisposalDossierHtml(batch);
  const printWindow = window.open('', '_blank');
  if (!printWindow) {
    alert('Por favor, permita pop-ups no navegador para abrir a página de impressão.');
    return;
  }
  printWindow.document.open();
  printWindow.document.write(html);
  printWindow.document.close();
}

/**
 * Downloads standalone HTML file for the disposal dossier
 */
export function downloadDisposalDossierHtml(batch: DisposalBatch): void {
  const html = generateDisposalDossierHtml(batch);
  const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `COMLURB_Fotos_Baixa_Lote_${batch.loteNumero || '001'}.html`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
