import { AssetItem, InspectionRecord } from '../types';

export function formatBRL(value: number): string {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
  }).format(value);
}

export function formatDateBR(dateStr?: string): string {
  if (!dateStr) return '-';
  // Handles YYYY-MM-DD or MM/DD/YYYY or D/M/YYYY
  if (dateStr.includes('-')) {
    const [year, month, day] = dateStr.split('-');
    if (year && month && day) {
      return `${day.padStart(2, '0')}/${month.padStart(2, '0')}/${year}`;
    }
  }
  return dateStr;
}

export function getStatusBadge(status: string) {
  switch (status) {
    case 'presente':
      return {
        label: 'Encontrado (Sim)',
        bg: 'bg-emerald-50 text-emerald-700 border-emerald-200',
        dot: 'bg-emerald-500',
        icon: 'check',
      };
    case 'ausente':
      return {
        label: 'Não Encontrado (Não)',
        bg: 'bg-rose-50 text-rose-700 border-rose-200',
        dot: 'bg-rose-500',
        icon: 'alert-triangle',
      };
    case 'transferido':
      return {
        label: 'Transferido',
        bg: 'bg-amber-50 text-amber-700 border-amber-200',
        dot: 'bg-amber-500',
        icon: 'arrow-right-left',
      };
    case 'baixado':
      return {
        label: 'Baixado / Inservível',
        bg: 'bg-slate-100 text-slate-700 border-slate-300',
        dot: 'bg-slate-500',
        icon: 'archive',
      };
    case 'pendente':
    default:
      return {
        label: 'Pendente de Vistoria',
        bg: 'bg-blue-50 text-blue-700 border-blue-200',
        dot: 'bg-blue-400',
        icon: 'clock',
      };
  }
}

export function getConditionBadge(condition: string) {
  switch (condition) {
    case 'excelente':
      return { label: 'Excelente', color: 'bg-emerald-100 text-emerald-800' };
    case 'bom':
      return { label: 'Bom', color: 'bg-teal-100 text-teal-800' };
    case 'regular':
      return { label: 'Regular', color: 'bg-yellow-100 text-yellow-800' };
    case 'ruim':
      return { label: 'Ruim', color: 'bg-orange-100 text-orange-800' };
    case 'inservivel':
      return { label: 'Inservível / Sucata', color: 'bg-red-100 text-red-800' };
    default:
      return { label: 'Não Avaliado', color: 'bg-gray-100 text-gray-600' };
  }
}

export function getSituacaoBadge(situacao?: string, dtBaixa?: string) {
  const isBaixado = situacao === 'baixado';
  if (isBaixado) {
    return {
      status: 'baixado',
      label: dtBaixa ? `Baixado (${formatDateBR(dtBaixa)})` : 'Baixado (Baixa)',
      shortLabel: 'Baixado',
      bg: 'bg-rose-50 text-rose-700 border-rose-200',
      dot: 'bg-rose-500',
      tagColor: 'bg-rose-100 text-rose-800 border-rose-200',
    };
  }
  return {
    status: 'ativo',
    label: 'Ativo',
    shortLabel: 'Ativo',
    bg: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    dot: 'bg-emerald-500',
    tagColor: 'bg-emerald-100 text-emerald-800 border-emerald-200',
  };
}

export function exportAssetsToCSV(
  assets: AssetItem[],
  inspections: Record<string, InspectionRecord>,
  year: number,
  titlePrefix: string = 'Relatorio_Inspecao_COMLURB'
) {
  const headers = [
    'Patrimônio',
    'Descrição',
    'Complemento',
    'Situação Patrimonial',
    'Data da Baixa',
    'Motivo da Baixa',
    'Dt. Aquisição',
    'Valor Base (R$)',
    'Unidade',
    'Gerência',
    'Localidade',
    'Centro de Custo',
    'Ano Inspeção',
    'Encontra-se no Local?',
    'Estado de Conservação',
    'Estado da Plaqueta',
    'Transferido Para',
    'Dt. Transferência',
    'Local Específico / Sala',
    'Observações da Vistoria',
    'Data da Vistoria',
    'Fiscal / Vistoriador',
  ];

  const rows = assets.map((asset) => {
    const insp: InspectionRecord = inspections[`${asset.id}-${year}`] || {
      assetId: asset.id,
      year,
      status: 'pendente',
      condition: 'nao_avaliado',
      tagCondition: 'legivel',
      observacao: '',
      transferidoPara: '',
      dtTransf: '',
      localizacaoEspecifica: '',
      inspectedAt: '',
      inspectedBy: '',
    };

    let statusText = 'Pendente';
    if (insp.status === 'presente') statusText = 'Sim (Presente)';
    else if (insp.status === 'ausente') statusText = 'Não (Ausente/Divergente)';
    else if (insp.status === 'transferido') statusText = 'Transferido';
    else if (insp.status === 'baixado') statusText = 'Baixado';

    const sitText = asset.situacao === 'baixado' ? 'Baixado' : 'Ativo';
    const dtBaixaText = asset.dtBaixa ? formatDateBR(asset.dtBaixa) : '';
    const motivoBaixaText = asset.motivoBaixa || '';

    return [
      `"${asset.patrimonio}"`,
      `"${asset.descricao.replace(/"/g, '""')}"`,
      `"${(asset.complemento || '').replace(/"/g, '""')}"`,
      `"${sitText}"`,
      `"${dtBaixaText}"`,
      `"${motivoBaixaText.replace(/"/g, '""')}"`,
      `"${formatDateBR(asset.dtAquisicao)}"`,
      `"${asset.vlBase.toFixed(2).replace('.', ',')}"`,
      `"${asset.unidade}"`,
      `"${asset.gerenciaName.replace(/"/g, '""')}"`,
      `"${asset.localidade}"`,
      `"${asset.centroCusto}"`,
      `"${year}"`,
      `"${statusText}"`,
      `"${insp.condition || 'Não Avaliado'}"`,
      `"${insp.tagCondition || 'Normal'}"`,
      `"${(insp.transferidoPara || '').replace(/"/g, '""')}"`,
      `"${formatDateBR(insp.dtTransf) || ''}"`,
      `"${(insp.localizacaoEspecifica || '').replace(/"/g, '""')}"`,
      `"${(insp.observacao || '').replace(/"/g, '""')}"`,
      `"${insp.inspectedAt ? formatDateBR(insp.inspectedAt.split('T')[0]) : ''}"`,
      `"${(insp.inspectedBy || '').replace(/"/g, '""')}"`,
    ];
  });

  const csvContent =
    '\uFEFF' + // UTF-8 BOM for Excel in Portuguese
    [headers.join(';'), ...rows.map((e) => e.join(';'))].join('\r\n');

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `${titlePrefix}_${year}_${new Date().toISOString().slice(0, 10)}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}
