import { ArchivedLabelBatch } from '../types';

const STORAGE_KEY = 'comlurb_archived_label_batches';

export function getArchivedLabelBatches(): ArchivedLabelBatch[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch (err) {
    console.error('Error loading archived batches from storage:', err);
    return [];
  }
}

export function saveArchivedLabelBatch(batch: ArchivedLabelBatch): void {
  try {
    const current = getArchivedLabelBatches();
    const updated = [batch, ...current.filter((b) => b.id !== batch.id)];
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  } catch (err) {
    console.error('Error saving archived batch:', err);
  }
}

export function deleteArchivedLabelBatch(batchId: string): void {
  try {
    const current = getArchivedLabelBatches();
    const updated = current.filter((b) => b.id !== batchId);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  } catch (err) {
    console.error('Error deleting archived batch:', err);
  }
}

export function exportArchivedBatchesToJson(): void {
  const batches = getArchivedLabelBatches();
  const blob = new Blob([JSON.stringify(batches, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `Arquivo_Lotes_Etiquetas_COMLURB_${new Date().toISOString().slice(0, 10)}.json`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

export function importArchivedBatchesFromJson(jsonStr: string): number {
  try {
    const parsed = JSON.parse(jsonStr);
    if (!Array.isArray(parsed)) return 0;
    const current = getArchivedLabelBatches();
    const mergedMap = new Map<string, ArchivedLabelBatch>();
    current.forEach((b) => mergedMap.set(b.id, b));
    parsed.forEach((b) => {
      if (b.id && b.name) mergedMap.set(b.id, b);
    });
    const updated = Array.from(mergedMap.values()).sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
    return parsed.length;
  } catch (err) {
    console.error('Error importing batches:', err);
    return 0;
  }
}
