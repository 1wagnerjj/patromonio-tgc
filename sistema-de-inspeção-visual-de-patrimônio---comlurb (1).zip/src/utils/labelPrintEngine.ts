import { AssetItem, InspectionRecord } from '../types';
import { generateBarcodeDataUrl, generateQRCodeDataUrl, buildAssetQRCodeContent } from './barcodeGenerator';

export interface LabelPrintOptions {
  assets: (AssetItem | null)[];
  paperFormat: 'letter' | 'a4';
  rowHeightMm: number; // Passo vertical / altura de cada linha (padrão Pimaco: 25.40mm)
  colWidthMm: number;  // Largura de cada etiqueta (padrão Pimaco: 101.60mm)
  colGapMm: number;    // Espaço horizontal entre as duas colunas (padrão: 5.20mm)
  offsetTopMm: number; // Margem superior inicial (padrão: 12.70mm + offset)
  offsetLeftMm: number;// Margem esquerda inicial (padrão: 4.00mm + offset)
  layoutStyle: 'standard_pimaco' | 'full_barcode' | 'only_barcode' | 'big_numbers';
  showHeader: boolean;
  showSubHeader?: boolean;
  showFooter?: boolean;
  showLoc?: boolean;
  showPatrTag?: boolean;
  showUnit: boolean;
  showCostCenter: boolean;
  showWarningFooter: boolean;
  showBorderGuide: boolean;
  customHeader: string;
  customSubHeader?: string;
  customFooter: string;
  customLoc?: string;
  barcodeType: 'barcode' | 'qrcode' | 'both' | 'none';
  patrimonioFontSizePt?: number; // Tamanho configurável da fonte do número (até 85pt)
  numberAlignment?: 'center' | 'left';
  selectedYear: number;
  isCalibrationSheet?: boolean;
  inspections?: Record<string, InspectionRecord>;
  batchTitle?: string;
  archivedBatchId?: string;
  archivedAt?: string;
}

/**
 * Builds a standalone, fully self-contained HTML document tailored specifically
 * for Pimaco 6181 / 6281 (20 labels per sheet, Letter or A4) with zero vertical drift.
 */
export async function generatePimacoHtmlDocument(options: LabelPrintOptions): Promise<string> {
  const {
    assets,
    paperFormat = 'letter',
    rowHeightMm = 25.4,
    colWidthMm = 101.6,
    colGapMm = 5.2,
    offsetTopMm = 0,
    offsetLeftMm = 0,
    layoutStyle = 'standard_pimaco',
    showHeader = true,
    showSubHeader = true,
    showFooter = true,
    showLoc = true,
    showPatrTag = true,
    showUnit = true,
    showCostCenter = true,
    showWarningFooter = false,
    showBorderGuide = false,
    customHeader = 'PREFEITURA DO RIO • COMLURB',
    customSubHeader = 'COMLURB',
    customFooter = 'PATRIMÔNIO PÚBLICO • NÃO REMOVER',
    customLoc = 'LOC PREENCHER',
    barcodeType = 'qrcode',
    patrimonioFontSizePt,
    numberAlignment = 'center',
    selectedYear = 2026,
    isCalibrationSheet = false,
    inspections,
  } = options;

  const topMargin = Math.max(0, 12.7 + offsetTopMm);
  const leftMargin = Math.max(0, (paperFormat === 'letter' ? 3.75 : 1.6) + offsetLeftMm);

  const sheetWidthMm = paperFormat === 'letter' ? 215.9 : 210.0;
  const sheetHeightMm = paperFormat === 'letter' ? 279.4 : 297.0;

  // Group into pages of 20 labels (2 cols x 10 rows)
  const LABELS_PER_PAGE = 20;
  const pages: (AssetItem | null)[][] = [];
  for (let i = 0; i < assets.length; i += LABELS_PER_PAGE) {
    pages.push(assets.slice(i, i + LABELS_PER_PAGE));
  }
  if (pages.length === 0) {
    pages.push([]);
  }

  // Pre-generate optical elements
  const renderedPagesHtml: string[] = [];

  for (let pIdx = 0; pIdx < pages.length; pIdx++) {
    const pageSlots = pages[pIdx];
    let pageCellsHtml = '';

    for (let slotIdx = 0; slotIdx < 20; slotIdx++) {
      const asset = slotIdx < pageSlots.length ? pageSlots[slotIdx] : null;
      const overallIndex = pIdx * 20 + slotIdx + 1;
      const rowNumber = Math.floor(slotIdx / 2) + 1;
      const colNumber = (slotIdx % 2) + 1;

      if (isCalibrationSheet) {
        // Calibration test crosshair mode
        pageCellsHtml += `
          <div class="pimaco-label-cell test-grid-cell">
            <div class="test-cell-inner">
              <div class="test-crosshair-tl">+</div>
              <div class="test-crosshair-tr">+</div>
              <div class="test-crosshair-bl">+</div>
              <div class="test-crosshair-br">+</div>
              <div class="test-cell-info">
                <span class="test-pos">Etiqueta #${slotIdx + 1} (Linha ${rowNumber}, Col ${colNumber})</span>
                <span class="test-dim">${colWidthMm} mm × ${rowHeightMm} mm</span>
                <span class="test-drift-indicator">Y: ${(topMargin + (rowNumber - 1) * rowHeightMm).toFixed(1)} mm</span>
              </div>
            </div>
          </div>
        `;
        continue;
      }

      if (!asset) {
        // Blank slot (skipped position)
        pageCellsHtml += `
          <div class="pimaco-label-cell empty-slot">
            <div class="empty-placeholder">
              <span class="no-print-screen-only">[ Etiqueta #${slotIdx + 1} ]</span>
            </div>
          </div>
        `;
        continue;
      }

      // Generate Barcode / QR Code
      let opticalHtml = '';
      const isBlank = asset.isBlank || asset.id.startsWith('blank_');
      const blankStyle = asset.blankStyle || 'write_lines';
      const effectiveFontSize = asset.customFontSize || patrimonioFontSizePt || (layoutStyle === 'big_numbers' || blankStyle === 'big_numbers' ? 56 : 13);
      const assetInspection = inspections?.[`${asset.id}-${selectedYear}`];
      const isQrHidden = barcodeType === 'none' || asset.hideQr === true;

      if (!isQrHidden) {
        if (isBlank && blankStyle === 'pure_blank') {
          // Pure blank has no barcode or QR
          opticalHtml = `
            <div class="blank-qr-box">
              <span class="blank-qr-text">QR / SELO</span>
            </div>
          `;
        } else {
          const qrPayload = buildAssetQRCodeContent(asset, assetInspection);
          if (layoutStyle === 'standard_pimaco' || layoutStyle === 'big_numbers' || barcodeType === 'qrcode') {
            const qrSrc = await generateQRCodeDataUrl(qrPayload, { width: 256, errorCorrectionLevel: 'M' });
            opticalHtml = `<img src="${qrSrc}" class="qr-image-pimaco" alt="QR ${asset.patrimonio || 'PROVISORIO'}" title="QR Code de identificação patrimonial" />`;
          } else if (barcodeType === 'barcode') {
            const barcodeValue = asset.patrimonio || 'COMLURB';
            const barcodeSrc = generateBarcodeDataUrl(barcodeValue, 1.2, 24);
            opticalHtml = `<img src="${barcodeSrc}" class="barcode-image-pimaco" alt="BarCode ${barcodeValue}" />`;
          } else if (barcodeType === 'both') {
            const barcodeValue = asset.patrimonio || 'COMLURB';
            const barcodeSrc = generateBarcodeDataUrl(barcodeValue, 1.1, 20);
            const qrSrc = await generateQRCodeDataUrl(qrPayload, { width: 256, errorCorrectionLevel: 'M' });
            opticalHtml = `
              <div class="both-opticals">
                <img src="${barcodeSrc}" class="barcode-image-mini" alt="BarCode" />
                <img src="${qrSrc}" class="qr-image-mini" alt="QR" title="QR Code de identificação patrimonial" />
              </div>
            `;
          }
        }
      }

      // Extract visibility flags per asset
      const isHeaderHidden = !showHeader || asset.hideHeader === true;
      const isSubHeaderHidden = showSubHeader === false || asset.hideSubHeader === true;
      const isFooterHidden = showFooter === false || asset.hideFooter === true;
      const isLocHidden = showLoc === false || asset.hideLoc === true;
      const isPatrTagHidden = showPatrTag === false || asset.hidePatrTag === true;
      const isAllTextHidden = isHeaderHidden && isSubHeaderHidden && isFooterHidden && isLocHidden;

      const topHeaderLeft = isHeaderHidden ? '' : (asset.customHeader !== undefined ? asset.customHeader : customHeader);
      const topHeaderRight = isSubHeaderHidden ? '' : (asset.customSubHeader !== undefined ? asset.customSubHeader : (asset.unidade || customSubHeader));
      const bottomDesc = isFooterHidden ? '' : (asset.customFooter !== undefined ? asset.customFooter : (asset.descricao || customFooter));
      const bottomLoc = isLocHidden ? '' : (asset.customLoc !== undefined ? asset.customLoc : (asset.localidade ? (asset.localidade.startsWith('LOC') ? asset.localidade : `LOC ${asset.localidade}`) : customLoc));

      const hasTopBar = !!(topHeaderLeft || topHeaderRight);
      const hasBottomBar = !!(bottomDesc || bottomLoc);

      // 1. Layout: Big Numbers OR Large Font (>= 22pt) OR Pure Clean Number
      if (layoutStyle === 'big_numbers' || blankStyle === 'big_numbers' || effectiveFontSize >= 22 || isAllTextHidden) {
        pageCellsHtml += `
          <div class="pimaco-label-cell">
            <div class="label-big-numbers-box ${showBorderGuide ? 'has-border' : ''} ${isQrHidden ? 'no-qr' : ''} ${!hasTopBar && !hasBottomBar ? 'pure-clean-number' : ''}">
              ${
                hasTopBar
                  ? `
                <div class="big-num-topbar">
                  <span class="big-num-org">${escapeHtml(topHeaderLeft)}</span>
                  <span class="big-num-dept">${escapeHtml(topHeaderRight)}</span>
                </div>
              `
                  : ''
              }

              <div class="big-num-center-row ${isQrHidden ? 'full-width-number' : ''}">
                <div class="big-num-value ${isQrHidden ? 'full-width' : ''}" style="font-size: ${effectiveFontSize}pt;">
                  ${!isPatrTagHidden ? `<span class="lbl-patr-prefix" style="font-size: ${Math.max(7, Math.min(16, Math.round(effectiveFontSize * 0.28)))}pt; margin-right: 1.5mm;">PATR:</span>` : ''}
                  ${
                    asset.patrimonio && !asset.patrimonio.startsWith('___')
                      ? escapeHtml(asset.patrimonio)
                      : isBlank && blankStyle === 'pure_blank'
                      ? ''
                      : `<span class="blank-patr-line" style="min-width: ${isQrHidden ? '65mm' : '45mm'}; height: 5mm;"></span>`
                  }
                </div>
                ${
                  !isQrHidden && (!isBlank || blankStyle !== 'pure_blank') && opticalHtml
                    ? `<div class="big-num-qr-wrapper">${opticalHtml}</div>`
                    : ''
                }
              </div>

              ${
                hasBottomBar
                  ? `
                <div class="big-num-bottombar">
                  <span class="big-num-desc">${escapeHtml(bottomDesc)}</span>
                  <span class="big-num-tag">${escapeHtml(bottomLoc)}</span>
                </div>
              `
                  : ''
              }
            </div>
          </div>
        `;
      } else if (layoutStyle === 'standard_pimaco') {
        // Layout Pimaco 6181
        const hasDescOrUnit = !isAllTextHidden && (!!bottomDesc || (showUnit && !isSubHeaderHidden && !!asset.unidade) || !!asset.complemento);

        if (!hasDescOrUnit) {
          // Pure clean number mode in standard pimaco
          pageCellsHtml += `
            <div class="pimaco-label-cell">
              <div class="label-pimaco-box pure-clean-number ${showBorderGuide ? 'has-border' : ''} ${isQrHidden ? 'no-qr' : ''}">
                <div class="col-patr full-width">
                  ${!isPatrTagHidden ? `<span class="lbl-patr-tag">PATR:</span>` : ''}
                  ${
                    asset.patrimonio && !asset.patrimonio.startsWith('___')
                      ? `<span class="val-patr-num ${isQrHidden ? 'full-width' : ''}" style="font-size: ${effectiveFontSize}pt;">${escapeHtml(asset.patrimonio)}</span>`
                      : `<span class="blank-patr-line" style="min-width: ${isQrHidden ? '65mm' : '45mm'};"></span>`
                  }
                </div>
                ${
                  !isQrHidden && opticalHtml
                    ? `<div class="col-optical">${opticalHtml}</div>`
                    : ''
                }
              </div>
            </div>
          `;
        } else if (isBlank) {
          pageCellsHtml += `
            <div class="pimaco-label-cell">
              <div class="label-pimaco-box ${effectiveFontSize >= 24 ? 'large-font' : ''} ${showBorderGuide ? 'has-border' : ''} ${isQrHidden ? 'no-qr' : ''}">
                <div class="col-patr">
                  ${!isPatrTagHidden ? `<span class="lbl-patr-tag">PATR:</span>` : ''}
                  ${
                    asset.patrimonio && !asset.patrimonio.startsWith('___')
                      ? `<span class="val-patr-num" style="font-size: ${effectiveFontSize}pt;">${escapeHtml(asset.patrimonio)}</span>`
                      : `<span class="blank-patr-line"></span>`
                  }
                </div>

                <div class="col-info">
                  ${
                    blankStyle === 'write_lines'
                      ? `
                    <div class="blank-line-field">
                      <span class="blank-lbl">DESC:</span> <span class="blank-fill-line"></span>
                    </div>
                    <div class="blank-line-field">
                      <span class="blank-lbl">MOD/SÉRIE:</span> <span class="blank-fill-line"></span>
                    </div>
                    <div class="blank-line-field">
                      <span class="blank-lbl">LOC:</span> <span class="blank-fill-line-sm"></span>
                      <span class="blank-lbl" style="margin-left: 2mm;">DATA:</span> <span class="blank-fill-line-xs">___/___</span>
                    </div>
                  `
                      : blankStyle === 'pure_blank'
                      ? `
                    <div class="blank-pure-space">
                      <div class="blank-pure-hint">ÁREA LIVRE PARA PREENCHIMENTO / CARIMBO</div>
                      ${asset.unidade && !isSubHeaderHidden ? `<div class="val-loc-unit" style="margin-top: 1mm;">${escapeHtml(asset.unidade)}</div>` : ''}
                    </div>
                  `
                      : `
                    ${!isFooterHidden && bottomDesc ? `<div class="val-desc-bold">${escapeHtml(bottomDesc)}</div>` : ''}
                    <div class="val-comp-mono">${escapeHtml(asset.complemento || 'VISTORIA PATRIMONIAL')}</div>
                    ${
                      showUnit && !isSubHeaderHidden && asset.unidade
                        ? `<div class="val-loc-unit">${escapeHtml(asset.unidade)} ${!isLocHidden && bottomLoc ? `(${escapeHtml(bottomLoc)})` : ''}</div>`
                        : !isLocHidden && bottomLoc
                        ? `<div class="val-loc-unit">${escapeHtml(bottomLoc)}</div>`
                        : ''
                    }
                  `
                  }
                </div>

                ${
                  !isQrHidden && opticalHtml
                    ? `<div class="col-optical">${opticalHtml}</div>`
                    : ''
                }
              </div>
            </div>
          `;
        } else {
          pageCellsHtml += `
            <div class="pimaco-label-cell">
              <div class="label-pimaco-box ${effectiveFontSize >= 24 ? 'large-font' : ''} ${showBorderGuide ? 'has-border' : ''} ${isQrHidden ? 'no-qr' : ''}">
                <div class="col-patr">
                  ${!isPatrTagHidden ? `<span class="lbl-patr-tag">PATR:</span>` : ''}
                  <span class="val-patr-num" style="font-size: ${effectiveFontSize}pt;">${escapeHtml(asset.patrimonio)}</span>
                </div>

                <div class="col-info">
                  ${!isFooterHidden && bottomDesc ? `<div class="val-desc-bold">${escapeHtml(bottomDesc)}</div>` : ''}
                  <div class="val-comp-mono">${escapeHtml(asset.complemento || '—')}</div>
                  ${
                    showUnit && !isSubHeaderHidden && asset.unidade
                      ? `
                    <div class="val-loc-unit">
                      ${escapeHtml(asset.unidade)} ${!isLocHidden && bottomLoc ? `(${escapeHtml(bottomLoc)})` : ''}
                      ${showCostCenter && asset.centroCusto ? ` • CC ${escapeHtml(asset.centroCusto)}` : ''}
                    </div>
                  `
                      : !isLocHidden && bottomLoc
                      ? `<div class="val-loc-unit">${escapeHtml(bottomLoc)}</div>`
                      : ''
                  }
                </div>

                ${
                  !isQrHidden && opticalHtml
                    ? `<div class="col-optical">${opticalHtml}</div>`
                    : ''
                }
              </div>
            </div>
          `;
        }
      } else {
        // Alternative layout with full header / footer
        if (isBlank) {
          pageCellsHtml += `
            <div class="pimaco-label-cell">
              <div class="label-full-box ${showBorderGuide ? 'has-border' : ''} ${isQrHidden ? 'no-qr' : ''}">
                ${
                  !isHeaderHidden && topHeaderLeft
                    ? `
                  <div class="full-header">
                    <span class="full-title">${escapeHtml(topHeaderLeft)}</span>
                    <span class="full-tag">${escapeHtml(topHeaderRight || 'ETIQUETA AVULSA')}</span>
                  </div>
                `
                    : ''
                }

                <div class="full-body">
                  <div class="full-info">
                    <div class="full-patr-line">
                      ${!isPatrTagHidden ? `<span class="lbl-patr-tag">PATR:</span>` : ''}
                      ${
                        asset.patrimonio && !asset.patrimonio.startsWith('___')
                          ? `<span class="val-patr-num" style="font-size: ${effectiveFontSize}pt;">${escapeHtml(asset.patrimonio)}</span>`
                          : `<span class="blank-patr-line" style="min-width: ${isQrHidden ? '45mm' : '28mm'};"></span>`
                      }
                    </div>
                    ${
                      blankStyle === 'write_lines'
                        ? `
                      <div class="blank-line-field" style="margin-top: 0.5mm;">
                        <span class="blank-lbl">DESC:</span> <span class="blank-fill-line"></span>
                      </div>
                      <div class="blank-line-field">
                        <span class="blank-lbl">LOC/SETOR:</span> <span class="blank-fill-line"></span>
                      </div>
                    `
                        : `
                      ${!isFooterHidden && bottomDesc ? `<div class="val-desc-bold">${escapeHtml(bottomDesc)}</div>` : ''}
                      <div class="val-comp-mono">${escapeHtml(asset.complemento || '')}</div>
                    `
                    }
                  </div>

                  ${
                    !isQrHidden && opticalHtml
                      ? `<div class="full-optical">${opticalHtml}</div>`
                      : ''
                  }
                </div>

                ${
                  !isFooterHidden && bottomDesc
                    ? `
                  <div class="full-footer">
                    <span>${escapeHtml(bottomDesc)}</span>
                    <span>${escapeHtml(bottomLoc || `#${overallIndex}`)}</span>
                  </div>
                `
                    : ''
                }
              </div>
            </div>
          `;
        } else {
          pageCellsHtml += `
            <div class="pimaco-label-cell">
              <div class="label-full-box ${showBorderGuide ? 'has-border' : ''} ${isQrHidden ? 'no-qr' : ''}">
                ${
                  !isHeaderHidden && topHeaderLeft
                    ? `
                  <div class="full-header">
                    <span class="full-title">${escapeHtml(topHeaderLeft)}</span>
                    <span class="full-tag">${escapeHtml(topHeaderRight || 'PATRIMÔNIO')}</span>
                  </div>
                `
                    : ''
                }

                <div class="full-body">
                  <div class="full-info">
                    <div class="full-patr-line">
                      ${!isPatrTagHidden ? `<span class="lbl-patr-tag">PATR:</span>` : ''}
                      <span class="val-patr-num" style="font-size: ${effectiveFontSize}pt;">${escapeHtml(asset.patrimonio)}</span>
                    </div>
                    ${!isFooterHidden && bottomDesc ? `<div class="val-desc-bold">${escapeHtml(bottomDesc)}</div>` : ''}
                    <div class="val-comp-mono">${escapeHtml(asset.complemento || '—')}</div>
                    ${
                      showUnit && !isSubHeaderHidden && asset.unidade
                        ? `
                      <div class="val-loc-unit">
                        ${escapeHtml(asset.unidade)} (Loc ${escapeHtml(asset.localidade)})
                        ${showCostCenter && asset.centroCusto ? ` • CC ${escapeHtml(asset.centroCusto)}` : ''}
                      </div>
                    `
                        : ''
                    }
                  </div>

                  ${
                    !isQrHidden && opticalHtml
                      ? `<div class="full-optical">${opticalHtml}</div>`
                      : ''
                  }
                </div>

                ${
                  !isFooterHidden && bottomDesc
                    ? `
                  <div class="full-footer">
                    <span>${escapeHtml(bottomDesc)}</span>
                    <span>${escapeHtml(bottomLoc || (showCostCenter && asset.centroCusto ? `CC ${asset.centroCusto}` : ''))}</span>
                  </div>
                `
                    : ''
                }
              </div>
            </div>
          `;
        }
      }
    }

    renderedPagesHtml.push(`
      <div class="pimaco-sheet">
        <div class="pimaco-grid">
          ${pageCellsHtml}
        </div>
      </div>
    `);
  }

  const html = `<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Pimaco 6181 / 6281 - Folhas de Etiquetas COMLURB</title>
  <style>
    /* Reset & Exact Millimeter Geometry for Pimaco 6181 (101.6mm x 25.4mm, 2x10) */
    *, *::before, *::after {
      box-sizing: border-box !important;
      margin: 0;
      padding: 0;
      -webkit-print-color-adjust: exact !important;
      print-color-adjust: exact !important;
    }

    @page {
      size: ${paperFormat === 'letter' ? 'letter portrait' : 'a4 portrait'};
      margin: 0mm !important;
    }

    html, body {
      background-color: #0f172a;
      color: #000000;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif;
      margin: 0;
      padding: 0;
    }

    /* Screen floating bar */
    .top-toolbar {
      position: sticky;
      top: 0;
      z-index: 9999;
      background: #1e293b;
      color: #ffffff;
      padding: 12px 24px;
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      justify-content: space-between;
      gap: 12px;
      box-shadow: 0 4px 16px rgba(0,0,0,0.3);
      border-bottom: 2px solid #ea580c;
    }

    .toolbar-title {
      font-size: 14px;
      font-weight: 800;
      display: flex;
      align-items: center;
      gap: 8px;
    }

    .toolbar-badge {
      background: #ea580c;
      color: #ffffff;
      font-size: 11px;
      padding: 3px 10px;
      border-radius: 999px;
      font-weight: bold;
    }

    .toolbar-guide {
      font-size: 12px;
      color: #fbd38d;
      background: #7c2d12;
      padding: 4px 12px;
      border-radius: 6px;
      border: 1px solid #c2410c;
    }

    .toolbar-actions {
      display: flex;
      align-items: center;
      gap: 8px;
    }

    .btn {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      padding: 8px 16px;
      font-size: 13px;
      font-weight: 700;
      border-radius: 8px;
      border: none;
      cursor: pointer;
      text-decoration: none;
      transition: all 0.15s ease;
    }

    .btn-primary {
      background: #ea580c;
      color: #ffffff;
    }
    .btn-primary:hover {
      background: #c2410c;
    }

    .btn-secondary {
      background: #334155;
      color: #ffffff;
    }
    .btn-secondary:hover {
      background: #475569;
    }

    .sheets-wrapper {
      display: flex;
      flex-direction: column;
      align-items: center;
      padding: 24px 0 80px 0;
      gap: 28px;
    }

    /* Pimaco Sheet Layout (Zero margin, millimeter precision) */
    .pimaco-sheet {
      width: ${sheetWidthMm}mm;
      height: ${sheetHeightMm}mm;
      min-height: ${sheetHeightMm}mm;
      max-height: ${sheetHeightMm}mm;
      padding-top: ${topMargin}mm;
      padding-left: ${leftMargin}mm;
      padding-right: 2.0mm;
      padding-bottom: 0mm;
      background: #ffffff;
      box-shadow: 0 8px 30px rgba(0,0,0,0.3);
      page-break-inside: avoid !important;
      page-break-after: always !important;
      break-after: page !important;
      overflow: hidden;
      box-sizing: border-box !important;
      position: relative;
    }

    /* Fixed 2 columns x 10 rows grid with strict pitch */
    .pimaco-grid {
      display: grid !important;
      grid-template-columns: ${colWidthMm}mm ${colWidthMm}mm !important;
      grid-template-rows: repeat(10, ${rowHeightMm}mm) !important;
      column-gap: ${colGapMm}mm !important;
      row-gap: 0.0mm !important;
      width: ${colWidthMm * 2 + colGapMm}mm !important;
      height: ${rowHeightMm * 10}mm !important;
      box-sizing: border-box !important;
      margin: 0 !important;
      padding: 0 !important;
    }

    .pimaco-label-cell {
      width: ${colWidthMm}mm !important;
      height: ${rowHeightMm}mm !important;
      min-height: ${rowHeightMm}mm !important;
      max-height: ${rowHeightMm}mm !important;
      box-sizing: border-box !important;
      overflow: hidden !important;
      background: #ffffff;
      padding: 0 !important;
      margin: 0 !important;
    }

    /* Layout Clássico Pimaco 6181 (Foto Oficial) */
    .label-pimaco-box {
      width: 100%;
      height: 100%;
      padding: 1.5mm 2.0mm;
      display: grid;
      grid-template-columns: 28mm 1fr 20mm;
      align-items: center;
      gap: 2mm;
      box-sizing: border-box;
      background: #ffffff;
    }

    .label-pimaco-box.has-border {
      border: 0.75px solid #000000;
      border-radius: 4px;
    }

    .col-patr {
      display: flex;
      align-items: baseline;
      gap: 2px;
      white-space: nowrap;
    }

    .lbl-patr-tag {
      font-size: 7.5pt;
      font-weight: 900;
      color: #000000;
      letter-spacing: -0.2px;
    }

    .val-patr-num {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "Arial Black", sans-serif;
      font-size: 13pt;
      font-weight: 900;
      color: #000000;
      letter-spacing: -0.4px;
      line-height: 1;
    }

    .col-info {
      display: flex;
      flex-direction: column;
      justify-content: center;
      min-width: 0;
      overflow: hidden;
      line-height: 1.15;
    }

    .val-desc-bold {
      font-size: 7.5pt;
      font-weight: 900;
      text-transform: uppercase;
      color: #000000;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }

    .val-comp-mono {
      font-family: monospace;
      font-size: 6.5pt;
      font-weight: 700;
      color: #000000;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }

    .val-loc-unit {
      font-size: 6pt;
      font-weight: 800;
      color: #000000;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
      margin-top: 0.2mm;
    }

    .col-optical {
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .qr-image-pimaco {
      width: 19.5mm;
      height: 19.5mm;
      object-fit: contain;
      image-rendering: pixelated;
    }

    .barcode-image-pimaco {
      height: 18mm;
      max-width: 100%;
      object-fit: contain;
      image-rendering: pixelated;
    }

    /* Layout Completo (Cabeçalho + Rodapé) */
    .label-full-box {
      width: 100%;
      height: 100%;
      padding: 1.0mm 2.0mm;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      box-sizing: border-box;
      background: #ffffff;
    }

    .label-full-box.has-border {
      border: 0.75px solid #000000;
      border-radius: 4px;
    }

    .full-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      border-bottom: 0.6px solid #000000;
      padding-bottom: 0.2mm;
      font-size: 7pt;
      font-weight: 800;
      line-height: 1;
      text-transform: uppercase;
    }

    .full-tag {
      font-size: 6pt;
      font-weight: 900;
    }

    .full-body {
      display: flex;
      align-items: center;
      justify-content: space-between;
      flex: 1;
      overflow: hidden;
      padding: 0.3mm 0;
    }

    .full-info {
      flex: 1;
      min-width: 0;
      display: flex;
      flex-direction: column;
      justify-content: center;
    }

    .full-patr-line {
      display: flex;
      align-items: baseline;
      gap: 3px;
    }

    .full-optical {
      flex-shrink: 0;
      display: flex;
      align-items: center;
      justify-content: center;
      padding-left: 2mm;
    }

    .full-footer {
      display: flex;
      justify-content: space-between;
      align-items: center;
      border-top: 0.6px solid #000000;
      padding-top: 0.2mm;
      font-size: 5.5pt;
      font-weight: 800;
      text-transform: uppercase;
      line-height: 1;
    }

    .both-opticals {
      display: flex;
      align-items: center;
      gap: 2mm;
    }

    .barcode-image-mini {
      height: 15mm;
      max-width: 22mm;
      object-fit: contain;
    }

    .qr-image-mini {
      width: 17mm;
      height: 17mm;
      object-fit: contain;
    }

    .empty-slot {
      background: transparent;
    }

    .empty-placeholder {
      width: 100%;
      height: 100%;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .no-print-screen-only {
      color: #cbd5e1;
      font-size: 9px;
      font-family: monospace;
    }

    /* Blank Label Field Styles */
    .blank-line-field {
      display: flex;
      align-items: flex-end;
      gap: 1mm;
      font-size: 6pt;
      font-weight: 800;
      color: #000000;
      line-height: 1.1;
      margin-bottom: 0.3mm;
    }

    /* Big Numbers Layout (Alta Visibilidade - Fonte até 85pt) */
    .label-big-numbers-box {
      width: 100%;
      height: 100%;
      padding: 0.8mm 2.0mm;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      box-sizing: border-box;
      background: #ffffff;
      overflow: hidden;
    }

    .label-big-numbers-box.has-border {
      border: 0.75px solid #000000;
      border-radius: 4px;
    }

    .big-num-topbar {
      display: flex;
      justify-content: space-between;
      align-items: center;
      border-bottom: 0.5px solid #000000;
      padding-bottom: 0.2mm;
      line-height: 1;
    }

    .big-num-org {
      font-size: 6pt;
      font-weight: 900;
      text-transform: uppercase;
      letter-spacing: -0.2px;
    }

    .big-num-dept {
      font-size: 6pt;
      font-weight: 900;
      text-transform: uppercase;
    }

    .big-num-center-row {
      display: flex;
      align-items: center;
      justify-content: ${numberAlignment === 'center' ? 'center' : 'space-between'};
      flex: 1;
      min-height: 0;
      padding: 0.2mm 0;
      gap: 2mm;
      overflow: hidden;
      width: 100%;
    }

    .big-num-value {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "Arial Black", Impact, sans-serif;
      font-weight: 900;
      color: #000000;
      letter-spacing: -0.04em;
      line-height: 0.88;
      white-space: nowrap;
      flex: 1;
      overflow: hidden;
      text-overflow: clip;
      display: flex;
      align-items: center;
      justify-content: ${numberAlignment === 'center' ? 'center' : 'flex-start'};
      text-align: ${numberAlignment === 'center' ? 'center' : 'left'};
      font-variant-numeric: tabular-nums;
    }

    .label-pimaco-box.no-qr {
      grid-template-columns: auto 1fr;
      gap: 3mm;
    }

    .label-pimaco-box.large-font {
      grid-template-columns: auto 1fr 20mm;
      gap: 2.5mm;
    }

    .label-pimaco-box.large-font.no-qr {
      grid-template-columns: auto 1fr;
      gap: 3mm;
    }

    .label-pimaco-box.pure-clean-number {
      display: flex !important;
      align-items: center !important;
      justify-content: ${numberAlignment === 'center' ? 'center' : 'space-between'} !important;
      padding: 1.0mm 2.5mm !important;
    }

    .col-patr.full-width {
      flex: 1 !important;
      width: 100% !important;
      display: flex !important;
      align-items: baseline !important;
      justify-content: ${numberAlignment === 'center' ? 'center' : 'flex-start'} !important;
      gap: 3px !important;
    }

    .val-patr-num.full-width {
      flex: 1 !important;
      letter-spacing: -0.03em !important;
      text-align: ${numberAlignment === 'center' ? 'center' : 'left'} !important;
    }

    .label-big-numbers-box.pure-clean-number {
      justify-content: center !important;
      padding: 0 1.5mm !important;
    }

    .lbl-patr-prefix {
      font-weight: 900;
      color: #000000;
      letter-spacing: -0.2px;
    }

    .label-big-numbers-box.no-qr .big-num-center-row,
    .big-num-center-row.full-width-number {
      justify-content: ${numberAlignment === 'center' ? 'center' : 'flex-start'};
      gap: 0;
      width: 100%;
    }

    .label-big-numbers-box.no-qr .big-num-value,
    .big-num-value.full-width {
      width: 100%;
      flex: 1 1 100%;
      letter-spacing: -0.04em;
      justify-content: ${numberAlignment === 'center' ? 'center' : 'flex-start'};
      text-align: ${numberAlignment === 'center' ? 'center' : 'left'};
    }

    .big-num-qr-wrapper {
      flex-shrink: 0;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .big-num-qr-wrapper .qr-image-pimaco {
      width: 17mm;
      height: 17mm;
    }

    .big-num-bottombar {
      display: flex;
      justify-content: space-between;
      align-items: center;
      border-top: 0.5px solid #000000;
      padding-top: 0.2mm;
      line-height: 1;
    }

    .big-num-desc {
      font-size: 5.5pt;
      font-weight: 800;
      text-transform: uppercase;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
      max-width: 65mm;
    }

    .big-num-tag {
      font-size: 5pt;
      font-weight: 900;
      letter-spacing: 0.2px;
    }

    .blank-lbl {
      font-size: 6pt;
      font-weight: 900;
      color: #000000;
      white-space: nowrap;
    }

    .blank-fill-line {
      flex: 1;
      min-width: 20mm;
      border-bottom: 0.75px dashed #000000;
      height: 2.2mm;
      display: inline-block;
    }

    .blank-fill-line-sm {
      min-width: 14mm;
      border-bottom: 0.75px dashed #000000;
      height: 2.2mm;
      display: inline-block;
    }

    .blank-fill-line-xs {
      min-width: 10mm;
      border-bottom: 0.75px dashed #000000;
      height: 2.2mm;
      display: inline-block;
      text-align: center;
      font-size: 5pt;
      color: #64748b;
    }

    .blank-patr-line {
      display: inline-block;
      min-width: 22mm;
      border-bottom: 1.2px solid #000000;
      height: 3.5mm;
      margin-left: 2px;
    }

    .blank-pure-space {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      height: 100%;
      border: 0.5px dashed #94a3b8;
      border-radius: 2px;
      padding: 1mm;
      background: #fafafa;
    }

    .blank-pure-hint {
      font-size: 5.5pt;
      font-weight: 800;
      color: #64748b;
      letter-spacing: 0.2px;
      text-align: center;
    }

    .blank-qr-box {
      width: 19mm;
      height: 19mm;
      border: 0.75px dashed #64748b;
      border-radius: 3px;
      display: flex;
      align-items: center;
      justify-content: center;
      background: #f8fafc;
    }

    .blank-qr-text {
      font-size: 5pt;
      font-weight: 900;
      color: #64748b;
      text-align: center;
      line-height: 1.1;
    }

    /* Calibration Grid Styles */
    .test-grid-cell {
      border: 0.5px dashed #64748b;
      position: relative;
    }
    .test-cell-inner {
      width: 100%;
      height: 100%;
      position: relative;
      display: flex;
      align-items: center;
      justify-content: center;
      font-family: monospace;
      font-size: 8pt;
      font-weight: bold;
      color: #334155;
    }
    .test-crosshair-tl { position: absolute; top: 0; left: 0; line-height: 1; }
    .test-crosshair-tr { position: absolute; top: 0; right: 0; line-height: 1; }
    .test-crosshair-bl { position: absolute; bottom: 0; left: 0; line-height: 1; }
    .test-crosshair-br { position: absolute; bottom: 0; right: 0; line-height: 1; }
    .test-cell-info {
      display: flex;
      flex-direction: column;
      align-items: center;
      line-height: 1.2;
    }
    .test-drift-indicator {
      color: #c2410c;
      font-weight: 900;
      font-size: 7.5pt;
    }

    /* Print Styles */
    @media print {
      .no-print,
      .top-toolbar,
      .no-print-screen-only {
        display: none !important;
      }

      html, body {
        background: #ffffff !important;
        margin: 0 !important;
        padding: 0 !important;
      }

      .sheets-wrapper {
        padding: 0 !important;
        gap: 0 !important;
      }

      .pimaco-sheet {
        box-shadow: none !important;
        margin: 0 !important;
        page-break-inside: avoid !important;
        page-break-after: always !important;
        break-after: page !important;
      }
    }
  </style>
</head>
<body>
  <div class="top-toolbar no-print">
    <div class="toolbar-title">
      <span>${options.batchTitle ? escapeHtml(options.batchTitle) : 'Pimaco 6181 / 6281 • COMLURB'}</span>
      <span class="toolbar-badge">${pages.length} Folha${pages.length !== 1 ? 's' : ''} (${assets.filter(Boolean).length} Etiquetas)</span>
      ${options.archivedAt ? `<span style="font-size: 11px; color: #cbd5e1; font-weight: normal; margin-left: 8px;">Arquivado em: ${escapeHtml(options.archivedAt)}</span>` : ''}
    </div>

    <div class="toolbar-guide">
      ⚠️ No diálogo de impressão: selecione <strong>Escala: 100% (Padrão)</strong> e <strong>Margens: Nenhuma</strong>.
    </div>

    <div class="toolbar-actions">
      <button onclick="window.print()" class="btn btn-primary">
        <svg width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24"><path d="M6 9V2h12v7M6 18H4a2 2 0 01-2-2v-5a2 2 0 012-2h16a2 2 0 012 2v5a2 2 0 01-2 2h-2"/><path d="M6 14h12v8H6z"/></svg>
        Imprimir Agora (Ctrl + P)
      </button>
      <button onclick="window.close()" class="btn btn-secondary">
        Fechar Janela
      </button>
    </div>
  </div>

  <div class="sheets-wrapper">
    ${renderedPagesHtml.join('\n')}
  </div>

  <script>
    // Automatically trigger print dialog on window load with slight delay
    window.addEventListener('load', function() {
      setTimeout(function() {
        window.focus();
        window.print();
      }, 350);
    });
  </script>
</body>
</html>`;

  return html;
}

function escapeHtml(text: string): string {
  if (!text) return '';
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

/**
 * Opens a dedicated popup / window containing the pre-rendered labels
 * and directly invokes print.
 */
export async function openPimacoPrintWindow(options: LabelPrintOptions): Promise<boolean> {
  try {
    const html = await generatePimacoHtmlDocument(options);
    const printWindow = window.open('', '_blank', 'width=1050,height=950,menubar=no,toolbar=no,location=no');

    if (!printWindow) {
      return false;
    }

    printWindow.document.open();
    printWindow.document.write(html);
    printWindow.document.close();
    printWindow.focus();
    return true;
  } catch (err) {
    console.error('Error opening print window:', err);
    return false;
  }
}

/**
 * Downloads a standalone HTML file ready for local printing
 */
export async function downloadPimacoHtmlFile(options: LabelPrintOptions, filename?: string): Promise<void> {
  const html = await generatePimacoHtmlDocument(options);
  const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename || `Etiquetas_Pimaco_6181_COMLURB_${options.selectedYear}.html`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
