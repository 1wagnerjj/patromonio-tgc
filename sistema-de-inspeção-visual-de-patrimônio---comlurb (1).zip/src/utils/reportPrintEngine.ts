import { AssetItem, InspectionRecord, DepartmentInfo, AuditSession, DepartmentManagerInfo } from '../types';
import { formatBRL, formatDateBR } from './formatters';

export interface ReportPrintOptions {
  assets: AssetItem[];
  inspections: Record<string, InspectionRecord>;
  departments: DepartmentInfo[];
  selectedYear: number;
  selectedGerencia: string;
  auditSession: AuditSession;
  printMode: 'blank' | 'completed' | 'divergences';
  fiscalName: string;
  fiscalMatricula: string;
  gerenteName?: string;
  departmentManagers?: Record<string, DepartmentManagerInfo>;
}

/**
 * Builds a standalone, complete HTML document for the COMLURB Official Inspection Report.
 * Uses native A4 landscape page sizing and clean vector print styling.
 */
export function generateOfficialReportHtml(options: ReportPrintOptions): string {
  const {
    assets,
    inspections,
    departments,
    selectedYear,
    selectedGerencia,
    auditSession,
    printMode,
    fiscalName,
    fiscalMatricula,
    gerenteName,
    departmentManagers,
  } = options;

  const departmentsToPrint =
    selectedGerencia === 'ALL'
      ? departments
      : departments.filter((d) => d.code === selectedGerencia);

  const sectionsHtml = departmentsToPrint
    .map((dept, deptIndex) => {
      let deptAssets = assets.filter((a) => a.gerenciaCode === dept.code);

      // Resolve specific division manager for this department
      const deptManager: Partial<DepartmentManagerInfo> = departmentManagers?.[dept.code] || {
        gerenteNome: dept.gerenteNome || gerenteName || 'Gerente da Divisão',
        gerenteMatricula: dept.gerenteMatricula || 'Matr. Não Informada',
        gerenteCargo: dept.gerenteCargo || `Gerente Responsável (${dept.code})`,
        fiscalNome: dept.fiscalNome || fiscalName || 'Wagner J. Jardim',
        fiscalMatricula: dept.fiscalMatricula || fiscalMatricula || 'Matr. 892.410-3',
        statusInspecao: dept.statusInspecao || 'em_andamento',
        dataConclusao: dept.dataConclusao || '',
        observacoes: dept.observacoes || '',
      };

      const resolvedGerenteNome = deptManager.gerenteNome || dept.gerenteNome || gerenteName || 'Gerente da Divisão';
      const resolvedGerenteMatr = deptManager.gerenteMatricula || dept.gerenteMatricula || 'Matr. Titular';
      const resolvedGerenteCargo = deptManager.gerenteCargo || dept.gerenteCargo || `Gerente de Divisão (${dept.code})`;
      const resolvedFiscalNome = deptManager.fiscalNome || fiscalName || 'Wagner J. Jardim';
      const resolvedFiscalMatr = deptManager.fiscalMatricula || fiscalMatricula || 'Matr. 892.410-3';
      const isConcluido = deptManager.statusInspecao === 'concluido';

      if (printMode === 'divergences') {
        deptAssets = deptAssets.filter((a) => {
          const insp = inspections[`${a.id}-${selectedYear}`];
          return insp?.status === 'ausente' || insp?.status === 'transferido';
        });
      }

      const deptTotalValue = deptAssets.reduce((sum, item) => sum + (item.vlBase || 0), 0);
      const deptPresentCount = deptAssets.filter(
        (a) => inspections[`${a.id}-${selectedYear}`]?.status === 'presente'
      ).length;
      const deptAbsentCount = deptAssets.filter(
        (a) => inspections[`${a.id}-${selectedYear}`]?.status === 'ausente'
      ).length;

      const rowsHtml =
        deptAssets.length === 0
          ? `
          <tr>
            <td colspan="10" style="text-align: center; padding: 20px; color: #666; font-style: italic; border: 1px solid #000;">
              Nenhum bem patrimonial encontrado para esta listagem no exercício ${selectedYear}.
            </td>
          </tr>
        `
          : deptAssets
              .map((asset) => {
                const key = `${asset.id}-${selectedYear}`;
                const insp: Partial<InspectionRecord> = inspections[key] || {
                  status: 'pendente',
                  condition: 'nao_avaliado',
                  observacao: '',
                  transferidoPara: '',
                  dtTransf: '',
                };

                const isSim = printMode !== 'blank' && insp.status === 'presente';
                const isNao = printMode !== 'blank' && insp.status === 'ausente';

                let obsContent = '';
                if (printMode !== 'blank') {
                  if (asset.situacao === 'baixado') {
                    obsContent += `<div style="color: #b91c1c; font-weight: bold; font-size: 7pt;">[BAIXA PATRIMONIAL: ${formatDateBR(asset.dtBaixa)}${asset.motivoBaixa ? ` - ${escapeHtml(asset.motivoBaixa)}` : ''}]</div>`;
                  }
                  if (insp.observacao) {
                    obsContent += `<div>${escapeHtml(insp.observacao)}</div>`;
                  }
                  if (insp.condition && insp.condition !== 'nao_avaliado') {
                    obsContent += `<div style="font-weight: 600; font-size: 7pt; color: #475569;">[Estado: ${insp.condition.toUpperCase()}]</div>`;
                  }
                } else {
                  obsContent = '<div style="border-bottom: 1px dotted #94a3b8; height: 10px;"></div>';
                }

                return `
              <tr style="page-break-inside: avoid;">
                <td style="text-align: center; font-family: monospace; font-weight: bold; border: 1px solid #000; padding: 3px;">
                  ${escapeHtml(asset.patrimonio)}
                </td>
                <td style="font-weight: 600; border: 1px solid #000; padding: 3px;">
                  ${escapeHtml(asset.descricao)}
                </td>
                <td style="font-family: monospace; font-size: 7pt; border: 1px solid #000; padding: 3px;">
                  ${escapeHtml(asset.complemento || '-')}
                </td>
                <td style="text-align: center; white-space: nowrap; border: 1px solid #000; padding: 3px;">
                  ${formatDateBR(asset.dtAquisicao)}
                </td>
                <td style="text-align: right; white-space: nowrap; font-family: monospace; border: 1px solid #000; padding: 3px;">
                  ${formatBRL(asset.vlBase)}
                </td>
                <td style="text-align: center; font-weight: 600; border: 1px solid #000; padding: 3px;">
                  ${escapeHtml(asset.unidade)}
                </td>
                <td style="text-align: center; border: 1px solid #000; padding: 0;">
                  <div style="display: flex; height: 100%; min-height: 18px;">
                    <div style="width: 50%; border-right: 1px solid #000; display: flex; align-items: center; justify-content: center; padding: 2px;">
                      ${
                        printMode === 'blank'
                          ? '<span style="display: inline-block; width: 10px; height: 10px; border: 1px solid #000;"></span>'
                          : isSim
                          ? '<strong style="color: #065f46; font-size: 8pt;">✓ SIM</strong>'
                          : '<span style="display: inline-block; width: 8px; height: 8px; border: 1px solid #cbd5e1;"></span>'
                      }
                    </div>
                    <div style="width: 50%; display: flex; align-items: center; justify-content: center; padding: 2px;">
                      ${
                        printMode === 'blank'
                          ? '<span style="display: inline-block; width: 10px; height: 10px; border: 1px solid #000;"></span>'
                          : isNao
                          ? '<strong style="color: #991b1b; font-size: 8pt;">✗ NÃO</strong>'
                          : '<span style="display: inline-block; width: 8px; height: 8px; border: 1px solid #cbd5e1;"></span>'
                      }
                    </div>
                  </div>
                </td>
                <td style="font-size: 7pt; border: 1px solid #000; padding: 3px;">
                  ${printMode !== 'blank' ? escapeHtml(insp.transferidoPara || '') : ''}
                </td>
                <td style="text-align: center; font-size: 7pt; border: 1px solid #000; padding: 3px;">
                  ${printMode !== 'blank' && insp.dtTransf ? formatDateBR(insp.dtTransf) : ''}
                </td>
                <td style="font-size: 7pt; border: 1px solid #000; padding: 3px;">
                  ${obsContent}
                </td>
              </tr>
            `;
              })
              .join('');

      return `
      <div class="report-page ${deptIndex > 0 ? 'page-break' : ''}">
        <!-- Department Header Box -->
        <div class="header-box">
          <div class="header-top">
            <div class="company-name">COMLURB - Companhia Municipal de Limpeza Urbana</div>
            <div class="doc-meta">
              <span>Data: <strong>${escapeHtml(auditSession.dataEmissao || new Date().toLocaleDateString('pt-BR'))}</strong></span>
              <span class="doc-code">${escapeHtml(auditSession.codigoDocumento || 'COML02.2.3.12')}</span>
            </div>
          </div>
          <div class="report-title">
            RELATÓRIO DE BENS MÓVEIS - INSPEÇÃO VISUAL ANUAL (EXERCÍCIO ${selectedYear})
          </div>
          <div class="header-details">
            <div style="flex: 2;"><strong>Gerência:</strong> ${escapeHtml(dept.name)}</div>
            <div style="flex: 1;"><strong>Localidade:</strong> <code>${escapeHtml(dept.locationCode)}</code></div>
            <div style="flex: 1; text-align: right;"><strong>Centro de Custo:</strong> <code>${escapeHtml(dept.costCenter)}</code></div>
          </div>
        </div>

        <!-- Table -->
        <table class="report-table">
          <thead>
            <tr>
              <th style="width: 70px;">Patrimônio</th>
              <th style="width: 140px;">Descrição</th>
              <th>Complemento / Especificação</th>
              <th style="width: 75px;">Dt. Aquisição</th>
              <th style="width: 80px; text-align: right;">Vl. Base</th>
              <th style="width: 45px;">Unid.</th>
              <th style="width: 100px; padding: 0;">
                <div style="padding: 2px 0;">Encontra-se no local?</div>
                <div style="display: flex; border-top: 1px solid #000; font-size: 6.5pt;">
                  <span style="width: 50%; border-right: 1px solid #000;">Sim</span>
                  <span style="width: 50%;">Não</span>
                </div>
              </th>
              <th style="width: 100px;">Transferido Para:</th>
              <th style="width: 70px;">Dt.Transf:</th>
              <th style="width: 130px;">Observação:</th>
            </tr>
          </thead>
          <tbody>
            ${rowsHtml}
          </tbody>
          <tfoot>
            <tr class="tfoot-row">
              <td colspan="3">
                <strong>Bens Relacionados:</strong> ${deptAssets.length}
                ${
                  printMode !== 'blank'
                    ? ` (Presentes: <strong style="color: #065f46;">${deptPresentCount}</strong> | Ausentes: <strong style="color: #991b1b;">${deptAbsentCount}</strong>)`
                    : ''
                }
              </td>
              <td style="text-align: right;"><strong>Total:</strong></td>
              <td style="text-align: right; font-family: monospace; font-weight: bold;">${formatBRL(deptTotalValue)}</td>
              <td colspan="5" style="text-align: right; font-size: 7pt; color: #334155;">
                Gerência: ${dept.code} • Localidade: ${dept.locationCode}
              </td>
            </tr>
          </tfoot>
        </table>

        <!-- Audit Signature Block -->
        <div class="signature-box">
          <div class="term-title" style="display: flex; justify-content: space-between; align-items: center;">
            <span>Termo de Responsabilidade e Conclusão de Vistoria Anual In Loco</span>
            ${
              isConcluido
                ? `<span style="background: #dcfce7; color: #166534; padding: 1px 6px; border-radius: 3px; font-size: 6.5pt; font-weight: bold; border: 1px solid #86efac;">
                    ✓ VISTORIA CONCLUÍDA${deptManager.dataConclusao ? ` EM ${formatDateBR(deptManager.dataConclusao)}` : ''}
                   </span>`
                : `<span style="background: #fef9c3; color: #854d0e; padding: 1px 6px; border-radius: 3px; font-size: 6.5pt; font-weight: bold; border: 1px solid #fde047;">
                    ⏳ VISTORIA EM ANDAMENTO
                   </span>`
            }
          </div>
          <p class="term-text">
            Certificamos que a conferência física e visual dos bens móveis da unidade <strong>${escapeHtml(dept.name)}</strong> (Centro de Custo: <strong>${escapeHtml(dept.costCenter)}</strong>) foi executada em estrita conformidade com as normas de patrimônio da COMLURB no exercício de <strong>${selectedYear}</strong>. As divergências e transferências identificadas foram devidamente registradas para regularização contábil e patrimonial.
            ${deptManager.observacoes ? `<br/><span style="display:inline-block; margin-top: 3px; font-style: italic; color: #334155;"><strong>Obs. da Gerência:</strong> ${escapeHtml(deptManager.observacoes)}</span>` : ''}
          </p>

          <div class="signatures-grid">
            <div class="signature-col">
              <div class="sig-line"></div>
              <div class="sig-name">${escapeHtml(resolvedFiscalNome)}</div>
              <div class="sig-matr">${escapeHtml(resolvedFiscalMatr)}</div>
              <div class="sig-role">Fiscal de Patrimônio / Vistoriador</div>
            </div>

            <div class="signature-col">
              <div class="sig-line"></div>
              <div class="sig-name">${escapeHtml(resolvedGerenteNome)}</div>
              <div class="sig-matr">${escapeHtml(resolvedGerenteMatr)}</div>
              <div class="sig-role">${escapeHtml(resolvedGerenteCargo)} • Centro de Custo: ${escapeHtml(dept.costCenter)}</div>
            </div>
          </div>
        </div>
      </div>
    `;
    })
    .join('');

  return `<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <title>COMLURB - Relatório Oficial de Inspeção e Inventário (${selectedYear})</title>
  <style>
    @page {
      size: A4 landscape;
      margin: 8mm 6mm 8mm 6mm;
    }
    *, *::before, *::after {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif;
      font-size: 8pt;
      color: #000;
      background: #f8fafc;
      line-height: 1.2;
      -webkit-print-color-adjust: exact !important;
      print-color-adjust: exact !important;
    }
    .no-print-bar {
      position: sticky;
      top: 0;
      z-index: 1000;
      background: #0f172a;
      color: #fff;
      padding: 12px 20px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    }
    .no-print-bar .title {
      font-weight: bold;
      font-size: 14px;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .no-print-bar .actions {
      display: flex;
      gap: 10px;
    }
    .btn {
      padding: 8px 16px;
      font-size: 12px;
      font-weight: bold;
      border-radius: 6px;
      border: none;
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      gap: 6px;
      transition: all 0.15s;
    }
    .btn-orange {
      background: #ea580c;
      color: white;
    }
    .btn-orange:hover {
      background: #c2410c;
    }
    .btn-slate {
      background: #334155;
      color: white;
    }
    .btn-slate:hover {
      background: #475569;
    }
    .document-container {
      max-width: 1100px;
      margin: 20px auto;
      background: #fff;
      padding: 20px;
      box-shadow: 0 2px 10px rgba(0,0,0,0.08);
    }
    .report-page {
      background: #fff;
      page-break-inside: auto;
    }
    .page-break {
      page-break-before: always;
      break-before: page;
      margin-top: 30px;
      padding-top: 20px;
      border-top: 2px dashed #94a3b8;
    }
    .header-box {
      border: 1px solid #000;
      padding: 8px 12px;
      margin-bottom: 8px;
      background: #f8fafc;
    }
    .header-top {
      display: flex;
      justify-content: space-between;
      align-items: center;
      border-bottom: 1px solid #000;
      padding-bottom: 4px;
      margin-bottom: 4px;
    }
    .company-name {
      font-weight: bold;
      font-size: 9.5pt;
    }
    .doc-meta {
      font-family: monospace;
      font-size: 8pt;
      display: flex;
      gap: 16px;
    }
    .doc-code {
      background: #e2e8f0;
      padding: 1px 6px;
      font-weight: bold;
    }
    .report-title {
      text-align: center;
      font-weight: 900;
      font-size: 9.5pt;
      text-transform: uppercase;
      padding: 3px 0;
      letter-spacing: 0.5px;
    }
    .header-details {
      display: flex;
      border-top: 1px solid #000;
      padding-top: 4px;
      font-size: 8pt;
    }
    .report-table {
      width: 100%;
      border-collapse: collapse;
      border: 1px solid #000;
      font-size: 7.5pt;
      margin-bottom: 10px;
    }
    .report-table th, .report-table td {
      border: 1px solid #000;
      padding: 3px 4px;
      text-align: left;
    }
    .report-table th {
      background: #e2e8f0;
      font-weight: bold;
      color: #000;
      text-align: center;
    }
    .tfoot-row {
      background: #f1f5f9;
      font-weight: bold;
    }
    .signature-box {
      border: 1px solid #000;
      padding: 8px 12px;
      background: #fff;
      margin-top: 8px;
    }
    .term-title {
      font-weight: bold;
      font-size: 8pt;
      text-transform: uppercase;
      border-bottom: 1px solid #000;
      padding-bottom: 2px;
      margin-bottom: 4px;
    }
    .term-text {
      font-size: 7pt;
      line-height: 1.25;
      margin-bottom: 16px;
      color: #1e293b;
    }
    .signatures-grid {
      display: flex;
      justify-content: space-around;
      padding-top: 10px;
    }
    .signature-col {
      text-align: center;
      width: 40%;
    }
    .sig-line {
      border-bottom: 1px solid #000;
      width: 80%;
      margin: 0 auto 4px auto;
    }
    .sig-name {
      font-weight: bold;
      font-size: 8pt;
    }
    .sig-matr {
      font-size: 7pt;
      color: #334155;
    }
    .sig-role {
      font-size: 6.5pt;
      color: #64748b;
      text-transform: uppercase;
    }

    @media print {
      .no-print-bar {
        display: none !important;
      }
      body {
        background: #fff !important;
      }
      .document-container {
        max-width: 100% !important;
        margin: 0 !important;
        padding: 0 !important;
        box-shadow: none !important;
      }
      .header-box {
        background: transparent !important;
      }
      .report-table th {
        background: #f1f5f9 !important;
      }
      .page-break {
        border-top: none !important;
        margin-top: 0 !important;
        padding-top: 0 !important;
      }
    }
  </style>
</head>
<body>
  <!-- Print Control Bar for direct browser view -->
  <div class="no-print-bar">
    <div class="title">
      <span>🖨️</span>
      <span>COMLURB - Visualização Oficial de Impressão (A4 Paisagem)</span>
    </div>
    <div class="actions">
      <button class="btn btn-orange" onclick="window.print()">
        Imprimir Agora (Ctrl + P)
      </button>
      <button class="btn btn-slate" onclick="window.close()">
        Fechar Janela
      </button>
    </div>
  </div>

  <div class="document-container">
    ${sectionsHtml}
  </div>

  <script>
    // Auto trigger print when page opens if requested
    window.addEventListener('DOMContentLoaded', () => {
      // Short delay to ensure styles and fonts render before dialog pops
      setTimeout(() => {
        try {
          window.print();
        } catch(e) {
          console.warn('Auto print was blocked by browser', e);
        }
      }, 400);
    });
  </script>
</body>
</html>`;
}

function escapeHtml(str: string): string {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

/**
 * Opens a dedicated popup window with the official report ready to print or save as PDF.
 */
export function openOfficialReportPrintWindow(options: ReportPrintOptions): boolean {
  try {
    const html = generateOfficialReportHtml(options);
    const printWindow = window.open('', '_blank', 'width=1200,height=800,menubar=no,toolbar=no,status=no');
    
    if (!printWindow || printWindow.closed || typeof printWindow.closed === 'undefined') {
      // Popup blocked, fallback to blob URL
      const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
      const blobUrl = URL.createObjectURL(blob);
      const newTab = window.open(blobUrl, '_blank');
      if (!newTab) {
        return false;
      }
      return true;
    }

    printWindow.document.open();
    printWindow.document.write(html);
    printWindow.document.close();
    printWindow.focus();
    return true;
  } catch (err) {
    console.error('Error opening print window:', err);
    return false;
  }
}

/**
 * Downloads the complete standalone HTML report file
 */
export function downloadOfficialReportHtml(options: ReportPrintOptions, filename?: string): void {
  const html = generateOfficialReportHtml(options);
  const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename || `COMLURB_Relatorio_Inspecao_${options.selectedYear}_${options.selectedGerencia}.html`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
