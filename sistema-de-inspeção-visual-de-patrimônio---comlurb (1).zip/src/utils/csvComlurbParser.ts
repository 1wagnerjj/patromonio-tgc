import { AssetItem, InspectionRecord } from '../types';

function parseCurrency(val: string): number {
  if (!val) return 0;
  const clean = val
    .replace('R$', '')
    .replace(/\s/g, '')
    .replace(/\./g, '')
    .replace(',', '.');
  const num = parseFloat(clean);
  return isNaN(num) ? 0 : num;
}

function parseDate(val: string): string {
  if (!val) return '';
  const trimmed = val.trim();
  // Format MM/DD/YYYY or M/D/YYYY
  if (/^\d{1,2}\/\d{1,2}\/\d{4}$/.test(trimmed)) {
    const parts = trimmed.split('/');
    const month = parts[0].padStart(2, '0');
    const day = parts[1].padStart(2, '0');
    const year = parts[2];
    return `${year}-${month}-${day}`;
  }
  // Format DD/MM/YYYY
  if (/^\d{1,2}-\d{1,2}-\d{4}$/.test(trimmed)) {
    const parts = trimmed.split('-');
    return `${parts[2]}-${parts[1].padStart(2, '0')}-${parts[0].padStart(2, '0')}`;
  }
  // Format YYYY-MM-DD
  if (/^\d{4}-\d{2}-\d{2}$/.test(trimmed)) {
    return trimmed;
  }
  return trimmed;
}

function getCategory(descricao: string): string {
  const d = (descricao || '').toUpperCase();
  if (d.includes('COMPUTADOR') || d.includes('MONITOR') || d.includes('TELEVISOR') || d.includes('NOTEBOOK') || d.includes('IMPRESSORA')) {
    return 'Informática & Audiovisual';
  }
  if (d.includes('CONDICIONADOR') || d.includes('BEBEDOURO') || d.includes('CAMARA FRIA') || d.includes('AR CONDICIONADO') || d.includes('REFRIGERADOR')) {
    return 'Climatização & Refrigeração';
  }
  if (d.includes('CARRO') || d.includes('VEICULO') || d.includes('CAMINHAO') || d.includes('RENAULT') || d.includes('MOTO')) {
    return 'Veículos & Frotas';
  }
  if (
    d.includes('MOTOR') ||
    d.includes('PRENSA') ||
    d.includes('BOMBA') ||
    d.includes('RETIFICADOR') ||
    d.includes('ROÇADEIRA') ||
    d.includes('MEDIDOR') ||
    d.includes('SISTEMA DE COMPOSTAGEM') ||
    d.includes('PENEIRA') ||
    d.includes('ANALISADOR') ||
    d.includes('BANCO DE RESISTENCIA') ||
    d.includes('MEGOMETRO') ||
    d.includes('FERRAMENTA') ||
    d.includes('EQUIPAMENTO')
  ) {
    return 'Máquinas & Equipamentos';
  }
  return 'Mobiliário & Escritório';
}

export interface ParseComlurbResult {
  assets: AssetItem[];
  inspections: Record<string, InspectionRecord>;
  summary: {
    total: number;
    byDepartment: Record<string, number>;
    inspectedCount: number;
  };
}

function parseCSVLine(text: string): string[] {
  const result: string[] = [];
  let cur = '';
  let inQuotes = false;
  for (let i = 0; i < text.length; i++) {
    const char = text[i];
    if (char === '"') {
      if (inQuotes && text[i + 1] === '"') {
        cur += '"';
        i++;
      } else {
        inQuotes = !inQuotes;
      }
    } else if ((char === ',' || char === '\t' || char === ';') && !inQuotes) {
      result.push(cur.trim());
      cur = '';
    } else {
      cur += char;
    }
  }
  result.push(cur.trim());
  return result;
}

export function parseComlurbSheetText(text: string, targetYear: number = 2026): ParseComlurbResult {
  const lines = text.split(/\r?\n/).map((l) => l.trim()).filter((l) => l.length > 0);
  
  const assets: AssetItem[] = [];
  const inspections: Record<string, InspectionRecord> = {};
  const byDepartment: Record<string, number> = {};
  let inspectedCount = 0;

  let currentGerencia = 'TGC';
  let currentLocation = '144';
  let currentCostCenter = '65020000';

  // Dynamic column mapping with sensible defaults matching standard COMLURB sheet
  let colMap = {
    patrimonio: 0,
    descricao: 1,
    complemento: 2,
    dtAquisicao: 4,
    vlBase: 5,
    unidade: 7,
    sim: 8,
    nao: 9,
    transfPara: 10,
    dtTransf: 12,
    obs: 13,
  };

  for (let i = 0; i < lines.length; i++) {
    const rawLine = lines[i];

    // Detect section header
    const upperLine = rawLine.toUpperCase();
    if (upperLine.includes('TGC') && (upperLine.includes('ECOPARQUE') || upperLine.includes('GERÊNCIA') || upperLine.includes('GERENCIA') || upperLine.includes('CAJU'))) {
      currentGerencia = 'TGC';
      currentLocation = '144';
      currentCostCenter = '65020000';
    } else if (upperLine.includes('TDO') && (upperLine.includes('DIVISÃO DE OPERAÇÃO') || upperLine.includes('DIVISAO DE OPERACAO') || upperLine.includes('OPERAÇÃO') || upperLine.includes('OPERACAO'))) {
      currentGerencia = 'TDO';
      currentLocation = '284';
      currentCostCenter = '65020100';
    } else if (upperLine.includes('TDM') && (upperLine.includes('DIVISÃO DE MANUTENÇÃO') || upperLine.includes('DIVISAO DE MANUTENCAO') || upperLine.includes('MANUTENÇÃO') || upperLine.includes('MANUTENCAO'))) {
      currentGerencia = 'TDM';
      currentLocation = '145';
      currentCostCenter = '65020200';
    }

    const cols = parseCSVLine(rawLine);
    if (cols.length < 2) continue;

    // Check if this line is the column header row
    if (cols.some((c) => {
      const u = c.toUpperCase();
      return u.includes('PATRIMÔNIO') || u.includes('PATRIMONIO');
    })) {
      cols.forEach((col, idx) => {
        const c = col.toUpperCase();
        if (c.includes('PATRIM')) colMap.patrimonio = idx;
        else if (c.includes('DESCRI')) colMap.descricao = idx;
        else if (c.includes('COMPLEMENTO')) colMap.complemento = idx;
        else if (c.includes('AQUISI') || c.includes('DT. AQUISI') || c.includes('DATA')) colMap.dtAquisicao = idx;
        else if (c.includes('VL.') || c.includes('BASE') || c.includes('VALOR')) colMap.vlBase = idx;
        else if (c.includes('UNIDADE')) colMap.unidade = idx;
        else if (c.includes('TRANSFERIDO')) colMap.transfPara = idx;
        else if (c.includes('DT.TRANSF') || c.includes('DT TRANSF')) colMap.dtTransf = idx;
        else if (c.includes('OBSERV')) colMap.obs = idx;
      });
      continue;
    }

    const firstCol = (cols[colMap.patrimonio] || cols[0] || '').replace(/^["']|["']$/g, '').trim();

    // Skip metadata headers and non-asset lines
    if (
      !firstCol ||
      firstCol.length < 2 ||
      !/^[A-Za-z0-9\-_.]+$/.test(firstCol) ||
      firstCol.toUpperCase().includes('COMLURB') ||
      firstCol.toUpperCase().includes('RELATÓRIO') ||
      firstCol.toUpperCase().includes('LOCALIDADE') ||
      firstCol.toUpperCase().includes('CENTRO') ||
      firstCol.toUpperCase().includes('SIM') ||
      firstCol.toUpperCase().includes('NÃO')
    ) {
      continue;
    }

    const descricao = (cols[colMap.descricao] || cols[1] || '').replace(/^["']|["']$/g, '').trim();
    if (
      !descricao ||
      descricao.toUpperCase().includes('COMLURB') ||
      descricao.toUpperCase().includes('RELATÓRIO') ||
      descricao.toUpperCase().includes('LOCALIDADE')
    ) {
      continue;
    }

    const complemento = (cols[colMap.complemento] || (colMap.complemento !== 2 ? cols[2] : '') || '').replace(/^["']|["']$/g, '').trim();
    const dtAquisicao = parseDate(cols[colMap.dtAquisicao] || '');
    const vlBase = parseCurrency(cols[colMap.vlBase] || '0');
    const unidade = (cols[colMap.unidade] || currentGerencia).replace(/^["']|["']$/g, '').trim();

    // Unit determines gerencia if specified
    let gerenciaCode = currentGerencia;
    let localidade = currentLocation;
    let centroCusto = currentCostCenter;

    const unitUpper = unidade.toUpperCase();
    if (unitUpper.includes('TDO')) {
      gerenciaCode = 'TDO';
      localidade = '284';
      centroCusto = '65020100';
    } else if (unitUpper.includes('TDM')) {
      gerenciaCode = 'TDM';
      localidade = '145';
      centroCusto = '65020200';
    } else if (unitUpper.includes('TGC')) {
      gerenciaCode = 'TGC';
      localidade = '144';
      centroCusto = '65020000';
    }

    const gerenciaName =
      gerenciaCode === 'TGC'
        ? 'TGC - GERÊNCIA DE ECOPARQUE DO CAJU'
        : gerenciaCode === 'TDO'
        ? 'TDO - DIVISÃO DE OPERAÇÃO'
        : 'TDM - DIVISAO DE MANUTENÇÃO';

    const patrimonio = firstCol;
    const assetId = `${gerenciaCode.toLowerCase()}-${patrimonio}`;

    const asset: AssetItem = {
      id: assetId,
      patrimonio,
      descricao: descricao.toUpperCase(),
      complemento,
      dtAquisicao,
      vlBase,
      unidade: gerenciaCode,
      gerenciaCode,
      gerenciaName,
      localidade,
      centroCusto,
      categoria: getCategory(descricao),
    };

    assets.push(asset);
    byDepartment[gerenciaCode] = (byDepartment[gerenciaCode] || 0) + 1;

    // Optional inspection columns: Sim (col 8/colMap.sim), Não (col 9/colMap.nao), Transferido Para, Dt.Transf, Observação
    const simVal = (cols[colMap.sim] || '').trim().toLowerCase();
    const naoVal = (cols[colMap.nao] || '').trim().toLowerCase();
    const transfPara = (cols[colMap.transfPara] || '').trim();
    const dtTransf = parseDate(cols[colMap.dtTransf] || '');
    const obs = (cols[colMap.obs] || '').trim();

    let status: 'presente' | 'ausente' | 'transferido' | 'pendente' = 'pendente';
    if (simVal === 'x' || simVal === 's' || simVal === 'sim' || simVal === '1' || simVal === 'v') {
      status = 'presente';
    } else if (naoVal === 'x' || naoVal === 's' || naoVal === 'sim' || naoVal === '1' || naoVal === 'v') {
      status = 'ausente';
    } else if (transfPara) {
      status = 'transferido';
    }

    if (status !== 'pendente' || obs || transfPara) {
      inspectedCount++;
      inspections[`${assetId}-${targetYear}`] = {
        assetId,
        year: targetYear,
        status,
        condition: 'bom',
        tagCondition: 'legivel',
        observacao: obs,
        transferidoPara: transfPara || undefined,
        dtTransf: dtTransf || undefined,
        inspectedAt: new Date().toISOString(),
        inspectedBy: 'Importação Planilha COMLURB',
      };
    }
  }

  return {
    assets,
    inspections,
    summary: {
      total: assets.length,
      byDepartment,
      inspectedCount,
    },
  };
}
