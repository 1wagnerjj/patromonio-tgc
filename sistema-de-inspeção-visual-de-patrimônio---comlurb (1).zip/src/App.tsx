import React, { useState, useEffect, useMemo } from 'react';
import { Header } from './components/Header';
import { InspectionStats } from './components/InspectionStats';
import { AssetFilters } from './components/AssetFilters';
import { AssetTable } from './components/AssetTable';
import { AssetCardView } from './components/AssetCardView';
import { PrintableInspectionReport } from './components/PrintableInspectionReport';
import { PimacoLabelPrint } from './components/PimacoLabelPrint';
import { AnnualAuditComparison } from './components/AnnualAuditComparison';
import { TransfersAndDisposalsReport } from './components/TransfersAndDisposalsReport';
import { DisposalPhotoDossier } from './components/DisposalPhotoDossier';
import { GerenciaDashboard } from './components/GerenciaDashboard';
import { AssetModal } from './components/AssetModal';
import { AddAssetModal } from './components/AddAssetModal';
import { ImportExportModal } from './components/ImportExportModal';
import { PublicLinkModal } from './components/PublicLinkModal';
import { AccountSwitcherModal } from './components/AccountSwitcherModal';
import {
  INITIAL_ASSETS,
  SAMPLE_COMLURB_ASSETS,
  SAMPLE_COMLURB_INSPECTIONS,
  DEPARTMENTS,
  DEFAULT_AUDIT_SESSION,
  DEFAULT_DEPARTMENT_MANAGERS,
  INITIAL_INSPECTIONS,
} from './data/initialData';
import {
  AssetItem,
  InspectionRecord,
  FilterState,
  AuditSession,
  UserAccountProfile,
  DEFAULT_USER_ACCOUNTS,
} from './types';
import { exportAssetsToCSV } from './utils/formatters';
import {
  fetchFromCloud,
  pushToCloud,
  clearCloudDatabase,
  checkCloudStatus,
} from './utils/cloudSync';
import { loadLocalDatabase, saveLocalDatabase } from './utils/persistentStorage';
import { Globe, X, CheckCircle2, AlertTriangle, Info, Save, Users, RefreshCw } from 'lucide-react';

const STORAGE_KEYS = {
  ASSETS: 'comlurb_assets_clean_v2',
  INSPECTIONS: 'comlurb_inspections_clean_v2',
  AUDIT_SESSION: 'comlurb_audit_session_clean_v2',
  SELECTED_YEAR: 'comlurb_selected_year_clean_v2',
};

export default function App() {
  // User Account Profile & Multi-Account Synchronization
  const [activeAccount, setActiveAccount] = useState<UserAccountProfile>(() => {
    try {
      const saved = localStorage.getItem('comlurb_active_account_v2');
      if (saved) return JSON.parse(saved);
    } catch {}
    return DEFAULT_USER_ACCOUNTS[0]; // Default: Wagner J. Jardim
  });

  const [isAccountSwitcherOpen, setIsAccountSwitcherOpen] = useState(false);
  const [multiAccountNotice, setMultiAccountNotice] = useState<{
    visible: boolean;
    message: string;
    modifiedBy?: string;
  } | null>(null);

  const lastSyncTimestampRef = React.useRef<string>('');

  const handleSelectAccount = (account: UserAccountProfile) => {
    setActiveAccount(account);
    try {
      localStorage.setItem('comlurb_active_account_v2', JSON.stringify(account));
    } catch {}
  };

  // Load persistent state or fall back to clean empty dataset (INITIAL_ASSETS = [])
  const [assets, setAssets] = useState<AssetItem[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.ASSETS);
      if (saved !== null) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) {
          return parsed;
        }
      }
    } catch (e) {
      console.error(e);
    }
    return INITIAL_ASSETS;
  });

  const [inspections, setInspections] = useState<Record<string, InspectionRecord>>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.INSPECTIONS);
      if (saved !== null) {
        const parsed = JSON.parse(saved);
        if (parsed && typeof parsed === 'object') {
          return parsed;
        }
      }
    } catch (e) {
      console.error(e);
    }
    return INITIAL_INSPECTIONS;
  });

  const [auditSession, setAuditSession] = useState<AuditSession>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.AUDIT_SESSION);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (!parsed.departmentManagers) {
          parsed.departmentManagers = DEFAULT_DEPARTMENT_MANAGERS;
        }
        return parsed;
      }
    } catch (e) {
      console.error(e);
    }
    return DEFAULT_AUDIT_SESSION;
  });

  // Dynamically merge department manager details into department list
  const departmentsWithManagers = useMemo(() => {
    return DEPARTMENTS.map((dept) => {
      const mgr = auditSession.departmentManagers?.[dept.code];
      if (mgr) {
        return {
          ...dept,
          gerenteNome: mgr.gerenteNome || dept.gerenteNome,
          gerenteMatricula: mgr.gerenteMatricula || dept.gerenteMatricula,
          gerenteCargo: mgr.gerenteCargo || dept.gerenteCargo,
          fiscalNome: mgr.fiscalNome || dept.fiscalNome,
          fiscalMatricula: mgr.fiscalMatricula || dept.fiscalMatricula,
          statusInspecao: mgr.statusInspecao || dept.statusInspecao,
          dataConclusao: mgr.dataConclusao || dept.dataConclusao,
          observacoes: mgr.observacoes || dept.observacoes,
        };
      }
      return dept;
    });
  }, [auditSession.departmentManagers]);

  const [selectedYear, setSelectedYear] = useState<number>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.SELECTED_YEAR);
      if (saved) return Number(saved);
    } catch (e) {
      console.error(e);
    }
    return 2025;
  });

  // Filter state
  const [filters, setFilters] = useState<FilterState>({
    gerencia: 'ALL',
    status: 'ALL',
    situacao: 'ALL',
    searchTerm: '',
    categoria: 'ALL',
    viewMode: 'table',
  });

  // Selection state for batch actions
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());

  // Modals state
  const [activeAssetDetails, setActiveAssetDetails] = useState<AssetItem | null>(null);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isImportExportOpen, setIsImportExportOpen] = useState(false);
  const [isPublicLinkOpen, setIsPublicLinkOpen] = useState(false);
  const [isPublicAccess, setIsPublicAccess] = useState(false);

  // Cloud synchronization state
  const [cloudStatus, setCloudStatus] = useState<'synced' | 'syncing' | 'error' | 'offline'>('synced');
  const [lastSyncTime, setLastSyncTime] = useState<string>('');
  const [isInitialHydrated, setIsInitialHydrated] = useState(false);

  // Disposal photos & batch metadata state (with IndexedDB & Cloud syncing)
  const [disposalPhotos, setDisposalPhotos] = useState<Record<string, string>>(() => {
    try {
      const saved = localStorage.getItem('comlurb_disposal_photos_v2');
      if (saved) return JSON.parse(saved);
    } catch {}
    return {};
  });

  const [disposalBatchMeta, setDisposalBatchMeta] = useState<Record<string, any>>(() => {
    try {
      const saved = localStorage.getItem('comlurb_disposal_batch_meta_v2');
      if (saved) return JSON.parse(saved);
    } catch {}
    return {};
  });

  // Manual save & unsaved changes tracking
  const [hasPendingChanges, setHasPendingChanges] = useState<boolean>(false);
  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [saveToast, setSaveToast] = useState<{
    visible: boolean;
    message: string;
    details?: string;
    type: 'success' | 'error' | 'info';
  } | null>(null);

  // Auto-dismiss toast after 5s
  useEffect(() => {
    if (!saveToast?.visible) return;
    const timer = setTimeout(() => {
      setSaveToast((prev) => (prev ? { ...prev, visible: false } : null));
    }, 5000);
    return () => clearTimeout(timer);
  }, [saveToast]);

  // URL query parameter parsing on load
  useEffect(() => {
    if (typeof window === 'undefined') return;
    try {
      const params = new URLSearchParams(window.location.search);
      const isPublic = params.get('public') === 'true';
      if (isPublic) {
        setIsPublicAccess(true);
      }

      const yearParam = params.get('year');
      if (yearParam && !isNaN(Number(yearParam))) {
        setSelectedYear(Number(yearParam));
      }

      const gerenciaParam = params.get('gerencia');
      const statusParam = params.get('status');
      const categoriaParam = params.get('categoria');
      const situacaoParam = params.get('situacao') as any;
      const viewParam = params.get('view') as any;
      const searchParam = params.get('search');
      const patrimonioParam = params.get('patrimonio');

      setFilters((prev) => ({
        ...prev,
        gerencia: gerenciaParam || prev.gerencia,
        status: statusParam || prev.status,
        categoria: categoriaParam || prev.categoria,
        situacao: situacaoParam || prev.situacao,
        viewMode: viewParam || prev.viewMode,
        searchTerm: searchParam || prev.searchTerm,
      }));

      if (patrimonioParam) {
        const found = assets.find(
          (a) => a.patrimonio.toLowerCase() === patrimonioParam.toLowerCase().trim()
        );
        if (found) {
          setActiveAssetDetails(found);
        }
      }
    } catch (e) {
      console.error('Error parsing URL params', e);
    }
  }, []);

  // Sync to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.ASSETS, JSON.stringify(assets));
    } catch (e) {
      console.error('Error saving assets to localStorage', e);
    }
  }, [assets]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.INSPECTIONS, JSON.stringify(inspections));
    } catch (e) {
      console.error('Error saving inspections to localStorage', e);
    }
  }, [inspections]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.AUDIT_SESSION, JSON.stringify(auditSession));
    } catch (e) {
      console.error('Error saving auditSession to localStorage', e);
    }
  }, [auditSession]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.SELECTED_YEAR, selectedYear.toString());
    } catch (e) {
      console.error('Error saving selectedYear to localStorage', e);
    }
  }, [selectedYear]);

  // Initial cloud synchronization & robust local database restoration on mount
  useEffect(() => {
    let isMounted = true;

    const initData = async () => {
      try {
        setCloudStatus('syncing');

        // 1. First restore full data from IndexedDB (survives 5MB localStorage limits)
        const localDb = await loadLocalDatabase();
        if (localDb && Array.isArray(localDb.assets) && localDb.assets.length > 0) {
          setAssets(localDb.assets);
          if (localDb.inspections) setInspections(localDb.inspections);
          if (localDb.disposalPhotos) setDisposalPhotos(localDb.disposalPhotos);
          if (localDb.disposalBatchMeta) setDisposalBatchMeta(localDb.disposalBatchMeta);
          if (localDb.selectedYear) setSelectedYear(localDb.selectedYear);
        }

        // 2. Fetch server cloud data
        const cloudRes = await fetchFromCloud();
        if (!isMounted) return;

        if (cloudRes.success && cloudRes.data && Array.isArray(cloudRes.data.assets) && cloudRes.data.assets.length > 0) {
          // Intelligent reconciliation: never wipe local baixas or photos
          setAssets((currentLocalAssets) => {
            return cloudRes.data!.assets.map((cloudAsset) => {
              const localAsset = currentLocalAssets.find((a) => a.id === cloudAsset.id);
              if (localAsset && localAsset.situacao === 'baixado' && cloudAsset.situacao !== 'baixado') {
                return {
                  ...cloudAsset,
                  situacao: 'baixado',
                  motivoBaixa: localAsset.motivoBaixa,
                  dtBaixa: localAsset.dtBaixa,
                  fotoUrl: localAsset.fotoUrl || cloudAsset.fotoUrl,
                };
              }
              if (localAsset?.fotoUrl && !cloudAsset.fotoUrl) {
                return { ...cloudAsset, fotoUrl: localAsset.fotoUrl };
              }
              return cloudAsset;
            });
          });

          if (cloudRes.data.inspections) {
            setInspections((prev) => ({
              ...(cloudRes.data?.inspections || {}),
              ...prev,
            }));
          }

          if (cloudRes.data.departmentManagers) {
            setAuditSession((prev) => ({
              ...prev,
              departmentManagers: cloudRes.data!.departmentManagers || prev.departmentManagers,
            }));
          }

          if (cloudRes.data.disposalPhotos) {
            setDisposalPhotos((prev) => {
              const merged = { ...cloudRes.data!.disposalPhotos, ...prev };
              try {
                localStorage.setItem('comlurb_disposal_photos_v2', JSON.stringify(merged));
              } catch {}
              return merged;
            });
          }

          if (cloudRes.data.disposalBatchMeta) {
            setDisposalBatchMeta((prev) => {
              const merged = { ...cloudRes.data!.disposalBatchMeta, ...prev };
              try {
                localStorage.setItem('comlurb_disposal_batch_meta_v2', JSON.stringify(merged));
              } catch {}
              return merged;
            });
          }

          setCloudStatus('synced');
          const ts = cloudRes.timestamp || new Date().toISOString();
          setLastSyncTime(ts);
          lastSyncTimestampRef.current = ts;
        } else {
          // Cloud server has no data yet - seed with our complete local state
          const initialModifier = `${activeAccount.name} (${activeAccount.email})`;
          const pushRes = await pushToCloud({
            assets: localDb?.assets || assets,
            inspections: localDb?.inspections || inspections,
            disposalPhotos: localDb?.disposalPhotos || disposalPhotos,
            disposalBatchMeta: localDb?.disposalBatchMeta || disposalBatchMeta,
            departmentManagers: auditSession.departmentManagers || DEFAULT_DEPARTMENT_MANAGERS,
            selectedYear,
            modifiedBy: initialModifier,
          });
          if (pushRes.success) {
            setCloudStatus('synced');
            const ts = pushRes.timestamp || new Date().toISOString();
            setLastSyncTime(ts);
            lastSyncTimestampRef.current = ts;
          } else {
            setCloudStatus('synced');
          }
        }
      } catch (err) {
        console.warn('Falha na inicialização da nuvem/armazenamento:', err);
        setCloudStatus('synced');
      } finally {
        if (isMounted) setIsInitialHydrated(true);
      }
    };

    initData();

    return () => {
      isMounted = false;
    };
  }, []);

  // Multi-Account Reconciliation Helper
  const reconcileWithCloudData = React.useCallback(
    async (cloudData: any, modifierName?: string) => {
      if (!cloudData || !Array.isArray(cloudData.assets)) return;

      // Intelligent reconciliation of assets:
      setAssets((currentLocalAssets) => {
        const serverMap = new Map<string, any>();
        cloudData.assets.forEach((a: any) => {
          if (a.id) serverMap.set(String(a.id), a);
          if (a.patrimonio) serverMap.set(`pat_${a.patrimonio}`, a);
        });

        return currentLocalAssets.map((localAsset) => {
          const keyId = String(localAsset.id);
          const serverAsset = serverMap.get(keyId) || serverMap.get(`pat_${localAsset.patrimonio}`);
          if (!serverAsset) return localAsset;

          // If server marked as baixado, honor server
          let finalSituacao = serverAsset.situacao || localAsset.situacao;
          let finalMotivo = serverAsset.motivoBaixa || localAsset.motivoBaixa;
          let finalDtBaixa = serverAsset.dtBaixa || localAsset.dtBaixa;

          // If local had baixado and server didn't explicitly reactivate, keep baixado
          if (localAsset.situacao === 'baixado' && serverAsset.situacao !== 'baixado' && !serverAsset.wasReactivated) {
            finalSituacao = 'baixado';
            finalMotivo = localAsset.motivoBaixa;
            finalDtBaixa = localAsset.dtBaixa;
          }

          const finalFoto = serverAsset.fotoUrl || localAsset.fotoUrl;

          return {
            ...localAsset,
            ...serverAsset,
            situacao: finalSituacao,
            motivoBaixa: finalMotivo,
            dtBaixa: finalDtBaixa,
            fotoUrl: finalFoto,
          };
        });
      });

      if (cloudData.inspections) {
        setInspections((prev) => ({
          ...prev,
          ...cloudData.inspections,
        }));
      }

      if (cloudData.disposalPhotos) {
        setDisposalPhotos((prev) => {
          const merged = { ...prev, ...cloudData.disposalPhotos };
          try {
            localStorage.setItem('comlurb_disposal_photos_v2', JSON.stringify(merged));
          } catch {}
          return merged;
        });
      }

      if (cloudData.disposalBatchMeta) {
        setDisposalBatchMeta((prev) => {
          const merged = { ...prev, ...cloudData.disposalBatchMeta };
          try {
            localStorage.setItem('comlurb_disposal_batch_meta_v2', JSON.stringify(merged));
          } catch {}
          return merged;
        });
      }

      if (cloudData.departmentManagers) {
        setAuditSession((prev) => ({
          ...prev,
          departmentManagers: cloudData.departmentManagers || prev.departmentManagers,
        }));
      }

      setCloudStatus('synced');
      const ts = cloudData.lastModified || new Date().toISOString();
      setLastSyncTime(ts);
      lastSyncTimestampRef.current = ts;

      // Save to local IndexedDB to mirror fresh cloud state
      await saveLocalDatabase({
        assets: cloudData.assets,
        inspections: cloudData.inspections,
        disposalPhotos: cloudData.disposalPhotos,
        disposalBatchMeta: cloudData.disposalBatchMeta,
        departmentManagers: cloudData.departmentManagers,
        selectedYear,
        modifiedBy: modifierName || 'Sincronização Nuvem Multi-Contas',
      });

      if (modifierName) {
        setMultiAccountNotice({
          visible: true,
          message: `Atualizações recebidas da conta: ${modifierName}`,
          modifiedBy: modifierName,
        });
        setTimeout(() => {
          setMultiAccountNotice((prev) => (prev ? { ...prev, visible: false } : null));
        }, 4000);
      }
    },
    [selectedYear]
  );

  // Real-Time Multi-Account Tab Broadcast Listener
  useEffect(() => {
    let channel: BroadcastChannel | null = null;
    try {
      channel = new BroadcastChannel('comlurb_multi_account_sync_v2');
      channel.onmessage = async (e) => {
        if (e.data?.type === 'SAVED_MODIFICATIONS') {
          const res = await fetchFromCloud();
          if (res.success && res.data) {
            await reconcileWithCloudData(res.data, e.data.modifiedBy);
          }
        }
      };
    } catch {
      // BroadcastChannel unsupported or restricted in some iframes
    }

    return () => {
      if (channel) channel.close();
    };
  }, [reconcileWithCloudData]);

  // Background Cloud Status Polling (Every 4 seconds across all accounts/devices)
  useEffect(() => {
    if (!isInitialHydrated) return;

    const interval = setInterval(async () => {
      try {
        const status = await checkCloudStatus();
        if (
          status &&
          status.hasData &&
          status.timestamp &&
          lastSyncTimestampRef.current &&
          status.timestamp !== lastSyncTimestampRef.current
        ) {
          const serverTime = new Date(status.timestamp).getTime();
          const localTime = new Date(lastSyncTimestampRef.current).getTime();
          if (serverTime > localTime) {
            const res = await fetchFromCloud();
            if (res.success && res.data) {
              await reconcileWithCloudData(res.data, status.modifiedBy);
            }
          }
        }
      } catch {
        // quiet poll
      }
    }, 4000);

    return () => clearInterval(interval);
  }, [isInitialHydrated, reconcileWithCloudData]);

  // Background auto-save to IndexedDB and Cloud (400ms debounce)
  useEffect(() => {
    if (!isInitialHydrated) return;

    const timer = setTimeout(async () => {
      try {
        setCloudStatus('syncing');
        const modifierLabel = `${activeAccount.name} (${activeAccount.email})`;

        // Save locally to IndexedDB
        await saveLocalDatabase({
          assets,
          inspections,
          disposalPhotos,
          disposalBatchMeta,
          departmentManagers: auditSession.departmentManagers,
          selectedYear,
          modifiedBy: modifierLabel,
        });

        // Push to server cloud
        const pushRes = await pushToCloud({
          assets,
          inspections,
          disposalPhotos,
          disposalBatchMeta,
          departmentManagers: auditSession.departmentManagers,
          selectedYear,
          modifiedBy: modifierLabel,
        });

        if (pushRes.success) {
          setCloudStatus('synced');
          const ts = pushRes.timestamp || new Date().toISOString();
          setLastSyncTime(ts);
          lastSyncTimestampRef.current = ts;
        } else {
          setCloudStatus('error');
        }
      } catch {
        setCloudStatus('error');
      }
    }, 400);

    return () => clearTimeout(timer);
  }, [assets, inspections, disposalPhotos, disposalBatchMeta, auditSession, selectedYear, isInitialHydrated, activeAccount]);

  // Flush to cloud & IndexedDB on page exit or visibility change
  useEffect(() => {
    if (!isInitialHydrated) return;

    const handleExitFlush = () => {
      const modifierLabel = `${activeAccount.name} (${activeAccount.email})`;
      saveLocalDatabase({
        assets,
        inspections,
        disposalPhotos,
        disposalBatchMeta,
        departmentManagers: auditSession.departmentManagers,
        selectedYear,
        modifiedBy: modifierLabel,
      });

      pushToCloud({
        assets,
        inspections,
        disposalPhotos,
        disposalBatchMeta,
        departmentManagers: auditSession.departmentManagers,
        selectedYear,
        modifiedBy: modifierLabel,
      });
    };

    window.addEventListener('beforeunload', handleExitFlush);
    const handleVisibility = () => {
      if (document.visibilityState === 'hidden') {
        handleExitFlush();
      }
    };
    document.addEventListener('visibilitychange', handleVisibility);

    return () => {
      window.removeEventListener('beforeunload', handleExitFlush);
      document.removeEventListener('visibilitychange', handleVisibility);
    };
  }, [assets, inspections, disposalPhotos, disposalBatchMeta, auditSession, selectedYear, isInitialHydrated, activeAccount]);

  // MANUAL SAVE ALL MODIFICATIONS (Requested by user)
  const handleSaveAllModifications = async () => {
    setIsSaving(true);
    setCloudStatus('syncing');
    try {
      const modifierLabel = `${activeAccount.name} (${activeAccount.email})`;

      // 1. Save to local IndexedDB & localStorage
      await saveLocalDatabase({
        assets,
        inspections,
        disposalPhotos,
        disposalBatchMeta,
        departmentManagers: auditSession.departmentManagers,
        selectedYear,
        modifiedBy: modifierLabel,
      });

      // 2. Push to backend cloud store
      const pushRes = await pushToCloud({
        assets,
        inspections,
        disposalPhotos,
        disposalBatchMeta,
        departmentManagers: auditSession.departmentManagers,
        selectedYear,
        modifiedBy: modifierLabel,
      });

      const baixadosCount = assets.filter((a) => a.situacao === 'baixado').length;
      const photosCount = Object.keys(disposalPhotos).length;

      const newTimestamp = pushRes.timestamp || new Date().toISOString();
      lastSyncTimestampRef.current = newTimestamp;
      setHasPendingChanges(false);
      setCloudStatus('synced');
      setLastSyncTime(newTimestamp);

      // 3. Broadcast to all open tabs/accounts on this machine immediately
      try {
        const channel = new BroadcastChannel('comlurb_multi_account_sync_v2');
        channel.postMessage({
          type: 'SAVED_MODIFICATIONS',
          timestamp: newTimestamp,
          modifiedBy: modifierLabel,
        });
        channel.close();
      } catch {}

      setSaveToast({
        visible: true,
        type: 'success',
        message: 'Modificações salvas e integradas entre todas as contas!',
        details: `Salvo pela conta: ${activeAccount.name} (${activeAccount.email}) • ${assets.length} bens (${baixadosCount} baixados), ${photosCount} fotos de baixa e todas as vistorias sincronizadas no servidor central para todas as contas e dispositivos.`,
      });
    } catch (err: any) {
      console.error('Erro ao salvar modificações:', err);
      setCloudStatus('error');
      setSaveToast({
        visible: true,
        type: 'error',
        message: 'Modificações salvas com segurança no navegador.',
        details: 'Houve instabilidade temporária ao sincronizar com o servidor, mas todos os dados estão salvos localmente.',
      });
    } finally {
      setIsSaving(false);
    }
  };

  // Photo save handler from dossier
  const handleSaveDisposalPhoto = async (assetId: string, patrimonio: string, photoUrl: string) => {
    const updatedPhotos = { ...disposalPhotos, [assetId]: photoUrl, [patrimonio]: photoUrl };
    setDisposalPhotos(updatedPhotos);

    const updatedAssets = assets.map((item) =>
      item.id === assetId || item.patrimonio === patrimonio ? { ...item, fotoUrl: photoUrl } : item
    );
    setAssets(updatedAssets);
    setHasPendingChanges(false);

    // Save immediately so it is never lost on refresh
    await saveLocalDatabase({
      assets: updatedAssets,
      inspections,
      disposalPhotos: updatedPhotos,
      disposalBatchMeta,
      departmentManagers: auditSession.departmentManagers,
      selectedYear,
      modifiedBy: 'Wagner J. Jardim (Foto Salva)',
    });

    pushToCloud({
      assets: updatedAssets,
      inspections,
      disposalPhotos: updatedPhotos,
      disposalBatchMeta,
      departmentManagers: auditSession.departmentManagers,
      selectedYear,
      modifiedBy: 'Wagner J. Jardim (Foto Salva)',
    });
  };

  // Batch meta update handler from dossier
  const handleUpdateDisposalBatchMeta = (gerencia: string, meta: any) => {
    const updatedMeta = { ...disposalBatchMeta, [gerencia]: { ...(disposalBatchMeta[gerencia] || {}), ...meta } };
    setDisposalBatchMeta(updatedMeta);
    setHasPendingChanges(true);
  };

  // Force manual cloud sync handler
  const handleForceCloudSync = async () => {
    await handleSaveAllModifications();
  };

  // Categories extraction
  const categories = useMemo(() => {
    const set = new Set<string>();
    assets.forEach((a) => {
      if (a.categoria) set.add(a.categoria);
    });
    return Array.from(set).sort();
  }, [assets]);

  // Counts by department
  const countsByDepartment = useMemo(() => {
    const counts: Record<string, number> = { ALL: assets.length };
    DEPARTMENTS.forEach((dept) => {
      counts[dept.code] = assets.filter((a) => a.gerenciaCode === dept.code).length;
    });
    return counts;
  }, [assets]);

  // Filtered Assets list
  const filteredAssets = useMemo(() => {
    return assets.filter((asset) => {
      // Gerência Filter
      if (filters.gerencia !== 'ALL' && asset.gerenciaCode !== filters.gerencia) {
        return false;
      }

      // Status Filter
      if (filters.status !== 'ALL') {
        const insp = inspections[`${asset.id}-${selectedYear}`];
        const status = insp?.status || 'pendente';
        if (status !== filters.status) return false;
      }

      // Categoria Filter
      if (filters.categoria !== 'ALL' && asset.categoria !== filters.categoria) {
        return false;
      }

      // Situação Filter (Ativo / Baixado)
      if (filters.situacao && filters.situacao !== 'ALL') {
        const sit = asset.situacao || 'ativo';
        if (sit !== filters.situacao) return false;
      }

      // Search Filter
      if (filters.searchTerm) {
        const term = filters.searchTerm.toLowerCase();
        const matchPatrimonio = asset.patrimonio.toLowerCase().includes(term);
        const matchDesc = asset.descricao.toLowerCase().includes(term);
        const matchComp = asset.complemento.toLowerCase().includes(term);
        const matchUnid = asset.unidade.toLowerCase().includes(term);
        if (!matchPatrimonio && !matchDesc && !matchComp && !matchUnid) {
          return false;
        }
      }

      return true;
    });
  }, [assets, inspections, selectedYear, filters]);

  // Update inspection single record
  const handleUpdateInspection = (assetId: string, updates: Partial<InspectionRecord>) => {
    const key = `${assetId}-${selectedYear}`;
    setInspections((prev) => {
      const existing = prev[key] || {
        assetId,
        year: selectedYear,
        status: 'pendente',
        condition: 'nao_avaliado',
        observacao: '',
      };

      let tagCondition = updates.tagCondition !== undefined ? updates.tagCondition : existing.tagCondition;
      if (
        updates.condition &&
        (updates.condition === 'bom' || updates.condition === 'excelente') &&
        updates.tagCondition === undefined
      ) {
        tagCondition = 'legivel';
      }

      const next = {
        ...prev,
        [key]: {
          ...existing,
          ...updates,
          tagCondition,
          year: selectedYear,
          assetId,
          inspectedAt: updates.inspectedAt || existing.inspectedAt || new Date().toISOString(),
        },
      };

      try {
        localStorage.setItem(STORAGE_KEYS.INSPECTIONS, JSON.stringify(next));
      } catch (err) {
        console.error('Local backup failed', err);
      }

      return next;
    });
    setHasPendingChanges(true);
  };

  // Batch toggle status (e.g. mark selected as 'presente' or 'ausente')
  const handleBatchSetStatus = (status: 'presente' | 'ausente') => {
    const updates: Record<string, InspectionRecord> = {};
    selectedIds.forEach((id) => {
      const key = `${id}-${selectedYear}`;
      const existing = inspections[key] || {
        assetId: id,
        year: selectedYear,
        status: 'pendente',
        condition: 'nao_avaliado',
        observacao: '',
      };
      updates[key] = {
        ...existing,
        status,
        inspectedAt: new Date().toISOString(),
      };
    });

    setInspections((prev) => ({
      ...prev,
      ...updates,
    }));
    setSelectedIds(new Set());
    setHasPendingChanges(true);
  };

  // Selection handlers
  const handleToggleSelect = (id: string) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  const handleSelectAll = (selectAll: boolean) => {
    if (selectAll) {
      setSelectedIds(new Set(filteredAssets.map((a) => a.id)));
    } else {
      setSelectedIds(new Set());
    }
  };

  // Add new asset
  const handleAddAsset = (newAsset: AssetItem) => {
    setAssets((prev) => [newAsset, ...prev]);
    setHasPendingChanges(true);
  };

  // Update existing asset properties (such as situacao, dtBaixa, motivoBaixa)
  const handleUpdateAsset = (assetId: string, updates: Partial<AssetItem>) => {
    setAssets((prev) =>
      prev.map((item) => (item.id === assetId ? { ...item, ...updates } : item))
    );
    setActiveAssetDetails((prev) =>
      prev && prev.id === assetId ? { ...prev, ...updates } : prev
    );
    setHasPendingChanges(true);

    // If marking as 'baixado' or updating photos, save immediately to IndexedDB
    if (updates.situacao === 'baixado' || updates.fotoUrl) {
      setTimeout(() => {
        saveLocalDatabase({
          assets: assets.map((item) => (item.id === assetId ? { ...item, ...updates } : item)),
          inspections,
          disposalPhotos,
          disposalBatchMeta,
          departmentManagers: auditSession.departmentManagers,
          selectedYear,
          modifiedBy: 'Wagner J. Jardim (Baixa Atualizada)',
        });
      }, 0);
    }
  };

  // Clear all data completely (Zerar base de dados)
  const handleClearAllData = async () => {
    setAssets([]);
    setInspections({});
    setSelectedIds(new Set());
    setActiveAssetDetails(null);
    localStorage.setItem(STORAGE_KEYS.ASSETS, JSON.stringify([]));
    localStorage.setItem(STORAGE_KEYS.INSPECTIONS, JSON.stringify({}));
    // Remove all old versions of storage
    localStorage.removeItem('comlurb_assets_v1');
    localStorage.removeItem('comlurb_inspections_v1');
    localStorage.removeItem('comlurb_disposal_photos');
    localStorage.removeItem('comlurb_disposal_meta');
    localStorage.removeItem('comlurb_disposal_photos_v2');
    localStorage.removeItem('comlurb_disposal_batch_meta_v2');
    await clearCloudDatabase();
    setCloudStatus('synced');
  };

  // Reset to empty default
  const handleResetToDefaults = () => {
    handleClearAllData();
  };

  // Load sample demonstration data (139 itens)
  const handleLoadSampleData = () => {
    setAssets(SAMPLE_COMLURB_ASSETS);
    setInspections(SAMPLE_COMLURB_INSPECTIONS);
    localStorage.setItem(STORAGE_KEYS.ASSETS, JSON.stringify(SAMPLE_COMLURB_ASSETS));
    localStorage.setItem(STORAGE_KEYS.INSPECTIONS, JSON.stringify(SAMPLE_COMLURB_INSPECTIONS));
  };

  // Restore data from backup
  const handleRestoreData = (newAssets: AssetItem[], newInspections: Record<string, InspectionRecord>) => {
    setAssets(newAssets);
    setInspections(newInspections);
  };

  // Export CSV handler
  const handleExportCSV = () => {
    const gerenciaTitle =
      filters.gerencia === 'ALL' ? 'Geral_Todas_Gerencias' : `Gerencia_${filters.gerencia}`;
    exportAssetsToCSV(filteredAssets, inspections, selectedYear, `COMLURB_${gerenciaTitle}`);
  };

  // Print view handler
  const handlePrint = () => {
    setFilters((prev) => ({ ...prev, viewMode: 'print_preview' }));
  };

  // Open Pimaco labels for a single specific asset
  const handleOpenLabelForAsset = (asset: AssetItem) => {
    setSelectedIds(new Set([asset.id]));
    setFilters((prev) => ({ ...prev, viewMode: 'pimaco_labels' }));
  };

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col font-sans">
      {/* Top Navbar Header */}
      <Header
        selectedYear={selectedYear}
        onYearChange={setSelectedYear}
        auditSession={auditSession}
        onUpdateAuditSession={(updates) => setAuditSession((prev) => ({ ...prev, ...updates }))}
        onOpenAddAsset={() => setIsAddModalOpen(true)}
        onOpenImportExport={() => setIsImportExportOpen(true)}
        onOpenPublicLink={() => setIsPublicLinkOpen(true)}
        onPrint={handlePrint}
        onOpenLabelsPrint={() => setFilters((prev) => ({ ...prev, viewMode: 'pimaco_labels' }))}
        onOpenDisposalPhotos={() => setFilters((prev) => ({ ...prev, viewMode: 'disposal_photos' }))}
        onExportCSV={handleExportCSV}
        onResetData={handleResetToDefaults}
        onClearAllData={handleClearAllData}
        cloudStatus={cloudStatus}
        lastSyncTime={lastSyncTime}
        onForceSync={handleForceCloudSync}
        onSaveAllModifications={handleSaveAllModifications}
        isSaving={isSaving}
        hasPendingChanges={hasPendingChanges}
        activeAccount={activeAccount}
        onOpenAccountSwitcher={() => setIsAccountSwitcherOpen(true)}
      />

      {/* Public Access Banner (if opened via public link) */}
      {isPublicAccess && (
        <div className="bg-blue-900 text-blue-50 px-4 py-2 text-xs flex items-center justify-between shadow-xs no-print">
          <div className="max-w-7xl mx-auto w-full flex items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <Globe className="w-4 h-4 text-blue-300 shrink-0" />
              <span>
                <strong>Modo de Consulta Pública / Link Compartilhado:</strong> Você está visualizando o inventário patrimonial oficial da COMLURB no exercício {selectedYear}.
              </span>
            </div>
            <button
              onClick={() => setIsPublicAccess(false)}
              className="text-blue-300 hover:text-white p-1 rounded-md transition-colors cursor-pointer shrink-0"
              title="Fechar aviso"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl 2xl:max-w-[1500px] w-full mx-auto p-4 sm:p-6 space-y-5">
        {/* KPI & Statistics Progress Dashboard */}
        {filters.viewMode !== 'print_preview' &&
          filters.viewMode !== 'pimaco_labels' &&
          filters.viewMode !== 'disposal_photos' && (
            <InspectionStats
              assets={filteredAssets}
              inspections={inspections}
              selectedYear={selectedYear}
              activeDepartment={filters.gerencia}
              departments={departmentsWithManagers}
              departmentManagers={auditSession.departmentManagers}
            />
          )}

        {/* Filters and Navigation Toolbar */}
        <AssetFilters
          filters={filters}
          onFilterChange={(newFilters) => setFilters((prev) => ({ ...prev, ...newFilters }))}
          departments={departmentsWithManagers}
          categories={categories}
          countsByDepartment={countsByDepartment}
          selectedCount={selectedIds.size}
          totalFilteredCount={filteredAssets.length}
          onBatchSetStatus={handleBatchSetStatus}
          onClearSelection={() => setSelectedIds(new Set())}
        />

        {/* View Mode Switching */}
        {filters.viewMode === 'table' && (
          <AssetTable
            assets={filteredAssets}
            inspections={inspections}
            selectedYear={selectedYear}
            selectedIds={selectedIds}
            onToggleSelect={handleToggleSelect}
            onSelectAll={handleSelectAll}
            onUpdateInspection={handleUpdateInspection}
            onUpdateAsset={handleUpdateAsset}
            onOpenDetails={(asset) => setActiveAssetDetails(asset)}
            onOpenLabelForAsset={handleOpenLabelForAsset}
            onOpenImport={() => setIsImportExportOpen(true)}
          />
        )}

        {filters.viewMode === 'cards' && (
          <AssetCardView
            assets={filteredAssets}
            inspections={inspections}
            selectedYear={selectedYear}
            selectedIds={selectedIds}
            onToggleSelect={handleToggleSelect}
            onUpdateInspection={handleUpdateInspection}
            onUpdateAsset={handleUpdateAsset}
            onOpenDetails={(asset) => setActiveAssetDetails(asset)}
            onOpenLabelForAsset={handleOpenLabelForAsset}
          />
        )}

        {filters.viewMode === 'pimaco_labels' && (
          <PimacoLabelPrint
            assets={assets}
            filteredAssets={filteredAssets}
            inspections={inspections}
            departments={departmentsWithManagers}
            selectedYear={selectedYear}
            selectedAssetIds={selectedIds}
            initialDept={filters.gerencia}
            onClose={() => setFilters((prev) => ({ ...prev, viewMode: 'table' }))}
          />
        )}

        {filters.viewMode === 'print_preview' && (
          <PrintableInspectionReport
            assets={filteredAssets}
            inspections={inspections}
            departments={departmentsWithManagers}
            selectedYear={selectedYear}
            selectedGerencia={filters.gerencia}
            auditSession={auditSession}
            onUpdateAuditSession={(updates) => setAuditSession((prev) => ({ ...prev, ...updates }))}
            onClosePreview={() => setFilters((prev) => ({ ...prev, viewMode: 'table' }))}
          />
        )}

        {filters.viewMode === 'dashboard' && (
          <GerenciaDashboard
            assets={assets}
            inspections={inspections}
            departments={departmentsWithManagers}
            selectedYear={selectedYear}
            initialGerencia={filters.gerencia}
            auditSession={auditSession}
            onOpenDetails={(asset) => setActiveAssetDetails(asset)}
            onClose={() => setFilters((prev) => ({ ...prev, viewMode: 'table' }))}
          />
        )}

        {filters.viewMode === 'transfers_and_disposals' && (
          <TransfersAndDisposalsReport
            assets={assets}
            inspections={inspections}
            departments={departmentsWithManagers}
            selectedYear={selectedYear}
            selectedGerencia={filters.gerencia}
            auditSession={auditSession}
            onUpdateInspection={handleUpdateInspection}
            onUpdateAsset={handleUpdateAsset}
            onOpenDetails={(asset) => setActiveAssetDetails(asset)}
            onOpenLabelForAsset={handleOpenLabelForAsset}
            onOpenDisposalPhotos={() => setFilters((prev) => ({ ...prev, viewMode: 'disposal_photos' }))}
            onClose={() => setFilters((prev) => ({ ...prev, viewMode: 'table' }))}
          />
        )}

        {filters.viewMode === 'annual_compare' && (
          <AnnualAuditComparison
            assets={assets}
            inspections={inspections}
            departments={departmentsWithManagers}
            currentYear={selectedYear}
          />
        )}

        {filters.viewMode === 'disposal_photos' && (
          <DisposalPhotoDossier
            assets={assets}
            departments={departmentsWithManagers}
            selectedYear={selectedYear}
            selectedGerencia={filters.gerencia}
            onSelectGerencia={(g) => setFilters((prev) => ({ ...prev, gerencia: g }))}
            onUpdateAsset={handleUpdateAsset}
            onClose={() => setFilters((prev) => ({ ...prev, viewMode: 'table' }))}
            disposalPhotos={disposalPhotos}
            onSavePhoto={handleSaveDisposalPhoto}
            disposalBatchMeta={disposalBatchMeta}
            onUpdateDisposalBatchMeta={handleUpdateDisposalBatchMeta}
            onManualSaveAll={handleSaveAllModifications}
            isSaving={isSaving}
          />
        )}
      </main>

      {/* Asset Inspection Details Modal */}
      {activeAssetDetails && (
        <AssetModal
          asset={activeAssetDetails}
          inspections={inspections}
          selectedYear={selectedYear}
          onClose={() => setActiveAssetDetails(null)}
          onSaveInspection={handleUpdateInspection}
          onUpdateAsset={handleUpdateAsset}
          onOpenLabelForAsset={handleOpenLabelForAsset}
        />
      )}

      {/* Add Asset Modal */}
      {isAddModalOpen && (
        <AddAssetModal
          departments={DEPARTMENTS}
          onClose={() => setIsAddModalOpen(false)}
          onAddAsset={handleAddAsset}
        />
      )}

      {/* Import / Export & Backup Modal */}
      {isImportExportOpen && (
        <ImportExportModal
          assets={assets}
          inspections={inspections}
          auditSession={auditSession}
          selectedYear={selectedYear}
          onClose={() => setIsImportExportOpen(false)}
          onRestoreData={handleRestoreData}
          onResetToDefaults={handleResetToDefaults}
          onClearAllData={handleClearAllData}
          onLoadSampleData={handleLoadSampleData}
        />
      )}

      {/* Public Shareable Link Generator Modal */}
      {isPublicLinkOpen && (
        <PublicLinkModal
          isOpen={isPublicLinkOpen}
          onClose={() => setIsPublicLinkOpen(false)}
          selectedYear={selectedYear}
          filters={filters}
          departments={DEPARTMENTS}
          selectedAssetPatrimonio={activeAssetDetails?.patrimonio}
          cloudStatus={cloudStatus}
          lastSyncTime={lastSyncTime}
          onForceSync={handleForceCloudSync}
        />
      )}

      {/* Multi-Account Switcher & Sync Modal */}
      {isAccountSwitcherOpen && (
        <AccountSwitcherModal
          isOpen={isAccountSwitcherOpen}
          onClose={() => setIsAccountSwitcherOpen(false)}
          activeAccount={activeAccount}
          onSelectAccount={handleSelectAccount}
          cloudStatus={cloudStatus}
          lastSyncTime={lastSyncTime}
          onForceSync={handleForceCloudSync}
          totalAssets={assets.length}
          totalBaixados={assets.filter((a) => a.situacao === 'baixado').length}
          totalPhotos={Object.keys(disposalPhotos).length}
        />
      )}

      {/* Multi-Account Real-Time Update Toast Banner */}
      {multiAccountNotice && multiAccountNotice.visible && (
        <div
          id="toast-multi-account-sync"
          role="status"
          className="fixed top-14 right-6 z-50 max-w-sm bg-slate-900 text-white rounded-xl shadow-2xl border border-slate-700 p-3.5 flex items-center gap-3 animate-in fade-in slide-in-from-top-2 duration-300"
        >
          <div className="p-2 bg-emerald-600 rounded-lg text-white shrink-0">
            <Users className="w-4 h-4" />
          </div>
          <div className="flex-1 min-w-0 text-xs">
            <div className="font-bold text-emerald-400">
              Integração entre Contas
            </div>
            <div className="text-slate-200 mt-0.5 text-[11px] leading-snug">
              {multiAccountNotice.message}
            </div>
          </div>
          <button
            onClick={() => setMultiAccountNotice(null)}
            className="text-slate-400 hover:text-white p-1 rounded transition-colors"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 py-4 px-6 text-center text-xs text-slate-500 no-print">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>COMLURB • Sistema de Controle e Inspeção Visual de Bens Móveis</span>
          <span>Exercício {selectedYear} • {assets.length} bens cadastrados</span>
        </div>
      </footer>

      {/* Toast Notification for Explicit Save & Cloud Synchronization */}
      {saveToast && saveToast.visible && (
        <div
          id="toast-save-notification"
          role="alert"
          aria-live="polite"
          className="fixed bottom-6 right-6 z-50 max-w-md bg-white rounded-2xl shadow-2xl border border-slate-200 p-4 transition-all duration-300 animate-in fade-in slide-in-from-bottom-4"
        >
          <div className="flex items-start gap-3">
            <div
              className={`p-2 rounded-xl shrink-0 ${
                saveToast.type === 'success'
                  ? 'bg-emerald-100 text-emerald-700'
                  : saveToast.type === 'error'
                  ? 'bg-rose-100 text-rose-700'
                  : 'bg-blue-100 text-blue-700'
              }`}
            >
              {saveToast.type === 'success' ? (
                <CheckCircle2 className="w-5 h-5" />
              ) : saveToast.type === 'error' ? (
                <AlertTriangle className="w-5 h-5" />
              ) : (
                <Info className="w-5 h-5" />
              )}
            </div>
            <div className="flex-1 min-w-0">
              <h4 className="text-sm font-bold text-slate-900 leading-tight">
                {saveToast.message}
              </h4>
              {saveToast.details && (
                <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                  {saveToast.details}
                </p>
              )}
            </div>
            <button
              onClick={() => setSaveToast((prev) => (prev ? { ...prev, visible: false } : null))}
              className="text-slate-400 hover:text-slate-600 p-1 rounded-md transition-colors cursor-pointer shrink-0"
              title="Fechar notificação"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
