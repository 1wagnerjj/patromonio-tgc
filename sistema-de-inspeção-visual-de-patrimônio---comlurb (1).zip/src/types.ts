export type AssetStatus = 'presente' | 'ausente' | 'transferido' | 'pendente' | 'baixado';

export type AssetCondition = 'excelente' | 'bom' | 'regular' | 'ruim' | 'inservivel' | 'sucata' | 'nao_avaliado';

export type TagCondition = 'legivel' | 'danificada' | 'sem_plaqueta' | 'placa_substituida';

export interface DepartmentManagerInfo {
  gerenciaCode: string;
  gerenteNome: string;
  gerenteMatricula: string;
  gerenteCargo?: string;
  fiscalNome?: string;
  fiscalMatricula?: string;
  statusInspecao?: 'em_andamento' | 'concluido';
  dataConclusao?: string;
  observacoes?: string;
}

export interface DepartmentInfo {
  code: string;
  name: string;
  locationCode: string;
  costCenter: string;
  totalItems: number;
  totalValue: number;
  gerenteNome?: string;
  gerenteMatricula?: string;
  gerenteCargo?: string;
  fiscalNome?: string;
  fiscalMatricula?: string;
  statusInspecao?: 'em_andamento' | 'concluido';
  dataConclusao?: string;
  observacoes?: string;
}

export interface AssetItem {
  id: string;
  patrimonio: string;
  descricao: string;
  complemento: string;
  dtAquisicao: string;
  vlBase: number;
  vlBaseFormatted?: string;
  unidade: string;
  gerenciaCode: string;
  gerenciaName: string;
  localidade: string;
  centroCusto: string;
  categoria?: string;
  situacao?: 'ativo' | 'baixado';
  dtBaixa?: string; // Data da Baixa (YYYY-MM-DD)
  motivoBaixa?: string; // Justificativa / Processo da Baixa
  fotoUrl?: string; // URL ou Base64 da foto do patrimônio (para baixas e vistorias)
  isBlank?: boolean; // Se é uma etiqueta avulsa/em branco para preenchimento manual
  blankStyle?: 'write_lines' | 'pure_blank' | 'sequential' | 'custom_text' | 'big_numbers';
  blankCustomNote?: string;
  customFontSize?: number;
  customHeader?: string;
  customSubHeader?: string;
  customFooter?: string;
  customLoc?: string;
  hideHeader?: boolean;
  hideSubHeader?: boolean;
  hideFooter?: boolean;
  hideLoc?: boolean;
  hidePatrTag?: boolean;
  hideQr?: boolean;
}

export interface ArchivedLabelBatch {
  id: string;
  name: string;
  createdAt: string; // ISO date string
  savedBy?: string;
  departmentCode: string;
  labelCount: number;
  sheetsCount: number;
  layoutStyle: 'standard_pimaco' | 'full_barcode' | 'only_barcode' | 'big_numbers';
  sourceType: 'all' | 'selected' | 'damaged_or_missing' | 'custom' | 'blank_labels';
  paperFormat: 'letter' | 'a4';
  copiesPerAsset: number;
  startPosition: number;
  barcodeType: 'barcode' | 'qrcode' | 'both' | 'none';
  patrimonioFontSizePt?: number; // Tamanho da fonte dos números (10 a 85pt)
  showHeader: boolean;
  showSubHeader?: boolean;
  showFooter?: boolean;
  showLoc?: boolean;
  showPatrTag?: boolean;
  showUnit: boolean;
  showCostCenter: boolean;
  showWarningFooter: boolean;
  showBorderGuide: boolean;
  customHeader: string;
  customSubHeader?: string;
  customFooter: string;
  customLoc?: string;
  rowHeightMm: number;
  colWidthMm: number;
  colGapMm: number;
  offsetTopMm: number;
  offsetLeftMm: number;
  blankConfig?: {
    blankStyle: 'write_lines' | 'pure_blank' | 'sequential' | 'custom_text' | 'big_numbers';
    quantity: number;
    sequentialPrefix?: string;
    customDept?: string;
    customLoc?: string;
    customDesc?: string;
    fontSizePt?: number;
  };
  assetSnapshots?: Array<{
    id: string;
    patrimonio: string;
    descricao: string;
    complemento?: string;
    unidade?: string;
    localidade?: string;
    centroCusto?: string;
    isBlank?: boolean;
    customFontSize?: number;
    customHeader?: string;
    customSubHeader?: string;
    customFooter?: string;
    customLoc?: string;
    hideHeader?: boolean;
    hideSubHeader?: boolean;
    hideFooter?: boolean;
    hideLoc?: boolean;
    hidePatrTag?: boolean;
    hideQr?: boolean;
  }>;
  notes?: string;
}

export interface InspectionRecord {
  assetId: string;
  year: number;
  status: AssetStatus; // 'presente' (Sim), 'ausente' (Não), 'transferido', 'pendente'
  condition: AssetCondition;
  tagCondition?: TagCondition;
  transferidoPara?: string;
  dtTransf?: string;
  observacao: string;
  inspectedAt?: string;
  inspectedBy?: string;
  localizacaoEspecifica?: string; // e.g. Sala 03, Galpão A, Sala de Reunião
  fotoUrl?: string;
}

export interface UserAccountProfile {
  id: string;
  name: string;
  email: string;
  cargo: string;
  matricula?: string;
  gerencia?: string;
}

export const DEFAULT_USER_ACCOUNTS: UserAccountProfile[] = [
  {
    id: 'wagner-jardim',
    name: 'Wagner J. Jardim',
    email: 'wagnerjjardim@prefeitura.rio',
    cargo: 'Fiscal Patrimonial Principal / Admin',
    matricula: '12.345-6',
    gerencia: 'GERAL',
  },
  {
    id: 'fiscal-tgc',
    name: 'Carlos Henrique Souza',
    email: 'fiscal.tgc@prefeitura.rio',
    cargo: 'Fiscal Setorial TGC (Coleta)',
    matricula: '24.112-9',
    gerencia: 'TGC',
  },
  {
    id: 'fiscal-tdm',
    name: 'Renata Albuquerque',
    email: 'fiscal.tdm@prefeitura.rio',
    cargo: 'Fiscal Setorial TDM (Destino Final & Manutenção)',
    matricula: '18.994-1',
    gerencia: 'TDM',
  },
  {
    id: 'fiscal-tdo',
    name: 'Marcos Vinicius Lima',
    email: 'fiscal.tdo@prefeitura.rio',
    cargo: 'Fiscal Setorial TDO (Operações e Serviços)',
    matricula: '31.450-8',
    gerencia: 'TDO',
  },
];

export interface AuditSession {
  id?: string;
  year: number;
  dataEmissao: string;
  codigoDocumento: string; // e.g., COML02.2.3.12
  fiscalResponsavel: string;
  matriculaFiscal: string;
  gerenteResponsavel: string;
  departmentManagers?: Record<string, DepartmentManagerInfo>;
  status: 'em_andamento' | 'concluido';
  updatedAt?: string;
}

export interface DisposalPhotoItem {
  id: string;
  assetId?: string; // ID do bem no inventário (se vinculado)
  patrimonio: string;
  descricao: string;
  complemento?: string;
  gerenciaCode?: string;
  motivoBaixa?: string;
  fotoUrl: string; // Base64 data URL ou link
  dataFoto?: string;
  observacoes?: string;
}

export interface DisposalBatch {
  id: string;
  loteNumero: string; // ex: "001"
  processoNumero: string; // ex: "01/500.123/2026"
  tituloDocumento: string; // ex: "Fotos das ferramentas selecionadas para baixa do Lote: 001"
  departamento?: string; // ex: "TDM - DIVISÃO DE MANUTENÇÃO"
  dataAssinatura: string; // ex: "01/11/2024 às 08:38:01"
  responsavelAssinatura: string; // ex: "LUCIANO NELVO SILVA"
  matriculaResponsavel?: string; // ex: "Matr. 892.410-3"
  documentoNumero: string; // ex: "83deb14.63215849-7374"
  urlAutenticidade: string; // ex: "https://processos.rio.rj.gov.br/autenticidade"
  items: DisposalPhotoItem[];
}

export interface FilterState {
  gerencia: string; // 'ALL', 'TGC', 'TDO', 'TDM'
  localidade?: string;
  status: string; // 'ALL', 'presente', 'ausente', 'transferido', 'pendente'
  situacao?: 'ALL' | 'ativo' | 'baixado'; // 'ALL', 'ativo', 'baixado'
  condition?: string; // 'ALL', ...
  searchTerm: string;
  categoria: string;
  viewMode: 'table' | 'cards' | 'dashboard' | 'transfers_and_disposals' | 'pimaco_labels' | 'print_preview' | 'annual_compare' | 'disposal_photos';
  printType?: 'blank_field' | 'completed_audit' | 'divergences_only';
}
