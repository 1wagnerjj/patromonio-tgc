import React, { useState, useMemo } from 'react';
import {
  ArrowRightLeft,
  Archive,
  Printer,
  ExternalLink,
  Download,
  FileSpreadsheet,
  Search,
  Building2,
  Calendar,
  DollarSign,
  PlusCircle,
  Edit3,
  Eye,
  CheckCircle2,
  Info,
  X,
  Tag,
  Share2,
  Check,
  AlertTriangle,
  Camera,
} from 'lucide-react';
import {
  AssetItem,
  InspectionRecord,
  DepartmentInfo,
  AuditSession,
  DepartmentManagerInfo,
} from '../types';
import { formatBRL, formatDateBR } from '../utils/formatters';
import {
  openTransfersReportPrintWindow,
  downloadTransfersReportHtml,
  exportMovementsToCsv,
  extractMovements,
  MovementItem,
  TransfersReportPrintOptions,
} from '../utils/transfersReportPrintEngine';

interface TransfersAndDisposalsReportProps {
  assets: AssetItem[];
  inspections: Record<string, InspectionRecord>;
  departments: DepartmentInfo[];
  selectedYear: number;
  selectedGerencia: string;
  auditSession: AuditSession;
  onUpdateInspection: (assetId: string, record: Partial<InspectionRecord>) => void;
  onUpdateAsset: (assetId: string, updates: Partial<AssetItem>) => void;
  onOpenDetails: (asset: AssetItem) => void;
  onOpenLabelForAsset?: (asset: AssetItem) => void;
  onOpenDisposalPhotos?: () => void;
  onClose?: () => void;
}

export const TransfersAndDisposalsReport: React.FC<TransfersAndDisposalsReportProps> = ({
  assets,
  inspections,
  departments,
  selectedYear,
  selectedGerencia,
  auditSession,
  onUpdateInspection,
  onUpdateAsset,
  onOpenDetails,
  onOpenLabelForAsset,
  onOpenDisposalPhotos,
}) => {
  const [filterType, setFilterType] = useState<'all' | 'transfers' | 'disposals'>('all');
  const [localGerencia, setLocalGerencia] = useState<string>(selectedGerencia || 'ALL');
  const [searchTerm, setSearchTerm] = useState('');
  const [feedbackMsg, setFeedbackMsg] = useState<{
    type: 'success' | 'info' | 'warning';
    text: string;
  } | null>(null);

  // Quick Registration Modal State
  const [isRegisterModalOpen, setIsRegisterModalOpen] = useState(false);
  const [selectedAssetForEdit, setSelectedAssetForEdit] = useState<AssetItem | null>(null);
  const [registerType, setRegisterType] = useState<'transferencia' | 'baixa'>('transferencia');
  const [selectedAssetId, setSelectedAssetId] = useState<string>('');
  const [regDate, setRegDate] = useState<string>(new Date().toISOString().slice(0, 10));
  const [regDestination, setRegDestination] = useState<string>('');
  const [regReason, setRegReason] = useState<string>('');
  const [regObservation, setRegObservation] = useState<string>('');

  // Extract all movements based on current filters
  const movements = useMemo(() => {
    return extractMovements(
      assets,
      inspections,
      selectedYear,
      localGerencia,
      filterType,
      searchTerm
    );
  }, [assets, inspections, selectedYear, localGerencia, filterType, searchTerm]);

  // Overall Statistics
  const stats = useMemo(() => {
    const allMovements = extractMovements(
      assets,
      inspections,
      selectedYear,
      'ALL',
      'all',
      ''
    );

    const totalCount = allMovements.length;
    const totalValue = allMovements.reduce((acc, m) => acc + m.vlBase, 0);

    const baixas = allMovements.filter((m) => m.type === 'baixa');
    const baixasCount = baixas.length;
    const baixasValue = baixas.reduce((acc, m) => acc + m.vlBase, 0);

    const transferencias = allMovements.filter((m) => m.type === 'transferencia');
    const transfCount = transferencias.length;
    const transfValue = transferencias.reduce((acc, m) => acc + m.vlBase, 0);

    // Group transfers by destination
    const destinationsMap: Record<string, number> = {};
    transferencias.forEach((t) => {
      const dest = t.destinationOrReason.trim() || 'Não especificado';
      destinationsMap[dest] = (destinationsMap[dest] || 0) + 1;
    });

    const topDestinations = Object.entries(destinationsMap)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 3);

    return {
      totalCount,
      totalValue,
      baixasCount,
      baixasValue,
      transfCount,
      transfValue,
      topDestinations,
    };
  }, [assets, inspections, selectedYear]);

  const getPrintOptions = (): TransfersReportPrintOptions => {
    return {
      assets,
      inspections,
      departments,
      selectedYear,
      selectedGerencia: localGerencia,
      auditSession,
      filterType,
      searchTerm,
      departmentManagers: auditSession.departmentManagers,
    };
  };

  const handlePrint = () => {
    const options = getPrintOptions();
    const success = openTransfersReportPrintWindow(options);
    if (success) {
      setFeedbackMsg({
        type: 'success',
        text: 'Janela de impressão A4 do Relatório de Baixas & Transferências aberta!',
      });
    } else {
      window.print();
    }
    setTimeout(() => setFeedbackMsg(null), 5000);
  };

  const handleOpenInNewTab = () => {
    const options = getPrintOptions();
    const success = openTransfersReportPrintWindow(options);
    if (!success) {
      downloadTransfersReportHtml(options);
      setFeedbackMsg({
        type: 'info',
        text: 'Relatório baixado em HTML pois a janela pop-up foi bloqueada.',
      });
    } else {
      setFeedbackMsg({
        type: 'success',
        text: 'Relatório oficial aberto em nova aba.',
      });
    }
    setTimeout(() => setFeedbackMsg(null), 5000);
  };

  const handleDownloadHtml = () => {
    const options = getPrintOptions();
    downloadTransfersReportHtml(options);
    setFeedbackMsg({
      type: 'success',
      text: 'Arquivo HTML do Relatório baixado com sucesso!',
    });
    setTimeout(() => setFeedbackMsg(null), 5000);
  };

  const handleExportCsv = () => {
    const options = getPrintOptions();
    exportMovementsToCsv(options);
    setFeedbackMsg({
      type: 'success',
      text: 'Planilha CSV exportada com sucesso com todas as datas e destinos.',
    });
    setTimeout(() => setFeedbackMsg(null), 5000);
  };

  // Open Quick Edit / Register Modal for an existing asset
  const handleOpenEditMovement = (asset: AssetItem) => {
    setSelectedAssetForEdit(asset);
    setSelectedAssetId(asset.id);

    const insp = inspections[`${asset.id}-${selectedYear}`];
    if (asset.situacao === 'baixado') {
      setRegisterType('baixa');
      setRegDate(asset.dtBaixa || new Date().toISOString().slice(0, 10));
      setRegReason(asset.motivoBaixa || insp?.observacao || '');
      setRegObservation(insp?.observacao || '');
    } else if (insp?.status === 'transferido' || insp?.transferidoPara) {
      setRegisterType('transferencia');
      setRegDate(insp?.dtTransf || new Date().toISOString().slice(0, 10));
      setRegDestination(insp?.transferidoPara || '');
      setRegObservation(insp?.observacao || '');
    } else {
      setRegisterType('transferencia');
      setRegDate(new Date().toISOString().slice(0, 10));
      setRegDestination('');
      setRegObservation('');
    }

    setIsRegisterModalOpen(true);
  };

  // Open Register Modal for a new movement
  const handleOpenNewMovement = () => {
    setSelectedAssetForEdit(null);
    setSelectedAssetId(assets[0]?.id || '');
    setRegisterType('transferencia');
    setRegDate(new Date().toISOString().slice(0, 10));
    setRegDestination('');
    setRegReason('');
    setRegObservation('');
    setIsRegisterModalOpen(true);
  };

  const handleSaveMovement = (e: React.FormEvent) => {
    e.preventDefault();
    const asset = assets.find((a) => a.id === selectedAssetId);
    if (!asset) return;

    if (registerType === 'baixa') {
      // Update asset lifecycle to baixado
      onUpdateAsset(asset.id, {
        situacao: 'baixado',
        dtBaixa: regDate,
        motivoBaixa: regReason,
      });

      // Update inspection status to reflect baixa
      onUpdateInspection(asset.id, {
        status: 'ausente',
        observacao: `[BAIXA REGISTRADA EM ${formatDateBR(regDate)}] ${regReason || regObservation}`,
        inspectedAt: new Date().toISOString(),
      });

      setFeedbackMsg({
        type: 'success',
        text: `Baixa do bem patrimônio ${asset.patrimonio} registrada com sucesso na data ${formatDateBR(regDate)}!`,
      });
    } else {
      // Update as Transferência
      onUpdateAsset(asset.id, {
        situacao: 'ativo',
      });

      onUpdateInspection(asset.id, {
        status: 'transferido',
        transferidoPara: regDestination,
        dtTransf: regDate,
        observacao: regObservation || `Transferido para ${regDestination} em ${formatDateBR(regDate)}`,
        inspectedAt: new Date().toISOString(),
      });

      setFeedbackMsg({
        type: 'success',
        text: `Transferência do bem patrimônio ${asset.patrimonio} para "${regDestination}" registrada com sucesso!`,
      });
    }

    setIsRegisterModalOpen(false);
    setTimeout(() => setFeedbackMsg(null), 5000);
  };

  return (
    <div className="space-y-6">
      {/* Top Header & Actions Control Panel */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-4 no-print">
        <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="p-2 bg-orange-100 text-orange-700 rounded-xl">
                <ArrowRightLeft className="w-5 h-5" />
              </span>
              <div>
                <h2 className="text-lg font-black text-slate-900 tracking-tight flex items-center gap-2">
                  <span>Relatório Geral de Baixas & Transferências</span>
                  <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 border border-slate-200">
                    Exercício {selectedYear}
                  </span>
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Controle analítico de movimentações intergerências com registro de datas e unidades de destino.
                </p>
              </div>
            </div>
          </div>

          {/* Actions Button Group */}
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={handleOpenNewMovement}
              className="flex items-center gap-1.5 px-3.5 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold shadow-xs transition-all cursor-pointer"
              title="Registrar nova baixa ou transferência patrimonial"
            >
              <PlusCircle className="w-4 h-4 text-orange-400" />
              <span>Registrar Movimentação</span>
            </button>

            {onOpenDisposalPhotos && (
              <button
                type="button"
                onClick={onOpenDisposalPhotos}
                className="flex items-center gap-1.5 px-3.5 py-2 bg-amber-500 hover:bg-amber-600 text-slate-950 font-black rounded-xl text-xs shadow-xs transition-all cursor-pointer border border-amber-600"
                title="Abrir Dossiê Fotográfico de Baixa de Ferramentas (Laudo A4 Oficial)"
              >
                <Camera className="w-4 h-4 text-slate-950" />
                <span>Laudo Fotográfico A4</span>
              </button>
            )}

            <button
              type="button"
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-3.5 py-2 bg-orange-600 hover:bg-orange-700 text-white rounded-xl text-xs font-extrabold shadow-sm transition-all cursor-pointer"
              title="Imprimir Relatório Oficial A4 Paisagem"
            >
              <Printer className="w-4 h-4" />
              <span>Imprimir Relatório (A4)</span>
            </button>

            <button
              type="button"
              onClick={handleExportCsv}
              className="flex items-center gap-1.5 px-3 py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 rounded-xl text-xs font-bold transition-colors cursor-pointer"
              title="Exportar dados para planilha Excel / CSV"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-700" />
              <span className="hidden sm:inline">Exportar Excel</span>
            </button>

            <button
              type="button"
              onClick={handleOpenInNewTab}
              className="flex items-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-300 rounded-xl text-xs font-bold transition-colors cursor-pointer"
              title="Abrir relatório em tela cheia numa nova aba"
            >
              <ExternalLink className="w-3.5 h-3.5 text-slate-600" />
              <span className="hidden sm:inline">Nova Aba</span>
            </button>

            <button
              type="button"
              onClick={handleDownloadHtml}
              className="flex items-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-300 rounded-xl text-xs font-bold transition-colors cursor-pointer"
              title="Baixar arquivo HTML independente"
            >
              <Download className="w-3.5 h-3.5 text-slate-600" />
              <span className="hidden sm:inline">Baixar HTML</span>
            </button>
          </div>
        </div>

        {/* Feedback Alert */}
        {feedbackMsg && (
          <div
            className={`p-3 rounded-xl text-xs font-medium flex items-center gap-2 border animate-in fade-in ${
              feedbackMsg.type === 'success'
                ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                : feedbackMsg.type === 'warning'
                ? 'bg-amber-50 text-amber-800 border-amber-200'
                : 'bg-blue-50 text-blue-800 border-blue-200'
            }`}
          >
            {feedbackMsg.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            ) : (
              <Info className="w-4 h-4 text-blue-600 shrink-0" />
            )}
            <span>{feedbackMsg.text}</span>
          </div>
        )}

        {/* Summary Metric KPI Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 pt-2 border-t border-slate-100">
          {/* Card 1: Total Movements */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 flex items-center justify-between">
            <div>
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
                Total de Movimentações
              </span>
              <span className="text-xl font-extrabold text-slate-900 font-mono">
                {stats.totalCount} <span className="text-xs text-slate-500 font-normal">bens</span>
              </span>
              <span className="text-[11px] text-slate-600 block mt-0.5">
                Valor Total: <strong>{formatBRL(stats.totalValue)}</strong>
              </span>
            </div>
            <div className="p-2.5 bg-slate-200/80 rounded-xl text-slate-700">
              <ArrowRightLeft className="w-5 h-5" />
            </div>
          </div>

          {/* Card 2: Baixas */}
          <div className="bg-rose-50/70 border border-rose-200 rounded-xl p-3.5 flex flex-col justify-between">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-[10px] font-bold text-rose-700 uppercase tracking-wider block">
                  Baixas / Desincorporações
                </span>
                <span className="text-xl font-extrabold text-rose-900 font-mono">
                  {stats.baixasCount} <span className="text-xs text-rose-600 font-normal">bens</span>
                </span>
                <span className="text-[11px] text-rose-800 block mt-0.5">
                  Impacto: <strong>{formatBRL(stats.baixasValue)}</strong>
                </span>
              </div>
              <div className="p-2.5 bg-rose-200/80 rounded-xl text-rose-800">
                <Archive className="w-5 h-5" />
              </div>
            </div>
            {onOpenDisposalPhotos && (
              <button
                type="button"
                onClick={onOpenDisposalPhotos}
                className="mt-2 text-[11px] font-bold text-rose-700 hover:text-rose-950 underline flex items-center gap-1 cursor-pointer pt-2 border-t border-rose-200/60"
                title="Abrir laudo fotográfico das ferramentas baixadas"
              >
                <Camera className="w-3.5 h-3.5" />
                <span>📸 Lançar / Ver Laudo Fotográfico</span>
              </button>
            )}
          </div>

          {/* Card 3: Transferências */}
          <div className="bg-orange-50/70 border border-orange-200 rounded-xl p-3.5 flex items-center justify-between">
            <div>
              <span className="text-[10px] font-bold text-orange-800 uppercase tracking-wider block">
                Transferências Entre Gerências
              </span>
              <span className="text-xl font-extrabold text-orange-950 font-mono">
                {stats.transfCount} <span className="text-xs text-orange-700 font-normal">bens</span>
              </span>
              <span className="text-[11px] text-orange-900 block mt-0.5">
                Valor Transferido: <strong>{formatBRL(stats.transfValue)}</strong>
              </span>
            </div>
            <div className="p-2.5 bg-orange-200/80 rounded-xl text-orange-800">
              <ArrowRightLeft className="w-5 h-5" />
            </div>
          </div>

          {/* Card 4: Top Destinos */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5">
            <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block mb-1">
              Principais Unidades de Destino
            </span>
            {stats.topDestinations.length === 0 ? (
              <span className="text-xs text-slate-400 italic">Nenhuma transferência com destino</span>
            ) : (
              <div className="space-y-1">
                {stats.topDestinations.map(([dest, count]) => (
                  <div key={dest} className="flex justify-between items-center text-xs">
                    <span className="font-semibold text-slate-800 truncate max-w-[140px]">{dest}</span>
                    <span className="font-mono text-orange-600 font-bold bg-orange-50 px-1.5 py-0.5 rounded text-[10px] border border-orange-200">
                      {count} bem{count > 1 ? 's' : ''}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Filter Toolbar: Movement Type Tabs + Gerência Dropdown + Search */}
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3 pt-3 border-t border-slate-100">
          {/* Movement Type Filter Tabs */}
          <div className="flex bg-slate-100 p-1 rounded-xl border border-slate-200 text-xs">
            <button
              type="button"
              onClick={() => setFilterType('all')}
              className={`px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                filterType === 'all'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <span>Todas as Movimentações</span>
              <span className="px-1.5 py-0.2 rounded-md bg-slate-200 text-slate-800 text-[10px] font-bold">
                {stats.totalCount}
              </span>
            </button>

            <button
              type="button"
              onClick={() => setFilterType('transfers')}
              className={`px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                filterType === 'transfers'
                  ? 'bg-white text-orange-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <ArrowRightLeft className="w-3.5 h-3.5 text-orange-600" />
              <span>Somente Transferências</span>
              <span className="px-1.5 py-0.2 rounded-md bg-orange-100 text-orange-800 text-[10px] font-bold">
                {stats.transfCount}
              </span>
            </button>

            <button
              type="button"
              onClick={() => setFilterType('disposals')}
              className={`px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
                filterType === 'disposals'
                  ? 'bg-white text-rose-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Archive className="w-3.5 h-3.5 text-rose-600" />
              <span>Somente Baixas</span>
              <span className="px-1.5 py-0.2 rounded-md bg-rose-100 text-rose-800 text-[10px] font-bold">
                {stats.baixasCount}
              </span>
            </button>
          </div>

          {/* Department and Search Filter */}
          <div className="flex flex-wrap items-center gap-2">
            {/* Origin Department Dropdown */}
            <div className="flex items-center gap-1.5">
              <Building2 className="w-3.5 h-3.5 text-slate-400" />
              <select
                value={localGerencia}
                onChange={(e) => setLocalGerencia(e.target.value)}
                className="px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-bold text-slate-700 focus:outline-none focus:ring-2 focus:ring-orange-500 cursor-pointer"
                aria-label="Filtrar por Gerência de Origem"
              >
                <option value="ALL">Origem: Todas as Gerências</option>
                {departments.map((d) => (
                  <option key={d.code} value={d.code}>
                    {d.code} - {d.name.replace(/Gerência de |Divisão de /, '')}
                  </option>
                ))}
              </select>
            </div>

            {/* Search Input */}
            <div className="relative min-w-[240px]">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Buscar por patrimônio, destino, motivo..."
                className="w-full pl-8 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-medium text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-orange-500 focus:bg-white"
              />
              {searchTerm && (
                <button
                  type="button"
                  onClick={() => setSearchTerm('')}
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Movements Interactive Table & Detailed Display */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 bg-slate-50 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <h3 className="font-extrabold text-slate-900 text-sm">
              Listagem Analítica de Baixas e Transferências
            </h3>
            <span className="px-2 py-0.5 rounded-full text-xs font-bold bg-orange-100 text-orange-800 border border-orange-200">
              {movements.length} registro{movements.length !== 1 ? 's' : ''}
            </span>
          </div>
          <span className="text-xs text-slate-500">
            Exibindo dados oficiais para auditoria patrimonial e regularização contábil
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-100 border-b border-slate-200 text-slate-700 font-bold">
                <th className="py-3 px-3 text-center w-20">Patrimônio</th>
                <th className="py-3 px-3 text-center w-28">Tipo</th>
                <th className="py-3 px-3">Descrição & Especificação</th>
                <th className="py-3 px-3 text-center w-28">Gerência Origem</th>
                <th className="py-3 px-3 min-w-[200px]">
                  {filterType === 'disposals'
                    ? 'Motivo / Processo da Baixa'
                    : filterType === 'transfers'
                    ? 'Gerência de Destino'
                    : 'Destino da Transferência / Motivo da Baixa'}
                </th>
                <th className="py-3 px-3 text-center w-28">Data do Evento</th>
                <th className="py-3 px-3 text-right w-28">Valor Base</th>
                <th className="py-3 px-3 text-center w-24">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {movements.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-slate-500">
                    <div className="max-w-md mx-auto space-y-2">
                      <AlertTriangle className="w-8 h-8 text-amber-500 mx-auto" />
                      <p className="font-bold text-slate-700">Nenhum registro de movimentação encontrado</p>
                      <p className="text-xs text-slate-500">
                        {searchTerm || localGerencia !== 'ALL' || filterType !== 'all'
                          ? 'Tente ajustar os filtros acima ou limpar o termo de busca.'
                          : 'Clique no botão "Registrar Movimentação" para dar baixa ou transferir um bem.'}
                      </p>
                    </div>
                  </td>
                </tr>
              ) : (
                movements.map((m) => {
                  const isBaixa = m.type === 'baixa';
                  return (
                    <tr key={`${m.asset.id}-${m.type}`} className="hover:bg-slate-50 transition-colors">
                      {/* Patrimonio */}
                      <td className="py-3 px-3 text-center">
                        <button
                          type="button"
                          onClick={() => onOpenDetails(m.asset)}
                          className="font-mono font-bold text-slate-900 hover:text-orange-600 transition-colors cursor-pointer"
                          title="Clique para ver os detalhes completos deste bem"
                        >
                          {m.asset.patrimonio}
                        </button>
                      </td>

                      {/* Type Badge */}
                      <td className="py-3 px-3 text-center">
                        {isBaixa ? (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-[11px] font-extrabold bg-rose-100 text-rose-800 border border-rose-300">
                            <Archive className="w-3 h-3" />
                            BAIXA
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-[11px] font-extrabold bg-orange-100 text-orange-800 border border-orange-300">
                            <ArrowRightLeft className="w-3 h-3" />
                            TRANSFERÊNCIA
                          </span>
                        )}
                      </td>

                      {/* Descricao */}
                      <td className="py-3 px-3">
                        <div className="font-bold text-slate-900">{m.asset.descricao}</div>
                        <div className="text-[11px] text-slate-500 font-mono mt-0.5">
                          {m.asset.complemento}
                        </div>
                        {m.observation && (
                          <div className="text-[11px] text-slate-600 mt-1 italic flex items-center gap-1">
                            <Info className="w-3 h-3 text-slate-400 shrink-0" />
                            <span>{m.observation}</span>
                          </div>
                        )}
                      </td>

                      {/* Gerência Origem */}
                      <td className="py-3 px-3 text-center">
                        <span className="font-bold text-slate-800 block">{m.originDeptCode}</span>
                        <span className="text-[10px] text-slate-500 font-mono block">CC: {m.costCenter}</span>
                      </td>

                      {/* Destino ou Motivo */}
                      <td className="py-3 px-3">
                        {isBaixa ? (
                          <div className="space-y-0.5">
                            <span className="text-[10px] font-bold text-rose-700 uppercase tracking-wider block">
                              Processo / Motivo de Baixa:
                            </span>
                            <span className="font-semibold text-slate-900 block bg-rose-50/60 p-1.5 rounded-lg border border-rose-200/80">
                              {m.destinationOrReason || 'Baixa do acervo físico patrimonial'}
                            </span>
                          </div>
                        ) : (
                          <div className="space-y-0.5">
                            <span className="text-[10px] font-bold text-orange-700 uppercase tracking-wider block">
                              Transferido Para (Gerência Destino):
                            </span>
                            <span className="font-extrabold text-blue-900 block bg-blue-50/70 p-1.5 rounded-lg border border-blue-200">
                              📍 {m.destinationOrReason}
                            </span>
                          </div>
                        )}
                      </td>

                      {/* Data do Evento */}
                      <td className="py-3 px-3 text-center">
                        <div className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-100 text-slate-800 font-mono font-bold text-xs border border-slate-200">
                          <Calendar className="w-3.5 h-3.5 text-slate-500" />
                          <span>{formatDateBR(m.date)}</span>
                        </div>
                      </td>

                      {/* Valor Base */}
                      <td className="py-3 px-3 text-right font-mono font-bold text-slate-900">
                        {formatBRL(m.vlBase)}
                      </td>

                      {/* Ações */}
                      <td className="py-3 px-3 text-center">
                        <div className="flex items-center justify-center gap-1">
                          <button
                            type="button"
                            onClick={() => handleOpenEditMovement(m.asset)}
                            className="p-1.5 hover:bg-orange-50 text-slate-600 hover:text-orange-600 rounded-lg transition-colors cursor-pointer"
                            title="Editar Dados da Baixa / Transferência"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                          </button>

                          <button
                            type="button"
                            onClick={() => onOpenDetails(m.asset)}
                            className="p-1.5 hover:bg-slate-100 text-slate-600 hover:text-slate-900 rounded-lg transition-colors cursor-pointer"
                            title="Ver Ficha Completa do Bem"
                          >
                            <Eye className="w-3.5 h-3.5" />
                          </button>

                          {onOpenLabelForAsset && (
                            <button
                              type="button"
                              onClick={() => onOpenLabelForAsset(m.asset)}
                              className="p-1.5 hover:bg-amber-50 text-slate-600 hover:text-amber-700 rounded-lg transition-colors cursor-pointer"
                              title="Gerar Etiqueta Pimaco com QR Code"
                            >
                              <Tag className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>

            {/* Table Footer with Subtotals */}
            {movements.length > 0 && (
              <tfoot>
                <tr className="bg-slate-100 font-bold text-slate-900 border-t-2 border-slate-300">
                  <td colSpan={4} className="py-3 px-3">
                    Total nesta visualização: <strong>{movements.length}</strong> bem{movements.length !== 1 ? 's' : ''}
                  </td>
                  <td colSpan={2} className="py-3 px-3 text-right">
                    Subtotal Financeiro:
                  </td>
                  <td className="py-3 px-3 text-right font-mono text-sm font-extrabold text-slate-900">
                    {formatBRL(movements.reduce((sum, m) => sum + m.vlBase, 0))}
                  </td>
                  <td></td>
                </tr>
              </tfoot>
            )}
          </table>
        </div>
      </div>

      {/* Modal: Registrar ou Editar Movimentação */}
      {isRegisterModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto no-print">
          <div className="bg-white rounded-2xl max-w-lg w-full overflow-hidden shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 duration-150">
            {/* Modal Header */}
            <div className="bg-slate-900 text-white p-5 flex items-start justify-between">
              <div>
                <h3 className="text-base font-extrabold flex items-center gap-2">
                  <ArrowRightLeft className="w-4 h-4 text-orange-400" />
                  {selectedAssetForEdit
                    ? `Editar Movimentação (Patr. ${selectedAssetForEdit.patrimonio})`
                    : 'Registrar Nova Baixa ou Transferência'}
                </h3>
                <p className="text-xs text-slate-300 mt-0.5">
                  Atualize a destinação, datas e motivos para regularização da carga patrimonial.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setIsRegisterModalOpen(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Form */}
            <form onSubmit={handleSaveMovement} className="p-5 space-y-4 text-xs">
              {/* Asset Selection (if not editing directly) */}
              {!selectedAssetForEdit ? (
                <div>
                  <label className="block font-bold text-slate-800 mb-1">
                    Selecione o Bem Patrimonial:
                  </label>
                  <select
                    value={selectedAssetId}
                    onChange={(e) => setSelectedAssetId(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-orange-500"
                    required
                  >
                    {assets.map((a) => (
                      <option key={a.id} value={a.id}>
                        {a.patrimonio} - {a.descricao} ({a.gerenciaCode})
                      </option>
                    ))}
                  </select>
                </div>
              ) : (
                <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-1">
                  <div className="flex justify-between items-center">
                    <span className="font-mono font-bold text-orange-600 text-xs">
                      PATRIMÔNIO Nº {selectedAssetForEdit.patrimonio}
                    </span>
                    <span className="font-semibold text-slate-600">
                      Lotação Atual: {selectedAssetForEdit.gerenciaCode}
                    </span>
                  </div>
                  <div className="font-bold text-slate-900 text-xs">{selectedAssetForEdit.descricao}</div>
                  <div className="text-[11px] text-slate-500 font-mono">{selectedAssetForEdit.complemento}</div>
                </div>
              )}

              {/* Type Switcher */}
              <div>
                <label className="block font-bold text-slate-800 mb-1.5">Tipo de Movimentação:</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setRegisterType('transferencia')}
                    className={`p-3 rounded-xl border font-bold flex items-center justify-center gap-2 transition-all cursor-pointer ${
                      registerType === 'transferencia'
                        ? 'bg-orange-600 text-white border-orange-600 shadow-xs ring-2 ring-orange-200'
                        : 'bg-white border-slate-300 text-slate-700 hover:bg-orange-50'
                    }`}
                  >
                    <ArrowRightLeft className="w-4 h-4" />
                    <span>TRANSFERÊNCIA</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setRegisterType('baixa')}
                    className={`p-3 rounded-xl border font-bold flex items-center justify-center gap-2 transition-all cursor-pointer ${
                      registerType === 'baixa'
                        ? 'bg-rose-600 text-white border-rose-600 shadow-xs ring-2 ring-rose-200'
                        : 'bg-white border-slate-300 text-slate-700 hover:bg-rose-50'
                    }`}
                  >
                    <Archive className="w-4 h-4" />
                    <span>BAIXA DEFINITIVA</span>
                  </button>
                </div>
              </div>

              {/* Conditional Fields: Transferência vs Baixa */}
              {registerType === 'transferencia' ? (
                <div className="space-y-3 bg-orange-50/70 p-3.5 rounded-xl border border-orange-200">
                  <div>
                    <label className="block font-bold text-slate-800 mb-1">
                      Gerência / Unidade de Destino: <span className="text-rose-600">*</span>
                    </label>
                    <input
                      type="text"
                      value={regDestination}
                      onChange={(e) => setRegDestination(e.target.value)}
                      placeholder="Ex: TDO - Operação / TDM - Manutenção / SEDE / Almoxarifado..."
                      className="w-full px-3 py-2 bg-white border border-orange-300 rounded-lg text-slate-900 font-semibold focus:outline-none focus:ring-2 focus:ring-orange-500"
                      required
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-slate-800 mb-1 flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5 text-orange-600" />
                      Data da Transferência: <span className="text-rose-600">*</span>
                    </label>
                    <input
                      type="date"
                      value={regDate}
                      onChange={(e) => setRegDate(e.target.value)}
                      className="w-full px-3 py-2 bg-white border border-orange-300 rounded-lg text-slate-900 font-bold focus:outline-none focus:ring-2 focus:ring-orange-500"
                      required
                    />
                  </div>
                </div>
              ) : (
                <div className="space-y-3 bg-rose-50/70 p-3.5 rounded-xl border border-rose-200">
                  <div>
                    <label className="block font-bold text-slate-800 mb-1">
                      Motivo / Processo Administrativo da Baixa: <span className="text-rose-600">*</span>
                    </label>
                    <input
                      type="text"
                      value={regReason}
                      onChange={(e) => setRegReason(e.target.value)}
                      placeholder="Ex: Inservível / Leilão nº 04/2025 / Processo SEI-240001/004521/2025"
                      className="w-full px-3 py-2 bg-white border border-rose-300 rounded-lg text-slate-900 font-semibold focus:outline-none focus:ring-2 focus:ring-rose-500"
                      required
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-slate-800 mb-1 flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5 text-rose-600" />
                      Data da Baixa: <span className="text-rose-600">*</span>
                    </label>
                    <input
                      type="date"
                      value={regDate}
                      onChange={(e) => setRegDate(e.target.value)}
                      className="w-full px-3 py-2 bg-white border border-rose-300 rounded-lg text-slate-900 font-bold focus:outline-none focus:ring-2 focus:ring-rose-500"
                      required
                    />
                  </div>
                </div>
              )}

              {/* Observações Gerais */}
              <div>
                <label className="block font-bold text-slate-800 mb-1">
                  Observações / Justificativa da Movimentação:
                </label>
                <textarea
                  rows={2}
                  value={regObservation}
                  onChange={(e) => setRegObservation(e.target.value)}
                  placeholder="Informações complementares sobre a transferência ou baixa..."
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-orange-500"
                />
              </div>

              {/* Modal Action Buttons */}
              <div className="flex justify-end gap-2 pt-2 border-t border-slate-200">
                <button
                  type="button"
                  onClick={() => setIsRegisterModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold transition-colors cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-orange-600 hover:bg-orange-700 text-white rounded-xl font-bold shadow-xs transition-colors cursor-pointer"
                >
                  Salvar Movimentação
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
