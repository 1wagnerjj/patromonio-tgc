import React from 'react';
import {
  Boxes,
  CheckCircle2,
  AlertTriangle,
  ArrowRightLeft,
  ShieldAlert,
  UserCheck,
} from 'lucide-react';
import { AssetItem, InspectionRecord, DepartmentInfo, DepartmentManagerInfo } from '../types';
import { formatBRL } from '../utils/formatters';

interface InspectionStatsProps {
  assets: AssetItem[];
  inspections: Record<string, InspectionRecord>;
  selectedYear: number;
  activeDepartment: string;
  departments?: DepartmentInfo[];
  departmentManagers?: Record<string, DepartmentManagerInfo>;
}

export const InspectionStats: React.FC<InspectionStatsProps> = ({
  assets,
  inspections,
  selectedYear,
  activeDepartment,
  departments = [],
  departmentManagers = {},
}) => {
  const totalAssets = assets.length;
  const totalValue = assets.reduce((sum, item) => sum + (item.vlBase || 0), 0);

  let presentCount = 0;
  let presentValue = 0;
  let absentCount = 0;
  let absentValue = 0;
  let transferredCount = 0;
  let transferredValue = 0;
  let pendingCount = 0;

  let needMaintenanceCount = 0;
  let badTagCount = 0;

  assets.forEach((asset) => {
    const key = `${asset.id}-${selectedYear}`;
    const insp = inspections[key];
    const status = insp?.status || 'pendente';
    const val = asset.vlBase || 0;

    if (status === 'presente') {
      presentCount++;
      presentValue += val;
    } else if (status === 'ausente') {
      absentCount++;
      absentValue += val;
    } else if (status === 'transferido') {
      transferredCount++;
      transferredValue += val;
    } else {
      pendingCount++;
    }

    if (insp?.condition === 'ruim' || insp?.condition === 'inservivel') {
      needMaintenanceCount++;
    }
    if (insp?.tagCondition === 'sem_plaqueta' || insp?.tagCondition === 'danificada') {
      badTagCount++;
    }
  });

  const inspectedCount = presentCount + absentCount + transferredCount;
  const completionPercentage = totalAssets > 0 ? Math.round((inspectedCount / totalAssets) * 100) : 0;

  // Selected department manager details
  const activeDeptInfo = departments.find((d) => d.code === activeDepartment);
  const activeDeptManager = departmentManagers[activeDepartment] || {
    gerenteNome: activeDeptInfo?.gerenteNome || 'Gerente da Divisão',
    gerenteMatricula: activeDeptInfo?.gerenteMatricula || '',
    gerenteCargo: activeDeptInfo?.gerenteCargo || '',
    statusInspecao: activeDeptInfo?.statusInspecao || 'em_andamento',
  };

  return (
    <div className="space-y-3.5 no-print">
      {/* Top Section with Department Title, Progress and Total Value */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-3.5 items-stretch">
        {/* Progress Card */}
        <div className="lg:col-span-8 bg-white rounded-xl p-5 border border-slate-200 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-3">
              <div>
                <div className="flex items-center gap-2">
                  <p className="text-[10px] font-bold text-orange-600 uppercase tracking-wider">
                    Inspeção {selectedYear} • {activeDepartment !== 'ALL' ? `Gerência ${activeDepartment}` : 'Todas as Unidades'}
                  </p>
                  {activeDepartment !== 'ALL' && activeDeptManager.statusInspecao === 'concluido' && (
                    <span className="bg-emerald-100 text-emerald-800 text-[10px] font-bold px-2 py-0.5 rounded-full border border-emerald-300">
                      ✓ Vistoria Concluída
                    </span>
                  )}
                </div>
                <h2 className="text-xl font-extrabold text-slate-900 tracking-tight mt-0.5 flex flex-wrap items-center gap-2">
                  <span>Status Geral do Inventário Físico</span>
                </h2>
                {activeDepartment !== 'ALL' && activeDeptManager.gerenteNome && (
                  <p className="text-xs text-slate-600 flex items-center gap-1.5 mt-1 font-medium">
                    <UserCheck className="w-3.5 h-3.5 text-orange-600" />
                    <span>
                      Gerente Responsável: <strong className="text-slate-900">{activeDeptManager.gerenteNome}</strong>
                      {activeDeptManager.gerenteMatricula ? ` (${activeDeptManager.gerenteMatricula})` : ''}
                      {activeDeptInfo?.costCenter ? ` • Centro de Custo: ${activeDeptInfo.costCenter}` : ''}
                    </span>
                  </p>
                )}
              </div>
              <div className="flex items-center gap-2">
                <span className="text-xs text-slate-500 font-medium">
                  <strong className="text-slate-900 font-bold">{inspectedCount}</strong> de {totalAssets} vistoriados
                </span>
                <span className="bg-orange-50 text-orange-800 text-xs font-bold px-2.5 py-1 rounded-full border border-orange-200">
                  {completionPercentage}% Concluído
                </span>
              </div>
            </div>

            {/* Progress Bar */}
            <div className="w-full bg-slate-100 rounded-full h-3 overflow-hidden flex p-0.5 border border-slate-200">
              <div
                className="bg-emerald-500 h-full rounded-full transition-all duration-500"
                style={{ width: `${totalAssets > 0 ? (presentCount / totalAssets) * 100 : 0}%` }}
                title={`Presentes: ${presentCount}`}
              />
              <div
                className="bg-amber-500 h-full rounded-full transition-all duration-500"
                style={{ width: `${totalAssets > 0 ? (transferredCount / totalAssets) * 100 : 0}%` }}
                title={`Transferidos: ${transferredCount}`}
              />
              <div
                className="bg-rose-500 h-full rounded-full transition-all duration-500"
                style={{ width: `${totalAssets > 0 ? (absentCount / totalAssets) * 100 : 0}%` }}
                title={`Ausentes: ${absentCount}`}
              />
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-4 text-xs text-slate-600 pt-3 border-t border-slate-100 mt-3">
            <span className="flex items-center gap-1.5 font-medium">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
              No Local (Sim): <strong className="text-slate-900">{presentCount}</strong>
            </span>
            <span className="flex items-center gap-1.5 font-medium">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500" />
              Ausentes (Não): <strong className="text-slate-900">{absentCount}</strong>
            </span>
            <span className="flex items-center gap-1.5 font-medium">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-500" />
              Transferidos: <strong className="text-slate-900">{transferredCount}</strong>
            </span>
            <span className="flex items-center gap-1.5 font-medium">
              <span className="w-2.5 h-2.5 rounded-full bg-slate-300" />
              Pendentes: <strong className="text-slate-900">{pendingCount}</strong>
            </span>
          </div>
        </div>

        {/* Total Patrimonio Value Dark Card - Sleek Interface Signature */}
        <div className="lg:col-span-4 bg-slate-800 text-white p-5 rounded-xl border border-slate-700 shadow-md flex flex-col justify-between">
          <div>
            <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">
              Valor Total do Patrimônio
            </p>
            <p className="text-2xl font-mono font-extrabold text-orange-400">
              {formatBRL(totalValue)}
            </p>
            <p className="text-xs text-slate-400 mt-1">
              {totalAssets} bens cadastrados no sistema
            </p>
          </div>

          <div className="pt-3 border-t border-slate-700/80 flex items-center justify-between text-xs text-slate-300">
            <span>Exercício Fiscal: <strong>{selectedYear}</strong></span>
            <span className="text-emerald-400 font-medium">Vistoriado: {formatBRL(presentValue)}</span>
          </div>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        {/* Total Assets */}
        <div className="bg-white p-3.5 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-[10px] font-bold uppercase tracking-wider">Total Bens</span>
            <Boxes className="w-4 h-4 text-slate-600" />
          </div>
          <div className="text-xl font-mono font-extrabold text-slate-900">{totalAssets}</div>
          <div className="text-[11px] text-slate-500 font-mono truncate mt-0.5">{formatBRL(totalValue)}</div>
        </div>

        {/* Present (Sim) */}
        <div className="bg-emerald-50/70 p-3.5 rounded-xl border border-emerald-200/80 shadow-xs">
          <div className="flex items-center justify-between text-emerald-700 mb-1">
            <span className="text-[10px] font-bold uppercase tracking-wider">No Local</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-xl font-mono font-extrabold text-emerald-900">{presentCount}</div>
          <div className="text-[11px] text-emerald-700 font-mono truncate mt-0.5">{formatBRL(presentValue)}</div>
        </div>

        {/* Absent (Não / Divergência) */}
        <div className="bg-rose-50/70 p-3.5 rounded-xl border border-rose-200/80 shadow-xs">
          <div className="flex items-center justify-between text-rose-700 mb-1">
            <span className="text-[10px] font-bold uppercase tracking-wider">Ausentes</span>
            <AlertTriangle className="w-4 h-4 text-rose-600" />
          </div>
          <div className="text-xl font-mono font-extrabold text-rose-900">{absentCount}</div>
          <div className="text-[11px] text-rose-700 font-mono truncate mt-0.5">
            {absentCount > 0 ? formatBRL(absentValue) : 'Sem ausências'}
          </div>
        </div>

        {/* Transferred */}
        <div className="bg-amber-50/70 p-3.5 rounded-xl border border-amber-200/80 shadow-xs">
          <div className="flex items-center justify-between text-amber-700 mb-1">
            <span className="text-[10px] font-bold uppercase tracking-wider">Transferidos</span>
            <ArrowRightLeft className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-xl font-mono font-extrabold text-amber-900">{transferredCount}</div>
          <div className="text-[11px] text-amber-700 font-mono truncate mt-0.5">{formatBRL(transferredValue)}</div>
        </div>

        {/* Pending */}
        <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-[10px] font-bold uppercase tracking-wider">Pendentes</span>
            <span className="w-2.5 h-2.5 rounded-full bg-slate-400"></span>
          </div>
          <div className="text-xl font-mono font-extrabold text-slate-800">{pendingCount}</div>
          <div className="text-[11px] text-slate-500 truncate mt-0.5">
            {totalAssets > 0 ? `${Math.round((pendingCount / totalAssets) * 100)}% a vistoriar` : '-'}
          </div>
        </div>

        {/* Attention / Alerts */}
        <div className="bg-orange-50/50 p-3.5 rounded-xl border border-orange-200/70 shadow-xs">
          <div className="flex items-center justify-between text-orange-800 mb-1">
            <span className="text-[10px] font-bold uppercase tracking-wider">Avarias / Placas</span>
            <ShieldAlert className="w-4 h-4 text-orange-600" />
          </div>
          <div className="text-xl font-mono font-extrabold text-orange-950">
            {needMaintenanceCount + badTagCount}
          </div>
          <div className="text-[11px] text-orange-800 truncate mt-0.5">
            {needMaintenanceCount} avarias • {badTagCount} s/ placa
          </div>
        </div>
      </div>
    </div>
  );
};

