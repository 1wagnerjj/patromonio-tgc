import React, { useState } from 'react';
import {
  Archive,
  Printer,
  Download,
  Trash2,
  Calendar,
  Layers,
  FileCode,
  Tag,
  CheckCircle2,
  Upload,
  Sparkles,
} from 'lucide-react';
import { ArchivedLabelBatch, AssetItem } from '../types';
import {
  getArchivedLabelBatches,
  deleteArchivedLabelBatch,
  exportArchivedBatchesToJson,
  importArchivedBatchesFromJson,
} from '../utils/labelArchiveStorage';
import {
  openPimacoPrintWindow,
  downloadPimacoHtmlFile,
  LabelPrintOptions,
} from '../utils/labelPrintEngine';

interface ArchivedLabelsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLoadBatch: (batch: ArchivedLabelBatch) => void;
  selectedYear: number;
}

export const ArchivedLabelsModal: React.FC<ArchivedLabelsModalProps> = ({
  isOpen,
  onClose,
  onLoadBatch,
  selectedYear,
}) => {
  const [batches, setBatches] = useState<ArchivedLabelBatch[]>(() => getArchivedLabelBatches());
  const [feedbackMsg, setFeedbackMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const reloadBatches = () => {
    setBatches(getArchivedLabelBatches());
  };

  const handleDelete = (id: string, name: string) => {
    if (window.confirm(`Tem certeza que deseja excluir o lote "${name}" do arquivo?`)) {
      deleteArchivedLabelBatch(id);
      reloadBatches();
      setFeedbackMsg(`Lote "${name}" excluído com sucesso.`);
      setTimeout(() => setFeedbackMsg(null), 3000);
    }
  };

  const handlePrintBatch = async (batch: ArchivedLabelBatch) => {
    // Reconstruct asset items from snapshots
    const assets: (AssetItem | null)[] = [];
    for (let i = 1; i < batch.startPosition; i++) {
      assets.push(null);
    }

    if (batch.assetSnapshots && batch.assetSnapshots.length > 0) {
      batch.assetSnapshots.forEach((snap) => {
        for (let c = 0; c < batch.copiesPerAsset; c++) {
          assets.push({
            id: snap.id,
            patrimonio: snap.patrimonio,
            descricao: snap.descricao,
            complemento: snap.complemento || '',
            dtAquisicao: '2026-01-01',
            vlBase: 0,
            unidade: snap.unidade || 'COMLURB',
            gerenciaCode: batch.departmentCode,
            gerenciaName: batch.departmentCode,
            localidade: snap.localidade || '',
            centroCusto: snap.centroCusto || '',
            isBlank: snap.isBlank,
            blankStyle: batch.blankConfig?.blankStyle,
          });
        }
      });
    }

    const printOptions: LabelPrintOptions = {
      assets,
      paperFormat: batch.paperFormat,
      rowHeightMm: batch.rowHeightMm,
      colWidthMm: batch.colWidthMm,
      colGapMm: batch.colGapMm,
      offsetTopMm: batch.offsetTopMm,
      offsetLeftMm: batch.offsetLeftMm,
      layoutStyle: batch.layoutStyle,
      showHeader: batch.showHeader,
      showUnit: batch.showUnit,
      showCostCenter: batch.showCostCenter,
      showWarningFooter: batch.showWarningFooter,
      showBorderGuide: batch.showBorderGuide,
      customHeader: batch.customHeader,
      customSubHeader: batch.customSubHeader,
      customFooter: batch.customFooter,
      customLoc: batch.customLoc,
      barcodeType: batch.barcodeType,
      patrimonioFontSizePt: batch.patrimonioFontSizePt || batch.blankConfig?.fontSizePt,
      selectedYear,
      batchTitle: batch.name,
      archivedBatchId: batch.id,
      archivedAt: new Date(batch.createdAt).toLocaleString('pt-BR'),
    };

    await openPimacoPrintWindow(printOptions);
  };

  const handleDownloadBatchHtml = async (batch: ArchivedLabelBatch) => {
    const assets: (AssetItem | null)[] = [];
    for (let i = 1; i < batch.startPosition; i++) {
      assets.push(null);
    }

    if (batch.assetSnapshots && batch.assetSnapshots.length > 0) {
      batch.assetSnapshots.forEach((snap) => {
        for (let c = 0; c < batch.copiesPerAsset; c++) {
          assets.push({
            id: snap.id,
            patrimonio: snap.patrimonio,
            descricao: snap.descricao,
            complemento: snap.complemento || '',
            dtAquisicao: '2026-01-01',
            vlBase: 0,
            unidade: snap.unidade || 'COMLURB',
            gerenciaCode: batch.departmentCode,
            gerenciaName: batch.departmentCode,
            localidade: snap.localidade || '',
            centroCusto: snap.centroCusto || '',
            isBlank: snap.isBlank,
            blankStyle: batch.blankConfig?.blankStyle,
            customFontSize: snap.customFontSize,
            customHeader: snap.customHeader,
            customSubHeader: snap.customSubHeader,
            customFooter: snap.customFooter,
            customLoc: snap.customLoc,
            hideQr: snap.hideQr,
          });
        }
      });
    }

    const printOptions: LabelPrintOptions = {
      assets,
      paperFormat: batch.paperFormat,
      rowHeightMm: batch.rowHeightMm,
      colWidthMm: batch.colWidthMm,
      colGapMm: batch.colGapMm,
      offsetTopMm: batch.offsetTopMm,
      offsetLeftMm: batch.offsetLeftMm,
      layoutStyle: batch.layoutStyle,
      showHeader: batch.showHeader,
      showUnit: batch.showUnit,
      showCostCenter: batch.showCostCenter,
      showWarningFooter: batch.showWarningFooter,
      showBorderGuide: batch.showBorderGuide,
      customHeader: batch.customHeader,
      customSubHeader: batch.customSubHeader,
      customFooter: batch.customFooter,
      customLoc: batch.customLoc,
      barcodeType: batch.barcodeType,
      patrimonioFontSizePt: batch.patrimonioFontSizePt || batch.blankConfig?.fontSizePt,
      selectedYear,
      batchTitle: batch.name,
      archivedBatchId: batch.id,
      archivedAt: new Date(batch.createdAt).toLocaleString('pt-BR'),
    };

    const safeName = batch.name.replace(/[^a-zA-Z0-9_-]/g, '_');
    await downloadPimacoHtmlFile(printOptions, `Etiquetas_Arquivadas_${safeName}.html`);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const text = evt.target?.result as string;
        const count = importArchivedBatchesFromJson(text);
        reloadBatches();
        setFeedbackMsg(`${count} lote(s) importado(s) com sucesso.`);
        setTimeout(() => setFeedbackMsg(null), 3000);
      } catch {
        alert('Arquivo JSON inválido.');
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 backdrop-blur-xs p-4 overflow-y-auto">
      <div className="bg-white w-full max-w-4xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-auto flex flex-col max-h-[90vh]">
        {/* Modal Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-200 bg-slate-50 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-orange-600 text-white flex items-center justify-center shadow-xs">
              <Archive className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-black text-slate-900">
                  Arquivo de Lotes de Etiquetas Salvas
                </h3>
                <span className="bg-orange-100 text-orange-900 font-extrabold text-xs px-2.5 py-0.5 rounded-full border border-orange-200">
                  {batches.length} Lote{batches.length !== 1 ? 's' : ''}
                </span>
              </div>
              <p className="text-xs text-slate-500 font-medium mt-0.5">
                Histórico de folhas geradas para reimpressão rápida, auditoria e download
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={exportArchivedBatchesToJson}
              disabled={batches.length === 0}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-white border border-slate-300 hover:bg-slate-50 disabled:opacity-40 text-slate-700 rounded-xl text-xs font-bold transition-colors cursor-pointer"
              title="Baixar cópia de segurança de todos os lotes"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Backup JSON</span>
            </button>

            <label className="flex items-center gap-1.5 px-3 py-1.5 bg-white border border-slate-300 hover:bg-slate-50 text-slate-700 rounded-xl text-xs font-bold transition-colors cursor-pointer">
              <Upload className="w-3.5 h-3.5" />
              <span>Restaurar</span>
              <input type="file" accept=".json" onChange={handleFileUpload} className="hidden" />
            </label>

            <button
              onClick={onClose}
              className="w-8 h-8 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-700 flex items-center justify-center font-bold text-sm cursor-pointer ml-1"
            >
              ✕
            </button>
          </div>
        </div>

        {/* Feedback alert */}
        {feedbackMsg && (
          <div className="mx-6 mt-4 p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs font-bold text-emerald-900 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{feedbackMsg}</span>
          </div>
        )}

        {/* Modal Body: List of Batches */}
        <div className="p-6 overflow-y-auto space-y-3.5 flex-1">
          {batches.length === 0 ? (
            <div className="text-center py-12 px-4 bg-slate-50 rounded-2xl border-2 border-dashed border-slate-200">
              <Archive className="w-12 h-12 text-slate-300 mx-auto mb-3" />
              <h4 className="text-sm font-bold text-slate-700">Nenhum lote arquivado ainda</h4>
              <p className="text-xs text-slate-500 max-w-md mx-auto mt-1">
                Ao configurar suas folhas de etiquetas ou etiquetas em branco, clique no botão{' '}
                <strong>"💾 Salvar Lote no Arquivo"</strong> para armazená-las e acessá-las aqui a qualquer momento.
              </p>
            </div>
          ) : (
            batches.map((batch) => {
              const isBlankBatch = batch.sourceType === 'blank_labels';
              const formattedDate = new Date(batch.createdAt).toLocaleString('pt-BR', {
                dateStyle: 'short',
                timeStyle: 'short',
              });

              return (
                <div
                  key={batch.id}
                  className="bg-white p-4 rounded-xl border border-slate-200 hover:border-orange-300 shadow-2xs hover:shadow-xs transition-all space-y-3"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div className="flex items-start gap-2.5">
                      <div
                        className={`w-9 h-9 rounded-lg flex items-center justify-center shrink-0 font-bold ${
                          isBlankBatch
                            ? 'bg-amber-100 text-amber-900 border border-amber-300'
                            : 'bg-orange-100 text-orange-900 border border-orange-200'
                        }`}
                      >
                        {isBlankBatch ? <Sparkles className="w-5 h-5" /> : <Tag className="w-5 h-5" />}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="font-extrabold text-slate-900 text-sm">{batch.name}</h4>
                          <span
                            className={`text-[10px] font-black px-2 py-0.5 rounded uppercase ${
                              isBlankBatch
                                ? 'bg-amber-100 text-amber-800'
                                : 'bg-slate-100 text-slate-700'
                            }`}
                          >
                            {isBlankBatch ? 'Em Branco / Avulso' : 'Bens Inventariados'}
                          </span>
                        </div>
                        <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-slate-500 font-medium mt-0.5">
                          <span className="flex items-center gap-1">
                            <Calendar className="w-3.5 h-3.5 text-slate-400" />
                            {formattedDate}
                          </span>
                          <span className="flex items-center gap-1">
                            <Layers className="w-3.5 h-3.5 text-slate-400" />
                            {batch.labelCount} etiquetas ({batch.sheetsCount} folha{batch.sheetsCount !== 1 ? 's' : ''})
                          </span>
                          <span className="font-mono text-[11px] bg-slate-100 px-1.5 py-0.5 rounded text-slate-700 font-bold">
                            {batch.layoutStyle === 'big_numbers'
                              ? `Números Gigantes (${batch.patrimonioFontSizePt || 85}pt)`
                              : batch.layoutStyle === 'standard_pimaco'
                              ? `Oficial Pimaco 6181 (${batch.patrimonioFontSizePt || 13}pt)`
                              : batch.layoutStyle === 'full_barcode'
                              ? 'Barras 128 + QR'
                              : 'Apenas Barras'}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Batch Actions */}
                    <div className="flex flex-wrap items-center gap-2 self-end sm:self-center">
                      <button
                        onClick={() => handlePrintBatch(batch)}
                        className="flex items-center gap-1.5 px-3 py-1.5 bg-orange-600 hover:bg-orange-700 text-white rounded-lg text-xs font-bold shadow-2xs transition-colors cursor-pointer"
                        title="Imprimir lote diretamente"
                      >
                        <Printer className="w-3.5 h-3.5" />
                        <span>Imprimir</span>
                      </button>

                      <button
                        onClick={() => {
                          onLoadBatch(batch);
                          onClose();
                        }}
                        className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-amber-400 rounded-lg text-xs font-bold transition-colors cursor-pointer"
                        title="Abrir no editor de etiquetas"
                      >
                        <span>Carregar</span>
                      </button>

                      <button
                        onClick={() => handleDownloadBatchHtml(batch)}
                        className="p-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg transition-colors cursor-pointer"
                        title="Baixar arquivo HTML independente"
                      >
                        <FileCode className="w-4 h-4" />
                      </button>

                      <button
                        onClick={() => handleDelete(batch.id, batch.name)}
                        className="p-1.5 bg-slate-100 hover:bg-red-100 text-slate-400 hover:text-red-700 rounded-lg transition-colors cursor-pointer"
                        title="Excluir lote arquivado"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {batch.notes && (
                    <div className="text-xs text-slate-600 bg-slate-50 p-2 rounded-lg border border-slate-100">
                      <strong>Obs:</strong> {batch.notes}
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex justify-between items-center text-xs text-slate-500 shrink-0">
          <span>Os lotes ficam salvos permanentemente no armazenamento do navegador.</span>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-800 font-bold rounded-xl cursor-pointer"
          >
            Fechar
          </button>
        </div>
      </div>
    </div>
  );
};
