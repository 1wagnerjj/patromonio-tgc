import React from 'react';
import {
  Check,
  X,
  ArrowRightLeft,
  Edit3,
  Tag,
  MapPin,
  Calendar,
  DollarSign,
  Archive,
  CheckCircle2,
} from 'lucide-react';
import { AssetItem, InspectionRecord } from '../types';
import { formatBRL, formatDateBR, getStatusBadge } from '../utils/formatters';

interface AssetCardViewProps {
  assets: AssetItem[];
  inspections: Record<string, InspectionRecord>;
  selectedYear: number;
  selectedIds: Set<string>;
  onToggleSelect: (id: string) => void;
  onUpdateInspection: (assetId: string, updates: Partial<InspectionRecord>) => void;
  onUpdateAsset?: (assetId: string, updates: Partial<AssetItem>) => void;
  onOpenDetails: (asset: AssetItem) => void;
  onOpenLabelForAsset?: (asset: AssetItem) => void;
}

export const AssetCardView: React.FC<AssetCardViewProps> = ({
  assets,
  inspections,
  selectedYear,
  selectedIds,
  onToggleSelect,
  onUpdateInspection,
  onOpenDetails,
  onOpenLabelForAsset,
}) => {
  if (assets.length === 0) {
    return (
      <div className="bg-white rounded-xl border border-slate-200 p-8 text-center text-slate-500 shadow-xs">
        Nenhum bem patrimonial encontrado com os filtros selecionados.
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      {assets.map((asset) => {
        const key = `${asset.id}-${selectedYear}`;
        const insp = inspections[key] || {
          assetId: asset.id,
          year: selectedYear,
          status: 'pendente',
          condition: 'nao_avaliado',
          observacao: '',
        };

        const isSelected = selectedIds.has(asset.id);
        const statusBadge = getStatusBadge(insp.status);

        return (
          <div
            key={asset.id}
            className={`bg-white rounded-xl border transition-all duration-200 shadow-xs flex flex-col justify-between overflow-hidden ${
              isSelected
                ? 'border-orange-500 ring-2 ring-orange-400/20'
                : insp.status === 'ausente'
                ? 'border-rose-300 bg-rose-50/20'
                : 'border-slate-200 hover:border-slate-300'
            }`}
          >
            {/* Card Header */}
            <div className="p-4 border-b border-slate-100 bg-slate-50/50">
              <div className="flex items-center justify-between gap-2 mb-1.5">
                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={isSelected}
                    onChange={() => onToggleSelect(asset.id)}
                    className="rounded border-slate-300 text-orange-600 focus:ring-orange-500 cursor-pointer"
                    aria-label={`Selecionar ${asset.patrimonio}`}
                  />
                  <span className="font-mono font-extrabold text-xs bg-slate-900 text-orange-400 px-2 py-0.5 rounded shadow-2xs">
                    Nº {asset.patrimonio}
                  </span>
                </div>

                <span
                  className={`text-[10px] font-bold px-2 py-0.5 rounded-full border flex items-center gap-1 ${statusBadge.bg}`}
                >
                  <span className={`w-1.5 h-1.5 rounded-full ${statusBadge.dot}`} />
                  {statusBadge.label}
                </span>
              </div>

              <h3 className="font-bold text-slate-900 text-sm leading-tight mt-2 uppercase">
                {asset.descricao}
              </h3>
              <p className="text-xs text-slate-500 font-mono mt-1 line-clamp-2">
                {asset.complemento}
              </p>
            </div>

            {/* Card Metadata Details */}
            <div className="p-4 space-y-2.5 text-xs text-slate-600 flex-1">
              <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                <span className="flex items-center gap-1 text-slate-500">
                  <DollarSign className="w-3.5 h-3.5" /> Valor Base:
                </span>
                <span className="font-mono font-bold text-slate-900">{formatBRL(asset.vlBase)}</span>
              </div>

              <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                <span className="flex items-center gap-1 text-slate-500">
                  <Calendar className="w-3.5 h-3.5" /> Aquisição:
                </span>
                <span className="font-medium text-slate-700">{formatDateBR(asset.dtAquisicao)}</span>
              </div>

              <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                <span className="flex items-center gap-1 text-slate-500">
                  <MapPin className="w-3.5 h-3.5" /> Gerência / Loc:
                </span>
                <span className="font-semibold text-slate-800 text-right">
                  {asset.gerenciaCode} (Loc. {asset.localidade})
                </span>
              </div>

              {/* Status Patrimonial: Ativo ou Baixa */}
              <div className="flex items-center justify-between border-b border-slate-100 pb-2">
                <span className="flex items-center gap-1 text-slate-500 font-medium">
                  Situação:
                </span>
                {asset.situacao === 'baixado' ? (
                  <div className="text-right">
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-rose-100 text-rose-800 border border-rose-200">
                      <Archive className="w-3 h-3 text-rose-600" />
                      Baixado
                    </span>
                    <span className="text-[10px] text-rose-600 block font-mono">
                      Baixa: {formatDateBR(asset.dtBaixa)}
                    </span>
                  </div>
                ) : (
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                    <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                    Ativo (Em Carga)
                  </span>
                )}
              </div>

              {/* Tag Physical State indicator */}
              <div className="flex items-center justify-between">
                <span className="flex items-center gap-1 text-slate-500">
                  <Tag className="w-3.5 h-3.5" /> Plaqueta Física:
                </span>
                <button
                  type="button"
                  onClick={() =>
                    onUpdateInspection(asset.id, {
                      tagCondition: insp.tagCondition === 'legivel' ? 'danificada' : 'legivel',
                    })
                  }
                  title="Clique para alternar / regularizar estado da plaqueta"
                  className={`font-semibold px-2 py-0.5 rounded text-[10px] cursor-pointer transition-all hover:ring-1 hover:ring-slate-400 ${
                    insp.tagCondition === 'sem_plaqueta'
                      ? 'bg-rose-100 text-rose-800'
                      : insp.tagCondition === 'danificada'
                      ? 'bg-orange-100 text-orange-800'
                      : 'bg-emerald-100 text-emerald-800'
                  }`}
                >
                  {insp.tagCondition === 'sem_plaqueta'
                    ? 'Sem Plaqueta (Regularizar)'
                    : insp.tagCondition === 'danificada'
                    ? 'Plaqueta Danificada (Regularizar)'
                    : '✓ Plaqueta Legível'}
                </button>
              </div>

              {/* Inline Observation */}
              <div className="mt-2">
                <label className="text-[11px] font-bold text-slate-500 block mb-1">
                  Observação / Sala:
                </label>
                <input
                  type="text"
                  value={insp.observacao || ''}
                  onChange={(e) =>
                    onUpdateInspection(asset.id, {
                      observacao: e.target.value,
                    })
                  }
                  placeholder="Ex: Sala 01, perfeito estado..."
                  className="w-full text-xs px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-slate-800 focus:bg-white focus:outline-none focus:ring-2 focus:ring-orange-500"
                />
              </div>
            </div>

            {/* Quick Action Bottom Bar */}
            <div className="p-3 bg-slate-50 border-t border-slate-200">
              <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1.5 text-center">
                Vistoria Física In Loco
              </div>
              <div className="grid grid-cols-3 gap-1.5 mb-2">
                <button
                  type="button"
                  onClick={() =>
                    onUpdateInspection(asset.id, {
                      status: 'presente',
                      inspectedAt: new Date().toISOString(),
                    })
                  }
                  className={`py-2 px-2 rounded-lg text-xs font-bold flex items-center justify-center gap-1 transition-all cursor-pointer ${
                    insp.status === 'presente'
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : 'bg-white border border-slate-300 text-slate-700 hover:bg-emerald-50 hover:text-emerald-700'
                  }`}
                >
                  <Check className="w-4 h-4" />
                  <span>Sim</span>
                </button>

                <button
                  type="button"
                  onClick={() =>
                    onUpdateInspection(asset.id, {
                      status: 'ausente',
                      inspectedAt: new Date().toISOString(),
                    })
                  }
                  className={`py-2 px-2 rounded-lg text-xs font-bold flex items-center justify-center gap-1 transition-all cursor-pointer ${
                    insp.status === 'ausente'
                      ? 'bg-rose-600 text-white shadow-xs'
                      : 'bg-white border border-slate-300 text-slate-700 hover:bg-rose-50 hover:text-rose-700'
                  }`}
                >
                  <X className="w-4 h-4" />
                  <span>Não</span>
                </button>

                <button
                  type="button"
                  onClick={() =>
                    onUpdateInspection(asset.id, {
                      status: 'transferido',
                      inspectedAt: new Date().toISOString(),
                    })
                  }
                  className={`py-2 px-2 rounded-lg text-xs font-bold flex items-center justify-center gap-1 transition-all cursor-pointer ${
                    insp.status === 'transferido'
                      ? 'bg-orange-600 text-white shadow-xs'
                      : 'bg-white border border-slate-300 text-slate-700 hover:bg-orange-50 hover:text-orange-700'
                  }`}
                >
                  <ArrowRightLeft className="w-4 h-4" />
                  <span>Transf.</span>
                </button>
              </div>

              <div className="flex gap-1.5">
                {onOpenLabelForAsset && (
                  <button
                    onClick={() => onOpenLabelForAsset(asset)}
                    className="py-1.5 px-2 bg-amber-100 hover:bg-amber-200 text-amber-900 rounded-lg text-xs font-bold flex items-center justify-center gap-1 transition-colors cursor-pointer border border-amber-300 shrink-0"
                    title="Imprimir Etiqueta Pimaco deste bem"
                  >
                    <Tag className="w-3.5 h-3.5 text-amber-800" />
                    <span>Etiqueta</span>
                  </button>
                )}
                <button
                  onClick={() => onOpenDetails(asset)}
                  className="flex-1 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-800 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                >
                  <Edit3 className="w-3.5 h-3.5" />
                  <span>Laudo Completo</span>
                </button>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
};

