import React, { useState } from 'react';
import { X, PlusCircle } from 'lucide-react';
import { AssetItem, DepartmentInfo } from '../types';

interface AddAssetModalProps {
  departments: DepartmentInfo[];
  onClose: () => void;
  onAddAsset: (newAsset: AssetItem) => void;
}

export const AddAssetModal: React.FC<AddAssetModalProps> = ({
  departments,
  onClose,
  onAddAsset,
}) => {
  const [patrimonio, setPatrimonio] = useState('');
  const [descricao, setDescricao] = useState('');
  const [complemento, setComplemento] = useState('');
  const [dtAquisicao, setDtAquisicao] = useState(new Date().toISOString().split('T')[0]);
  const [vlBase, setVlBase] = useState('');
  const [gerenciaCode, setGerenciaCode] = useState(departments[0]?.code || 'TGC');
  const [categoria, setCategoria] = useState('Mobiliário & Escritório');
  const [situacao, setSituacao] = useState<'ativo' | 'baixado'>('ativo');
  const [dtBaixa, setDtBaixa] = useState('');
  const [motivoBaixa, setMotivoBaixa] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!patrimonio.trim() || !descricao.trim()) return;

    const dept = departments.find((d) => d.code === gerenciaCode) || departments[0];
    const val = parseFloat(vlBase.replace(',', '.')) || 0;

    const newAsset: AssetItem = {
      id: `${gerenciaCode.toLowerCase()}-${patrimonio.trim()}`,
      patrimonio: patrimonio.trim(),
      descricao: descricao.trim().toUpperCase(),
      complemento: complemento.trim(),
      dtAquisicao,
      vlBase: val,
      unidade: dept.code,
      gerenciaCode: dept.code,
      gerenciaName: dept.name,
      localidade: dept.locationCode,
      centroCusto: dept.costCenter,
      categoria,
      situacao,
      dtBaixa: situacao === 'baixado' ? (dtBaixa || new Date().toISOString().slice(0, 10)) : undefined,
      motivoBaixa: situacao === 'baixado' ? motivoBaixa : undefined,
    };

    onAddAsset(newAsset);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto no-print">
      <div className="bg-white rounded-2xl max-w-lg w-full overflow-hidden shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 duration-200">
        <div className="bg-slate-900 text-white p-5 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <PlusCircle className="w-5 h-5 text-orange-400" />
            <h2 className="text-lg font-extrabold tracking-tight">Cadastrar Novo Bem Patrimonial</h2>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs">
          <div>
            <label className="block font-bold text-slate-700 mb-1">
              Número de Tombamento / Patrimônio *:
            </label>
            <input
              type="text"
              required
              value={patrimonio}
              onChange={(e) => setPatrimonio(e.target.value)}
              placeholder="Ex: 58165, i00509"
              className="w-full px-3 py-2 border border-slate-300 rounded-lg font-mono font-bold text-slate-900 focus:ring-2 focus:ring-orange-500"
            />
          </div>

          <div>
            <label className="block font-bold text-slate-700 mb-1">
              Descrição Principal do Bem *:
            </label>
            <input
              type="text"
              required
              value={descricao}
              onChange={(e) => setDescricao(e.target.value)}
              placeholder="Ex: CADEIRA, ARMARIO, COMPUTADOR, MOTOR"
              className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 uppercase font-bold focus:ring-2 focus:ring-orange-500"
            />
          </div>

          <div>
            <label className="block font-bold text-slate-700 mb-1">
              Complemento / Especificação Técnica:
            </label>
            <textarea
              rows={2}
              value={complemento}
              onChange={(e) => setComplemento(e.target.value)}
              placeholder="Ex: ESTOFADA PRETA / ESTRUTURA FERRO / DOC: 0123 DE 05/2024"
              className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 focus:ring-2 focus:ring-orange-500 font-mono"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-slate-700 mb-1">
                Data de Aquisição:
              </label>
              <input
                type="date"
                value={dtAquisicao}
                onChange={(e) => setDtAquisicao(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 focus:ring-2 focus:ring-orange-500"
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">
                Valor Base (R$):
              </label>
              <input
                type="text"
                value={vlBase}
                onChange={(e) => setVlBase(e.target.value)}
                placeholder="Ex: 350,00"
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 font-mono font-bold focus:ring-2 focus:ring-orange-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-slate-700 mb-1">
                Gerência / Unidade *:
              </label>
              <select
                value={gerenciaCode}
                onChange={(e) => setGerenciaCode(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 font-bold focus:ring-2 focus:ring-orange-500 cursor-pointer"
              >
                {departments.map((d) => (
                  <option key={d.code} value={d.code}>
                    {d.code} (Loc. {d.locationCode})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">
                Categoria:
              </label>
              <select
                value={categoria}
                onChange={(e) => setCategoria(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-lg text-slate-900 font-medium focus:ring-2 focus:ring-orange-500 cursor-pointer"
              >
                <option value="Mobiliário & Escritório">Mobiliário & Escritório</option>
                <option value="Climatização & Refrigeração">Climatização & Refrigeração</option>
                <option value="Informática & Audiovisual">Informática & Audiovisual</option>
                <option value="Máquinas & Equipamentos">Máquinas & Equipamentos</option>
                <option value="Veículos & Frotas">Veículos & Frotas</option>
              </select>
            </div>
          </div>

          {/* Situação Cadastral: Ativo ou Baixa */}
          <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
            <div>
              <label className="block font-bold text-slate-800 mb-1">
                Situação Inicial do Bem:
              </label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setSituacao('ativo')}
                  className={`py-2 px-3 rounded-lg border text-xs font-bold transition-all cursor-pointer ${
                    situacao === 'ativo'
                      ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                      : 'bg-white border-slate-300 text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  ✓ Ativo (Regular)
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setSituacao('baixado');
                    if (!dtBaixa) setDtBaixa(new Date().toISOString().slice(0, 10));
                  }}
                  className={`py-2 px-3 rounded-lg border text-xs font-bold transition-all cursor-pointer ${
                    situacao === 'baixado'
                      ? 'bg-rose-600 text-white border-rose-600 shadow-xs'
                      : 'bg-white border-slate-300 text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  ⚠️ Baixa (Baixado)
                </button>
              </div>
            </div>

            {situacao === 'baixado' && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-slate-200 animate-in fade-in">
                <div>
                  <label className="block font-bold text-slate-800 mb-1">
                    Data da Baixa:
                  </label>
                  <input
                    type="date"
                    value={dtBaixa}
                    onChange={(e) => setDtBaixa(e.target.value)}
                    className="w-full px-2.5 py-1.5 border border-rose-300 rounded-lg text-slate-900 font-bold focus:ring-2 focus:ring-rose-500 bg-white"
                    required
                  />
                </div>
                <div>
                  <label className="block font-bold text-slate-800 mb-1">
                    Motivo da Baixa:
                  </label>
                  <input
                    type="text"
                    value={motivoBaixa}
                    onChange={(e) => setMotivoBaixa(e.target.value)}
                    placeholder="Ex: Leilão, Inservível..."
                    className="w-full px-2.5 py-1.5 border border-slate-300 rounded-lg text-slate-900 focus:ring-2 focus:ring-rose-500 bg-white"
                  />
                </div>
              </div>
            )}
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-white border border-slate-300 text-slate-700 hover:bg-slate-50 rounded-lg font-bold cursor-pointer"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-orange-600 hover:bg-orange-700 text-white rounded-lg font-bold shadow-xs cursor-pointer transition-colors"
            >
              Adicionar Bem
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

