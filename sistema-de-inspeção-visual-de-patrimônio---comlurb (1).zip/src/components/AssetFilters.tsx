import React from 'react';
import {
  Search,
  Table,
  LayoutGrid,
  BarChart3,
  FileText,
  History,
  CheckSquare,
  XSquare,
  Building,
  Tag,
  ArrowRightLeft,
  Camera,
} from 'lucide-react';
import { FilterState, DepartmentInfo } from '../types';

interface AssetFiltersProps {
  filters: FilterState;
  onFilterChange: (newFilters: Partial<FilterState>) => void;
  departments: DepartmentInfo[];
  categories: string[];
  countsByDepartment: Record<string, number>;
  selectedCount: number;
  totalFilteredCount: number;
  onBatchSetStatus: (status: 'presente' | 'ausente') => void;
  onClearSelection: () => void;
}

export const AssetFilters: React.FC<AssetFiltersProps> = ({
  filters,
  onFilterChange,
  departments,
  categories,
  countsByDepartment,
  selectedCount,
  onBatchSetStatus,
  onClearSelection,
}) => {
  return (
    <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-4 sm:p-5 space-y-3.5 no-print">
      {/* Top Row: Department Filter Pills + View Mode Switcher */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3 pb-3 border-b border-slate-100">
        {/* Department Tabs */}
        <div className="flex-1 min-w-0">
          <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
            <Building className="w-3.5 h-3.5 text-slate-500" />
            Filtros de Gerência & Unidade Operacional
          </div>
          <div className="flex flex-wrap items-center gap-1.5">
            <button
              onClick={() => onFilterChange({ gerencia: 'ALL' })}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 border ${
                filters.gerencia === 'ALL'
                  ? 'bg-slate-900 text-white border-slate-900 shadow-xs'
                  : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
              }`}
            >
              <span>Todas as Gerências</span>
              <span
                className={`px-1.5 py-0.2 rounded text-[10px] font-bold ${
                  filters.gerencia === 'ALL' ? 'bg-slate-800 text-orange-400' : 'bg-slate-200 text-slate-700'
                }`}
              >
                {countsByDepartment['ALL'] || 0}
              </span>
            </button>

            {departments.map((dept) => {
              const isSelected = filters.gerencia === dept.code;
              return (
                <button
                  key={dept.code}
                  onClick={() => onFilterChange({ gerencia: dept.code })}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 border ${
                    isSelected
                      ? 'bg-white border-2 border-orange-500 text-orange-700 shadow-xs'
                      : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  <span>
                    {dept.code} - {dept.name.replace(/Gerência de |Divisão de /, '')}
                  </span>
                  <span
                    className={`px-1.5 py-0.2 rounded text-[10px] font-bold ${
                      isSelected ? 'bg-orange-100 text-orange-800' : 'bg-slate-200 text-slate-700'
                    }`}
                  >
                    {countsByDepartment[dept.code] || 0}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* View Mode Segmented Tabs Switcher */}
        <div className="shrink-0 flex items-center bg-slate-100 p-1 rounded-lg border border-slate-200 gap-0.5 overflow-x-auto">
          <button
            onClick={() => onFilterChange({ viewMode: 'table' })}
            className={`flex items-center gap-1 py-1.5 px-2.5 rounded-md text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
              filters.viewMode === 'table'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
            title="Visualização em Tabela Interativa"
          >
            <Table className="w-3.5 h-3.5" />
            <span>Tabela</span>
          </button>

          <button
            onClick={() => onFilterChange({ viewMode: 'cards' })}
            className={`flex items-center gap-1 py-1.5 px-2.5 rounded-md text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
              filters.viewMode === 'cards'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
            title="Visualização em Cartões de Campo"
          >
            <LayoutGrid className="w-3.5 h-3.5" />
            <span>Cartões</span>
          </button>

          <button
            onClick={() => onFilterChange({ viewMode: 'dashboard' })}
            className={`flex items-center gap-1 py-1.5 px-2.5 rounded-md text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
              filters.viewMode === 'dashboard'
                ? 'bg-orange-600 text-white shadow-xs'
                : 'text-slate-700 hover:text-orange-700 hover:bg-orange-50'
            }`}
            title="Dashboard Demonstrativo por Gerência & Evolução"
          >
            <BarChart3 className="w-3.5 h-3.5" />
            <span>Dashboard</span>
          </button>

          <button
            onClick={() => onFilterChange({ viewMode: 'disposal_photos' })}
            className={`flex items-center gap-1 py-1.5 px-2.5 rounded-md text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
              filters.viewMode === 'disposal_photos'
                ? 'bg-orange-600 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
            title="Dossiê Fotográfico de Baixa de Patrimônio (Laudo A4 Oficial)"
          >
            <Camera className="w-3.5 h-3.5" />
            <span>Fotos Baixa</span>
          </button>

          <button
            onClick={() => onFilterChange({ viewMode: 'transfers_and_disposals' })}
            className={`flex items-center gap-1 py-1.5 px-2.5 rounded-md text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
              filters.viewMode === 'transfers_and_disposals'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
            title="Relatório Geral de Baixas e Transferências"
          >
            <ArrowRightLeft className="w-3.5 h-3.5" />
            <span>Baixas/Transf.</span>
          </button>

          <button
            onClick={() => onFilterChange({ viewMode: 'pimaco_labels' })}
            className={`flex items-center gap-1 py-1.5 px-2.5 rounded-md text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
              filters.viewMode === 'pimaco_labels'
                ? 'bg-amber-500 text-slate-950 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
            title="Imprimir Etiquetas Pimaco 6181/6281"
          >
            <Tag className="w-3.5 h-3.5" />
            <span>Etiquetas</span>
          </button>

          <button
            onClick={() => onFilterChange({ viewMode: 'print_preview' })}
            className={`flex items-center gap-1 py-1.5 px-2.5 rounded-md text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
              filters.viewMode === 'print_preview'
                ? 'bg-white text-orange-700 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
            title="Ver Ficha Oficial de Impressão"
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Relatório</span>
          </button>

          <button
            onClick={() => onFilterChange({ viewMode: 'annual_compare' })}
            className={`flex items-center gap-1 py-1.5 px-2.5 rounded-md text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
              filters.viewMode === 'annual_compare'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
            title="Comparativo Anual de Inspeção"
          >
            <History className="w-3.5 h-3.5" />
            <span>Histórico</span>
          </button>
        </div>
      </div>

      {/* Second Row: Search and Attribute Dropdowns in balanced 12-column grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-12 gap-3 items-center">
        {/* Search Bar (5 cols on lg) */}
        <div className="lg:col-span-5 relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={filters.searchTerm}
            onChange={(e) => onFilterChange({ searchTerm: e.target.value })}
            placeholder="Buscar por Nº Patrimônio, descrição ou especificação..."
            className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs font-medium text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-orange-500 focus:bg-white transition-all"
          />
        </div>

        {/* Status de Vistoria Filter (2 cols on lg) */}
        <div className="lg:col-span-2">
          <select
            value={filters.status}
            onChange={(e) => onFilterChange({ status: e.target.value })}
            className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs font-semibold text-slate-700 focus:outline-none focus:ring-2 focus:ring-orange-500 focus:bg-white cursor-pointer"
            aria-label="Filtrar por Status de Vistoria"
          >
            <option value="ALL">Vistoria: Todas</option>
            <option value="presente">✓ No Local (Sim)</option>
            <option value="ausente">✗ Ausente (Não)</option>
            <option value="transferido">⇄ Transferido</option>
            <option value="pendente">⏳ Pendente</option>
          </select>
        </div>

        {/* Situação Cadastral: Ativo ou Baixa (2 cols on lg) */}
        <div className="lg:col-span-2">
          <select
            value={filters.situacao || 'ALL'}
            onChange={(e) => onFilterChange({ situacao: e.target.value as any })}
            className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs font-semibold text-slate-700 focus:outline-none focus:ring-2 focus:ring-orange-500 focus:bg-white cursor-pointer"
            aria-label="Filtrar por Situação do Bem"
          >
            <option value="ALL">Situação: Todas</option>
            <option value="ativo">✓ Somente Ativos</option>
            <option value="baixado">⚠️ Somente Baixados</option>
          </select>
        </div>

        {/* Category Filter (3 cols on lg) */}
        <div className="lg:col-span-3">
          <select
            value={filters.categoria}
            onChange={(e) => onFilterChange({ categoria: e.target.value })}
            className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs font-semibold text-slate-700 focus:outline-none focus:ring-2 focus:ring-orange-500 focus:bg-white cursor-pointer"
            aria-label="Filtrar por Categoria"
          >
            <option value="ALL">Categoria: Todas</option>
            {categories.map((cat) => (
              <option key={cat} value={cat}>
                {cat}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Batch Action Toolbar when items are selected */}
      {selectedCount > 0 && (
        <div className="bg-orange-50 border border-orange-200 rounded-lg p-3 flex flex-wrap items-center justify-between gap-3 text-xs text-orange-950">
          <div className="flex items-center gap-2 font-medium">
            <span className="bg-orange-600 text-white px-2 py-0.5 rounded-full font-bold">
              {selectedCount}
            </span>
            <span>bens selecionados:</span>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => onFilterChange({ viewMode: 'pimaco_labels' })}
              className="flex items-center gap-1 px-3 py-1.5 bg-amber-500 hover:bg-amber-600 text-slate-950 rounded-md font-bold cursor-pointer shadow-xs transition-colors border border-amber-600"
              title="Gerar Etiquetas Pimaco 6181 para os selecionados"
            >
              <Tag className="w-3.5 h-3.5" />
              Imprimir Etiquetas Pimaco ({selectedCount})
            </button>
            <button
              onClick={() => onBatchSetStatus('presente')}
              className="flex items-center gap-1 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-md font-bold cursor-pointer shadow-xs transition-colors"
            >
              <CheckSquare className="w-3.5 h-3.5" />
              Confirmar "No Local (Sim)"
            </button>
            <button
              onClick={() => onBatchSetStatus('ausente')}
              className="flex items-center gap-1 px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-md font-bold cursor-pointer shadow-xs transition-colors"
            >
              <XSquare className="w-3.5 h-3.5" />
              Marcar "Ausente (Não)"
            </button>
            <button
              onClick={onClearSelection}
              className="px-2.5 py-1.5 bg-white border border-slate-300 text-slate-700 hover:bg-slate-100 rounded-md font-medium cursor-pointer"
            >
              Cancelar
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

