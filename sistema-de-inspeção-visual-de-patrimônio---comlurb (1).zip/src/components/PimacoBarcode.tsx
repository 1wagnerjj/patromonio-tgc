import React, { useEffect, useState } from 'react';
import { generateBarcodeDataUrl, generateQRCodeDataUrl, buildAssetQRCodeContent } from '../utils/barcodeGenerator';
import { AssetItem, InspectionRecord } from '../types';

interface PimacoBarcodeProps {
  value: string;
  asset?: AssetItem;
  inspection?: InspectionRecord;
  qrData?: string;
  type?: 'barcode' | 'qrcode' | 'both';
  height?: number;
  width?: number;
  showText?: boolean;
}

export const PimacoBarcode: React.FC<PimacoBarcodeProps> = ({
  value,
  asset,
  inspection,
  qrData,
  type = 'barcode',
  height = 24,
  width = 1.2,
}) => {
  const isPureBlank = asset?.isBlank && asset?.blankStyle === 'pure_blank';
  const effectiveValue = value && !value.startsWith('___') ? value : (asset?.patrimonio && !asset.patrimonio.startsWith('___') ? asset.patrimonio : 'COMLURB');

  const [barcodeDataUrl, setBarcodeDataUrl] = useState<string>(() =>
    !isPureBlank ? generateBarcodeDataUrl(effectiveValue, width, height) : ''
  );
  const [qrDataUrl, setQrDataUrl] = useState<string>('');

  useEffect(() => {
    if (isPureBlank) {
      setBarcodeDataUrl('');
      setQrDataUrl('');
      return;
    }

    if (type === 'barcode' || type === 'both') {
      const url = generateBarcodeDataUrl(effectiveValue, width, height);
      setBarcodeDataUrl(url);
    }
  }, [effectiveValue, type, height, width, isPureBlank]);

  useEffect(() => {
    if (isPureBlank) return;

    if (type === 'qrcode' || type === 'both') {
      const payload = qrData || (asset ? buildAssetQRCodeContent(asset, inspection) : `PATRIMONIO:${effectiveValue}|COMLURB`);
      generateQRCodeDataUrl(payload, { width: 256, errorCorrectionLevel: 'M' }).then((url) => {
        setQrDataUrl(url);
      });
    }
  }, [effectiveValue, asset, inspection, qrData, type, isPureBlank]);

  if (isPureBlank) {
    return (
      <div className="w-[19mm] h-[19mm] border border-dashed border-slate-300 rounded flex items-center justify-center bg-slate-50/50">
        <span className="text-[7px] font-bold text-slate-400">QR / SELO</span>
      </div>
    );
  }

  return (
    <div className="flex items-center justify-center gap-1.5 overflow-hidden">
      {(type === 'barcode' || type === 'both') && barcodeDataUrl && (
        <img
          src={barcodeDataUrl}
          alt={`Código de barras ${value}`}
          className="block h-[22px] max-w-full object-contain"
          style={{ imageRendering: 'pixelated' }}
        />
      )}
      {(type === 'qrcode' || type === 'both') && qrDataUrl && (
        <img
          src={qrDataUrl}
          alt={`QR Code ${value}`}
          className="w-7 h-7 shrink-0 object-contain"
          title="QR Code contendo todas as informações do bem"
        />
      )}
    </div>
  );
};
