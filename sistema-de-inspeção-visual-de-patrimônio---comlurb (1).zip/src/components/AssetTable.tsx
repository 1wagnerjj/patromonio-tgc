import React, { useState, useMemo } from 'react';
import {
  Check,
  X,
  ArrowRightLeft,
  Edit3,
  Tag,
  ChevronDown,
  ChevronUp,
  Archive,
  CheckCircle2,
  FileSpreadsheet,
} from 'lucide-react';
import { AssetItem, InspectionRecord, AssetCondition } from '../types';
import { formatBRL, formatDateBR, getSituacaoBadge } from '../utils/formatters';

interface AssetTableProps {
  assets: AssetItem[];
  inspections: Record<string, InspectionRecord>;
  selectedYear: number;
  selectedIds: Set<string>;
  onToggleSelect: (id: string) => void;
  onSelectAll: (all: boolean) => void;
  onUpdateInspection: (assetId: string, updates: Partial<InspectionRecord>) => void;
  onUpdateAsset?: (assetId: string, updates: Partial<AssetItem>) => void;
  onOpenDetails: (asset: AssetItem) => void;
  onOpenLabelForAsset?: (asset: AssetItem) => void;
  onOpenImport?: () => void;
}

type SortField = 'patrimonio' | 'descricao' | 'dtAquisicao' | 'vlBase' | 'status' | 'gerenciaCode' | 'situacao' | 'dtBaixa';
type SortOrder = 'asc' | 'desc';

export const AssetTable: React.FC<AssetTableProps> = ({
  assets,
  inspections,
  selectedYear,
  selectedIds,
  onToggleSelect,
  onSelectAll,
  onUpdateInspection,
  onUpdateAsset,
  onOpenDetails,
  onOpenLabelForAsset,
  onOpenImport,
}) => {
  const [sortField, setSortField] = useState<SortField>('patrimonio');
  const [sortOrder, setSortOrder] = useState<SortOrder>('asc');

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortOrder('asc');
    }
  };

  const sortedAssets = useMemo(() => {
    return [...assets].sort((a, b) => {
      let valA: any = a[sortField as keyof AssetItem] || '';
      let valB: any = b[sortField as keyof AssetItem] || '';

      if (sortField === 'status') {
        valA = inspections[`${a.id}-${selectedYear}`]?.status || 'pendente';
        valB = inspections[`${b.id}-${selectedYear}`]?.status || 'pendente';
      }

      if (sortField === 'situacao') {
        valA = a.situacao || 'ativo';
        valB = b.situacao || 'ativo';
      }

      if (sortField === 'dtBaixa') {
        valA = a.dtBaixa || '';
        valB = b.dtBaixa || '';
      }

      if (sortField === 'vlBase') {
        return sortOrder === 'asc' ? a.vlBase - b.vlBase : b.vlBase - a.vlBase;
      }

      if (typeof valA === 'string') {
        const cmp = valA.localeCompare(valB, 'pt-BR', { numeric: true });
        return sortOrder === 'asc' ? cmp : -cmp;
      }

      return 0;
    });
  }, [assets, inspections, selectedYear, sortField, sortOrder]);

  const allSelected = assets.length > 0 && assets.every((a) => selectedIds.has(a.id));
  const someSelected = assets.some((a) => selectedIds.has(a.id)) && !allSelected;

  const totalValue = assets.reduce((sum, item) => sum + (item.vlBase || 0), 0);

  return (
    <div className="bg-white rounded-xl border border-slate-200 shadow-xs overflow-hidden">
      <div className="overflow-x-auto scrollbar-thin scrollbar-thumb-slate-300">
        <table className="w-full text-left text-xs text-slate-700 border-collapse table-auto">
          <thead className="bg-slate-50 border-b border-slate-200 text-[10px] font-bold text-slate-500 uppercase tracking-wider select-none sticky top-0 z-10">
            <tr>
              <th scope="col" className="p-2.5 w-10 text-center">
                <input
                  type="checkbox"
                  checked={allSelected}
                  ref={(input) => {
                    if (input) input.indeterminate = someSelected;
                  }}
                  onChange={(e) => onSelectAll(e.target.checked)}
                  className="rounded border-slate-300 text-orange-600 focus:ring-orange-500 cursor-pointer"
                  aria-label="Selecionar todos os bens"
                />
              </th>
              <th
                scope="col"
                onClick={() => handleSort('patrimonio')}
                className="p-2.5 cursor-pointer hover:text-slate-900 transition-colors whitespace-nowrap min-w-[90px]"
              >
                <div className="flex items-center gap-1">
                  <span>Patrimônio</span>
                  {sortField === 'patrimonio' && (
                    sortOrder === 'asc' ? <ChevronUp className="w-3 h-3 text-orange-600" /> : <ChevronDown className="w-3 h-3 text-orange-600" />
                  )}
                </div>
              </th>
              <th
                scope="col"
                onClick={() => handleSort('descricao')}
                className="p-2.5 cursor-pointer hover:text-slate-900 transition-colors min-w-[170px]"
              >
                <div className="flex items-center gap-1">
                  <span>Descrição / Especificação</span>
                  {sortField === 'descricao' && (
                    sortOrder === 'asc' ? <ChevronUp className="w-3 h-3 text-orange-600" /> : <ChevronDown className="w-3 h-3 text-orange-600" />
                  )}
                </div>
              </th>
              <th
                scope="col"
                onClick={() => handleSort('situacao')}
                className="p-2.5 cursor-pointer hover:text-slate-900 transition-colors whitespace-nowrap min-w-[120px]"
              >
                <div className="flex items-center gap-1">
                  <span>Status / Baixa</span>
                  {sortField === 'situacao' && (
                    sortOrder === 'asc' ? <ChevronUp className="w-3 h-3 text-orange-600" /> : <ChevronDown className="w-3 h-3 text-orange-600" />
                  )}
                </div>
              </th>
              <th
                scope="col"
                onClick={() => handleSort('dtAquisicao')}
                className="p-2.5 cursor-pointer hover:text-slate-900 transition-colors hidden md:table-cell whitespace-nowrap min-w-[85px]"
              >
                <div className="flex items-center gap-1">
                  <span>Aquisição</span>
                  {sortField === 'dtAquisicao' && (
                    sortOrder === 'asc' ? <ChevronUp className="w-3 h-3 text-orange-600" /> : <ChevronDown className="w-3 h-3 text-orange-600" />
                  )}
                </div>
              </th>
              <th
                scope="col"
                onClick={() => handleSort('vlBase')}
                className="p-2.5 cursor-pointer hover:text-slate-900 transition-colors text-right whitespace-nowrap min-w-[85px]"
              >
                <div className="flex items-center justify-end gap-1">
                  <span>Vl. Base</span>
                  {sortField === 'vlBase' && (
                    sortOrder === 'asc' ? <ChevronUp className="w-3 h-3 text-orange-600" /> : <ChevronDown className="w-3 h-3 text-orange-600" />
                  )}
                </div>
              </th>
              <th scope="col" className="p-2.5 hidden lg:table-cell whitespace-nowrap min-w-[120px]">
                Unidade / Loc.
              </th>
              <th scope="col" className="p-2.5 text-center min-w-[165px] border-l border-slate-200">
                No Local? (Sim / Não)
              </th>
              <th scope="col" className="p-2.5 min-w-[115px] hidden sm:table-cell">
                Conservação
              </th>
              <th scope="col" className="p-2.5 min-w-[140px] hidden xl:table-cell">
                Observação / Sala
              </th>
              <th scope="col" className="p-2.5 text-right whitespace-nowrap w-20">
                Ações
              </th>
            </tr>
          </thead>

          <tbody className="divide-y divide-slate-100 text-sm">
            {sortedAssets.length === 0 ? (
              <tr>
                <td colSpan={11} className="p-12 text-center">
                  <div className="max-w-md mx-auto flex flex-col items-center justify-center space-y-3">
                    <div className="w-12 h-12 rounded-full bg-slate-100 flex items-center justify-center text-slate-400">
                      <Archive className="w-6 h-6" />
                    </div>
                    <div>
                      <h3 className="text-sm font-bold text-slate-800">
                        {assets.length === 0 ? 'Base de Dados Limpa (0 patrimônios cadastrados)' : 'Nenhum bem patrimonial encontrado'}
                      </h3>
                      <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
                        {assets.length === 0
                          ? 'A base de dados está completamente limpa. Importe sua planilha oficial do Google Sheets ou CSV da COMLURB para carregar os bens de TGC, TDO e TDM.'
                          : 'Nenhum item correspondeu aos filtros aplicados (gerência, status ou termo de busca).'}
                      </p>
                    </div>
                    {assets.length === 0 && onOpenImport && (
                      <button
                        type="button"
                        onClick={onOpenImport}
                        className="mt-2 inline-flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow-xs transition-colors cursor-pointer"
                      >
                        <FileSpreadsheet className="w-4 h-4" />
                        <span>Importar Planilha Oficial da COMLURB (ID Atualizado: 1ZsoXBfn...)</span>
                      </button>
                    )}
                  </div>
                </td>
              </tr>
            ) : (
              sortedAssets.map((asset) => {
                const key = `${asset.id}-${selectedYear}`;
                const insp = inspections[key] || {
                  assetId: asset.id,
                  year: selectedYear,
                  status: 'pendente',
                  condition: 'nao_avaliado',
                  observacao: '',
                };

                const isSelected = selectedIds.has(asset.id);

                return (
                  <tr
                    key={asset.id}
                    className={`hover:bg-slate-50 transition-colors ${
                      isSelected ? 'bg-orange-50/50' : ''
                    } ${insp.status === 'ausente' ? 'bg-rose-50/30' : ''}`}
                  >
                    {/* Checkbox */}
                    <td className="p-2.5 text-center">
                      <input
                        type="checkbox"
                        checked={isSelected}
                        onChange={() => onToggleSelect(asset.id)}
                        className="rounded border-slate-300 text-orange-600 focus:ring-orange-500 cursor-pointer"
                        aria-label={`Selecionar bem ${asset.patrimonio}`}
                      />
                    </td>

                    {/* Patrimonio # */}
                    <td className="p-2.5 font-mono font-bold text-slate-900 whitespace-nowrap">
                      <div className="flex items-center gap-1.5">
                        <span className="bg-slate-100 text-slate-900 px-2 py-0.5 rounded text-xs border border-slate-200 font-mono">
                          {asset.patrimonio}
                        </span>
                        {insp.tagCondition && insp.tagCondition !== 'legivel' && (
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              onUpdateInspection(asset.id, { tagCondition: 'legivel' });
                            }}
                            title={
                              insp.tagCondition === 'sem_plaqueta'
                                ? 'Sem plaqueta de identificação (Clique para marcar como legível / regularizada)'
                                : 'Plaqueta danificada / ilegível (Clique para marcar como legível / regularizada)'
                            }
                            className="text-orange-600 hover:text-emerald-600 transition-colors p-0.5 rounded hover:bg-orange-50 cursor-pointer flex items-center"
                            aria-label="Regularizar estado da plaqueta"
                          >
                            <Tag className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </td>

                    {/* Descricao & Complemento */}
                    <td className="p-2.5">
                      <div className="font-bold text-slate-900 uppercase text-xs leading-tight">{asset.descricao}</div>
                      <div className="text-[11px] text-slate-500 line-clamp-2 max-w-sm font-mono mt-0.5">
                        {asset.complemento}
                      </div>
                      <div className="mt-1 flex flex-wrap gap-1">
                        <span className="inline-block text-[10px] text-slate-500 bg-slate-100 px-1.5 py-0.2 rounded border border-slate-200">
                          {asset.categoria}
                        </span>
                      </div>
                    </td>

                    {/* Status / Situação (Ativo ou Baixa) */}
                    <td className="p-2.5 whitespace-nowrap">
                      {asset.situacao === 'baixado' ? (
                        <div className="flex flex-col items-start gap-0.5">
                          <span
                            onClick={() => onOpenDetails(asset)}
                            className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-bold bg-rose-100 text-rose-800 border border-rose-200 cursor-pointer hover:bg-rose-200 transition-colors"
                            title="Bem baixado do acervo. Clique para gerenciar ou editar."
                          >
                            <Archive className="w-3 h-3 text-rose-600" />
                            Baixado
                          </span>
                          <span className="text-[10px] text-rose-700 font-mono font-medium">
                            Baixa: {formatDateBR(asset.dtBaixa)}
                          </span>
                        </div>
                      ) : (
                        <span
                          onClick={() => onOpenDetails(asset)}
                          className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200 cursor-pointer hover:bg-emerald-200 transition-colors"
                          title="Bem ativo no patrimônio. Clique para gerenciar."
                        >
                          <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                          Ativo
                        </span>
                      )}
                    </td>

                    {/* Data Aquisição */}
                    <td className="p-2.5 whitespace-nowrap text-slate-500 text-xs hidden md:table-cell">
                      {formatDateBR(asset.dtAquisicao)}
                    </td>

                    {/* Valor Base */}
                    <td className="p-2.5 text-right font-mono font-medium text-slate-900 whitespace-nowrap text-xs">
                      {formatBRL(asset.vlBase)}
                    </td>

                    {/* Unidade / Localidade */}
                    <td className="p-2.5 whitespace-nowrap hidden lg:table-cell text-xs">
                      <span className="font-bold text-slate-800">{asset.unidade}</span>
                      <span className="text-[10px] text-slate-500 block font-mono">
                        Loc: {asset.localidade} • CC: {asset.centroCusto}
                      </span>
                    </td>

                    {/* Encontra-se no Local? (Interactive Audit Controls) */}
                    <td className="p-2.5 border-l border-slate-200">
                      <div className="flex items-center justify-center gap-1 bg-slate-100 p-0.5 rounded-lg border border-slate-200">
                        {/* Sim Button */}
                        <button
                          type="button"
                          onClick={() =>
                            onUpdateInspection(asset.id, {
                              status: 'presente',
                              inspectedAt: new Date().toISOString(),
                            })
                          }
                          className={`flex-1 flex items-center justify-center gap-1 py-1 px-2 rounded-md text-xs font-bold transition-all cursor-pointer ${
                            insp.status === 'presente'
                              ? 'bg-emerald-600 text-white shadow-xs'
                              : 'text-slate-600 hover:bg-slate-200 hover:text-emerald-700'
                          }`}
                          title="Confirmar presença física do bem no local"
                        >
                          <Check className="w-3.5 h-3.5" />
                          <span>Sim</span>
                        </button>

                        {/* Não Button */}
                        <button
                          type="button"
                          onClick={() =>
                            onUpdateInspection(asset.id, {
                              status: 'ausente',
                              inspectedAt: new Date().toISOString(),
                            })
                          }
                          className={`flex-1 flex items-center justify-center gap-1 py-1 px-2 rounded-md text-xs font-bold transition-all cursor-pointer ${
                            insp.status === 'ausente'
                              ? 'bg-rose-600 text-white shadow-xs'
                              : 'text-slate-600 hover:bg-slate-200 hover:text-rose-700'
                          }`}
                          title="Marcar como bem NÃO encontrado no local (Divergência)"
                        >
                          <X className="w-3.5 h-3.5" />
                          <span>Não</span>
                        </button>

                        {/* Transferido Button */}
                        <button
                          type="button"
                          onClick={() =>
                            onUpdateInspection(asset.id, {
                              status: 'transferido',
                              inspectedAt: new Date().toISOString(),
                            })
                          }
                          className={`py-1 px-1.5 rounded-md text-xs font-bold transition-all cursor-pointer ${
                            insp.status === 'transferido'
                              ? 'bg-orange-600 text-white shadow-xs'
                              : 'text-slate-600 hover:bg-slate-200 hover:text-orange-700'
                          }`}
                          title="Bem transferido para outra gerência ou unidade"
                        >
                          <ArrowRightLeft className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      {/* Transferred destination indicator */}
                      {insp.status === 'transferido' && (
                        <div className="mt-1 text-[10px] text-orange-700 font-bold">
                          Transf: {insp.transferidoPara || '(informar unidade)'}
                        </div>
                      )}
                    </td>

                    {/* Estado de Conservação */}
                    <td className="p-2.5 hidden sm:table-cell text-xs">
                      <select
                        value={insp.condition || 'nao_avaliado'}
                        onChange={(e) => {
                          const newCondition = e.target.value as AssetCondition;
                          onUpdateInspection(asset.id, {
                            condition: newCondition,
                            tagCondition:
                              newCondition === 'bom' || newCondition === 'excelente'
                                ? 'legivel'
                                : insp.tagCondition,
                          });
                        }}
                        className={`w-full text-xs font-semibold px-2 py-1 rounded-md border focus:outline-none cursor-pointer ${
                          insp.condition === 'bom' || insp.condition === 'excelente'
                            ? 'border-emerald-200 bg-emerald-50 text-emerald-800'
                            : insp.condition === 'regular'
                            ? 'border-yellow-200 bg-yellow-50 text-yellow-800'
                            : insp.condition === 'ruim' || insp.condition === 'inservivel'
                            ? 'border-rose-200 bg-rose-50 text-rose-800'
                            : 'border-slate-200 bg-slate-50 text-slate-600'
                        }`}
                        aria-label="Estado de Conservação"
                      >
                        <option value="nao_avaliado">Não avaliado</option>
                        <option value="excelente">Excelente</option>
                        <option value="bom">Bom</option>
                        <option value="regular">Regular</option>
                        <option value="ruim">Ruim</option>
                        <option value="inservivel">Inservível</option>
                      </select>
                    </td>

                    {/* Observações / Sala */}
                    <td className="p-2.5 hidden xl:table-cell">
                      <input
                        type="text"
                        value={insp.observacao || ''}
                        onChange={(e) =>
                          onUpdateInspection(asset.id, {
                            observacao: e.target.value,
                          })
                        }
                        placeholder="Ex: Sala 02, galpão B..."
                        className="w-full text-xs px-2 py-1 bg-slate-50 border border-slate-200 rounded text-slate-800 placeholder-slate-400 focus:bg-white focus:outline-none focus:ring-1 focus:ring-orange-500"
                      />
                    </td>

                    {/* Ações */}
                    <td className="p-2.5 text-right whitespace-nowrap">
                      <div className="flex items-center justify-end gap-1">
                        {onOpenLabelForAsset && (
                          <button
                            onClick={() => onOpenLabelForAsset(asset)}
                            className="p-1.5 text-slate-400 hover:text-amber-600 hover:bg-amber-50 rounded-md transition-colors cursor-pointer"
                            title="Imprimir Etiqueta Pimaco 6181 deste bem"
                          >
                            <Tag className="w-4 h-4" />
                          </button>
                        )}
                        <button
                          onClick={() => onOpenDetails(asset)}
                          className="p-1.5 text-slate-400 hover:text-orange-600 hover:bg-slate-100 rounded-md transition-colors cursor-pointer"
                          title="Ver detalhes completos do bem e laudo"
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>

          {/* Official COMLURB Footer matching Report Totals */}
          <tfoot className="bg-slate-50 text-slate-800 font-bold border-t border-slate-200">
            <tr>
              <td colSpan={3} className="p-3 text-xs">
                Exibindo <span className="text-slate-900 font-mono font-bold">{sortedAssets.length}</span> bens patrimoniais
              </td>
              <td className="p-3 hidden md:table-cell"></td>
              <td className="p-3 text-right font-mono text-orange-600 text-sm font-extrabold">
                {formatBRL(totalValue)}
              </td>
              <td colSpan={5} className="p-3 text-right text-xs text-slate-500">
                Inventário Anual • Exercício {selectedYear} • COML02.2.3.12
              </td>
            </tr>
          </tfoot>
        </table>
      </div>
    </div>
  );
};

