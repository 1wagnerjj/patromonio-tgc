import React, { useState } from 'react';
import {
  X,
  User,
  Check,
  Shield,
  Cloud,
  RefreshCw,
  Users,
  CheckCircle2,
  Mail,
  Building,
} from 'lucide-react';
import { UserAccountProfile, DEFAULT_USER_ACCOUNTS } from '../types';

interface AccountSwitcherModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeAccount: UserAccountProfile;
  onSelectAccount: (account: UserAccountProfile) => void;
  cloudStatus: 'synced' | 'syncing' | 'error' | 'offline';
  lastSyncTime?: string;
  onForceSync: () => Promise<void> | void;
  totalAssets: number;
  totalBaixados: number;
  totalPhotos: number;
}

export const AccountSwitcherModal: React.FC<AccountSwitcherModalProps> = ({
  isOpen,
  onClose,
  activeAccount,
  onSelectAccount,
  cloudStatus,
  lastSyncTime,
  onForceSync,
  totalAssets,
  totalBaixados,
  totalPhotos,
}) => {
  const [customName, setCustomName] = useState('');
  const [customEmail, setCustomEmail] = useState('');
  const [customCargo, setCustomCargo] = useState('');
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncFeedback, setSyncFeedback] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleManualSync = async () => {
    setIsSyncing(true);
    setSyncFeedback(null);
    try {
      await onForceSync();
      setSyncFeedback('Dados sincronizados com sucesso com o servidor central!');
      setTimeout(() => setSyncFeedback(null), 3000);
    } catch {
      setSyncFeedback('Falha ao sincronizar. Tente novamente.');
    } finally {
      setIsSyncing(false);
    }
  };

  const handleCreateCustom = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customName.trim() || !customEmail.trim()) return;
    const newAcc: UserAccountProfile = {
      id: `custom-${Date.now()}`,
      name: customName.trim(),
      email: customEmail.trim().toLowerCase(),
      cargo: customCargo.trim() || 'Fiscal / Auditor Setorial',
      gerencia: 'GERAL',
    };
    onSelectAccount(newAcc);
    setCustomName('');
    setCustomEmail('');
    setCustomCargo('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto no-print">
      <div className="bg-white rounded-2xl max-w-lg w-full overflow-hidden shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="bg-slate-900 text-white p-5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-orange-600 rounded-xl text-white shadow-xs">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-extrabold tracking-tight">
                Integração e Troca de Contas
              </h2>
              <p className="text-xs text-slate-400">
                Sincronização compartilhada entre fiscais e gerências COMLURB
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5 text-xs text-slate-700">
          {/* Cloud Sync Live Status Box */}
          <div className="p-4 bg-emerald-50 border border-emerald-300 rounded-2xl space-y-2.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
                <span className="font-extrabold text-emerald-950 text-xs uppercase tracking-wider">
                  Nuvem Compartilhada Ativa
                </span>
              </div>
              <button
                onClick={handleManualSync}
                disabled={isSyncing}
                className="flex items-center gap-1.5 px-2.5 py-1 bg-emerald-700 hover:bg-emerald-800 text-white text-[11px] font-bold rounded-lg shadow-2xs cursor-pointer transition-colors"
              >
                <RefreshCw className={`w-3 h-3 ${isSyncing ? 'animate-spin' : ''}`} />
                <span>{isSyncing ? 'Sincronizando...' : 'Sincronizar Agora'}</span>
              </button>
            </div>
            <p className="text-emerald-800 text-xs leading-relaxed">
              Todas as modificações, baixas e fotos salvas são gravadas em banco central e integradas automaticamente entre todas as contas.
            </p>
            <div className="pt-2 border-t border-emerald-200/80 flex flex-wrap items-center justify-between text-[11px] text-emerald-900 font-semibold gap-2">
              <span>Bens: <strong>{totalAssets}</strong> ({totalBaixados} baixados)</span>
              <span>Fotos: <strong>{totalPhotos}</strong></span>
              {lastSyncTime && (
                <span>Último sync: <strong className="font-mono">{new Date(lastSyncTime).toLocaleTimeString('pt-BR')}</strong></span>
              )}
            </div>
            {syncFeedback && (
              <div className="text-[11px] font-bold text-emerald-900 bg-emerald-200/60 p-1.5 rounded-md text-center">
                {syncFeedback}
              </div>
            )}
          </div>

          {/* Current Active Account Card */}
          <div className="space-y-1.5">
            <label className="font-bold text-slate-900 text-xs flex items-center gap-1.5">
              <User className="w-3.5 h-3.5 text-orange-600" />
              <span>Conta Ativa no Momento:</span>
            </label>
            <div className="p-3 bg-slate-900 text-white rounded-xl flex items-center justify-between shadow-xs">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-orange-600 flex items-center justify-center font-black text-sm text-white border-2 border-orange-400">
                  {activeAccount.name.slice(0, 2).toUpperCase()}
                </div>
                <div>
                  <div className="font-bold text-sm text-white flex items-center gap-2">
                    <span>{activeAccount.name}</span>
                    <span className="text-[10px] bg-orange-500/30 text-orange-300 font-bold px-1.5 py-0.5 rounded border border-orange-400/40">
                      {activeAccount.gerencia || 'GERAL'}
                    </span>
                  </div>
                  <div className="text-xs text-slate-300 flex items-center gap-1.5 mt-0.5">
                    <Mail className="w-3 h-3 text-slate-400" />
                    <span>{activeAccount.email}</span>
                  </div>
                  <div className="text-[11px] text-slate-400 mt-0.5">
                    {activeAccount.cargo}
                  </div>
                </div>
              </div>
              <span className="bg-emerald-500/20 text-emerald-300 text-[10px] font-extrabold uppercase px-2 py-1 rounded border border-emerald-400/30">
                Ativa
              </span>
            </div>
          </div>

          {/* Switch Account Options */}
          <div className="space-y-2">
            <label className="font-bold text-slate-900 text-xs">
              Alternar para outra conta da equipe:
            </label>
            <div className="space-y-1.5">
              {DEFAULT_USER_ACCOUNTS.map((account) => {
                const isCurrent = account.email === activeAccount.email;
                return (
                  <button
                    key={account.id}
                    onClick={() => {
                      onSelectAccount(account);
                      onClose();
                    }}
                    className={`w-full p-3 rounded-xl border text-left flex items-center justify-between transition-all cursor-pointer ${
                      isCurrent
                        ? 'border-orange-500 bg-orange-50/50 shadow-xs'
                        : 'border-slate-200 hover:border-slate-300 hover:bg-slate-50'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs ${
                          isCurrent
                            ? 'bg-orange-600 text-white'
                            : 'bg-slate-200 text-slate-700'
                        }`}
                      >
                        {account.name.slice(0, 2).toUpperCase()}
                      </div>
                      <div>
                        <div className="font-bold text-slate-900 text-xs">
                          {account.name}
                        </div>
                        <div className="text-[11px] text-slate-500">
                          {account.email} • {account.cargo}
                        </div>
                      </div>
                    </div>
                    {isCurrent ? (
                      <CheckCircle2 className="w-5 h-5 text-orange-600 shrink-0" />
                    ) : (
                      <span className="text-[11px] text-slate-500 font-semibold hover:text-slate-900">
                        Selecionar
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Add custom account / email */}
          <form onSubmit={handleCreateCustom} className="pt-3 border-t border-slate-200 space-y-2.5">
            <label className="font-bold text-slate-900 text-xs block">
              Ou entrar com outro email funcional (@prefeitura.rio):
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              <input
                type="text"
                placeholder="Nome Completo"
                value={customName}
                onChange={(e) => setCustomName(e.target.value)}
                className="w-full text-xs px-2.5 py-1.5 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
              />
              <input
                type="email"
                placeholder="email@prefeitura.rio"
                value={customEmail}
                onChange={(e) => setCustomEmail(e.target.value)}
                className="w-full text-xs px-2.5 py-1.5 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500"
              />
            </div>
            <button
              type="submit"
              disabled={!customName.trim() || !customEmail.trim()}
              className="w-full py-2 bg-slate-900 hover:bg-black text-white text-xs font-bold rounded-lg shadow-xs cursor-pointer transition-colors disabled:opacity-50"
            >
              Usar Este Perfil e Sincronizar
            </button>
          </form>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-800 text-xs font-bold rounded-xl cursor-pointer transition-colors"
          >
            Fechar
          </button>
        </div>
      </div>
    </div>
  );
};
