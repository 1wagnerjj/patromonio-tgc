import React, { useState } from 'react';
import {
  X,
  Download,
  Upload,
  RotateCcw,
  Check,
  AlertCircle,
  Database,
  FileSpreadsheet,
  Link,
  RefreshCw,
  CheckCircle2,
  Table,
  Trash2,
} from 'lucide-react';
import { AssetItem, InspectionRecord, AuditSession } from '../types';
import { parseComlurbSheetText, ParseComlurbResult } from '../utils/csvComlurbParser';

interface ImportExportModalProps {
  assets: AssetItem[];
  inspections: Record<string, InspectionRecord>;
  auditSession: AuditSession;
  selectedYear: number;
  onClose: () => void;
  onRestoreData: (assets: AssetItem[], inspections: Record<string, InspectionRecord>) => void;
  onResetToDefaults: () => void;
  onClearAllData?: () => void;
  onLoadSampleData?: () => void;
}

export const ImportExportModal: React.FC<ImportExportModalProps> = ({
  assets,
  inspections,
  auditSession,
  selectedYear,
  onClose,
  onRestoreData,
  onResetToDefaults,
  onClearAllData,
  onLoadSampleData,
}) => {
  const [activeTab, setActiveTab] = useState<'sheet' | 'backup'>('sheet');
  const [sheetInputMode, setSheetInputMode] = useState<'paste' | 'file' | 'google_link'>('google_link');
  const [spreadsheetId, setSpreadsheetId] = useState('1ZsoXBfn-wTR3gb52vjaE6cOvAWL6DiF5');
  const [sheetText, setSheetText] = useState('');
  const [jsonText, setJsonText] = useState('');
  const [importStatus, setImportStatus] = useState<string | null>(null);
  const [isFetchingSheet, setIsFetchingSheet] = useState(false);
  const [parsedPreview, setParsedPreview] = useState<ParseComlurbResult | null>(null);

  // Download complete JSON backup
  const handleDownloadBackup = () => {
    const backup = {
      version: '1.0',
      exportedAt: new Date().toISOString(),
      auditSession,
      totalAssets: assets.length,
      assets,
      inspections,
    };

    const blob = new Blob([JSON.stringify(backup, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Backup_Patrimonio_COMLURB_${selectedYear}_${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Restore complete JSON backup
  const handleImportJSON = () => {
    try {
      const parsed = JSON.parse(jsonText);
      if (parsed.assets && Array.isArray(parsed.assets)) {
        onRestoreData(parsed.assets, parsed.inspections || {});
        setImportStatus('Sucesso: Dados restaurados com êxito!');
        setTimeout(() => {
          onClose();
        }, 1200);
      } else {
        setImportStatus('Erro: Formato de arquivo inválido. Lista de bens não encontrada.');
      }
    } catch {
      setImportStatus('Erro ao ler JSON. Verifique a sintaxe.');
    }
  };

  // Handle file upload (CSV or JSON)
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>, type: 'sheet' | 'json') => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (evt) => {
      const content = evt.target?.result as string;
      if (type === 'sheet') {
        setSheetText(content);
        const result = parseComlurbSheetText(content, selectedYear);
        setParsedPreview(result);
        if (result.assets.length === 0) {
          setImportStatus('Atenção: Nenhum patrimônio reconhecido no arquivo enviado.');
        } else {
          setImportStatus(`Reconhecidos ${result.assets.length} bens patrimoniais no arquivo!`);
        }
      } else {
        setJsonText(content);
      }
    };
    reader.readAsText(file);
  };

  // Parse text whenever user pastes or changes text
  const handleTextChange = (text: string) => {
    setSheetText(text);
    if (!text.trim()) {
      setParsedPreview(null);
      setImportStatus(null);
      return;
    }
    const result = parseComlurbSheetText(text, selectedYear);
    setParsedPreview(result);
    if (result.assets.length > 0) {
      setImportStatus(`Reconhecidos ${result.assets.length} bens patrimoniais prontos para atualização.`);
    } else {
      setImportStatus('Cole as linhas da planilha (com cabeçalho de colunas como Patrimônio, Descrição, etc).');
    }
  };

  // Fetch Google Sheet by ID with server-side proxy support to prevent CORS issues
  const handleFetchGoogleSheet = async (overrideId?: string) => {
    const rawTarget = (typeof overrideId === 'string' ? overrideId : spreadsheetId).trim();
    let gid = '1407549722';

    if (rawTarget.includes('gid=')) {
      const matchGid = rawTarget.match(/gid=([0-9]+)/);
      if (matchGid && matchGid[1]) {
        gid = matchGid[1];
      }
    }

    const cleanId = rawTarget
      .replace(/^https?:\/\/docs\.google\.com\/spreadsheets\/d\//, '')
      .split('/')[0]
      .split('?')[0];

    if (!cleanId) {
      setImportStatus('Informe o ID ou link da planilha do Google Sheets.');
      return;
    }

    setIsFetchingSheet(true);
    setImportStatus('Conectando à planilha do Google Sheets...');

    try {
      let csvContent = '';

      // 1. Try server-side proxy endpoint (avoids CORS in browser)
      try {
        const proxyRes = await fetch(`/api/fetch-google-sheet?id=${encodeURIComponent(cleanId)}&gid=${encodeURIComponent(gid)}`);
        if (proxyRes.ok) {
          const json = await proxyRes.json();
          if (json.success && json.csv) {
            csvContent = json.csv;
          }
        }
      } catch (err) {
        console.warn('Proxy fetch attempt notice:', err);
      }

      // 2. Direct browser fallback
      if (!csvContent) {
        const exportUrls = [
          `https://docs.google.com/spreadsheets/d/${cleanId}/export?format=csv&gid=${gid}`,
          `https://docs.google.com/spreadsheets/d/${cleanId}/export?format=csv`,
          `https://docs.google.com/spreadsheets/d/${cleanId}/gviz/tq?tqx=out:csv`,
        ];

        for (const url of exportUrls) {
          try {
            const res = await fetch(url);
            if (res.ok) {
              const text = await res.text();
              if (text && !text.includes('<!doctype') && !text.includes('Sign in to your Google Account')) {
                csvContent = text;
                break;
              }
            }
          } catch {
            // continue
          }
        }
      }

      if (csvContent) {
        setSheetText(csvContent);
        const result = parseComlurbSheetText(csvContent, selectedYear);
        setParsedPreview(result);
        if (result.assets.length > 0) {
          setImportStatus(`Sucesso! ${result.assets.length} bens carregados da planilha do Google Sheets!`);
        } else {
          setImportStatus('A planilha foi lida, mas nenhuma coluna de patrimônio foi identificada.');
        }
      } else {
        setImportStatus(
          'A planilha do Google está em modo privado (Restrito). Clique no botão azul "Compartilhar" na sua planilha e marque "Qualquer pessoa com o link: Leitor", ou baixe como CSV (Arquivo > Fazer download > CSV) e envie na aba Arquivo.'
        );
      }
    } catch {
      setImportStatus('Falha ao conectar ao Google Sheets. Verifique o compartilhamento ou use a opção de colar.');
    } finally {
      setIsFetchingSheet(false);
    }
  };

  // Apply parsed assets to system
  const handleApplySheetData = () => {
    if (!parsedPreview || parsedPreview.assets.length === 0) return;

    // Merge or replace: we update assets that match or add new ones
    const newAssets = parsedPreview.assets;
    const newInspections = { ...inspections, ...parsedPreview.inspections };

    onRestoreData(newAssets, newInspections);
    setImportStatus(`Base atualizada com sucesso! ${newAssets.length} bens da COMLURB ativos no sistema.`);

    setTimeout(() => {
      onClose();
    }, 1500);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto no-print">
      <div className="bg-white rounded-2xl max-w-2xl w-full overflow-hidden shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="bg-slate-900 text-white p-5 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-orange-600 rounded-xl text-white">
              <FileSpreadsheet className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-extrabold tracking-tight">Atualizar Base de Dados dos Patrimônios</h2>
              <p className="text-xs text-slate-400">
                Corrija ou importe a lista oficial de bens da TGC, TDM e TDO via Google Sheets ou CSV
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Selector */}
        <div className="flex border-b border-slate-200 bg-slate-50 px-6 pt-3 gap-2">
          <button
            type="button"
            onClick={() => setActiveTab('sheet')}
            className={`pb-3 px-3 text-xs font-bold flex items-center gap-2 border-b-2 transition-all cursor-pointer ${
              activeTab === 'sheet'
                ? 'border-orange-600 text-orange-600'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <FileSpreadsheet className="w-4 h-4" />
            <span>Planilha COMLURB (Google Sheets / CSV)</span>
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('backup')}
            className={`pb-3 px-3 text-xs font-bold flex items-center gap-2 border-b-2 transition-all cursor-pointer ${
              activeTab === 'backup'
                ? 'border-orange-600 text-orange-600'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <Database className="w-4 h-4" />
            <span>Backup do Sistema (JSON)</span>
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5 text-xs text-slate-700 max-h-[75vh] overflow-y-auto">
          {activeTab === 'sheet' ? (
            <div className="space-y-4">
              {/* Method Sub-Tabs */}
              <div className="flex items-center gap-2 p-1 bg-slate-100 rounded-xl text-xs font-bold">
                <button
                  type="button"
                  onClick={() => setSheetInputMode('google_link')}
                  className={`flex-1 py-1.5 px-3 rounded-lg flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                    sheetInputMode === 'google_link'
                      ? 'bg-white text-orange-600 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <Link className="w-3.5 h-3.5" />
                  <span>Link / ID Google Sheets</span>
                </button>
                <button
                  type="button"
                  onClick={() => setSheetInputMode('paste')}
                  className={`flex-1 py-1.5 px-3 rounded-lg flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                    sheetInputMode === 'paste'
                      ? 'bg-white text-orange-600 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <Table className="w-3.5 h-3.5" />
                  <span>Copiar & Colar Linhas</span>
                </button>
                <button
                  type="button"
                  onClick={() => setSheetInputMode('file')}
                  className={`flex-1 py-1.5 px-3 rounded-lg flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                    sheetInputMode === 'file'
                      ? 'bg-white text-orange-600 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  <Upload className="w-3.5 h-3.5" />
                  <span>Enviar Arquivo (.csv / .txt)</span>
                </button>
              </div>

              {/* Mode 1: Google Sheet ID / Link */}
              {sheetInputMode === 'google_link' && (
                <div className="space-y-3 bg-orange-50/60 p-4 rounded-xl border border-orange-200">
                  <div className="flex items-start gap-2">
                    <FileSpreadsheet className="w-4 h-4 text-orange-600 shrink-0 mt-0.5" />
                    <div>
                      <span className="font-bold text-slate-900 block text-xs">
                        Planilha COML02.2.3.12 - Relatório de Bens Móveis:
                      </span>
                      <p className="text-[11px] text-slate-600 mt-0.5 leading-relaxed">
                        Para sincronizar diretamente, certifique-se de que a planilha no Google Sheets esteja compartilhada com 
                        <strong> "Qualquer pessoa com o link: Leitor"</strong> (no botão azul <em>Compartilhar</em> da sua planilha).
                      </p>
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={spreadsheetId}
                      onChange={(e) => setSpreadsheetId(e.target.value)}
                      placeholder="Cole o ID ou link da planilha do Google Sheets..."
                      className="flex-1 px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs font-mono font-bold text-slate-900 focus:ring-2 focus:ring-orange-500"
                    />
                    <button
                      type="button"
                      onClick={() => handleFetchGoogleSheet()}
                      disabled={isFetchingSheet || !spreadsheetId.trim()}
                      className="px-4 py-2 bg-orange-600 hover:bg-orange-700 disabled:opacity-50 text-white font-bold rounded-lg flex items-center gap-1.5 cursor-pointer shadow-xs transition-colors shrink-0"
                    >
                      <RefreshCw className={`w-3.5 h-3.5 ${isFetchingSheet ? 'animate-spin' : ''}`} />
                      <span>{isFetchingSheet ? 'Conectando...' : 'Carregar Dados'}</span>
                    </button>
                  </div>

                  <div className="flex flex-wrap items-center gap-2 pt-1">
                    <span className="text-[11px] text-slate-600 font-medium">Planilha Oficial Atualizada:</span>
                    <button
                      type="button"
                      onClick={() => {
                        setSpreadsheetId('1ZsoXBfn-wTR3gb52vjaE6cOvAWL6DiF5');
                        handleFetchGoogleSheet('1ZsoXBfn-wTR3gb52vjaE6cOvAWL6DiF5');
                      }}
                      className="inline-flex items-center gap-1 px-2.5 py-1 bg-white hover:bg-orange-100 text-orange-800 font-mono text-[11px] font-bold rounded-md border border-orange-300 shadow-2xs transition-colors cursor-pointer"
                      title="Clique para preencher e conectar à nova planilha oficial"
                    >
                      <span>1ZsoXBfn-wTR3gb52vjaE6cOvAWL6DiF5</span>
                      <span className="text-[10px] text-orange-600 font-sans font-semibold">(Aba: Patrimônios_2026)</span>
                    </button>
                  </div>
                </div>
              )}

              {/* Mode 2: Paste Rows */}
              {sheetInputMode === 'paste' && (
                <div className="space-y-2">
                  <label className="block text-slate-800 font-bold text-xs">
                    Copie as linhas da sua planilha do Google Sheets e cole abaixo:
                  </label>
                  <p className="text-[11px] text-slate-500">
                    Dica: No Google Sheets, selecione os dados (a partir das colunas Patrimônio, Descrição, etc.), aperte <strong>Ctrl+C</strong> e depois dê <strong>Ctrl+V</strong> no campo abaixo:
                  </p>
                  <textarea
                    rows={6}
                    value={sheetText}
                    onChange={(e) => handleTextChange(e.target.value)}
                    placeholder="03417	CADEIRA	ESTOFADA/ESTRUTURA FERRO	12/27/1979	R$ 0,12	TGC..."
                    className="w-full p-3 bg-slate-50 border border-slate-300 rounded-xl font-mono text-[11px] text-slate-800 focus:bg-white focus:ring-2 focus:ring-orange-500"
                  />
                </div>
              )}

              {/* Mode 3: File Upload */}
              {sheetInputMode === 'file' && (
                <div className="space-y-2">
                  <label className="block text-slate-800 font-bold text-xs">
                    Selecione o arquivo CSV baixado do Google Sheets:
                  </label>
                  <p className="text-[11px] text-slate-500">
                    No Google Sheets: clique em <strong>Arquivo &gt; Fazer download &gt; Valores separados por vírgula (.csv)</strong>.
                  </p>
                  <input
                    type="file"
                    accept=".csv,.txt,.tsv"
                    onChange={(e) => handleFileUpload(e, 'sheet')}
                    className="block w-full text-xs text-slate-500 file:mr-4 file:py-2.5 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-bold file:bg-orange-600 file:text-white hover:file:bg-orange-700 cursor-pointer border border-dashed border-slate-300 rounded-xl p-3 bg-slate-50"
                  />
                </div>
              )}

              {/* Status Message */}
              {importStatus && (
                <div
                  className={`p-3 rounded-xl font-bold flex items-start gap-2.5 text-xs ${
                    importStatus.startsWith('Sucesso') || (parsedPreview && parsedPreview.assets.length > 0)
                      ? 'bg-emerald-50 text-emerald-900 border border-emerald-300'
                      : 'bg-amber-50 text-amber-900 border border-amber-300'
                  }`}
                >
                  {importStatus.startsWith('Sucesso') || (parsedPreview && parsedPreview.assets.length > 0) ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  ) : (
                    <AlertCircle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                  )}
                  <div className="leading-relaxed">{importStatus}</div>
                </div>
              )}

              {/* Parsed Preview Card */}
              {parsedPreview && parsedPreview.assets.length > 0 && (
                <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3 animate-in fade-in">
                  <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                    <span className="font-bold text-slate-900 text-xs flex items-center gap-1.5">
                      <Check className="w-4 h-4 text-emerald-600" />
                      Resumo dos Bens Identificados na Planilha:
                    </span>
                    <span className="font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded text-[11px]">
                      Total: {parsedPreview.summary.total} itens
                    </span>
                  </div>

                  <div className="grid grid-cols-3 gap-2 text-center text-[11px]">
                    <div className="p-2 bg-white rounded-lg border border-slate-200">
                      <span className="text-slate-500 block">TGC (Ecoparque)</span>
                      <strong className="text-slate-900 text-sm">{parsedPreview.summary.byDepartment.TGC || 0}</strong>
                    </div>
                    <div className="p-2 bg-white rounded-lg border border-slate-200">
                      <span className="text-slate-500 block">TDO (Operação)</span>
                      <strong className="text-slate-900 text-sm">{parsedPreview.summary.byDepartment.TDO || 0}</strong>
                    </div>
                    <div className="p-2 bg-white rounded-lg border border-slate-200">
                      <span className="text-slate-500 block">TDM (Manutenção)</span>
                      <strong className="text-slate-900 text-sm">{parsedPreview.summary.byDepartment.TDM || 0}</strong>
                    </div>
                  </div>

                  {parsedPreview.summary.inspectedCount > 0 && (
                    <div className="text-[11px] text-slate-600 bg-blue-50 p-2 rounded-lg border border-blue-200">
                      ℹ️ Foram reconhecidos <strong>{parsedPreview.summary.inspectedCount}</strong> registros de vistoria 
                      preenchidos na planilha (Presença, Ausência ou Transferência).
                    </div>
                  )}

                  {/* Sample rows */}
                  <div className="space-y-1">
                    <span className="text-[10px] text-slate-500 font-bold uppercase">Primeiros itens da lista:</span>
                    <div className="max-h-28 overflow-y-auto space-y-1 pr-1">
                      {parsedPreview.assets.slice(0, 5).map((a) => (
                        <div
                          key={a.id}
                          className="flex items-center justify-between text-[11px] p-1.5 bg-white rounded border border-slate-200 font-mono"
                        >
                          <span className="font-bold text-orange-600">{a.patrimonio}</span>
                          <span className="text-slate-700 truncate max-w-[200px]">{a.descricao}</span>
                          <span className="text-slate-500 text-[10px]">{a.unidade}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={handleApplySheetData}
                    className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl flex items-center justify-center gap-2 cursor-pointer shadow-xs transition-colors"
                  >
                    <Check className="w-4 h-4" />
                    <span>Confirmar e Atualizar Base do Sistema ({parsedPreview.summary.total} bens)</span>
                  </button>
                </div>
              )}
            </div>
          ) : (
            /* Tab 2: Backup JSON */
            <div className="space-y-5">
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2">
                <h3 className="font-bold text-slate-900 text-xs flex items-center gap-2">
                  <Download className="w-4 h-4 text-emerald-600" />
                  1. Exportar Cópia de Segurança Completa (JSON)
                </h3>
                <p className="text-slate-600 text-[11px]">
                  Salva todos os {assets.length} bens patrimoniais e os registros de vistorias de todos os anos em um arquivo JSON.
                </p>
                <button
                  type="button"
                  onClick={handleDownloadBackup}
                  className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-lg shadow-xs cursor-pointer flex items-center gap-2"
                >
                  <Download className="w-4 h-4 text-orange-400" />
                  Baixar Arquivo de Backup
                </button>
              </div>

              <div className="space-y-3">
                <h3 className="font-bold text-slate-900 text-xs flex items-center gap-2">
                  <Upload className="w-4 h-4 text-orange-600" />
                  2. Restaurar Cópia de Segurança (JSON)
                </h3>
                <input
                  type="file"
                  accept=".json"
                  onChange={(e) => handleFileUpload(e, 'json')}
                  className="block w-full text-xs text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-xs file:font-bold file:bg-orange-50 file:text-orange-700 hover:file:bg-orange-100 cursor-pointer"
                />
                <textarea
                  rows={3}
                  value={jsonText}
                  onChange={(e) => setJsonText(e.target.value)}
                  placeholder="Cole o código JSON de backup aqui..."
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg font-mono text-[11px] text-slate-800 focus:bg-white focus:ring-2 focus:ring-orange-500"
                />
                <button
                  type="button"
                  disabled={!jsonText.trim()}
                  onClick={handleImportJSON}
                  className="w-full py-2 bg-orange-600 hover:bg-orange-700 disabled:opacity-50 text-white font-bold rounded-lg shadow-xs cursor-pointer transition-colors"
                >
                  Restaurar Dados do JSON
                </button>
              </div>

              {onClearAllData && (
                <div className="pt-4 border-t border-slate-200 flex items-center justify-between">
                  <div>
                    <span className="font-bold text-rose-700 block text-xs">Zerar / Limpar Todos os Dados</span>
                    <span className="text-slate-500 text-[11px]">
                      Apaga permanentemente todos os bens cadastrados e vistorias (base ficará com 0 itens).
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      if (window.confirm('⚠️ ATENÇÃO: Deseja realmente limpar e excluir TODOS os dados do patrimônio?\n\nA base ficará vazia (0 itens) para você importar sua planilha do zero.')) {
                        onClearAllData();
                        setParsedPreview(null);
                        setSheetText('');
                        setImportStatus('A base de dados foi completamente limpa (0 itens cadastrados).');
                      }
                    }}
                    className="px-3 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-lg font-bold flex items-center gap-1.5 cursor-pointer text-xs shadow-xs transition-colors"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    Limpar Todos os Dados
                  </button>
                </div>
              )}

              {onLoadSampleData && (
                <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
                  <div>
                    <span className="font-bold text-slate-900 block text-xs">Carregar Dados de Demonstração</span>
                    <span className="text-slate-500 text-[11px]">
                      Carrega 139 bens simulados de TGC, TDO e TDM para testes.
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      if (window.confirm('Deseja carregar a base de demonstração (139 itens de exemplo)?')) {
                        onLoadSampleData();
                        onClose();
                      }
                    }}
                    className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg font-bold flex items-center gap-1.5 cursor-pointer text-xs"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    Carregar Amostra
                  </button>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 bg-slate-900 hover:bg-black text-white rounded-xl font-bold cursor-pointer transition-colors"
          >
            Fechar
          </button>
        </div>
      </div>
    </div>
  );
};
