import React, { useState, useEffect } from 'react';
import {
  Printer,
  ExternalLink,
  Download,
  CheckCircle2,
  AlertCircle,
  FileText,
  Info,
  UserCheck,
  Building2,
  Save,
  Check,
  Clock,
  ShieldCheck,
  Edit3,
} from 'lucide-react';
import {
  AssetItem,
  InspectionRecord,
  DepartmentInfo,
  AuditSession,
  DepartmentManagerInfo,
} from '../types';
import { formatBRL, formatDateBR } from '../utils/formatters';
import {
  openOfficialReportPrintWindow,
  downloadOfficialReportHtml,
  ReportPrintOptions,
} from '../utils/reportPrintEngine';

interface PrintableInspectionReportProps {
  assets: AssetItem[];
  inspections: Record<string, InspectionRecord>;
  departments: DepartmentInfo[];
  selectedYear: number;
  selectedGerencia: string;
  auditSession: AuditSession;
  onUpdateAuditSession: (updates: Partial<AuditSession>) => void;
  onClosePreview?: () => void;
}

export const PrintableInspectionReport: React.FC<PrintableInspectionReportProps> = ({
  assets,
  inspections,
  departments,
  selectedYear,
  selectedGerencia,
  auditSession,
  onUpdateAuditSession,
}) => {
  const [printMode, setPrintMode] = useState<'blank' | 'completed' | 'divergences'>('completed');
  const [feedbackMsg, setFeedbackMsg] = useState<{
    type: 'success' | 'info' | 'warning';
    text: string;
  } | null>(null);

  // Active gerência being configured in the Manager Settings Tab
  const [activeDeptTab, setActiveDeptTab] = useState<string>(() => {
    if (selectedGerencia !== 'ALL') return selectedGerencia;
    return departments[0]?.code || 'TGC';
  });

  // Local state for the division managers map
  const [deptManagers, setDeptManagers] = useState<Record<string, DepartmentManagerInfo>>(() => {
    const existing = auditSession.departmentManagers || {};
    const initial: Record<string, DepartmentManagerInfo> = { ...existing };

    departments.forEach((dept) => {
      if (!initial[dept.code]) {
        initial[dept.code] = {
          gerenciaCode: dept.code,
          gerenteNome: dept.gerenteNome || auditSession.gerenteResponsavel || 'Gerente da Divisão',
          gerenteMatricula: dept.gerenteMatricula || 'Matr. Não Informada',
          gerenteCargo: dept.gerenteCargo || `Gerente de Divisão (${dept.code})`,
          fiscalNome: dept.fiscalNome || auditSession.fiscalResponsavel || 'Wagner J. Jardim',
          fiscalMatricula: dept.fiscalMatricula || auditSession.matriculaFiscal || 'Matr. 892.410-3',
          statusInspecao: dept.statusInspecao || 'em_andamento',
          dataConclusao: dept.dataConclusao || '',
          observacoes: dept.observacoes || '',
        };
      }
    });

    return initial;
  });

  // Synchronize when selectedGerencia changes
  useEffect(() => {
    if (selectedGerencia !== 'ALL') {
      setActiveDeptTab(selectedGerencia);
    }
  }, [selectedGerencia]);

  // Handler to update a specific field of the current department's manager
  const handleUpdateDeptManager = (
    deptCode: string,
    field: keyof DepartmentManagerInfo,
    value: string
  ) => {
    setDeptManagers((prev) => ({
      ...prev,
      [deptCode]: {
        ...prev[deptCode],
        gerenciaCode: deptCode,
        [field]: value,
      },
    }));
  };

  // Save current department manager configuration to parent AuditSession & LocalStorage
  const handleSaveDeptManager = (deptCode: string) => {
    const updated = {
      ...deptManagers,
    };
    onUpdateAuditSession({
      departmentManagers: updated,
      updatedAt: new Date().toISOString(),
    });
    setFeedbackMsg({
      type: 'success',
      text: `Dados do responsável da Gerência ${deptCode} salvos com sucesso!`,
    });
    setTimeout(() => setFeedbackMsg(null), 4000);
  };

  // Toggle conclusion status for a gerência
  const handleToggleConcludeInspection = (deptCode: string) => {
    const currentStatus = deptManagers[deptCode]?.statusInspecao || 'em_andamento';
    const newStatus = currentStatus === 'concluido' ? 'em_andamento' : 'concluido';
    const nowStr = new Date().toISOString().split('T')[0];

    const updatedDept: DepartmentManagerInfo = {
      ...(deptManagers[deptCode] || {
        gerenciaCode: deptCode,
        gerenteNome: 'Gerente da Divisão',
        gerenteMatricula: 'Matr. Titular',
      }),
      statusInspecao: newStatus,
      dataConclusao: newStatus === 'concluido' ? nowStr : '',
    };

    const newMap = {
      ...deptManagers,
      [deptCode]: updatedDept,
    };

    setDeptManagers(newMap);
    onUpdateAuditSession({
      departmentManagers: newMap,
      updatedAt: new Date().toISOString(),
    });

    setFeedbackMsg({
      type: 'success',
      text:
        newStatus === 'concluido'
          ? `Inspeção da Gerência ${deptCode} marcada como CONCLUÍDA no exercício ${selectedYear}!`
          : `Inspeção da Gerência ${deptCode} reaberta (Em Andamento).`,
    });
    setTimeout(() => setFeedbackMsg(null), 4500);
  };

  const getPrintOptions = (): ReportPrintOptions => {
    const currentActiveMgr = deptManagers[activeDeptTab];
    return {
      assets,
      inspections,
      departments,
      selectedYear,
      selectedGerencia,
      auditSession,
      printMode,
      fiscalName: currentActiveMgr?.fiscalNome || auditSession.fiscalResponsavel || 'Wagner J. Jardim',
      fiscalMatricula:
        currentActiveMgr?.fiscalMatricula || auditSession.matriculaFiscal || 'Matr. 892.410-3',
      gerenteName:
        currentActiveMgr?.gerenteNome || auditSession.gerenteResponsavel || 'Gerente da Divisão',
      departmentManagers: deptManagers,
    };
  };

  const handlePrint = () => {
    const options = getPrintOptions();
    const success = openOfficialReportPrintWindow(options);

    if (success) {
      setFeedbackMsg({
        type: 'success',
        text: 'Janela de impressão A4 Paisagem aberta com sucesso! O relatório utiliza os responsáveis específicos de cada divisão.',
      });
    } else {
      try {
        window.print();
        setFeedbackMsg({
          type: 'info',
          text: 'Comando de impressão acionado no navegador.',
        });
      } catch {
        setFeedbackMsg({
          type: 'warning',
          text: 'O navegador bloqueou o diálogo de impressão. Por favor, use o botão "Abrir em Nova Aba" ou "Baixar HTML".',
        });
      }
    }

    setTimeout(() => {
      setFeedbackMsg(null), 6000;
    });
  };

  const handleOpenInNewTab = () => {
    const options = getPrintOptions();
    const success = openOfficialReportPrintWindow(options);
    if (!success) {
      downloadOfficialReportHtml(options);
      setFeedbackMsg({
        type: 'info',
        text: 'O bloqueador de pop-ups impediu a nova aba. O arquivo HTML oficial foi baixado para o seu computador.',
      });
    } else {
      setFeedbackMsg({
        type: 'success',
        text: 'Relatório oficial aberto em nova aba para visualização e impressão.',
      });
    }
    setTimeout(() => setFeedbackMsg(null), 5000);
  };

  const handleDownload = () => {
    const options = getPrintOptions();
    downloadOfficialReportHtml(options);
    setFeedbackMsg({
      type: 'success',
      text: 'Arquivo HTML do Relatório Oficial baixado com sucesso.',
    });
    setTimeout(() => setFeedbackMsg(null), 5000);
  };

  // Group assets by Gerência for clean sectioning
  const departmentsToPrint =
    selectedGerencia === 'ALL'
      ? departments
      : departments.filter((d) => d.code === selectedGerencia);

  const activeDeptInfo = departments.find((d) => d.code === activeDeptTab) || departments[0];
  const activeDeptManager = deptManagers[activeDeptTab] || {
    gerenciaCode: activeDeptTab,
    gerenteNome: activeDeptInfo?.gerenteNome || 'Gerente da Divisão',
    gerenteMatricula: activeDeptInfo?.gerenteMatricula || 'Matr. Não Informada',
    gerenteCargo: activeDeptInfo?.gerenteCargo || `Gerente de Divisão (${activeDeptTab})`,
    fiscalNome: activeDeptInfo?.fiscalNome || auditSession.fiscalResponsavel || 'Wagner J. Jardim',
    fiscalMatricula:
      activeDeptInfo?.fiscalMatricula || auditSession.matriculaFiscal || 'Matr. 892.410-3',
    statusInspecao: 'em_andamento',
    dataConclusao: '',
    observacoes: '',
  };

  const isCurrentDeptConcluded = activeDeptManager.statusInspecao === 'concluido';

  return (
    <div className="space-y-6">
      {/* Top Header & Action Controls Bar */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs no-print space-y-4">
        <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-4">
          <div>
            <h2 className="text-lg font-black text-slate-900 flex items-center gap-2 tracking-tight">
              <Printer className="w-5 h-5 text-orange-600" />
              Ficha Oficial de Inspeção Visual e Inventário COMLURB
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Layout formatado para impressão A4 Paisagem (Código COML02.2.3.12) com gerentes de divisão individualizados
            </p>
          </div>

          {/* Actions & Print Mode Selector */}
          <div className="flex flex-wrap items-center gap-2">
            {/* Mode selector */}
            <div className="flex bg-slate-100 p-1 rounded-xl border border-slate-200 text-xs">
              <button
                type="button"
                onClick={() => setPrintMode('completed')}
                className={`px-3 py-1.5 rounded-lg font-bold cursor-pointer transition-all ${
                  printMode === 'completed'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Relatório Preenchido
              </button>
              <button
                type="button"
                onClick={() => setPrintMode('blank')}
                className={`px-3 py-1.5 rounded-lg font-bold cursor-pointer transition-all ${
                  printMode === 'blank'
                    ? 'bg-white text-orange-600 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Ficha em Branco (Campo)
              </button>
              <button
                type="button"
                onClick={() => setPrintMode('divergences')}
                className={`px-3 py-1.5 rounded-lg font-bold cursor-pointer transition-all ${
                  printMode === 'divergences'
                    ? 'bg-white text-rose-700 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Apenas Divergências
              </button>
            </div>

            {/* Primary Direct Print Button */}
            <button
              type="button"
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-4 py-2 bg-orange-600 hover:bg-orange-700 text-white rounded-xl text-xs font-extrabold shadow-sm hover:shadow-md transition-all cursor-pointer"
              title="Abrir diálogo de impressão oficial sem restrições"
            >
              <Printer className="w-4 h-4" />
              <span>Imprimir Agora (Ctrl + P)</span>
            </button>

            {/* Open in New Tab Button */}
            <button
              type="button"
              onClick={handleOpenInNewTab}
              className="flex items-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-300 rounded-xl text-xs font-bold transition-colors cursor-pointer"
              title="Abrir o relatório oficial em tela cheia numa nova aba"
            >
              <ExternalLink className="w-3.5 h-3.5 text-slate-600" />
              <span className="hidden sm:inline">Abrir em Nova Aba</span>
            </button>

            {/* Download HTML Button */}
            <button
              type="button"
              onClick={handleDownload}
              className="flex items-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-300 rounded-xl text-xs font-bold transition-colors cursor-pointer"
              title="Baixar arquivo HTML independente para impressão offline ou arquivamento"
            >
              <Download className="w-3.5 h-3.5 text-slate-600" />
              <span className="hidden sm:inline">Baixar HTML</span>
            </button>
          </div>
        </div>

        {/* Feedback Message */}
        {feedbackMsg && (
          <div
            className={`p-3 rounded-xl text-xs font-medium flex items-center gap-2 border animate-in fade-in ${
              feedbackMsg.type === 'success'
                ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                : feedbackMsg.type === 'warning'
                ? 'bg-amber-50 text-amber-800 border-amber-200'
                : 'bg-blue-50 text-blue-800 border-blue-200'
            }`}
          >
            {feedbackMsg.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            ) : feedbackMsg.type === 'warning' ? (
              <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
            ) : (
              <Info className="w-4 h-4 text-blue-600 shrink-0" />
            )}
            <span>{feedbackMsg.text}</span>
          </div>
        )}

        {/* --- DIVISION MANAGERS MANAGEMENT PANEL --- */}
        <div className="pt-3 border-t border-slate-200 space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <UserCheck className="w-4 h-4 text-orange-600" />
              <span className="font-bold text-xs text-slate-900 uppercase tracking-wide">
                Responsáveis e Gerentes por Divisão / Centro de Custo
              </span>
            </div>
            <span className="text-[11px] text-slate-500">
              Cada gerência possui seu próprio gerente para assinatura e ratificação do inventário.
            </span>
          </div>

          {/* Department Selection Pills */}
          <div className="flex flex-wrap items-center gap-2">
            {departments.map((d) => {
              const mgr = deptManagers[d.code];
              const isDone = mgr?.statusInspecao === 'concluido';
              const isSelected = activeDeptTab === d.code;

              return (
                <button
                  key={d.code}
                  type="button"
                  onClick={() => setActiveDeptTab(d.code)}
                  className={`flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer border ${
                    isSelected
                      ? 'bg-orange-500 text-white border-orange-600 shadow-xs'
                      : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  <Building2 className={`w-3.5 h-3.5 ${isSelected ? 'text-white' : 'text-slate-500'}`} />
                  <span>{d.code}</span>
                  <span
                    className={`text-[9px] px-1.5 py-0.5 rounded-md font-semibold ${
                      isSelected
                        ? isDone
                          ? 'bg-emerald-800 text-white'
                          : 'bg-orange-700 text-orange-100'
                        : isDone
                        ? 'bg-emerald-100 text-emerald-800'
                        : 'bg-slate-200 text-slate-600'
                    }`}
                  >
                    {isDone ? '✓ Concluída' : '⏳ Em Andamento'}
                  </span>
                </button>
              );
            })}
          </div>

          {/* Active Department Manager Form Card */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-3.5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2.5 border-b border-slate-200">
              <div>
                <h4 className="font-extrabold text-slate-900 text-xs flex items-center gap-1.5">
                  <Edit3 className="w-3.5 h-3.5 text-orange-600" />
                  Gerência {activeDeptInfo?.name || activeDeptTab} (CC: {activeDeptInfo?.costCenter})
                </h4>
                <p className="text-[11px] text-slate-500">
                  Defina o Gerente Responsável, Matrícula, Cargo e Fiscal designado para esta unidade.
                </p>
              </div>

              {/* Status and Conclude Button */}
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => handleToggleConcludeInspection(activeDeptTab)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer border ${
                    isCurrentDeptConcluded
                      ? 'bg-emerald-600 hover:bg-emerald-700 text-white border-emerald-700 shadow-xs'
                      : 'bg-white hover:bg-emerald-50 text-emerald-800 border-emerald-300'
                  }`}
                  title="Concluir ou reabrir o inventário físico desta gerência no exercício atual"
                >
                  {isCurrentDeptConcluded ? (
                    <>
                      <ShieldCheck className="w-3.5 h-3.5" />
                      <span>✓ Vistoria Concluída</span>
                    </>
                  ) : (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-600" />
                      <span>Concluir Vistoria da Gerência</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Inputs Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
              {/* Gerente da Divisão */}
              <div>
                <label className="block text-slate-700 font-bold mb-1">
                  Gerente de Divisão / Titular ({activeDeptTab}):
                </label>
                <input
                  type="text"
                  value={activeDeptManager.gerenteNome || ''}
                  onChange={(e) =>
                    handleUpdateDeptManager(activeDeptTab, 'gerenteNome', e.target.value)
                  }
                  className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-orange-500 font-medium"
                  placeholder="Nome do gerente"
                />
              </div>

              {/* Matrícula do Gerente */}
              <div>
                <label className="block text-slate-700 font-bold mb-1">
                  Matrícula do Gerente:
                </label>
                <input
                  type="text"
                  value={activeDeptManager.gerenteMatricula || ''}
                  onChange={(e) =>
                    handleUpdateDeptManager(activeDeptTab, 'gerenteMatricula', e.target.value)
                  }
                  className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-orange-500 font-medium"
                  placeholder="Ex: Matr. 741.852-0"
                />
              </div>

              {/* Cargo do Gerente */}
              <div>
                <label className="block text-slate-700 font-bold mb-1">Cargo / Função:</label>
                <input
                  type="text"
                  value={activeDeptManager.gerenteCargo || ''}
                  onChange={(e) =>
                    handleUpdateDeptManager(activeDeptTab, 'gerenteCargo', e.target.value)
                  }
                  className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-orange-500 font-medium"
                  placeholder={`Ex: Gerente da Divisão (${activeDeptTab})`}
                />
              </div>

              {/* Data de Conclusão */}
              <div>
                <label className="block text-slate-700 font-bold mb-1">
                  Data de Conclusão / Fechamento:
                </label>
                <input
                  type="date"
                  value={activeDeptManager.dataConclusao || ''}
                  onChange={(e) =>
                    handleUpdateDeptManager(activeDeptTab, 'dataConclusao', e.target.value)
                  }
                  className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-orange-500 font-medium"
                />
              </div>

              {/* Fiscal Responsavel */}
              <div>
                <label className="block text-slate-700 font-bold mb-1">
                  Fiscal de Patrimônio Vistoriador:
                </label>
                <input
                  type="text"
                  value={activeDeptManager.fiscalNome || ''}
                  onChange={(e) =>
                    handleUpdateDeptManager(activeDeptTab, 'fiscalNome', e.target.value)
                  }
                  className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-orange-500 font-medium"
                  placeholder="Nome do fiscal"
                />
              </div>

              {/* Matrícula do Fiscal */}
              <div>
                <label className="block text-slate-700 font-bold mb-1">
                  Matrícula do Fiscal:
                </label>
                <input
                  type="text"
                  value={activeDeptManager.fiscalMatricula || ''}
                  onChange={(e) =>
                    handleUpdateDeptManager(activeDeptTab, 'fiscalMatricula', e.target.value)
                  }
                  className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-orange-500 font-medium"
                  placeholder="Ex: Matr. 892.410-3"
                />
              </div>

              {/* Observações da Vistoria da Gerência */}
              <div className="sm:col-span-2">
                <label className="block text-slate-700 font-bold mb-1">
                  Observações de Conclusão da Divisão:
                </label>
                <input
                  type="text"
                  value={activeDeptManager.observacoes || ''}
                  onChange={(e) =>
                    handleUpdateDeptManager(activeDeptTab, 'observacoes', e.target.value)
                  }
                  className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:ring-2 focus:ring-orange-500 font-medium"
                  placeholder="Ex: Conferência concluída in loco sem ocorrências graves."
                />
              </div>
            </div>

            {/* Save Button for this Gerência */}
            <div className="flex justify-end pt-1">
              <button
                type="button"
                onClick={() => handleSaveDeptManager(activeDeptTab)}
                className="flex items-center gap-1.5 px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold transition-all cursor-pointer shadow-xs"
              >
                <Save className="w-3.5 h-3.5 text-orange-400" />
                <span>Salvar Responsável da Gerência {activeDeptTab}</span>
              </button>
            </div>
          </div>
        </div>

        {/* Informative Hint */}
        <div className="bg-slate-50 border border-slate-200 p-2.5 rounded-xl text-[11px] text-slate-600 flex items-center justify-between gap-2">
          <span className="flex items-center gap-1.5">
            <FileText className="w-3.5 h-3.5 text-orange-600 shrink-0" />
            <span>
              <strong>Dica de Impressão / Salvar em PDF:</strong> Ao clicar em <em>Imprimir Agora</em> ou <em>Abrir em Nova Aba</em>, selecione <strong>Destino: Salvar como PDF</strong> ou a sua impressora na caixa de diálogo do navegador. Cada página exibirá os dados e o gerente correspondente à sua divisão.
            </span>
          </span>
        </div>
      </div>

      {/* Printable Area with Exact Official COMLURB Formatting */}
      <div className="printable-area bg-white p-6 sm:p-8 rounded-xl border border-slate-300 shadow-sm text-black">
        {departmentsToPrint.map((dept, deptIndex) => {
          let deptAssets = assets.filter((a) => a.gerenciaCode === dept.code);

          const mgr = deptManagers[dept.code] || {
            gerenciaCode: dept.code,
            gerenteNome: dept.gerenteNome || 'Gerente da Divisão',
            gerenteMatricula: dept.gerenteMatricula || 'Matr. Titular',
            gerenteCargo: dept.gerenteCargo || `Gerente de Divisão (${dept.code})`,
            fiscalNome: dept.fiscalNome || auditSession.fiscalResponsavel || 'Wagner J. Jardim',
            fiscalMatricula:
              dept.fiscalMatricula || auditSession.matriculaFiscal || 'Matr. 892.410-3',
            statusInspecao: dept.statusInspecao || 'em_andamento',
            dataConclusao: dept.dataConclusao || '',
            observacoes: dept.observacoes || '',
          };

          const isConcluido = mgr.statusInspecao === 'concluido';

          if (printMode === 'divergences') {
            deptAssets = deptAssets.filter((a) => {
              const insp = inspections[`${a.id}-${selectedYear}`];
              return insp?.status === 'ausente' || insp?.status === 'transferido';
            });
          }

          const deptTotalValue = deptAssets.reduce((sum, item) => sum + (item.vlBase || 0), 0);
          const deptPresentCount = deptAssets.filter(
            (a) => inspections[`${a.id}-${selectedYear}`]?.status === 'presente'
          ).length;
          const deptAbsentCount = deptAssets.filter(
            (a) => inspections[`${a.id}-${selectedYear}`]?.status === 'ausente'
          ).length;

          return (
            <div
              key={dept.code}
              className={`${deptIndex > 0 ? 'mt-8 pt-8 border-t-2 border-slate-400 print-page-break' : ''}`}
            >
              {/* Header Box */}
              <div className="border border-black p-3 mb-3 bg-slate-50 print:bg-transparent">
                <div className="flex justify-between items-center text-xs font-bold border-b border-black pb-1.5 mb-1.5">
                  <div className="text-sm tracking-wide">
                    COMLURB - Companhia Municipal de Limpeza Urbana
                  </div>
                  <div className="flex gap-6 font-mono text-xs">
                    <span>Data: {auditSession.dataEmissao || new Date().toLocaleDateString('pt-BR')}</span>
                    <span className="bg-slate-200 print:bg-transparent px-1 font-bold">
                      {auditSession.codigoDocumento || 'COML02.2.3.12'}
                    </span>
                  </div>
                </div>

                <div className="text-center font-extrabold text-sm uppercase tracking-wider py-1">
                  RELATÓRIO DE BENS MÓVEIS - INSPEÇÃO VISUAL ANUAL (EXERCÍCIO {selectedYear})
                </div>

                <div className="grid grid-cols-1 md:grid-cols-12 text-xs border-t border-black pt-1.5 gap-2">
                  <div className="md:col-span-6 font-bold truncate">
                    {dept.name}
                  </div>
                  <div className="md:col-span-3">
                    <span className="font-semibold">Localidade:</span>{' '}
                    <span className="font-mono font-bold">{dept.locationCode}</span>
                  </div>
                  <div className="md:col-span-3 text-right">
                    <span className="font-semibold">Centro de Custo:</span>{' '}
                    <span className="font-mono font-bold">{dept.costCenter}</span>
                  </div>
                </div>
              </div>

              {/* Data Table */}
              <table className="w-full text-left text-[10px] print:text-[8pt] border border-black border-collapse">
                <thead>
                  <tr className="bg-slate-200 print-bg-header font-bold text-black border-b border-black">
                    <th className="border-r border-black p-1.5 w-16 text-center">Patrimônio</th>
                    <th className="border-r border-black p-1.5 w-24">Descrição</th>
                    <th className="border-r border-black p-1.5">Complemento / Especificação</th>
                    <th className="border-r border-black p-1.5 w-20 text-center">Dt. Aquisição</th>
                    <th className="border-r border-black p-1.5 w-20 text-right">Vl. Base</th>
                    <th className="border-r border-black p-1.5 w-12 text-center">Unid.</th>
                    <th className="border-r border-black p-1.5 w-28 text-center">
                      Encontra-se no local?
                      <div className="flex justify-around border-t border-black mt-0.5 text-[8px] print:text-[7pt]">
                        <span className="w-1/2 border-r border-black">Sim</span>
                        <span className="w-1/2">Não</span>
                      </div>
                    </th>
                    <th className="border-r border-black p-1.5 w-24">Transferido Para:</th>
                    <th className="border-r border-black p-1.5 w-18 text-center">Dt.Transf:</th>
                    <th className="p-1.5 w-36">Observação:</th>
                  </tr>
                </thead>

                <tbody>
                  {deptAssets.length === 0 ? (
                    <tr>
                      <td colSpan={10} className="p-4 text-center text-slate-500 italic border-b border-black">
                        Nenhum bem patrimonial encontrado para esta listagem.
                      </td>
                    </tr>
                  ) : (
                    deptAssets.map((asset) => {
                      const key = `${asset.id}-${selectedYear}`;
                      const insp: Partial<InspectionRecord> = inspections[key] || {
                        status: 'pendente',
                        condition: 'nao_avaliado',
                        observacao: '',
                        transferidoPara: '',
                        dtTransf: '',
                      };

                      const isSim = printMode !== 'blank' && insp.status === 'presente';
                      const isNao = printMode !== 'blank' && insp.status === 'ausente';

                      return (
                        <tr
                          key={asset.id}
                          className="border-b border-black hover:bg-slate-50 leading-tight"
                        >
                          {/* Patrimonio */}
                          <td className="border-r border-black p-1 text-center font-mono font-bold">
                            {asset.patrimonio}
                          </td>

                          {/* Descricao */}
                          <td className="border-r border-black p-1 font-semibold">
                            {asset.descricao}
                          </td>

                          {/* Complemento */}
                          <td className="border-r border-black p-1 font-mono text-[9px] print:text-[7.5pt]">
                            {asset.complemento}
                          </td>

                          {/* Dt Aquisicao */}
                          <td className="border-r border-black p-1 text-center whitespace-nowrap">
                            {formatDateBR(asset.dtAquisicao)}
                          </td>

                          {/* Vl Base */}
                          <td className="border-r border-black p-1 text-right whitespace-nowrap font-mono">
                            {formatBRL(asset.vlBase)}
                          </td>

                          {/* Unidade */}
                          <td className="border-r border-black p-1 text-center font-semibold">
                            {asset.unidade}
                          </td>

                          {/* Encontra-se no local? Sim / Nao */}
                          <td className="border-r border-black p-1 text-center">
                            <div className="flex justify-around items-center h-full">
                              <div className="w-1/2 border-r border-black flex justify-center items-center">
                                {printMode === 'blank' ? (
                                  <div className="w-3.5 h-3.5 border border-black rounded-xs"></div>
                                ) : isSim ? (
                                  <span className="font-extrabold text-emerald-800 text-xs">✓ SIM</span>
                                ) : (
                                  <div className="w-3 h-3 border border-slate-300"></div>
                                )}
                              </div>
                              <div className="w-1/2 flex justify-center items-center">
                                {printMode === 'blank' ? (
                                  <div className="w-3.5 h-3.5 border border-black rounded-xs"></div>
                                ) : isNao ? (
                                  <span className="font-extrabold text-rose-800 text-xs">✗ NÃO</span>
                                ) : (
                                  <div className="w-3 h-3 border border-slate-300"></div>
                                )}
                              </div>
                            </div>
                          </td>

                          {/* Transferido Para */}
                          <td className="border-r border-black p-1 text-[9px]">
                            {printMode !== 'blank' ? insp.transferidoPara || '' : ''}
                          </td>

                          {/* Dt Transf */}
                          <td className="border-r border-black p-1 text-center whitespace-nowrap text-[9px]">
                            {printMode !== 'blank' && insp.dtTransf
                              ? formatDateBR(insp.dtTransf)
                              : ''}
                          </td>

                          {/* Observacao */}
                          <td className="p-1 text-[9px] print:text-[7.5pt] leading-tight">
                            {printMode !== 'blank' && insp.observacao ? (
                              <div>
                                <span>{insp.observacao}</span>
                                {insp.condition && insp.condition !== 'nao_avaliado' && (
                                  <span className="font-semibold block text-[8px] text-slate-700">
                                    [Estado: {insp.condition.toUpperCase()}]
                                  </span>
                                )}
                              </div>
                            ) : (
                              <div className="border-b border-dotted border-slate-400 h-3"></div>
                            )}
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>

                {/* Subtotal Footer */}
                <tfoot>
                  <tr className="bg-slate-100 print-bg-header font-bold text-black border-t-2 border-black">
                    <td colSpan={3} className="border-r border-black p-1.5">
                      Bens: <span className="font-mono text-xs">{deptAssets.length}</span>
                      {printMode !== 'blank' && (
                        <span className="ml-4 font-normal text-[9px]">
                          (No Local: <strong className="text-emerald-900">{deptPresentCount}</strong> | Ausentes:{' '}
                          <strong className="text-rose-900">{deptAbsentCount}</strong>)
                        </span>
                      )}
                    </td>
                    <td className="border-r border-black p-1.5 text-right">Total :</td>
                    <td className="border-r border-black p-1.5 text-right font-mono text-xs">
                      {formatBRL(deptTotalValue)}
                    </td>
                    <td colSpan={5} className="p-1.5 text-right text-[9px]">
                      Gerência: {dept.code} • Localidade: {dept.locationCode}
                    </td>
                  </tr>
                </tfoot>
              </table>

              {/* Official Term & Signature Block for Audit Validation */}
              <div className="mt-4 border border-black p-3 text-xs bg-white">
                <div className="flex justify-between items-center border-b border-black pb-1 mb-2">
                  <span className="font-bold text-[10px] uppercase">
                    Termo de Responsabilidade e Conclusão de Vistoria Anual In Loco
                  </span>
                  {isConcluido ? (
                    <span className="bg-emerald-100 text-emerald-800 border border-emerald-300 px-2 py-0.5 rounded text-[8px] font-bold">
                      ✓ VISTORIA CONCLUÍDA{mgr.dataConclusao ? ` EM ${formatDateBR(mgr.dataConclusao)}` : ''}
                    </span>
                  ) : (
                    <span className="bg-amber-100 text-amber-800 border border-amber-300 px-2 py-0.5 rounded text-[8px] font-bold">
                      ⏳ VISTORIA EM ANDAMENTO
                    </span>
                  )}
                </div>
                <p className="text-[9px] leading-snug mb-4 text-slate-800">
                  Certificamos que a conferência física e visual dos bens móveis da unidade{' '}
                  <strong>{dept.name}</strong> (Centro de Custo: <strong>{dept.costCenter}</strong>) foi
                  executada em estrita conformidade com as normas de patrimônio da COMLURB no exercício de{' '}
                  <strong>{selectedYear}</strong>. As divergências e transferências identificadas foram
                  devidamente registradas para regularização contábil e patrimonial.
                  {mgr.observacoes && (
                    <span className="block mt-1 italic text-slate-600">
                      <strong>Obs. da Gerência:</strong> {mgr.observacoes}
                    </span>
                  )}
                </p>

                <div className="grid grid-cols-2 gap-8 pt-3">
                  {/* Fiscal Signature */}
                  <div className="text-center">
                    <div className="border-b border-black w-3/4 mx-auto mb-1"></div>
                    <div className="font-bold text-[10px]">{mgr.fiscalNome || 'Wagner J. Jardim'}</div>
                    <div className="text-[9px] text-slate-700">{mgr.fiscalMatricula || 'Matr. 892.410-3'}</div>
                    <div className="text-[8px] text-slate-500 uppercase">
                      Fiscal de Patrimônio / Vistoriador
                    </div>
                  </div>

                  {/* Gerente da Divisão Signature */}
                  <div className="text-center">
                    <div className="border-b border-black w-3/4 mx-auto mb-1"></div>
                    <div className="font-bold text-[10px]">{mgr.gerenteNome || 'Gerente da Divisão'}</div>
                    <div className="text-[9px] text-slate-700">{mgr.gerenteMatricula || 'Matr. Titular'}</div>
                    <div className="text-[8px] text-slate-500 uppercase">
                      {mgr.gerenteCargo || `Gerente da Divisão (${dept.code})`} • CC: {dept.costCenter}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
