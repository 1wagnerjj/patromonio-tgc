import React, { useState, useEffect } from 'react';
import {
  X,
  Copy,
  Check,
  ExternalLink,
  QrCode,
  Globe,
  Shield,
  Filter,
  Eye,
  Cloud,
  RefreshCw,
  Camera,
  CheckCircle2,
} from 'lucide-react';
import { generateQRCodeDataUrl } from '../utils/barcodeGenerator';
import { DepartmentInfo, FilterState } from '../types';

interface PublicLinkModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedYear: number;
  filters: FilterState;
  departments: DepartmentInfo[];
  selectedAssetPatrimonio?: string;
  cloudStatus?: 'synced' | 'syncing' | 'error' | 'offline';
  lastSyncTime?: string;
  onForceSync?: () => Promise<void> | void;
}

export const PublicLinkModal: React.FC<PublicLinkModalProps> = ({
  isOpen,
  onClose,
  selectedYear,
  filters,
  departments,
  selectedAssetPatrimonio,
  cloudStatus = 'synced',
  lastSyncTime,
  onForceSync,
}) => {
  const [copiedType, setCopiedType] = useState<string | null>(null);
  const [isSyncingLocal, setIsSyncingLocal] = useState(false);
  const [syncFeedback, setSyncFeedback] = useState<string | null>(null);
  const [linkScope, setLinkScope] = useState<'current_view' | 'specific_asset' | 'full_inventory'>(
    selectedAssetPatrimonio ? 'specific_asset' : 'current_view'
  );
  const [targetPatrimonio, setTargetPatrimonio] = useState(selectedAssetPatrimonio || '');
  const [readOnlyMode, setReadOnlyMode] = useState(false);
  const [qrCodeUrl, setQrCodeUrl] = useState<string>('');

  const baseUrl = typeof window !== 'undefined' ? `${window.location.origin}${window.location.pathname}` : '';

  // Generate URL based on scope
  const getGeneratedUrl = () => {
    const params = new URLSearchParams();
    params.set('public', 'true');
    params.set('year', selectedYear.toString());

    if (readOnlyMode) {
      params.set('mode', 'readonly');
    }

    if (linkScope === 'specific_asset' && targetPatrimonio.trim()) {
      params.set('patrimonio', targetPatrimonio.trim());
    } else if (linkScope === 'current_view') {
      if (filters.gerencia !== 'ALL') params.set('gerencia', filters.gerencia);
      if (filters.status !== 'ALL') params.set('status', filters.status);
      if (filters.categoria !== 'ALL') params.set('categoria', filters.categoria);
      if (filters.situacao && filters.situacao !== 'ALL') params.set('situacao', filters.situacao);
      if (filters.viewMode) params.set('view', filters.viewMode);
      if (filters.searchTerm) params.set('search', filters.searchTerm);
    }

    return `${baseUrl}?${params.toString()}`;
  };

  const currentUrl = getGeneratedUrl();
  const disposalPhotosUrl = `${baseUrl}?view=disposal_photos`;

  useEffect(() => {
    if (isOpen && currentUrl) {
      generateQRCodeDataUrl(currentUrl, { width: 256, errorCorrectionLevel: 'M' }).then((dataUri) => {
        setQrCodeUrl(dataUri);
      });
    }
  }, [isOpen, currentUrl]);

  if (!isOpen) return null;

  const handleCopy = (url: string, type: string) => {
    navigator.clipboard.writeText(url);
    setCopiedType(type);
    setTimeout(() => setCopiedType(null), 2500);
  };

  const handleManualSync = async () => {
    if (!onForceSync) return;
    setIsSyncingLocal(true);
    setSyncFeedback(null);
    try {
      await onForceSync();
      setSyncFeedback('Dados e laudos gravados no servidor em nuvem com sucesso!');
      setTimeout(() => setSyncFeedback(null), 3500);
    } catch (err: any) {
      setSyncFeedback('Erro ao sincronizar na nuvem. Verifique a conexão.');
    } finally {
      setIsSyncingLocal(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto no-print">
      <div className="bg-white rounded-2xl max-w-xl w-full overflow-hidden shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="bg-slate-900 text-white p-5 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-orange-600 rounded-xl text-white">
              <Cloud className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-extrabold tracking-tight">Nuvem & Acesso em Outra Conta</h2>
              <p className="text-xs text-slate-400">
                Sincronize as alterações para abrir em qualquer computador, celular ou outra conta
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5 text-xs text-slate-700">
          {/* Cloud Synchronization Status Card */}
          <div className="p-4 bg-emerald-50/90 border border-emerald-300 rounded-2xl space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-emerald-600 text-white flex items-center justify-center shadow-xs shrink-0">
                  {cloudStatus === 'syncing' || isSyncingLocal ? (
                    <RefreshCw className="w-4 h-4 animate-spin" />
                  ) : (
                    <CheckCircle2 className="w-5 h-5" />
                  )}
                </div>
                <div>
                  <h3 className="font-extrabold text-emerald-950 text-sm">
                    {cloudStatus === 'syncing' || isSyncingLocal
                      ? 'Sincronizando com a Nuvem...'
                      : 'Servidor em Nuvem Vinculado e Ativo'}
                  </h3>
                  <p className="text-[11px] text-emerald-800 leading-tight">
                    Todas as ferramentas e bens baixados (TGC, TDM, TDO) e fotos estão gravados no servidor central.
                  </p>
                </div>
              </div>

              {onForceSync && (
                <button
                  type="button"
                  onClick={handleManualSync}
                  disabled={isSyncingLocal || cloudStatus === 'syncing'}
                  className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white rounded-lg font-bold text-xs flex items-center gap-1.5 shadow-xs cursor-pointer transition-colors shrink-0"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isSyncingLocal ? 'animate-spin' : ''}`} />
                  <span>Sincronizar Nuvem</span>
                </button>
              )}
            </div>

            {syncFeedback && (
              <div className="text-[11px] text-emerald-950 bg-emerald-100 font-bold px-3 py-1.5 rounded-lg border border-emerald-300 animate-in fade-in">
                ✓ {syncFeedback}
              </div>
            )}

            <div className="text-[11px] text-emerald-900/80 pt-1 border-t border-emerald-200 flex items-center justify-between">
              <span>Garantia: <strong>Nenhum dado é perdido ao trocar de conta</strong></span>
              {lastSyncTime && (
                <span className="font-mono text-[10px]">Último sincronismo: {lastSyncTime.split('T')[1]?.slice(0, 8)}</span>
              )}
            </div>
          </div>

          {/* Quick Direct Links */}
          <div>
            <label className="block text-slate-900 font-bold mb-2 uppercase text-[11px] tracking-wider">
              Links Rápidos para Outra Conta / Computador:
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {/* Disposal Photos Direct Link */}
              <div className="p-3 bg-orange-50 border border-orange-200 rounded-xl space-y-1.5">
                <div className="flex items-center gap-1.5 text-orange-950 font-bold">
                  <Camera className="w-4 h-4 text-orange-600" />
                  <span>Dossiê / Fotos de Baixa</span>
                </div>
                <p className="text-[11px] text-orange-800 leading-tight">
                  Abre diretamente na tela do laudo com as ferramentas baixadas do TGC, TDM e TDO.
                </p>
                <div className="flex items-center gap-1.5 pt-1">
                  <button
                    type="button"
                    onClick={() => handleCopy(disposalPhotosUrl, 'disposal_photos')}
                    className="flex-1 py-1.5 px-2 bg-orange-600 hover:bg-orange-700 text-white rounded-lg font-bold text-[11px] flex items-center justify-center gap-1 cursor-pointer shadow-2xs"
                  >
                    {copiedType === 'disposal_photos' ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                    <span>{copiedType === 'disposal_photos' ? 'Copiado!' : 'Copiar Link de Fotos'}</span>
                  </button>
                  <a
                    href={disposalPhotosUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-1.5 bg-white hover:bg-orange-100 text-orange-700 border border-orange-300 rounded-lg cursor-pointer"
                    title="Abrir em Nova Aba"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>

              {/* Full System Link */}
              <div className="p-3 bg-blue-50 border border-blue-200 rounded-xl space-y-1.5">
                <div className="flex items-center gap-1.5 text-blue-950 font-bold">
                  <Globe className="w-4 h-4 text-blue-600" />
                  <span>Painel Geral do Inventário</span>
                </div>
                <p className="text-[11px] text-blue-800 leading-tight">
                  Acesso à listagem completa com filtros, etiquetas Pimaco e relatório oficial.
                </p>
                <div className="flex items-center gap-1.5 pt-1">
                  <button
                    type="button"
                    onClick={() => handleCopy(baseUrl, 'general_link')}
                    className="flex-1 py-1.5 px-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-bold text-[11px] flex items-center justify-center gap-1 cursor-pointer shadow-2xs"
                  >
                    {copiedType === 'general_link' ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                    <span>{copiedType === 'general_link' ? 'Copiado!' : 'Copiar Link Geral'}</span>
                  </button>
                  <a
                    href={baseUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-1.5 bg-white hover:bg-blue-100 text-blue-700 border border-blue-300 rounded-lg cursor-pointer"
                    title="Abrir em Nova Aba"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>
            </div>
          </div>

          {/* Scope Selector */}
          <div>
            <label className="block text-slate-900 font-bold mb-2 uppercase text-[11px] tracking-wider">
              Personalizar Link Específico:
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setLinkScope('current_view')}
                className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                  linkScope === 'current_view'
                    ? 'border-orange-500 bg-orange-50/50 text-orange-950 ring-2 ring-orange-200 font-bold'
                    : 'border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100'
                }`}
              >
                <div className="flex items-center gap-1.5 mb-1 text-orange-600">
                  <Filter className="w-4 h-4" />
                  <span className="font-bold">Visualização Atual</span>
                </div>
                <div className="text-[11px] text-slate-500 font-normal">
                  Filtros atuais ({filters.gerencia})
                </div>
              </button>

              <button
                type="button"
                onClick={() => setLinkScope('specific_asset')}
                className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                  linkScope === 'specific_asset'
                    ? 'border-orange-500 bg-orange-50/50 text-orange-950 ring-2 ring-orange-200 font-bold'
                    : 'border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100'
                }`}
              >
                <div className="flex items-center gap-1.5 mb-1 text-orange-600">
                  <Eye className="w-4 h-4" />
                  <span className="font-bold">Bem Específico</span>
                </div>
                <div className="text-[11px] text-slate-500 font-normal">
                  Abre na ficha do patrimônio
                </div>
              </button>

              <button
                type="button"
                onClick={() => setLinkScope('full_inventory')}
                className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                  linkScope === 'full_inventory'
                    ? 'border-orange-500 bg-orange-50/50 text-orange-950 ring-2 ring-orange-200 font-bold'
                    : 'border-slate-200 bg-slate-50 text-slate-700 hover:bg-slate-100'
                }`}
              >
                <div className="flex items-center gap-1.5 mb-1 text-orange-600">
                  <Globe className="w-4 h-4" />
                  <span className="font-bold">Inventário Geral</span>
                </div>
                <div className="text-[11px] text-slate-500 font-normal">
                  Todas as gerências
                </div>
              </button>
            </div>
          </div>

          {/* If specific asset selected, show input */}
          {linkScope === 'specific_asset' && (
            <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-2 animate-in fade-in">
              <label className="block text-slate-800 font-bold">
                Número do Patrimônio / Tombamento:
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={targetPatrimonio}
                  onChange={(e) => setTargetPatrimonio(e.target.value)}
                  placeholder="Ex: 58165, i00509..."
                  className="flex-1 px-3 py-2 border border-slate-300 rounded-lg font-mono font-bold text-slate-900 bg-white focus:ring-2 focus:ring-orange-500"
                />
              </div>
            </div>
          )}

          {/* Options: Read-Only Toggle */}
          <div className="flex items-center justify-between p-3 bg-slate-50 border border-slate-200 rounded-xl">
            <div className="flex items-center gap-2">
              <Shield className="w-4 h-4 text-emerald-600" />
              <div>
                <div className="font-bold text-slate-900">Modo Somente Leitura (Consulta Pública)</div>
                <div className="text-[11px] text-slate-500">
                  Permite consultar bens e relatórios sem alterar dados acidentalmente
                </div>
              </div>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={readOnlyMode}
                onChange={(e) => setReadOnlyMode(e.target.checked)}
                className="sr-only peer"
              />
              <div className="w-9 h-5 bg-slate-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-emerald-600"></div>
            </label>
          </div>

          {/* Generated URL Box & Actions */}
          <div className="space-y-2">
            <label className="block text-slate-900 font-bold uppercase text-[11px] tracking-wider">
              Link Gerado:
            </label>
            <div className="flex items-center gap-2 bg-slate-100 p-2 rounded-xl border border-slate-300">
              <input
                type="text"
                readOnly
                value={currentUrl}
                className="w-full bg-transparent text-slate-800 font-mono text-xs focus:outline-none px-2 select-all"
              />
              <button
                type="button"
                onClick={() => handleCopy(currentUrl, 'main_link')}
                className={`px-4 py-2 rounded-lg font-bold flex items-center gap-1.5 transition-all cursor-pointer shrink-0 ${
                  copiedType === 'main_link'
                    ? 'bg-emerald-600 text-white'
                    : 'bg-orange-600 hover:bg-orange-700 text-white shadow-xs'
                }`}
              >
                {copiedType === 'main_link' ? (
                  <>
                    <Check className="w-4 h-4" />
                    <span>Copiado!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-4 h-4" />
                    <span>Copiar</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* QR Code Quick Share */}
          <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="font-bold text-slate-900 flex items-center gap-1.5">
                <QrCode className="w-4 h-4 text-slate-700" />
                QR Code para Acesso Rápido via Celular
              </div>
              <p className="text-[11px] text-slate-500 leading-tight">
                Aponte a câmera do celular para abrir instantaneamente este inventário em qualquer dispositivo.
              </p>
              <div className="pt-1">
                <a
                  href={currentUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1 text-orange-600 hover:text-orange-700 font-bold hover:underline"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  Testar e Abrir Link em Nova Aba
                </a>
              </div>
            </div>

            <div className="bg-white p-2.5 rounded-xl border border-slate-300 shadow-2xs shrink-0 flex flex-col items-center">
              {qrCodeUrl ? (
                <img src={qrCodeUrl} alt="QR Code Link Público" className="w-[88px] h-[88px] object-contain" />
              ) : (
                <div className="w-[88px] h-[88px] bg-slate-100 animate-pulse rounded-lg" />
              )}
              <span className="text-[9px] text-slate-500 font-mono mt-1 font-bold">SCAN COMLURB</span>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 bg-slate-900 hover:bg-black text-white rounded-xl font-bold cursor-pointer transition-colors"
          >
            Fechar
          </button>
        </div>
      </div>
    </div>
  );
};
