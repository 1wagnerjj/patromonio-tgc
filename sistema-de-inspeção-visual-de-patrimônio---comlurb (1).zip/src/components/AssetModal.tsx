import React, { useState } from 'react';
import {
  X,
  CheckCircle,
  AlertTriangle,
  ArrowRightLeft,
  Save,
  Clock,
  Tag,
  QrCode,
  Archive,
  CheckCircle2,
  Calendar,
  ShieldCheck,
  Share2,
  Copy,
  Check,
} from 'lucide-react';
import { AssetItem, InspectionRecord, AssetStatus, AssetCondition, TagCondition } from '../types';
import { formatBRL, formatDateBR, getStatusBadge, getSituacaoBadge } from '../utils/formatters';
import { PimacoBarcode } from './PimacoBarcode';

interface AssetModalProps {
  asset: AssetItem | null;
  inspections: Record<string, InspectionRecord>;
  selectedYear: number;
  onClose: () => void;
  onSaveInspection: (assetId: string, record: Partial<InspectionRecord>) => void;
  onUpdateAsset?: (assetId: string, updates: Partial<AssetItem>) => void;
  onOpenLabelForAsset?: (asset) => void;
}

export const AssetModal: React.FC<AssetModalProps> = ({
  asset,
  inspections,
  selectedYear,
  onClose,
  onSaveInspection,
  onUpdateAsset,
  onOpenLabelForAsset,
}) => {
  if (!asset) return null;

  const key = `${asset.id}-${selectedYear}`;
  const currentRecord = inspections[key] || {
    assetId: asset.id,
    year: selectedYear,
    status: 'pendente' as AssetStatus,
    condition: 'nao_avaliado' as AssetCondition,
    tagCondition: 'legivel' as TagCondition,
    transferidoPara: '',
    dtTransf: '',
    observacao: '',
    localizacaoEspecifica: '',
    inspectedBy: 'Wagner J. Jardim',
  };

  const [status, setStatus] = useState<AssetStatus>(currentRecord.status);
  const [condition, setCondition] = useState<AssetCondition>(currentRecord.condition || 'nao_avaliado');
  const [tagCondition, setTagCondition] = useState<TagCondition>(currentRecord.tagCondition || 'legivel');
  const [localizacao, setLocalizacao] = useState(currentRecord.localizacaoEspecifica || '');
  const [transferidoPara, setTransferidoPara] = useState(currentRecord.transferidoPara || '');
  const [dtTransf, setDtTransf] = useState(currentRecord.dtTransf || '');
  const [observacao, setObservacao] = useState(currentRecord.observacao || '');
  const [inspectedBy, setInspectedBy] = useState(currentRecord.inspectedBy || 'Fiscal Responsável');

  // Asset Lifecycle Status (Ativo / Baixa)
  const [situacao, setSituacao] = useState<'ativo' | 'baixado'>(asset.situacao || 'ativo');
  const [dtBaixa, setDtBaixa] = useState<string>(
    asset.dtBaixa || (asset.situacao === 'baixado' ? new Date().toISOString().slice(0, 10) : '')
  );
  const [motivoBaixa, setMotivoBaixa] = useState<string>(asset.motivoBaixa || '');
  const [copiedLink, setCopiedLink] = useState(false);

  const handleCopyPublicLink = () => {
    const baseUrl = typeof window !== 'undefined' ? `${window.location.origin}${window.location.pathname}` : '';
    const url = `${baseUrl}?public=true&patrimonio=${encodeURIComponent(asset.patrimonio)}&year=${selectedYear}`;
    navigator.clipboard.writeText(url);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2500);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();

    // Save asset lifecycle updates
    if (onUpdateAsset) {
      onUpdateAsset(asset.id, {
        situacao,
        dtBaixa: situacao === 'baixado' ? (dtBaixa || new Date().toISOString().slice(0, 10)) : undefined,
        motivoBaixa: situacao === 'baixado' ? motivoBaixa : undefined,
      });
    }

    // Save inspection updates
    onSaveInspection(asset.id, {
      status,
      condition,
      tagCondition,
      localizacaoEspecifica: localizacao,
      transferidoPara,
      dtTransf,
      observacao,
      inspectedBy,
      inspectedAt: new Date().toISOString(),
    });
    onClose();
  };

  // Previous years history (e.g., 2024, 2025, 2026)
  const previousYears = [2024, 2025, 2026, 2027].filter((y) => y !== selectedYear);

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto no-print">
      <div className="bg-white rounded-2xl max-w-2xl w-full overflow-hidden shadow-2xl border border-slate-200 animate-in fade-in zoom-in-95 duration-200 my-8">
        {/* Modal Header */}
        <div className="bg-slate-900 text-white p-5 flex items-start justify-between">
          <div>
            <div className="flex items-center gap-2">
              <span className="bg-orange-600 text-white font-mono font-bold text-xs px-2.5 py-1 rounded shadow-2xs">
                PATRIMÔNIO Nº {asset.patrimonio}
              </span>
              <span className="text-xs text-slate-400 font-medium">
                Exercício {selectedYear}
              </span>
            </div>
            <h2 className="text-xl font-extrabold mt-2 text-white uppercase">{asset.descricao}</h2>
            <p className="text-xs text-slate-300 font-mono mt-0.5 max-w-lg">
              {asset.complemento}
            </p>
          </div>

          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Asset Static Info Badges */}
        <div className="bg-slate-50 border-b border-slate-200 p-4 space-y-3">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
            <div>
              <span className="text-slate-500 block text-[10px] font-bold uppercase tracking-wider">Valor Base</span>
              <span className="font-mono font-bold text-slate-900 text-sm">{formatBRL(asset.vlBase)}</span>
            </div>
            <div>
              <span className="text-slate-500 block text-[10px] font-bold uppercase tracking-wider">Aquisição</span>
              <span className="font-semibold text-slate-800">{formatDateBR(asset.dtAquisicao)}</span>
            </div>
            <div>
              <span className="text-slate-500 block text-[10px] font-bold uppercase tracking-wider">Unidade / Loc.</span>
              <span className="font-semibold text-slate-800">{asset.unidade} (Loc. {asset.localidade})</span>
            </div>
            <div>
              <span className="text-slate-500 block text-[10px] font-bold uppercase tracking-wider">Centro de Custo</span>
              <span className="font-mono font-semibold text-slate-800">{asset.centroCusto}</span>
            </div>
          </div>

          {/* QR Code Quick Scan / Pimaco Label Strip */}
          <div className="pt-2 border-t border-slate-200/80 flex items-center justify-between gap-3 bg-white p-2.5 rounded-xl border border-slate-200/90 shadow-2xs">
            <div className="flex items-center gap-3">
              <div className="p-1 bg-slate-50 border border-slate-200 rounded-lg shrink-0">
                <PimacoBarcode
                  value={asset.patrimonio}
                  asset={asset}
                  inspection={currentRecord}
                  type="qrcode"
                  height={24}
                />
              </div>
              <div className="text-xs">
                <div className="font-bold text-slate-900 flex items-center gap-1.5">
                  <QrCode className="w-3.5 h-3.5 text-orange-600" />
                  <span>QR Code Inteligente (Dados Completos)</span>
                </div>
                <p className="text-[11px] text-slate-500">
                  Escaneie com a câmera do celular para ler descrição, complemento, CC, data e laudo.
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <button
                type="button"
                onClick={handleCopyPublicLink}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-bold text-xs border transition-all cursor-pointer ${
                  copiedLink
                    ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                    : 'bg-blue-50 text-blue-800 border-blue-200 hover:bg-blue-600 hover:text-white'
                }`}
                title="Copiar Link Público Direto deste Bem"
              >
                {copiedLink ? (
                  <>
                    <Check className="w-3.5 h-3.5" />
                    <span>Link Copiado!</span>
                  </>
                ) : (
                  <>
                    <Share2 className="w-3.5 h-3.5" />
                    <span>Link Público</span>
                  </>
                )}
              </button>

              {onOpenLabelForAsset && (
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onOpenLabelForAsset(asset);
                  }}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-orange-50 text-orange-700 hover:bg-orange-600 hover:text-white rounded-lg font-bold text-xs border border-orange-200 transition-colors cursor-pointer"
                  title="Gerar etiqueta Pimaco 6181"
                >
                  <Tag className="w-3.5 h-3.5" />
                  <span>Etiqueta Pimaco</span>
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Inspection Form */}
        <form onSubmit={handleSave} className="p-6 space-y-5">
          {/* Asset Lifecycle Status: ATIVO ou BAIXA */}
          <div className="bg-slate-50 border border-slate-200 p-4 rounded-xl space-y-3">
            <div className="flex items-center justify-between">
              <label className="block text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-orange-600" />
                Status do Bem no Patrimônio (Situação Cadastral)
              </label>
              <span
                className={`text-[11px] font-bold px-2 py-0.5 rounded-md border ${
                  situacao === 'ativo'
                    ? 'bg-emerald-100 text-emerald-800 border-emerald-300'
                    : 'bg-rose-100 text-rose-800 border-rose-300'
                }`}
              >
                {situacao === 'ativo' ? '● BEM ATIVO' : '● BEM BAIXADO'}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setSituacao('ativo')}
                className={`py-2.5 px-3 rounded-lg border text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer ${
                  situacao === 'ativo'
                    ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs ring-2 ring-emerald-200'
                    : 'bg-white border-slate-300 text-slate-700 hover:bg-emerald-50 hover:text-emerald-800'
                }`}
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>ATIVO (Em Carga Regular)</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setSituacao('baixado');
                  if (!dtBaixa) {
                    setDtBaixa(new Date().toISOString().slice(0, 10));
                  }
                }}
                className={`py-2.5 px-3 rounded-lg border text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer ${
                  situacao === 'baixado'
                    ? 'bg-rose-600 text-white border-rose-600 shadow-xs ring-2 ring-rose-200'
                    : 'bg-white border-slate-300 text-slate-700 hover:bg-rose-50 hover:text-rose-800'
                }`}
              >
                <Archive className="w-4 h-4" />
                <span>BAIXA (Baixado do Acervo)</span>
              </button>
            </div>

            {/* Baixa specific fields */}
            {situacao === 'baixado' && (
              <div className="pt-3 border-t border-slate-200 grid grid-cols-1 sm:grid-cols-2 gap-3 bg-white p-3 rounded-lg border border-rose-200 animate-in fade-in duration-150">
                <div>
                  <label className="block text-slate-800 font-bold text-xs mb-1 flex items-center gap-1">
                    <Calendar className="w-3.5 h-3.5 text-rose-600" />
                    Data da Baixa:
                  </label>
                  <div className="flex items-center gap-1.5">
                    <input
                      type="date"
                      value={dtBaixa}
                      onChange={(e) => setDtBaixa(e.target.value)}
                      className="w-full px-2.5 py-1.5 bg-slate-50 border border-rose-300 rounded-lg text-slate-800 text-xs font-bold focus:outline-none focus:ring-2 focus:ring-rose-500 focus:bg-white"
                      required
                    />
                    <button
                      type="button"
                      onClick={() => setDtBaixa(new Date().toISOString().slice(0, 10))}
                      className="px-2 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-[11px] font-bold rounded-lg border border-slate-300 whitespace-nowrap cursor-pointer"
                      title="Definir data de hoje"
                    >
                      Hoje
                    </button>
                  </div>
                </div>

                <div>
                  <label className="block text-slate-800 font-bold text-xs mb-1">
                    Motivo / Processo da Baixa:
                  </label>
                  <input
                    type="text"
                    value={motivoBaixa}
                    onChange={(e) => setMotivoBaixa(e.target.value)}
                    placeholder="Ex: Inservível / Leilão / Furto / Processo SEI..."
                    className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-300 rounded-lg text-slate-800 text-xs focus:outline-none focus:ring-2 focus:ring-rose-500 focus:bg-white"
                  />
                </div>
              </div>
            )}
          </div>

          {/* Main Question: Encontra-se no Local? */}
          <div>
            <label className="block text-xs font-bold text-slate-900 uppercase tracking-wider mb-2">
              1. Encontra-se no local da Gerência? (Conferência Física In Loco)
            </label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setStatus('presente')}
                className={`py-3 px-3 rounded-xl border text-xs font-bold flex flex-col items-center justify-center gap-1.5 transition-all cursor-pointer ${
                  status === 'presente'
                    ? 'bg-emerald-600 text-white border-emerald-600 shadow-md ring-2 ring-emerald-300'
                    : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-emerald-50 hover:text-emerald-800'
                }`}
              >
                <CheckCircle className="w-5 h-5" />
                <span>SIM (Presente)</span>
              </button>

              <button
                type="button"
                onClick={() => setStatus('ausente')}
                className={`py-3 px-3 rounded-xl border text-xs font-bold flex flex-col items-center justify-center gap-1.5 transition-all cursor-pointer ${
                  status === 'ausente'
                    ? 'bg-rose-600 text-white border-rose-600 shadow-md ring-2 ring-rose-300'
                    : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-rose-50 hover:text-rose-800'
                }`}
              >
                <AlertTriangle className="w-5 h-5" />
                <span>NÃO (Ausente)</span>
              </button>

              <button
                type="button"
                onClick={() => setStatus('transferido')}
                className={`py-3 px-3 rounded-xl border text-xs font-bold flex flex-col items-center justify-center gap-1.5 transition-all cursor-pointer ${
                  status === 'transferido'
                    ? 'bg-orange-600 text-white border-orange-600 shadow-md ring-2 ring-orange-300'
                    : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-orange-50 hover:text-orange-800'
                }`}
              >
                <ArrowRightLeft className="w-5 h-5" />
                <span>TRANSFERIDO</span>
              </button>
            </div>
          </div>

          {/* Transfer Info if Transferred */}
          {status === 'transferido' && (
            <div className="bg-orange-50 border border-orange-200 p-4 rounded-xl space-y-3">
              <h4 className="text-xs font-bold text-orange-950 uppercase tracking-wider flex items-center gap-1.5">
                <ArrowRightLeft className="w-4 h-4 text-orange-600" /> Dados de Transferência do Bem
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div>
                  <label className="block text-slate-700 font-bold mb-1">Transferido Para (Unidade / Destino):</label>
                  <input
                    type="text"
                    value={transferidoPara}
                    onChange={(e) => setTransferidoPara(e.target.value)}
                    placeholder="Ex: TDO - Operação, Sede, Galpão B..."
                    className="w-full px-3 py-2 bg-white border border-orange-300 rounded-lg text-slate-800 focus:outline-none focus:ring-2 focus:ring-orange-500 font-medium"
                    required
                  />
                </div>
                <div>
                  <label className="block text-slate-700 font-bold mb-1">Data da Transferência:</label>
                  <input
                    type="date"
                    value={dtTransf}
                    onChange={(e) => setDtTransf(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-orange-300 rounded-lg text-slate-800 focus:outline-none focus:ring-2 focus:ring-orange-500 font-medium"
                  />
                </div>
              </div>
            </div>
          )}

          {/* Condition and Tag State */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                2. Estado de Conservação Física:
              </label>
              <select
                value={condition}
                onChange={(e) => {
                  const newCond = e.target.value as AssetCondition;
                  setCondition(newCond);
                  if (newCond === 'bom' || newCond === 'excelente') {
                    setTagCondition('legivel');
                  }
                }}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-medium text-slate-800 focus:ring-2 focus:ring-orange-500 focus:bg-white"
              >
                <option value="nao_avaliado">Não avaliado</option>
                <option value="excelente">Excelente (Sem marcas de uso)</option>
                <option value="bom">Bom (Em pleno funcionamento)</option>
                <option value="regular">Regular (Desgaste natural, operacional)</option>
                <option value="ruim">Ruim (Necessita manutenção imediata)</option>
                <option value="inservivel">Inservível (Sem condições de uso / Baixa)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                3. Plaqueta de Identificação Patrimonial:
              </label>
              <select
                value={tagCondition}
                onChange={(e) => setTagCondition(e.target.value as TagCondition)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs font-medium text-slate-800 focus:ring-2 focus:ring-orange-500 focus:bg-white"
              >
                <option value="legivel">✓ Plaqueta Metálica Fixada e Legível</option>
                <option value="danificada">⚠️ Plaqueta Danificada / Rasurada</option>
                <option value="sem_plaqueta">❌ Sem Plaqueta (Necessita Replaquetamento)</option>
                <option value="placa_substituida">🔄 Placa Substituída no Inventário</option>
              </select>
            </div>
          </div>

          {/* Room / Location & Notes */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                Local Específico (Sala / Setor):
              </label>
              <input
                type="text"
                value={localizacao}
                onChange={(e) => setLocalizacao(e.target.value)}
                placeholder="Ex: Sala da Diretoria, Galpão 03, Copa..."
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs text-slate-800 focus:ring-2 focus:ring-orange-500 focus:bg-white"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                Vistoriador / Fiscal Responsável:
              </label>
              <input
                type="text"
                value={inspectedBy}
                onChange={(e) => setInspectedBy(e.target.value)}
                placeholder="Nome do fiscal que inspecionou"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs text-slate-800 focus:ring-2 focus:ring-orange-500 focus:bg-white"
              />
            </div>
          </div>

          {/* Observations */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5">
              Observações e Ocorrências da Vistoria Visual:
            </label>
            <textarea
              rows={3}
              value={observacao}
              onChange={(e) => setObservacao(e.target.value)}
              placeholder="Descreva detalhes como estado da pintura, necessidade de reparo, motivos de transferência ou divergências encontradas..."
              className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-lg text-xs text-slate-800 focus:ring-2 focus:ring-orange-500 focus:bg-white"
            />
          </div>

          {/* Multi-Year History Summary */}
          <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
            <h5 className="text-xs font-bold text-slate-700 mb-2 flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-slate-500" />
              Histórico de Vistorias em Outros Exercícios
            </h5>
            <div className="flex flex-wrap gap-2 text-[11px]">
              {previousYears.map((prevYear) => {
                const prevRecord = inspections[`${asset.id}-${prevYear}`];
                const prevStatus = prevRecord?.status || 'pendente';
                const badge = getStatusBadge(prevStatus);

                return (
                  <div
                    key={prevYear}
                    className="bg-white px-2.5 py-1 rounded-md border border-slate-200 flex items-center gap-1.5"
                  >
                    <span className="font-bold text-slate-700">{prevYear}:</span>
                    <span className={`px-1.5 py-0.2 rounded font-semibold ${badge.bg}`}>
                      {badge.label}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Form Actions */}
          <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-slate-200">
            <div>
              {onOpenLabelForAsset && (
                <button
                  type="button"
                  onClick={() => {
                    onOpenLabelForAsset(asset);
                    onClose();
                  }}
                  className="flex items-center gap-1.5 px-3 py-2 bg-amber-100 hover:bg-amber-200 text-amber-950 rounded-lg text-xs font-bold transition-colors cursor-pointer border border-amber-300"
                  title="Gerar e imprimir etiqueta Pimaco 6181 para este patrimônio"
                >
                  <Tag className="w-3.5 h-3.5 text-amber-800" />
                  <span>Imprimir Etiqueta Pimaco</span>
                </button>
              )}
            </div>

            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 bg-white border border-slate-300 text-slate-700 hover:bg-slate-50 rounded-lg text-xs font-bold cursor-pointer transition-colors"
              >
                Cancelar
              </button>
              <button
                type="submit"
                className="flex items-center gap-1.5 px-5 py-2 bg-orange-600 hover:bg-orange-700 text-white rounded-lg text-xs font-bold shadow-xs cursor-pointer transition-colors"
              >
                <Save className="w-4 h-4" />
                <span>Salvar Vistoria</span>
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};

