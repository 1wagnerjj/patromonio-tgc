import React, { useState } from 'react';
import {
  History,
} from 'lucide-react';
import { AssetItem, InspectionRecord, DepartmentInfo } from '../types';
import { getStatusBadge } from '../utils/formatters';

interface AnnualAuditComparisonProps {
  assets: AssetItem[];
  inspections: Record<string, InspectionRecord>;
  departments: DepartmentInfo[];
  currentYear: number;
}

export const AnnualAuditComparison: React.FC<AnnualAuditComparisonProps> = ({
  assets,
  inspections,
  departments,
  currentYear,
}) => {
  const auditYears = [2024, 2025, 2026, 2027];
  const [selectedGerencia, setSelectedGerencia] = useState<string>('ALL');
  const [searchTerm, setSearchTerm] = useState('');

  const filteredAssets = assets.filter((asset) => {
    if (selectedGerencia !== 'ALL' && asset.gerenciaCode !== selectedGerencia) {
      return false;
    }
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      return (
        asset.patrimonio.toLowerCase().includes(term) ||
        asset.descricao.toLowerCase().includes(term) ||
        asset.complemento.toLowerCase().includes(term)
      );
    }
    return true;
  });

  // Calculate stats for each year
  const statsByYear = auditYears.map((year) => {
    let present = 0;
    let absent = 0;
    let transferred = 0;
    let pending = 0;

    filteredAssets.forEach((asset) => {
      const key = `${asset.id}-${year}`;
      const rec = inspections[key];
      const status = rec?.status || 'pendente';
      if (status === 'presente') present++;
      else if (status === 'ausente') absent++;
      else if (status === 'transferido') transferred++;
      else pending++;
    });

    const total = filteredAssets.length;
    const verifiedRate = total > 0 ? Math.round((present / total) * 100) : 0;

    return {
      year,
      total,
      present,
      absent,
      transferred,
      pending,
      verifiedRate,
    };
  });

  return (
    <div className="space-y-6 no-print">
      {/* Overview Banner */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-4">
          <div>
            <h2 className="text-lg font-black text-slate-900 flex items-center gap-2 tracking-tight">
              <History className="w-5 h-5 text-orange-600" />
              Histórico Comparativo Anual de Vistorias (2024 - 2027)
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Acompanhamento da evolução física dos bens patrimoniais ao longo dos ciclos anuais de auditoria
            </p>
          </div>

          {/* Gerência Filter */}
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-slate-600">Gerência:</span>
            <select
              value={selectedGerencia}
              onChange={(e) => setSelectedGerencia(e.target.value)}
              className="px-3 py-1.5 bg-slate-50 border border-slate-300 rounded-lg text-xs font-bold text-slate-800 focus:ring-2 focus:ring-orange-500 cursor-pointer"
            >
              <option value="ALL">Todas as Gerências (Geral)</option>
              {departments.map((d) => (
                <option key={d.code} value={d.code}>
                  {d.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Year by Year Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          {statsByYear.map((stat) => (
            <div
              key={stat.year}
              className={`p-4 rounded-xl border transition-all ${
                stat.year === currentYear
                  ? 'bg-orange-50/40 border-orange-300 ring-2 ring-orange-400/30'
                  : 'bg-slate-50 border-slate-200'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <span className="font-extrabold text-slate-900 text-sm">Exercício {stat.year}</span>
                {stat.year === currentYear && (
                  <span className="text-[10px] font-bold bg-orange-600 text-white px-2 py-0.5 rounded shadow-2xs">
                    Atual
                  </span>
                )}
              </div>

              <div className="space-y-1.5 text-xs text-slate-600">
                <div className="flex justify-between">
                  <span>Encontrados no local:</span>
                  <strong className="text-emerald-700 font-bold">{stat.present}</strong>
                </div>
                <div className="flex justify-between">
                  <span>Ausentes / Não localizados:</span>
                  <strong className="text-rose-700 font-bold">{stat.absent}</strong>
                </div>
                <div className="flex justify-between">
                  <span>Transferidos:</span>
                  <strong className="text-orange-700 font-bold">{stat.transferred}</strong>
                </div>
                <div className="flex justify-between">
                  <span>Pendentes:</span>
                  <span className="text-slate-500">{stat.pending}</span>
                </div>
              </div>

              <div className="mt-3 pt-2 border-t border-slate-200">
                <div className="flex justify-between text-xs font-semibold mb-1">
                  <span>Taxa de Presença:</span>
                  <span className="text-slate-900 font-bold">{stat.verifiedRate}%</span>
                </div>
                <div className="w-full bg-slate-200 rounded-full h-2 overflow-hidden">
                  <div
                    className="bg-emerald-600 h-2 rounded-full transition-all duration-500"
                    style={{ width: `${stat.verifiedRate}%` }}
                  />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Asset Level Cross-Year Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-50">
          <div>
            <h3 className="font-extrabold text-slate-900 text-sm">
              Tabela de Rastreabilidade Anual por Item Patrimonial
            </h3>
            <span className="text-xs text-slate-500">
              Visualização de presenças, ausências e movimentações em cada ano
            </span>
          </div>

          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Filtrar por patrimônio ou descrição..."
            className="px-3 py-1.5 bg-white border border-slate-300 rounded-lg text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-orange-500 font-medium"
          />
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-700">
            <thead className="bg-slate-900 text-slate-200 uppercase tracking-wider font-bold text-[11px]">
              <tr>
                <th className="p-3 w-24">Patrimônio</th>
                <th className="p-3 min-w-[220px]">Descrição / Especificação</th>
                <th className="p-3 hidden md:table-cell">Gerência</th>
                {auditYears.map((year) => (
                  <th key={year} className="p-3 text-center w-28">
                    {year}
                  </th>
                ))}
              </tr>
            </thead>

            <tbody className="divide-y divide-slate-200">
              {filteredAssets.map((asset) => (
                <tr key={asset.id} className="hover:bg-slate-50/80 transition-colors">
                  <td className="p-3 font-mono font-bold text-slate-900">
                    <span className="bg-slate-100 text-slate-800 px-2 py-0.5 rounded border border-slate-200">
                      {asset.patrimonio}
                    </span>
                  </td>
                  <td className="p-3">
                    <div className="font-bold text-slate-900 uppercase">{asset.descricao}</div>
                    <div className="text-[11px] text-slate-500 font-mono line-clamp-1">
                      {asset.complemento}
                    </div>
                  </td>
                  <td className="p-3 text-slate-600 hidden md:table-cell font-semibold">
                    {asset.unidade} ({asset.localidade})
                  </td>

                  {auditYears.map((year) => {
                    const insp = inspections[`${asset.id}-${year}`];
                    const status = insp?.status || 'pendente';
                    const badge = getStatusBadge(status);

                    return (
                      <td key={year} className="p-3 text-center">
                        <span
                          className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold border ${badge.bg}`}
                        >
                          <span className={`w-1.5 h-1.5 rounded-full ${badge.dot}`} />
                          {status === 'presente'
                            ? 'Sim'
                            : status === 'ausente'
                            ? 'Não'
                            : status === 'transferido'
                            ? 'Transf.'
                            : 'Pendente'}
                        </span>
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

