import React, { useState, useMemo, useEffect } from 'react';
import {
  Printer,
  Tag,
  Settings2,
  Sparkles,
  Building,
  Filter,
  ChevronLeft,
  ChevronRight,
  ExternalLink,
  Download,
  CheckCircle2,
  AlertCircle,
  Sliders,
  RotateCcw,
  LayoutGrid,
  ArrowDown,
  ArrowUp,
  HelpCircle,
  ScanLine,
  Archive,
  Save,
  FileText,
  Copy,
  PenLine,
  Layers,
  Edit3,
  Pencil,
  Plus,
  Trash2,
  Table,
  Check,
  X,
  Type,
  QrCode,
  RefreshCw,
  SlidersHorizontal,
  Wand2,
  Eye,
  EyeOff,
} from 'lucide-react';
import { AssetItem, InspectionRecord, DepartmentInfo, ArchivedLabelBatch } from '../types';
import { PimacoBarcode } from './PimacoBarcode';
import { ArchivedLabelsModal } from './ArchivedLabelsModal';
import {
  openPimacoPrintWindow,
  downloadPimacoHtmlFile,
  LabelPrintOptions,
} from '../utils/labelPrintEngine';
import {
  getArchivedLabelBatches,
  saveArchivedLabelBatch,
} from '../utils/labelArchiveStorage';

interface PimacoLabelPrintProps {
  assets: AssetItem[];
  filteredAssets?: AssetItem[];
  inspections: Record<string, InspectionRecord>;
  departments: DepartmentInfo[];
  selectedYear: number;
  selectedAssetIds: Set<string>;
  initialDept?: string;
  onClose: () => void;
}

export const PimacoLabelPrint: React.FC<PimacoLabelPrintProps> = ({
  assets,
  filteredAssets,
  inspections,
  departments,
  selectedYear,
  selectedAssetIds,
  initialDept,
  onClose,
}) => {
  // Filter settings
  const [filterDept, setFilterDept] = useState<string>(initialDept && initialDept !== 'ALL' ? initialDept : 'ALL');
  const [filterSource, setFilterSource] = useState<'all' | 'selected' | 'damaged_or_missing' | 'custom' | 'blank_labels'>(() => {
    return selectedAssetIds.size > 0 ? 'selected' : 'all';
  });
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [selectedForPrint, setSelectedForPrint] = useState<Set<string>>(() => {
    if (selectedAssetIds.size > 0) {
      return new Set(selectedAssetIds);
    }
    return new Set(assets.map((a) => a.id));
  });

  // Blank Labels Configuration
  const [blankQuantity, setBlankQuantity] = useState<number>(20); // 1 folha padrão = 20 etiquetas
  const [blankStyle, setBlankStyle] = useState<'write_lines' | 'pure_blank' | 'sequential' | 'custom_text' | 'big_numbers'>('write_lines');
  const [blankSequentialPrefix, setBlankSequentialPrefix] = useState<string>('PROV-');
  const [blankSequentialStart, setBlankSequentialStart] = useState<number>(1);
  const [blankCustomDept, setBlankCustomDept] = useState<string>(initialDept && initialDept !== 'ALL' ? initialDept : 'COMLURB');
  const [blankCustomLoc, setBlankCustomLoc] = useState<string>('');
  const [blankCustomDesc, setBlankCustomDesc] = useState<string>('BEM EM CADASTRAMENTO');

  // Font Size for Numbers / Patrimonio (Permite ajustar de 8pt até 85pt!)
  const [patrimonioFontSize, setPatrimonioFontSize] = useState<number>(13);

  // Archive & Save Batch Modals
  const [isArchiveModalOpen, setIsArchiveModalOpen] = useState<boolean>(false);
  const [isSaveBatchModalOpen, setIsSaveBatchModalOpen] = useState<boolean>(false);
  const [saveBatchName, setSaveBatchName] = useState<string>('');
  const [saveBatchNotes, setSaveBatchNotes] = useState<string>('');
  const [archivedCount, setArchivedCount] = useState<number>(() => getArchivedLabelBatches().length);

  // Keep selection synchronized when selectedAssetIds prop changes
  React.useEffect(() => {
    if (selectedAssetIds.size > 0) {
      setFilterSource('selected');
      setSelectedForPrint(new Set(selectedAssetIds));
    }
  }, [selectedAssetIds]);

  // Label configuration & layout
  const [layoutStyle, setLayoutStyle] = useState<'standard_pimaco' | 'full_barcode' | 'only_barcode' | 'big_numbers'>('standard_pimaco');
  const [copiesPerAsset, setCopiesPerAsset] = useState<number>(1);
  const [startPosition, setStartPosition] = useState<number>(1); // 1 to 20
  const [barcodeType, setBarcodeType] = useState<'barcode' | 'qrcode' | 'both' | 'none'>('qrcode');
  const [showHeader, setShowHeader] = useState<boolean>(true);
  const [showSubHeader, setShowSubHeader] = useState<boolean>(true);
  const [showFooter, setShowFooter] = useState<boolean>(true);
  const [showLoc, setShowLoc] = useState<boolean>(true);
  const [showPatrTag, setShowPatrTag] = useState<boolean>(true);
  const [showUnit, setShowUnit] = useState<boolean>(true);
  const [showCostCenter, setShowCostCenter] = useState<boolean>(true);
  const [showWarningFooter, setShowWarningFooter] = useState<boolean>(false);
  const [showBorderGuide, setShowBorderGuide] = useState<boolean>(false);
  
  // Custom Global Text Fields
  const [customHeader, setCustomHeader] = useState<string>('PREFEITURA DO RIO • COMLURB');
  const [customSubHeader, setCustomSubHeader] = useState<string>('COMLURB');
  const [customFooter, setCustomFooter] = useState<string>('BEM EM CADASTRAMENTO');
  const [customLoc, setCustomLoc] = useState<string>('LOC PREENCHER');

  // Per-label overrides map: { [assetId]: Partial<AssetItem> }
  const [labelOverrides, setLabelOverrides] = useState<Record<string, Partial<AssetItem>>>({});

  // Additional custom added blank/custom rows (when user adds lines in table editor)
  const [additionalCustomAssets, setAdditionalCustomAssets] = useState<AssetItem[]>([]);

  // Interactive In-Place & Modal Editors
  const [isDirectEditMode, setIsDirectEditMode] = useState<boolean>(true);
  const [editingSlotAsset, setEditingSlotAsset] = useState<{ asset: AssetItem; slotIndex: number } | null>(null);
  const [isBatchTableEditorOpen, setIsBatchTableEditorOpen] = useState<boolean>(false);
  const [batchTableSeqStart, setBatchTableSeqStart] = useState<number>(3327);
  const [batchTableSeqPrefix, setBatchTableSeqPrefix] = useState<string>('');
  const [batchTableBulkDesc, setBatchTableBulkDesc] = useState<string>('BEM EM CADASTRAMENTO');
  const [batchTableBulkLoc, setBatchTableBulkLoc] = useState<string>('LOC PREENCHER');
  const [batchTableBulkDept, setBatchTableBulkDept] = useState<string>('COMLURB');

  // Precision Calibration & Pitch (Anti-Drift Engine)
  const [paperFormat, setPaperFormat] = useState<'letter' | 'a4'>('letter');
  const [rowHeightMm, setRowHeightMm] = useState<number>(25.40); // Passo vertical (25.40mm = 1 polegada exata)
  const [colWidthMm, setColWidthMm] = useState<number>(101.60);  // Largura (101.60mm = 4 polegadas exatas)
  const [colGapMm, setColGapMm] = useState<number>(5.20);        // Espaçamento entre colunas
  const [offsetTopMm, setOffsetTopMm] = useState<number>(0);     // Margem superior inicial (Y)
  const [offsetLeftMm, setOffsetLeftMm] = useState<number>(0);   // Margem esquerda inicial (X)
  const [numberAlignment, setNumberAlignment] = useState<'center' | 'left'>('center'); // Alinhamento dos números

  // Pagination for preview & status
  const [previewPage, setPreviewPage] = useState<number>(1);
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [actionMessage, setActionMessage] = useState<{ type: 'success' | 'warning' | 'info'; text: string } | null>(null);

  // Filtered base asset list based on selected rules
  const baseTargetAssets = useMemo(() => {
    if (filterSource === 'blank_labels') {
      const blanks: AssetItem[] = [];
      for (let i = 0; i < blankQuantity; i++) {
        const indexNum = blankSequentialStart + i;
        const formattedNum = indexNum.toString().padStart(4, '0');
        const patrValue =
          blankStyle === 'sequential' || blankStyle === 'big_numbers'
            ? `${blankSequentialPrefix}${formattedNum}`
            : blankStyle === 'custom_text'
            ? `${blankSequentialPrefix || 'AVULSO-'}${formattedNum}`
            : '';

        blanks.push({
          id: `blank_${i + 1}`,
          patrimonio: patrValue,
          descricao:
            blankStyle === 'write_lines'
              ? ''
              : blankStyle === 'pure_blank'
              ? ''
              : blankStyle === 'custom_text'
              ? blankCustomDesc || customFooter || 'BEM EM CADASTRAMENTO'
              : blankStyle === 'big_numbers'
              ? blankCustomDesc || customFooter || 'CADASTRAMENTO PROVISÓRIO'
              : 'CADASTRAMENTO PROVISÓRIO',
          complemento:
            blankStyle === 'write_lines' || blankStyle === 'pure_blank'
              ? ''
              : 'VISTORIA PATRIMONIAL IN LOCO',
          dtAquisicao: '2026-01-01',
          vlBase: 0,
          unidade: blankCustomDept || (filterDept !== 'ALL' ? filterDept : customSubHeader || 'COMLURB'),
          gerenciaCode: filterDept !== 'ALL' ? filterDept : 'COMLURB',
          gerenciaName: filterDept !== 'ALL' ? filterDept : 'COMLURB',
          localidade: blankCustomLoc || customLoc || 'LOC PREENCHER',
          centroCusto: '',
          isBlank: true,
          blankStyle: blankStyle,
          customFontSize: patrimonioFontSize,
          customHeader: customHeader,
          customSubHeader: customSubHeader,
          customFooter: customFooter,
          customLoc: customLoc,
        });
      }
      return blanks;
    }

    const filtered = assets.filter((asset) => {
      // Dept filter
      if (filterDept !== 'ALL' && asset.gerenciaCode !== filterDept) {
        return false;
      }

      // Filter source rule
      if (filterSource === 'selected' && !selectedAssetIds.has(asset.id)) {
        return false;
      }

      if (filterSource === 'damaged_or_missing') {
        const insp = inspections[`${asset.id}-${selectedYear}`];
        const isDamagedOrMissing =
          insp?.tagCondition === 'sem_plaqueta' ||
          insp?.tagCondition === 'danificada' ||
          insp?.tagCondition === 'placa_substituida';
        if (!isDamagedOrMissing) return false;
      }

      if (filterSource === 'custom' && !selectedForPrint.has(asset.id)) {
        return false;
      }

      // Search term
      if (searchTerm) {
        const term = searchTerm.toLowerCase();
        const matchPatrimonio = asset.patrimonio.toLowerCase().includes(term);
        const matchDesc = asset.descricao.toLowerCase().includes(term);
        const matchComp = asset.complemento.toLowerCase().includes(term);
        if (!matchPatrimonio && !matchDesc && !matchComp) return false;
      }

      return true;
    });

    return filtered;
  }, [
    assets,
    filterDept,
    filterSource,
    selectedAssetIds,
    inspections,
    selectedYear,
    selectedForPrint,
    searchTerm,
    blankQuantity,
    blankStyle,
    blankSequentialPrefix,
    blankSequentialStart,
    blankCustomDept,
    blankCustomLoc,
    blankCustomDesc,
    patrimonioFontSize,
    customHeader,
    customSubHeader,
    customFooter,
    customLoc,
  ]);

  // Merge base assets with additional assets and per-asset user edits (labelOverrides)
  const targetAssets = useMemo(() => {
    const combined = [...baseTargetAssets, ...additionalCustomAssets];
    return combined.map((asset) => {
      const override = labelOverrides[asset.id] || {};
      return {
        ...asset,
        ...override,
        patrimonio: override.patrimonio !== undefined ? override.patrimonio : asset.patrimonio,
        descricao: override.descricao !== undefined ? override.descricao : (asset.descricao || customFooter),
        unidade: override.unidade !== undefined ? override.unidade : (asset.unidade || customSubHeader),
        localidade: override.localidade !== undefined ? override.localidade : (asset.localidade || customLoc),
        customHeader: override.customHeader !== undefined ? override.customHeader : (asset.customHeader || customHeader),
        customSubHeader: override.customSubHeader !== undefined ? override.customSubHeader : (asset.customSubHeader || customSubHeader),
        customFooter: override.customFooter !== undefined ? override.customFooter : (asset.customFooter || customFooter),
        customLoc: override.customLoc !== undefined ? override.customLoc : (asset.customLoc || customLoc),
        customFontSize: override.customFontSize !== undefined ? override.customFontSize : (asset.customFontSize || patrimonioFontSize),
        hideQr: override.hideQr !== undefined ? override.hideQr : (asset.hideQr || false),
      };
    });
  }, [
    baseTargetAssets,
    additionalCustomAssets,
    labelOverrides,
    customHeader,
    customSubHeader,
    customFooter,
    customLoc,
    patrimonioFontSize,
  ]);

  // Update a single field on a specific asset
  const handleUpdateAssetField = (assetId: string, field: keyof AssetItem, value: any) => {
    setLabelOverrides((prev) => ({
      ...prev,
      [assetId]: {
        ...prev[assetId],
        [field]: value,
      },
    }));
  };

  // Quick reset of all manual edits
  const handleResetAllOverrides = () => {
    if (window.confirm('Deseja redefinir todas as alterações manuais feitas nas etiquetas desta folha?')) {
      setLabelOverrides({});
      setAdditionalCustomAssets([]);
      setActionMessage({
        type: 'info',
        text: 'Todas as edições manuais foram redefinidas para o padrão.',
      });
    }
  };

  // Bulk Apply Current Global Texts to ALL active assets
  const handleApplyGlobalTextsToAll = () => {
    const newOverrides: Record<string, Partial<AssetItem>> = { ...labelOverrides };
    targetAssets.forEach((asset) => {
      newOverrides[asset.id] = {
        ...(newOverrides[asset.id] || {}),
        customHeader: customHeader,
        customSubHeader: customSubHeader,
        customFooter: customFooter,
        customLoc: customLoc,
        unidade: customSubHeader,
        localidade: customLoc,
        descricao: customFooter,
        customFontSize: patrimonioFontSize,
      };
    });
    setLabelOverrides(newOverrides);
    setActionMessage({
      type: 'success',
      text: `Textos personalizados e fonte (${patrimonioFontSize}pt) aplicados em todas as ${targetAssets.length} etiquetas da folha!`,
    });
  };

  // Generate numerical sequence in table modal (e.g. from 3327 up to 3346)
  const handleApplySequenceToBatch = (explicitStart?: number, explicitPrefix?: string) => {
    const start = explicitStart !== undefined ? explicitStart : batchTableSeqStart;
    const prefix = explicitPrefix !== undefined ? explicitPrefix : batchTableSeqPrefix;
    const newOverrides: Record<string, Partial<AssetItem>> = { ...labelOverrides };
    targetAssets.forEach((asset, idx) => {
      const currentNumber = start + idx;
      const formatted = `${prefix}${currentNumber}`;
      newOverrides[asset.id] = {
        ...(newOverrides[asset.id] || {}),
        patrimonio: formatted,
      };
    });
    setLabelOverrides(newOverrides);
    setActionMessage({
      type: 'success',
      text: `Sequência numérica gerada com sucesso (${prefix}${start} até ${prefix}${start + targetAssets.length - 1})!`,
    });
  };

  // Bulk set description in table modal
  const handleApplyBulkDescToBatch = (explicitDesc?: string) => {
    const descToUse = explicitDesc !== undefined ? explicitDesc : batchTableBulkDesc;
    if (!descToUse.trim()) return;
    const newOverrides: Record<string, Partial<AssetItem>> = { ...labelOverrides };
    targetAssets.forEach((asset) => {
      newOverrides[asset.id] = {
        ...(newOverrides[asset.id] || {}),
        descricao: descToUse,
        customFooter: descToUse,
      };
    });
    setLabelOverrides(newOverrides);
    setActionMessage({
      type: 'success',
      text: `Descrição "${descToUse}" aplicada em todas as etiquetas!`,
    });
  };

  // Bulk set location in table modal
  const handleApplyBulkLocToBatch = (explicitLoc?: string) => {
    const locToUse = explicitLoc !== undefined ? explicitLoc : batchTableBulkLoc;
    if (!locToUse.trim()) return;
    const newOverrides: Record<string, Partial<AssetItem>> = { ...labelOverrides };
    targetAssets.forEach((asset) => {
      newOverrides[asset.id] = {
        ...(newOverrides[asset.id] || {}),
        localidade: locToUse,
        customLoc: locToUse,
      };
    });
    setLabelOverrides(newOverrides);
    setActionMessage({
      type: 'success',
      text: `Localidade "${locToUse}" aplicada em todas as etiquetas!`,
    });
  };

  // Bulk toggle QR code visibility in batch table
  const handleSetAllQrVisibility = (showQr: boolean) => {
    const newOverrides: Record<string, Partial<AssetItem>> = { ...labelOverrides };
    targetAssets.forEach((asset) => {
      newOverrides[asset.id] = {
        ...(newOverrides[asset.id] || {}),
        hideQr: !showQr,
      };
    });
    setLabelOverrides(newOverrides);
    setActionMessage({
      type: 'success',
      text: showQr
        ? 'QR Code ativado em todas as etiquetas do lote!'
        : 'QR Code ocultado em todas as etiquetas (Somente Número ativo)!',
    });
  };

  // Bulk toggle pure clean numbers (hide/show all headers, footers, loc, and PATR prefix)
  const handleSetPureCleanNumbersAll = (clean: boolean) => {
    const newOverrides: Record<string, Partial<AssetItem>> = { ...labelOverrides };
    targetAssets.forEach((asset) => {
      newOverrides[asset.id] = {
        ...(newOverrides[asset.id] || {}),
        hideHeader: clean,
        hideSubHeader: clean,
        hideFooter: clean,
        hideLoc: clean,
        hidePatrTag: clean,
      };
    });
    setLabelOverrides(newOverrides);
    setShowHeader(!clean);
    setShowSubHeader(!clean);
    setShowFooter(!clean);
    setShowLoc(!clean);
    setShowPatrTag(!clean);
    setActionMessage({
      type: 'success',
      text: clean
        ? 'Modo Totalmente Limpo ativado: cabeçalhos, descrições, gerência e legendas foram ocultados!'
        : 'Todos os textos, cabeçalhos e legendas foram restaurados!',
    });
  };

  // Add a new custom row to the batch
  const handleAddNewCustomRow = () => {
    const newId = `custom_slot_${Date.now()}_${additionalCustomAssets.length + 1}`;
    const nextNum = (batchTableSeqStart + targetAssets.length).toString();
    const newAsset: AssetItem = {
      id: newId,
      patrimonio: nextNum,
      descricao: customFooter || 'BEM EM CADASTRAMENTO',
      complemento: 'VISTORIA PATRIMONIAL IN LOCO',
      dtAquisicao: '2026-01-01',
      vlBase: 0,
      unidade: customSubHeader || 'COMLURB',
      gerenciaCode: filterDept !== 'ALL' ? filterDept : 'COMLURB',
      gerenciaName: filterDept !== 'ALL' ? filterDept : 'COMLURB',
      localidade: customLoc || 'LOC PREENCHER',
      centroCusto: '',
      isBlank: true,
      blankStyle: 'big_numbers',
      customFontSize: patrimonioFontSize,
      customHeader: customHeader,
      customSubHeader: customSubHeader,
      customFooter: customFooter,
      customLoc: customLoc,
    };
    setAdditionalCustomAssets((prev) => [...prev, newAsset]);
    setActionMessage({
      type: 'success',
      text: `Nova etiqueta #${targetAssets.length + 1} adicionada ao lote!`,
    });
  };

  // Duplicate a specific asset in the batch (by AssetItem or slot index)
  const handleDuplicateAsset = (target: AssetItem | number) => {
    const asset = typeof target === 'number' ? targetAssets[target] : target;
    if (!asset) return;
    const newId = `dup_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    const duplicated: AssetItem = {
      ...asset,
      id: newId,
      patrimonio: `${asset.patrimonio} (CÓPIA)`,
    };
    setAdditionalCustomAssets((prev) => [...prev, duplicated]);
    setActionMessage({
      type: 'success',
      text: `Etiqueta "${asset.patrimonio}" duplicada com sucesso!`,
    });
  };

  // Clear slot content (by assetId or slot index)
  const handleClearSlotAsset = (target: string | number) => {
    const assetId = typeof target === 'number' ? targetAssets[target]?.id : target;
    if (!assetId) return;
    setLabelOverrides((prev) => ({
      ...prev,
      [assetId]: {
        patrimonio: '0000',
        descricao: 'EM BRANCO',
        localidade: '—',
        customHeader: '—',
        customSubHeader: '—',
        customFooter: 'EM BRANCO',
        customLoc: '—',
      },
    }));
  };

  // Generate flat array of labels including start position offset (blanks) and copies
  const labelSlots = useMemo(() => {
    const slots: (AssetItem | null)[] = [];

    // Add empty placeholder slots if starting from label > 1
    for (let i = 1; i < startPosition; i++) {
      slots.push(null);
    }

    // Add items with copies
    targetAssets.forEach((asset) => {
      for (let c = 0; c < copiesPerAsset; c++) {
        slots.push(asset);
      }
    });

    return slots;
  }, [targetAssets, startPosition, copiesPerAsset]);

  // Group into pages of 20 labels each
  const pages = useMemo(() => {
    const p: (AssetItem | null)[][] = [];
    const LABELS_PER_PAGE = 20;

    for (let i = 0; i < labelSlots.length; i += LABELS_PER_PAGE) {
      p.push(labelSlots.slice(i, i + LABELS_PER_PAGE));
    }

    if (p.length === 0) {
      p.push([]);
    }

    return p;
  }, [labelSlots]);

  const totalSheets = Math.max(1, pages.length);
  const totalLabelsToPrint = targetAssets.length * copiesPerAsset;

  const getPrintOptions = (isCalibrationSheet = false): LabelPrintOptions => ({
    assets: labelSlots,
    paperFormat,
    rowHeightMm,
    colWidthMm,
    colGapMm,
    offsetTopMm,
    offsetLeftMm,
    layoutStyle,
    showHeader,
    showSubHeader,
    showFooter,
    showLoc,
    showPatrTag,
    showUnit,
    showCostCenter,
    showWarningFooter,
    showBorderGuide,
    customHeader,
    customSubHeader,
    customFooter,
    customLoc,
    barcodeType,
    patrimonioFontSizePt: patrimonioFontSize,
    numberAlignment,
    selectedYear,
    isCalibrationSheet,
    inspections,
    batchTitle: saveBatchName || undefined,
  });

  // Action: Save Current Batch to Archive
  const handleOpenSaveBatchModal = () => {
    const formattedDateTime = `${new Date().toLocaleDateString('pt-BR')} às ${new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}`;
    const defaultBatchTitle =
      filterSource === 'blank_labels'
        ? `Lote ${filterDept !== 'ALL' ? filterDept : 'COMLURB'} • ${blankQuantity} Etiquetas em Branco (${formattedDateTime})`
        : `Lote ${filterDept !== 'ALL' ? filterDept : 'Geral'} • ${totalLabelsToPrint} Etiquetas (${formattedDateTime})`;

    setSaveBatchName(defaultBatchTitle);
    setSaveBatchNotes('');
    setIsSaveBatchModalOpen(true);
  };

  const handleConfirmSaveBatch = () => {
    if (!saveBatchName.trim()) {
      alert('Por favor, informe um nome para o lote.');
      return;
    }

    const newBatch: ArchivedLabelBatch = {
      id: `batch_${Date.now()}`,
      name: saveBatchName.trim(),
      createdAt: new Date().toISOString(),
      departmentCode: filterDept,
      labelCount: totalLabelsToPrint,
      sheetsCount: totalSheets,
      layoutStyle,
      sourceType: filterSource,
      paperFormat,
      copiesPerAsset,
      startPosition,
      barcodeType,
      showHeader,
      showUnit,
      showCostCenter,
      showWarningFooter,
      showBorderGuide,
      customHeader,
      customSubHeader,
      customFooter,
      customLoc,
      rowHeightMm,
      colWidthMm,
      colGapMm,
      offsetTopMm,
      offsetLeftMm,
      patrimonioFontSizePt: patrimonioFontSize,
      blankConfig:
        filterSource === 'blank_labels'
          ? {
              blankStyle,
              quantity: blankQuantity,
              sequentialPrefix: blankSequentialPrefix,
              customDept: blankCustomDept,
              customLoc: blankCustomLoc,
              customDesc: blankCustomDesc,
              fontSizePt: patrimonioFontSize,
            }
          : undefined,
      assetSnapshots: targetAssets.map((a) => ({
        id: a.id,
        patrimonio: a.patrimonio,
        descricao: a.descricao,
        complemento: a.complemento,
        unidade: a.unidade,
        localidade: a.localidade,
        centroCusto: a.centroCusto,
        isBlank: a.isBlank,
        customFontSize: a.customFontSize,
        customHeader: a.customHeader,
        customSubHeader: a.customSubHeader,
        customFooter: a.customFooter,
        customLoc: a.customLoc,
        hideQr: a.hideQr,
      })),
      notes: saveBatchNotes.trim(),
    };

    saveArchivedLabelBatch(newBatch);
    setArchivedCount(getArchivedLabelBatches().length);
    setIsSaveBatchModalOpen(false);
    setActionMessage({
      type: 'success',
      text: `Lote "${saveBatchName}" arquivado com sucesso! Você pode visualizá-lo e reimprimi-lo a qualquer momento em "Etiquetas Arquivadas".`,
    });
  };

  const handleLoadBatch = (batch: ArchivedLabelBatch) => {
    setLayoutStyle(batch.layoutStyle);
    setPaperFormat(batch.paperFormat);
    setCopiesPerAsset(batch.copiesPerAsset);
    setStartPosition(batch.startPosition);
    setBarcodeType(batch.barcodeType);
    setShowHeader(batch.showHeader);
    setShowUnit(batch.showUnit);
    setShowCostCenter(batch.showCostCenter);
    setShowWarningFooter(batch.showWarningFooter);
    setShowBorderGuide(batch.showBorderGuide);
    if (batch.customHeader) setCustomHeader(batch.customHeader);
    if (batch.customSubHeader) setCustomSubHeader(batch.customSubHeader);
    if (batch.customFooter) setCustomFooter(batch.customFooter);
    if (batch.customLoc) setCustomLoc(batch.customLoc);
    if (batch.patrimonioFontSizePt) setPatrimonioFontSize(batch.patrimonioFontSizePt);
    setRowHeightMm(batch.rowHeightMm);
    setColWidthMm(batch.colWidthMm);
    setColGapMm(batch.colGapMm);
    setOffsetTopMm(batch.offsetTopMm);
    setOffsetLeftMm(batch.offsetLeftMm);
    setFilterDept(batch.departmentCode);
    setFilterSource(batch.sourceType as any);

    if (batch.blankConfig) {
      setBlankStyle(batch.blankConfig.blankStyle);
      setBlankQuantity(batch.blankConfig.quantity);
      setBlankSequentialPrefix(batch.blankConfig.sequentialPrefix);
      if (batch.blankConfig.customDept) setBlankCustomDept(batch.blankConfig.customDept);
      if (batch.blankConfig.customLoc) setBlankCustomLoc(batch.blankConfig.customLoc);
      if (batch.blankConfig.customDesc) setBlankCustomDesc(batch.blankConfig.customDesc);
      if (batch.blankConfig.fontSizePt) setPatrimonioFontSize(batch.blankConfig.fontSizePt);
    }

    if (batch.assetSnapshots && batch.assetSnapshots.length > 0) {
      const restoredOverrides: Record<string, Partial<AssetItem>> = {};
      batch.assetSnapshots.forEach((snap) => {
        restoredOverrides[snap.id] = {
          patrimonio: snap.patrimonio,
          descricao: snap.descricao,
          unidade: snap.unidade,
          localidade: snap.localidade,
          customFontSize: snap.customFontSize,
          customHeader: snap.customHeader,
          customSubHeader: snap.customSubHeader,
          customFooter: snap.customFooter,
          customLoc: snap.customLoc,
          hideQr: snap.hideQr,
        };
      });
      setLabelOverrides(restoredOverrides);
    }

    if (batch.assetSnapshots && batch.sourceType === 'custom') {
      setSelectedForPrint(new Set(batch.assetSnapshots.map((s) => s.id)));
    }

    setActionMessage({
      type: 'info',
      text: `Lote "${batch.name}" carregado com sucesso no editor!`,
    });
  };

  // Action 1: Direct print
  const handleDirectPrint = () => {
    try {
      window.focus();
      window.print();
    } catch (err) {
      console.error('Error during direct print:', err);
      handleOpenNewWindow();
    }
  };

  // Action 2: Open in new standalone print window (100% reliable)
  const handleOpenNewWindow = async () => {
    setIsGenerating(true);
    setActionMessage(null);
    try {
      const opened = await openPimacoPrintWindow(getPrintOptions());
      if (opened) {
        setActionMessage({
          type: 'success',
          text: 'Janela de impressão aberta! No diálogo da impressora, confirme: "Escala: 100%" e "Margens: Nenhuma".',
        });
      } else {
        setActionMessage({
          type: 'warning',
          text: 'O navegador bloqueou a abertura do popup. Usando diálogo de impressão direta.',
        });
        window.focus();
        window.print();
      }
    } catch (err) {
      console.error('Failed to open print window:', err);
    } finally {
      setIsGenerating(false);
    }
  };

  // Action 3: Calibration Test Sheet
  const handlePrintCalibrationSheet = async () => {
    setIsGenerating(true);
    try {
      const opened = await openPimacoPrintWindow(getPrintOptions(true));
      if (opened) {
        setActionMessage({
          type: 'info',
          text: 'Gabarito de calibração gerado! Imprima em papel comum e sobreponha sobre a folha Pimaco contra a luz para conferência.',
        });
      }
    } catch (err) {
      console.error('Failed to print calibration sheet:', err);
    } finally {
      setIsGenerating(false);
    }
  };

  // Action 4: Download standalone HTML
  const handleDownloadHtml = async () => {
    setIsGenerating(true);
    try {
      const filename = `Etiquetas_Pimaco_6181_COMLURB_${selectedYear}_${totalLabelsToPrint}_itens.html`;
      await downloadPimacoHtmlFile(getPrintOptions(), filename);
      setActionMessage({
        type: 'success',
        text: `Arquivo "${filename}" baixado! Abra-o no navegador e pressione Ctrl + P para imprimir.`,
      });
    } catch (err) {
      console.error('Failed to download HTML:', err);
    } finally {
      setIsGenerating(false);
    }
  };

  // Quick Calibration Presets to solve drift on bottom rows
  const handleFixDriftDown = () => {
    // Last labels are coming out too low (downward drift) -> compress row pitch
    setRowHeightMm((prev) => Math.max(24.40, Number((prev - 0.15).toFixed(2))));
    setActionMessage({
      type: 'info',
      text: 'Passo vertical reduzido para comprimir as linhas inferiores. O desalinhamento acumulado nas últimas etiquetas foi reduzido.',
    });
  };

  const handleFixDriftUp = () => {
    // Last labels are coming out too high (upward drift) -> expand row pitch
    setRowHeightMm((prev) => Math.min(26.40, Number((prev + 0.15).toFixed(2))));
    setActionMessage({
      type: 'info',
      text: 'Passo vertical aumentado para expandir as linhas inferiores.',
    });
  };

  const handleResetCalibration = () => {
    setRowHeightMm(25.40);
    setColWidthMm(101.60);
    setColGapMm(5.20);
    setOffsetTopMm(0);
    setOffsetLeftMm(0);
    setPaperFormat('letter');
    setActionMessage({
      type: 'info',
      text: 'Calibração restaurada para o padrão oficial Pimaco 6181 / 6281 (Carta: 25,4 mm × 101,6 mm).',
    });
  };

  const handleToggleSelectAsset = (id: string) => {
    setSelectedForPrint((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const handleSelectAllCurrent = (checked: boolean) => {
    if (checked) {
      setSelectedForPrint(new Set(assets.map((a) => a.id)));
    } else {
      setSelectedForPrint(new Set());
    }
  };

  const calculatedTopMargin = Math.max(0, 12.7 + offsetTopMm);
  const calculatedLeftMargin = Math.max(0, (paperFormat === 'letter' ? 3.75 : 1.6) + offsetLeftMm);

  // Position accumulator statistics
  const row1Y = calculatedTopMargin;
  const row5Y = calculatedTopMargin + 4 * rowHeightMm;
  const row10Y = calculatedTopMargin + 9 * rowHeightMm;
  const totalGridHeight = 10 * rowHeightMm;

  return (
    <div className="space-y-6">
      {/* Precision Dynamic Print CSS */}
      <style>{`
        @media print {
          @page {
            size: ${paperFormat === 'letter' ? 'letter portrait' : 'a4 portrait'};
            margin: 0mm !important;
          }

          html, body {
            background: #ffffff !important;
            margin: 0 !important;
            padding: 0 !important;
            -webkit-print-color-adjust: exact !important;
            print-color-adjust: exact !important;
          }

          .no-print,
          nav,
          header,
          aside,
          button,
          .print-hide {
            display: none !important;
          }

          .pimaco-print-wrapper {
            display: block !important;
            margin: 0 !important;
            padding: 0 !important;
            background: #ffffff !important;
          }

          .pimaco-print-sheet {
            display: block !important;
            width: ${paperFormat === 'letter' ? '215.9mm' : '210.0mm'} !important;
            height: ${paperFormat === 'letter' ? '279.4mm' : '297.0mm'} !important;
            min-height: ${paperFormat === 'letter' ? '279.4mm' : '297.0mm'} !important;
            max-height: ${paperFormat === 'letter' ? '279.4mm' : '297.0mm'} !important;
            padding-top: ${calculatedTopMargin}mm !important;
            padding-left: ${calculatedLeftMargin}mm !important;
            padding-right: 2.0mm !important;
            padding-bottom: 0mm !important;
            margin: 0 !important;
            page-break-inside: avoid !important;
            page-break-after: always !important;
            break-after: page !important;
            box-sizing: border-box !important;
            overflow: hidden !important;
            background: #ffffff !important;
          }

          .pimaco-grid-container {
            display: grid !important;
            grid-template-columns: ${colWidthMm}mm ${colWidthMm}mm !important;
            grid-template-rows: repeat(10, ${rowHeightMm}mm) !important;
            column-gap: ${colGapMm}mm !important;
            row-gap: 0.0mm !important;
            width: ${colWidthMm * 2 + colGapMm}mm !important;
            height: ${totalGridHeight}mm !important;
            box-sizing: border-box !important;
            margin: 0 !important;
            padding: 0 !important;
          }

          .pimaco-label-cell {
            width: ${colWidthMm}mm !important;
            height: ${rowHeightMm}mm !important;
            min-height: ${rowHeightMm}mm !important;
            max-height: ${rowHeightMm}mm !important;
            box-sizing: border-box !important;
            overflow: hidden !important;
            background: #ffffff !important;
            padding: 0 !important;
            margin: 0 !important;
          }
        }
      `}</style>

      {/* Control Panel / Form Configuration (no-print) */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xs p-6 space-y-6 no-print">
        {/* Header with Title and Action buttons */}
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-slate-200 pb-5">
          <div className="flex items-start gap-3">
            <div className="w-12 h-12 bg-amber-500 text-slate-950 rounded-xl flex items-center justify-center font-black shadow-xs shrink-0">
              <Tag className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-black text-slate-900 tracking-tight">
                  Pimaco 6181 / 6281 • Etiquetas de Patrimônio
                </h2>
                <span className="bg-amber-100 text-amber-900 text-[11px] font-extrabold px-2.5 py-0.5 rounded-full border border-amber-300">
                  20 Etiquetas por Folha (Carta)
                </span>
              </div>
              <p className="text-xs text-slate-500 font-medium mt-0.5">
                Dimensões oficiais: <strong>25,4 mm × 101,6 mm</strong> (1" × 4") • 2 colunas × 10 linhas
              </p>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={onClose}
              className="px-3.5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition-colors cursor-pointer"
            >
              Voltar ao Inventário
            </button>

            {/* View Archived Batches */}
            <button
              onClick={() => setIsArchiveModalOpen(true)}
              className="flex items-center gap-1.5 px-3.5 py-2.5 bg-slate-100 hover:bg-orange-50 text-slate-800 hover:text-orange-900 border border-slate-300 hover:border-orange-300 rounded-xl text-xs font-bold transition-all cursor-pointer"
              title="Abrir histórico de folhas de etiquetas salvas e arquivadas"
            >
              <Archive className="w-4 h-4 text-orange-600" />
              <span>Arquivo de Lotes</span>
              {archivedCount > 0 && (
                <span className="bg-orange-600 text-white font-black text-[10px] px-1.5 py-0.2 rounded-full">
                  {archivedCount}
                </span>
              )}
            </button>

            {/* Save Batch to Archive */}
            <button
              onClick={handleOpenSaveBatchModal}
              disabled={totalLabelsToPrint === 0}
              className="flex items-center gap-1.5 px-3.5 py-2.5 bg-amber-50 hover:bg-amber-100 text-amber-950 border border-amber-300 rounded-xl text-xs font-black transition-all cursor-pointer disabled:opacity-40"
              title="Salvar a folha atual no arquivo permanente para reimpressão e auditoria"
            >
              <Save className="w-4 h-4 text-amber-700" />
              <span>Salvar Lote</span>
            </button>

            {/* Test Sheet */}
            <button
              onClick={handlePrintCalibrationSheet}
              disabled={isGenerating}
              className="flex items-center gap-1.5 px-3.5 py-2.5 bg-slate-100 hover:bg-amber-100 text-slate-800 hover:text-amber-900 border border-slate-200 hover:border-amber-300 rounded-xl text-xs font-bold transition-all cursor-pointer"
              title="Imprimir folha de calibração milimétrica em papel sulfite para testar o enquadramento"
            >
              <ScanLine className="w-4 h-4 text-amber-600" />
              <span>Testar Alinhamento</span>
            </button>

            {/* Open in new window (Recommended) */}
            <button
              onClick={handleOpenNewWindow}
              disabled={totalLabelsToPrint === 0 || isGenerating}
              className="flex items-center gap-2 px-4 py-2.5 bg-slate-900 hover:bg-slate-800 disabled:opacity-50 text-white rounded-xl text-xs font-bold shadow-xs transition-all cursor-pointer"
              title="Abre a folha de etiquetas em nova janela com alinhamento isolado"
            >
              <ExternalLink className="w-4 h-4 text-amber-400" />
              <span>Abrir em Nova Janela</span>
            </button>

            {/* Direct print */}
            <button
              onClick={handleDirectPrint}
              disabled={totalLabelsToPrint === 0 || isGenerating}
              className="flex items-center gap-2 px-5 py-2.5 bg-orange-600 hover:bg-orange-700 disabled:opacity-50 text-white rounded-xl text-xs font-black shadow-xs transition-all cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              <span>
                Imprimir {totalLabelsToPrint} Etiqueta{totalLabelsToPrint !== 1 ? 's' : ''} ({totalSheets} Folha{totalSheets !== 1 ? 's' : ''})
              </span>
            </button>

            {/* Download HTML */}
            <button
              onClick={handleDownloadHtml}
              disabled={totalLabelsToPrint === 0 || isGenerating}
              className="p-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl transition-colors cursor-pointer"
              title="Baixar arquivo HTML avulso para arquivar no computador"
            >
              <Download className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Action Message Alert */}
        {actionMessage && (
          <div
            className={`p-3.5 rounded-xl text-xs font-medium flex items-center justify-between gap-3 border ${
              actionMessage.type === 'success'
                ? 'bg-emerald-50 text-emerald-900 border-emerald-200'
                : actionMessage.type === 'warning'
                ? 'bg-amber-50 text-amber-900 border-amber-200'
                : 'bg-sky-50 text-sky-900 border-sky-200'
            }`}
          >
            <div className="flex items-center gap-2.5">
              {actionMessage.type === 'success' ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              ) : actionMessage.type === 'warning' ? (
                <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
              ) : (
                <Sliders className="w-4 h-4 text-sky-600 shrink-0" />
              )}
              <span>{actionMessage.text}</span>
            </div>
            <button
              onClick={() => setActionMessage(null)}
              className="text-slate-400 hover:text-slate-700 text-xs font-bold cursor-pointer"
            >
              ✕
            </button>
          </div>
        )}

        {/* CRITICAL CALIBRATION & DIMENSIONS BOX (Ajuste Fino de Enquadramento, Largura, Altura e Posição) */}
        <div className="bg-amber-50/90 border-2 border-amber-300 rounded-2xl p-5 space-y-4 shadow-xs">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-amber-200/80 pb-3">
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 rounded-full bg-amber-500 animate-pulse"></span>
              <div>
                <h3 className="text-xs font-black text-amber-950 uppercase tracking-wider">
                  Calibração Milimétrica & Enquadramento Perfeito da Folha (Pimaco 6181 / 6281)
                </h3>
                <p className="text-[11px] text-amber-800 font-medium">
                  Ajuste milimétrico de altura, largura, margens e tamanho do número para zerar desvios na impressora.
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2 text-[11px] font-bold text-amber-900 self-start sm:self-center">
              <span>Passo: <strong className="font-mono bg-white px-2 py-0.5 rounded border border-amber-300 text-slate-900">{rowHeightMm.toFixed(2)} mm</strong></span>
              <span>Largura: <strong className="font-mono bg-white px-2 py-0.5 rounded border border-amber-300 text-slate-900">{colWidthMm.toFixed(1)} mm</strong></span>
              {(rowHeightMm !== 25.40 || colWidthMm !== 101.60 || colGapMm !== 5.20 || offsetTopMm !== 0 || offsetLeftMm !== 0) && (
                <button
                  type="button"
                  onClick={handleResetCalibration}
                  className="text-amber-900 hover:text-amber-950 font-black underline flex items-center gap-1 cursor-pointer ml-1"
                  title="Restaurar valores de fábrica"
                >
                  <RotateCcw className="w-3 h-3" />
                  Restaurar Padrão
                </button>
              )}
            </div>
          </div>

          {/* Quick Problem Solvers (1-Click Fixes) */}
          <div className="bg-white/80 p-3 rounded-xl border border-amber-200/90 space-y-2">
            <span className="text-[11px] font-extrabold text-amber-950 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-amber-600" />
              Soluções Rápidas de 1 Clique para Correção de Desvios:
            </span>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2 text-xs">
              <button
                type="button"
                onClick={() => {
                  setRowHeightMm(25.10);
                  setActionMessage({
                    type: 'success',
                    text: 'Correção Anti-Descida Aplicada (Passo 25.10mm). As linhas inferiores foram comprimidas para cima.',
                  });
                }}
                className="p-2 bg-amber-500/15 hover:bg-amber-500/25 border border-amber-400 rounded-xl text-left cursor-pointer transition-colors"
                title="Resolve o caso onde as 2 primeiras linhas estão boas e as linhas 3 a 10 vão saindo por baixo"
              >
                <div className="font-black text-amber-950 text-[11px]">⚡ Anti-Descida (25.10 mm)</div>
                <div className="text-[10px] text-amber-800">Puxa linhas inferiores que saem por baixo</div>
              </button>

              <button
                type="button"
                onClick={() => {
                  setRowHeightMm(25.20);
                  setActionMessage({
                    type: 'success',
                    text: 'Correção Anti-Descida Moderada (Passo 25.20mm) aplicada.',
                  });
                }}
                className="p-2 bg-amber-500/10 hover:bg-amber-500/20 border border-amber-300 rounded-xl text-left cursor-pointer transition-colors"
              >
                <div className="font-bold text-amber-950 text-[11px]">⚡ Anti-Descida Leve (25.20 mm)</div>
                <div className="text-[10px] text-amber-800">Ajuste fino de -0.20 mm por linha</div>
              </button>

              <button
                type="button"
                onClick={() => {
                  setRowHeightMm(25.40);
                  setPaperFormat('letter');
                  setActionMessage({
                    type: 'info',
                    text: 'Passo restaurado para o padrão Carta Oficial Pimaco (25.40 mm x 101.60 mm).',
                  });
                }}
                className="p-2 bg-slate-100 hover:bg-slate-200 border border-slate-300 rounded-xl text-left cursor-pointer transition-colors"
              >
                <div className="font-bold text-slate-900 text-[11px]">🎯 Padrão Carta (25.40 mm)</div>
                <div className="text-[10px] text-slate-600">Medida exata de fábrica Pimaco</div>
              </button>

              <button
                type="button"
                onClick={() => {
                  setRowHeightMm(25.00);
                  setPaperFormat('a4');
                  setActionMessage({
                    type: 'info',
                    text: 'Modo Folha A4 ativado (Passo 25.00 mm).',
                  });
                }}
                className="p-2 bg-slate-100 hover:bg-slate-200 border border-slate-300 rounded-xl text-left cursor-pointer transition-colors"
              >
                <div className="font-bold text-slate-900 text-[11px]">📄 Folha A4 (25.00 mm)</div>
                <div className="text-[10px] text-slate-600">Compensação para folhas A4</div>
              </button>
            </div>
          </div>

          {/* Detailed Sliders Grid (Vertical Pitch, Width, Column Gap, Offsets, Font Size & Alignment) */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-3 text-xs">
            {/* 1. Row Height (Passo Vertical) */}
            <div className="bg-white p-2.5 rounded-xl border border-amber-200 flex flex-col justify-between">
              <div>
                <div className="flex justify-between font-bold text-slate-800 text-[11px] mb-1">
                  <span>Altura / Passo (Y):</span>
                  <span className="font-mono text-amber-700 font-black">{rowHeightMm.toFixed(2)} mm</span>
                </div>
                <input
                  type="range"
                  min="24.00"
                  max="26.40"
                  step="0.05"
                  value={rowHeightMm}
                  onChange={(e) => setRowHeightMm(Number(e.target.value))}
                  className="w-full accent-amber-600 cursor-pointer"
                />
              </div>
              <div className="flex justify-between text-[9px] text-slate-500 font-mono mt-1 pt-1 border-t border-slate-100">
                <button type="button" onClick={handleFixDriftDown} className="hover:text-amber-700 font-bold cursor-pointer">-0.15mm</button>
                <span>25.4 mm</span>
                <button type="button" onClick={handleFixDriftUp} className="hover:text-amber-700 font-bold cursor-pointer">+0.15mm</button>
              </div>
            </div>

            {/* 2. Col Width (Largura da Etiqueta) */}
            <div className="bg-white p-2.5 rounded-xl border border-amber-200 flex flex-col justify-between">
              <div>
                <div className="flex justify-between font-bold text-slate-800 text-[11px] mb-1">
                  <span>Largura Etiqueta (X):</span>
                  <span className="font-mono text-amber-700 font-black">{colWidthMm.toFixed(1)} mm</span>
                </div>
                <input
                  type="range"
                  min="94.0"
                  max="106.0"
                  step="0.2"
                  value={colWidthMm}
                  onChange={(e) => setColWidthMm(Number(e.target.value))}
                  className="w-full accent-amber-600 cursor-pointer"
                />
              </div>
              <div className="flex justify-between text-[9px] text-slate-500 font-mono mt-1 pt-1 border-t border-slate-100">
                <span>94 mm</span>
                <span>Padrão 101.6 mm</span>
                <span>106 mm</span>
              </div>
            </div>

            {/* 3. Col Gap (Espaçamento entre Colunas) */}
            <div className="bg-white p-2.5 rounded-xl border border-amber-200 flex flex-col justify-between">
              <div>
                <div className="flex justify-between font-bold text-slate-800 text-[11px] mb-1">
                  <span>Espaço Colunas (Gap):</span>
                  <span className="font-mono text-amber-700 font-black">{colGapMm.toFixed(1)} mm</span>
                </div>
                <input
                  type="range"
                  min="0.0"
                  max="10.0"
                  step="0.2"
                  value={colGapMm}
                  onChange={(e) => setColGapMm(Number(e.target.value))}
                  className="w-full accent-amber-600 cursor-pointer"
                />
              </div>
              <div className="flex justify-between text-[9px] text-slate-500 font-mono mt-1 pt-1 border-t border-slate-100">
                <span>0 mm</span>
                <span>Padrão 5.2 mm</span>
                <span>10 mm</span>
              </div>
            </div>

            {/* 4. Offset Top (Deslocamento Vertical Global) */}
            <div className="bg-white p-2.5 rounded-xl border border-amber-200 flex flex-col justify-between">
              <div>
                <div className="flex justify-between font-bold text-slate-800 text-[11px] mb-1">
                  <span>Margem Topo (Y):</span>
                  <span className="font-mono text-amber-700 font-black">{offsetTopMm > 0 ? `+${offsetTopMm}` : offsetTopMm} mm</span>
                </div>
                <input
                  type="range"
                  min="-8"
                  max="8"
                  step="0.2"
                  value={offsetTopMm}
                  onChange={(e) => setOffsetTopMm(Number(e.target.value))}
                  className="w-full accent-amber-600 cursor-pointer"
                />
              </div>
              <div className="flex justify-between text-[9px] text-slate-500 font-mono mt-1 pt-1 border-t border-slate-100">
                <span>-8 mm</span>
                <span>Topo 0 mm</span>
                <span>+8 mm</span>
              </div>
            </div>

            {/* 5. Offset Left (Deslocamento Horizontal Global) */}
            <div className="bg-white p-2.5 rounded-xl border border-amber-200 flex flex-col justify-between">
              <div>
                <div className="flex justify-between font-bold text-slate-800 text-[11px] mb-1">
                  <span>Margem Esq (X):</span>
                  <span className="font-mono text-amber-700 font-black">{offsetLeftMm > 0 ? `+${offsetLeftMm}` : offsetLeftMm} mm</span>
                </div>
                <input
                  type="range"
                  min="-6"
                  max="6"
                  step="0.2"
                  value={offsetLeftMm}
                  onChange={(e) => setOffsetLeftMm(Number(e.target.value))}
                  className="w-full accent-amber-600 cursor-pointer"
                />
              </div>
              <div className="flex justify-between text-[9px] text-slate-500 font-mono mt-1 pt-1 border-t border-slate-100">
                <span>-6 mm</span>
                <span>Esq 0 mm</span>
                <span>+6 mm</span>
              </div>
            </div>

            {/* 6. Number Font Size & Alignment */}
            <div className="bg-white p-2.5 rounded-xl border border-amber-200 flex flex-col justify-between">
              <div>
                <div className="flex justify-between font-bold text-slate-800 text-[11px] mb-1">
                  <span>Fonte / Alinhamento:</span>
                  <span className="font-mono text-amber-700 font-black">{patrimonioFontSize} pt</span>
                </div>
                <input
                  type="range"
                  min="12"
                  max="85"
                  step="1"
                  value={patrimonioFontSize}
                  onChange={(e) => setPatrimonioFontSize(Number(e.target.value))}
                  className="w-full accent-amber-600 cursor-pointer"
                />
              </div>
              <div className="flex items-center justify-between text-[9px] font-bold mt-1 pt-1 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setNumberAlignment('left')}
                  className={`px-1.5 py-0.5 rounded cursor-pointer ${numberAlignment === 'left' ? 'bg-amber-500 text-slate-950 font-black' : 'text-slate-600 hover:bg-slate-100'}`}
                >
                  À Esquerda
                </button>
                <button
                  type="button"
                  onClick={() => setNumberAlignment('center')}
                  className={`px-1.5 py-0.5 rounded cursor-pointer ${numberAlignment === 'center' ? 'bg-amber-500 text-slate-950 font-black' : 'text-slate-600 hover:bg-slate-100'}`}
                >
                  Centralizado
                </button>
              </div>
            </div>
          </div>

          {/* Calculated Millimeter Checkpoints & Golden Rule Instructions */}
          <div className="bg-amber-100/70 rounded-xl p-3 flex flex-col md:flex-row md:items-center justify-between gap-3 text-[11px] font-mono text-amber-950">
            <div className="flex items-center gap-2">
              <HelpCircle className="w-4 h-4 text-amber-700 shrink-0" />
              <span className="font-sans font-bold">Posições Físicas na Folha:</span>
              <span>Linha 1: <strong>{row1Y.toFixed(1)} mm</strong></span>
              <span>• Linha 5: <strong>{row5Y.toFixed(1)} mm</strong></span>
              <span>• Linha 10 (Última): <strong className="text-amber-900 font-black">{row10Y.toFixed(1)} mm</strong></span>
              <span>• Altura Total: <strong>{totalGridHeight.toFixed(1)} mm</strong></span>
            </div>

            <div className="font-sans text-[11px] text-amber-900 bg-white/70 px-2.5 py-1 rounded-lg border border-amber-300 font-medium">
              💡 <strong>Dica de Ouro:</strong> No diálogo de impressão, use <strong>Escala: 100%</strong> e <strong>Margens: Nenhuma</strong>.
            </div>
          </div>
        </div>

        {/* Section: Visual Layout Mode & Selection Filters */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 text-xs">
          {/* Layout Style */}
          <div>
            <label className="block text-slate-700 font-bold mb-1.5 flex items-center gap-1.5">
              <LayoutGrid className="w-3.5 h-3.5 text-orange-600" />
              Modelo Visual da Etiqueta:
            </label>
            <select
              value={layoutStyle}
              onChange={(e) => {
                const newStyle = e.target.value as any;
                setLayoutStyle(newStyle);
                if (newStyle === 'big_numbers' && patrimonioFontSize < 38) {
                  setPatrimonioFontSize(56);
                }
              }}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl font-bold text-slate-800 focus:ring-2 focus:ring-orange-500 cursor-pointer"
            >
              <option value="standard_pimaco">Oficial Pimaco 6181 (PATR + QR)</option>
              <option value="big_numbers">🔥 Números Gigantes (Alta Visibilidade - até 85pt)</option>
              <option value="full_barcode">Código de Barras 128 + QR Code</option>
              <option value="only_barcode">Apenas Código de Barras 128</option>
            </select>
          </div>

          {/* QR Code / Barcode / Somente Número Mode */}
          <div>
            <label className="block text-slate-700 font-bold mb-1.5 flex items-center gap-1.5">
              <QrCode className="w-3.5 h-3.5 text-orange-600" />
              QR Code / Tipo de Código:
            </label>
            <select
              value={barcodeType}
              onChange={(e) => setBarcodeType(e.target.value as any)}
              className={`w-full px-3 py-2 border rounded-xl font-bold focus:ring-2 focus:ring-orange-500 cursor-pointer transition-colors ${
                barcodeType === 'none'
                  ? 'bg-amber-100/70 border-amber-400 text-amber-950 font-black'
                  : 'bg-slate-50 border-slate-300 text-slate-800'
              }`}
            >
              <option value="qrcode">Com QR Code (Escaneável)</option>
              <option value="none">🚫 Sem QR Code (Somente Nº do Patrimônio)</option>
              <option value="barcode">Código de Barras 128</option>
              <option value="both">QR Code + Código de Barras</option>
            </select>
          </div>

          {/* Source Filter */}
          <div>
            <label className="block text-slate-700 font-bold mb-1.5 flex items-center gap-1.5">
              <Filter className="w-3.5 h-3.5 text-orange-600" />
              Bens Selecionados:
            </label>
            <select
              value={filterSource}
              onChange={(e) => setFilterSource(e.target.value as any)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl font-bold text-slate-800 focus:ring-2 focus:ring-orange-500 cursor-pointer"
            >
              <option value="all">Todos do inventário ({assets.length})</option>
              {selectedAssetIds.size > 0 && (
                <option value="selected">Apenas selecionados ({selectedAssetIds.size})</option>
              )}
              <option value="damaged_or_missing">Ausentes / Danificadas</option>
              <option value="custom">Escolha manual...</option>
              <option value="blank_labels">✨ Etiquetas em Branco / Avulsas</option>
            </select>
          </div>

          {/* Department Filter */}
          <div>
            <label className="block text-slate-700 font-bold mb-1.5 flex items-center gap-1.5">
              <Building className="w-3.5 h-3.5 text-orange-600" />
              Gerência / Lotação:
            </label>
            <select
              value={filterDept}
              onChange={(e) => setFilterDept(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl font-bold text-slate-800 focus:ring-2 focus:ring-orange-500 cursor-pointer"
            >
              <option value="ALL">Todas as Gerências</option>
              {departments.map((d) => (
                <option key={d.code} value={d.code}>
                  {d.code} - {d.name.replace(/Gerência de |Divisão de /, '')}
                </option>
              ))}
            </select>
          </div>

          {/* Copies */}
          <div>
            <label className="block text-slate-700 font-bold mb-1.5">
              Cópias por Patrimônio:
            </label>
            <div className="flex items-center gap-2">
              <input
                type="number"
                min="1"
                max="10"
                value={copiesPerAsset}
                onChange={(e) => setCopiesPerAsset(Math.max(1, Number(e.target.value)))}
                className="w-20 px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl font-mono font-bold text-slate-900 text-center focus:ring-2 focus:ring-orange-500"
              />
              <span className="text-slate-500 font-medium">etiqueta(s) / bem</span>
            </div>
          </div>
        </div>

        {/* Dynamic Quick Toggle Banner for QR vs No-QR */}
        <div className="flex flex-wrap items-center justify-between gap-2 p-2.5 bg-slate-100 rounded-xl border border-slate-200 text-xs">
          <div className="flex items-center gap-2">
            <span className="font-bold text-slate-700 flex items-center gap-1">
              <QrCode className="w-3.5 h-3.5 text-orange-600" />
              Exibição de QR Code:
            </span>
            <div className="flex items-center gap-1 bg-white p-1 rounded-lg border border-slate-300 shadow-2xs">
              <button
                type="button"
                onClick={() => setBarcodeType('qrcode')}
                className={`px-2.5 py-1 rounded-md font-bold transition-all cursor-pointer ${
                  barcodeType === 'qrcode'
                    ? 'bg-orange-600 text-white shadow-2xs'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                Com QR Code
              </button>
              <button
                type="button"
                onClick={() => setBarcodeType('none')}
                className={`px-2.5 py-1 rounded-md font-bold transition-all cursor-pointer ${
                  barcodeType === 'none'
                    ? 'bg-amber-500 text-slate-950 font-black shadow-2xs'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                🚫 Sem QR Code (Somente Nº do Patrimônio)
              </button>
              <button
                type="button"
                onClick={() => setBarcodeType('barcode')}
                className={`px-2.5 py-1 rounded-md font-bold transition-all cursor-pointer ${
                  barcodeType === 'barcode'
                    ? 'bg-slate-800 text-white shadow-2xs'
                    : 'text-slate-600 hover:bg-slate-100'
                }`}
              >
                Código de Barras 128
              </button>
            </div>
          </div>

          <div className="text-[11px] text-slate-500 font-medium">
            {barcodeType === 'none' ? (
              <span className="text-amber-800 font-bold bg-amber-100 px-2 py-0.5 rounded">
                ✓ Modo Somente Número ativo: 100% da largura livre para numeração grande (até 85pt)!
              </span>
            ) : (
              <span>QR Code patrimonial incluído na lateral direita da etiqueta.</span>
            )}
          </div>
        </div>

        {/* Global Font Size Controller Box */}
        <div className="p-4 bg-slate-900 text-white rounded-2xl border border-slate-800 shadow-md">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-amber-400 text-slate-950 flex items-center justify-center font-black text-lg shadow-sm">
                A
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h4 className="font-extrabold text-sm text-white flex items-center gap-1.5">
                    Tamanho da Fonte dos Números (Patrimônio):
                  </h4>
                  <span className="px-2.5 py-0.5 rounded-full bg-amber-400 text-slate-950 font-black font-mono text-xs shadow-xs">
                    {patrimonioFontSize} pt
                  </span>
                  {patrimonioFontSize === 85 && (
                    <span className="px-2 py-0.5 rounded-md bg-orange-600 text-white text-[10px] font-black uppercase tracking-wider animate-pulse">
                      Máxima Visibilidade (85pt)
                    </span>
                  )}
                </div>
                <p className="text-xs text-slate-400">
                  Ajuste o tamanho dos dígitos numéricos para leitura fácil e destaque na plaqueta.
                </p>
              </div>
            </div>

            {/* Slider & Presets */}
            <div className="flex flex-wrap items-center gap-3">
              {/* Slider */}
              <div className="flex items-center gap-2 bg-slate-800 px-3 py-1.5 rounded-xl border border-slate-700">
                <span className="text-[10px] text-slate-400 font-bold">8pt</span>
                <input
                  type="range"
                  min="8"
                  max="85"
                  step="1"
                  value={patrimonioFontSize}
                  onChange={(e) => setPatrimonioFontSize(Number(e.target.value))}
                  className="w-32 sm:w-44 accent-amber-400 cursor-pointer"
                />
                <span className="text-[10px] text-amber-400 font-bold">85pt</span>
              </div>

              {/* Direct numeric input */}
              <div className="flex items-center gap-1.5">
                <input
                  type="number"
                  min="8"
                  max="85"
                  value={patrimonioFontSize}
                  onChange={(e) => setPatrimonioFontSize(Math.min(85, Math.max(8, Number(e.target.value))))}
                  className="w-16 px-2 py-1.5 bg-slate-800 border border-slate-700 rounded-xl font-mono font-black text-amber-400 text-center text-sm focus:ring-2 focus:ring-amber-400 outline-hidden"
                />
                <span className="text-xs text-slate-400 font-bold">pt</span>
              </div>

              {/* Quick Presets Buttons */}
              <div className="flex items-center gap-1">
                {[
                  { label: '13pt (Padrão)', size: 13 },
                  { label: '24pt', size: 24 },
                  { label: '38pt', size: 38 },
                  { label: '56pt', size: 56 },
                  { label: '🔥 85pt (Gigante)', size: 85 },
                ].map((preset) => (
                  <button
                    key={preset.size}
                    type="button"
                    onClick={() => {
                      setPatrimonioFontSize(preset.size);
                    }}
                    className={`px-2 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                      patrimonioFontSize === preset.size
                        ? 'bg-amber-400 text-slate-950 font-black shadow-xs'
                        : 'bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white border border-slate-700'
                    }`}
                  >
                    {preset.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Dedicated Editable Label Text Customization Hub */}
        <div className="p-4.5 bg-gradient-to-r from-slate-900 via-slate-850 to-slate-900 text-white rounded-2xl border border-slate-700 shadow-lg space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-700/80 pb-3">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-orange-500 text-white flex items-center justify-center font-bold">
                <Edit3 className="w-4 h-4" />
              </div>
              <div>
                <h3 className="font-extrabold text-sm text-white flex items-center gap-2">
                  <span>Editor de Textos & Cabeçalhos das Etiquetas</span>
                  <span className="text-[10px] bg-amber-400 text-slate-950 px-2 py-0.5 rounded-full font-black uppercase tracking-wider">
                    Totalmente Editável
                  </span>
                </h3>
                <p className="text-xs text-slate-300">
                  Configure os cabeçalhos, setores, descrições e localidades padrão, ou edite diretamente qualquer etiqueta no preview.
                </p>
              </div>
            </div>

            {/* Action Bar */}
            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={() => setIsBatchTableEditorOpen(true)}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-xl text-xs shadow-xs transition-colors cursor-pointer"
                title="Abre a planilha completa com todas as etiquetas para edição em lote e sequencial"
              >
                <Table className="w-3.5 h-3.5" />
                <span>Abrir Editor em Planilha</span>
              </button>

              <button
                type="button"
                onClick={handleApplyGlobalTextsToAll}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-white border border-slate-600 rounded-xl text-xs font-bold transition-colors cursor-pointer"
                title="Aplica os textos abaixo em todas as etiquetas desta folha"
              >
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span>Aplicar a Todas</span>
              </button>

              <button
                type="button"
                onClick={handleAddNewCustomRow}
                className="flex items-center gap-1.5 px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-600 rounded-xl text-xs font-bold transition-colors cursor-pointer"
                title="Adiciona mais uma etiqueta ao lote atual"
              >
                <Plus className="w-3.5 h-3.5 text-amber-400" />
                <span>+1 Etiqueta</span>
              </button>

              {Object.keys(labelOverrides).length > 0 && (
                <button
                  type="button"
                  onClick={handleResetAllOverrides}
                  className="flex items-center gap-1 px-2.5 py-1.5 bg-red-950/60 hover:bg-red-900 text-red-200 border border-red-800/80 rounded-xl text-xs font-bold transition-colors cursor-pointer"
                  title="Redefinir todas as edições manuais feitas nas etiquetas"
                >
                  <RotateCcw className="w-3 h-3" />
                  <span>Redefinir ({Object.keys(labelOverrides).length})</span>
                </button>
              )}
            </div>
          </div>

          {/* Quick Visibility & Layout Presets */}
          <div className="flex flex-wrap items-center gap-2 pb-1">
            <span className="text-[11px] font-bold text-amber-400 flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5" />
              Predefinições Rápidas:
            </span>
            <button
              type="button"
              onClick={() => {
                setShowHeader(true);
                setShowSubHeader(true);
                setShowFooter(true);
                setShowLoc(true);
                setShowPatrTag(true);
                setBarcodeType('qrcode');
                handleSetPureCleanNumbersAll(false);
              }}
              className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-white border border-slate-600 rounded-lg text-xs font-bold transition-all cursor-pointer"
              title="Exibir todos os campos de texto, cabeçalho e QR Code padrão"
            >
              📋 Padrão Completo
            </button>
            <button
              type="button"
              onClick={() => {
                setShowHeader(false);
                setShowSubHeader(false);
                setShowFooter(false);
                setShowLoc(false);
                setShowPatrTag(true);
                setBarcodeType('qrcode');
                const newOverrides = { ...labelOverrides };
                targetAssets.forEach((a) => {
                  newOverrides[a.id] = {
                    ...(newOverrides[a.id] || {}),
                    hideHeader: true,
                    hideSubHeader: true,
                    hideFooter: true,
                    hideLoc: true,
                    hidePatrTag: false,
                    hideQr: false,
                  };
                });
                setLabelOverrides(newOverrides);
                setActionMessage({ type: 'success', text: 'Modo "Somente Número + QR" ativado (Textos ocultados)!' });
              }}
              className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-amber-300 border border-slate-600 rounded-lg text-xs font-bold transition-all cursor-pointer"
              title="Oculta cabeçalhos e descrições, deixando o número com o QR Code"
            >
              📱 Somente Número + QR
            </button>
            <button
              type="button"
              onClick={() => {
                handleSetPureCleanNumbersAll(true);
                setBarcodeType('none');
                handleSetAllQrVisibility(false);
              }}
              className="px-2.5 py-1 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded-lg text-xs font-black transition-all cursor-pointer shadow-xs"
              title="Oculta tudo: sem cabeçalho, sem gerência, sem descrição, sem localidade e sem QR Code"
            >
              ✨ Totalmente Limpo (Apenas Número)
            </button>
            <button
              type="button"
              onClick={() => {
                handleSetPureCleanNumbersAll(true);
                setLayoutStyle('big_numbers');
                setPatrimonioFontSize(85);
                setBarcodeType('none');
                handleSetAllQrVisibility(false);
              }}
              className="px-2.5 py-1 bg-orange-600 hover:bg-orange-500 text-white rounded-lg text-xs font-black transition-all cursor-pointer shadow-xs"
              title="Número Gigante 85pt totalmente em branco sem legendas"
            >
              🔥 Número Gigante Limpo (85pt)
            </button>
          </div>

          {/* 4 Editable Text Fields with Individual Visibility Checkboxes */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
            {/* 1. Header Top-Left */}
            <div className={`p-2.5 rounded-xl border transition-colors ${showHeader ? 'bg-slate-800/90 border-slate-700' : 'bg-slate-900/60 border-slate-800 opacity-60'}`}>
              <div className="flex items-center justify-between mb-1.5">
                <label className="flex items-center gap-1.5 cursor-pointer text-amber-400 font-bold select-none">
                  <input
                    type="checkbox"
                    checked={showHeader}
                    onChange={(e) => setShowHeader(e.target.checked)}
                    className="rounded text-amber-400 focus:ring-amber-400"
                  />
                  <span>Cabeçalho (Orgão)</span>
                </label>
                <span className="text-[9px] text-slate-400 font-normal">Topo Esq</span>
              </div>
              <input
                type="text"
                disabled={!showHeader}
                value={customHeader}
                onChange={(e) => setCustomHeader(e.target.value)}
                placeholder="Ex: PREFEITURA DO RIO • COMLURB"
                className={`w-full px-2.5 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-white font-bold text-xs focus:ring-2 focus:ring-amber-400 outline-hidden ${!showHeader ? 'opacity-40 cursor-not-allowed' : ''}`}
              />
            </div>

            {/* 2. SubHeader Top-Right (Dept / Gerência) */}
            <div className={`p-2.5 rounded-xl border transition-colors ${showSubHeader ? 'bg-slate-800/90 border-slate-700' : 'bg-slate-900/60 border-slate-800 opacity-60'}`}>
              <div className="flex items-center justify-between mb-1.5">
                <label className="flex items-center gap-1.5 cursor-pointer text-amber-400 font-bold select-none">
                  <input
                    type="checkbox"
                    checked={showSubHeader}
                    onChange={(e) => setShowSubHeader(e.target.checked)}
                    className="rounded text-amber-400 focus:ring-amber-400"
                  />
                  <span>Gerência / Setor</span>
                </label>
                <span className="text-[9px] text-slate-400 font-normal">Topo Dir</span>
              </div>
              <input
                type="text"
                disabled={!showSubHeader}
                value={customSubHeader}
                onChange={(e) => setCustomSubHeader(e.target.value)}
                placeholder="Ex: COMLURB, TGC, DLOG"
                className={`w-full px-2.5 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-white font-bold text-xs focus:ring-2 focus:ring-amber-400 outline-hidden ${!showSubHeader ? 'opacity-40 cursor-not-allowed' : ''}`}
              />
            </div>

            {/* 3. Footer Bottom-Left (Desc / Rodapé) */}
            <div className={`p-2.5 rounded-xl border transition-colors ${showFooter ? 'bg-slate-800/90 border-slate-700' : 'bg-slate-900/60 border-slate-800 opacity-60'}`}>
              <div className="flex items-center justify-between mb-1.5">
                <label className="flex items-center gap-1.5 cursor-pointer text-amber-400 font-bold select-none">
                  <input
                    type="checkbox"
                    checked={showFooter}
                    onChange={(e) => setShowFooter(e.target.checked)}
                    className="rounded text-amber-400 focus:ring-amber-400"
                  />
                  <span>Descrição / Rodapé</span>
                </label>
                <span className="text-[9px] text-slate-400 font-normal">Base Esq</span>
              </div>
              <input
                type="text"
                disabled={!showFooter}
                value={customFooter}
                onChange={(e) => setCustomFooter(e.target.value)}
                placeholder="Ex: BEM EM CADASTRAMENTO"
                className={`w-full px-2.5 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-white font-bold text-xs focus:ring-2 focus:ring-amber-400 outline-hidden ${!showFooter ? 'opacity-40 cursor-not-allowed' : ''}`}
              />
            </div>

            {/* 4. Loc Bottom-Right (Localidade) */}
            <div className={`p-2.5 rounded-xl border transition-colors ${showLoc ? 'bg-slate-800/90 border-slate-700' : 'bg-slate-900/60 border-slate-800 opacity-60'}`}>
              <div className="flex items-center justify-between mb-1.5">
                <label className="flex items-center gap-1.5 cursor-pointer text-amber-400 font-bold select-none">
                  <input
                    type="checkbox"
                    checked={showLoc}
                    onChange={(e) => setShowLoc(e.target.checked)}
                    className="rounded text-amber-400 focus:ring-amber-400"
                  />
                  <span>Localidade / Sala</span>
                </label>
                <span className="text-[9px] text-slate-400 font-normal">Base Dir</span>
              </div>
              <input
                type="text"
                disabled={!showLoc}
                value={customLoc}
                onChange={(e) => setCustomLoc(e.target.value)}
                placeholder="Ex: LOC PREENCHER, SALA 104"
                className={`w-full px-2.5 py-1.5 bg-slate-900 border border-slate-700 rounded-lg text-white font-bold text-xs focus:ring-2 focus:ring-amber-400 outline-hidden ${!showLoc ? 'opacity-40 cursor-not-allowed' : ''}`}
              />
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-3 text-[11px] text-slate-400 pt-2 border-t border-slate-800">
            <div className="flex items-center gap-2">
              <span className="text-amber-400 font-bold">💡 Dica de Edição:</span>
              <span>Você pode clicar diretamente em qualquer número ou texto na folha abaixo para editá-lo na hora.</span>
            </div>
            <div className="flex flex-wrap items-center gap-4">
              <label className="flex items-center gap-1.5 cursor-pointer text-slate-200 font-bold hover:text-amber-400 transition-colors">
                <input
                  type="checkbox"
                  checked={showPatrTag}
                  onChange={(e) => setShowPatrTag(e.target.checked)}
                  className="rounded text-amber-400"
                />
                <span>Exibir Prefixo "PATR:"</span>
              </label>

              <label className="flex items-center gap-1.5 cursor-pointer text-slate-200 font-bold hover:text-amber-400 transition-colors">
                <input
                  type="checkbox"
                  checked={barcodeType !== 'none'}
                  onChange={(e) => setBarcodeType(e.target.checked ? 'qrcode' : 'none')}
                  className="rounded text-amber-400"
                />
                <span>Exibir QR Code</span>
              </label>

              <label className="flex items-center gap-1.5 cursor-pointer text-slate-300 font-medium">
                <input
                  type="checkbox"
                  checked={isDirectEditMode}
                  onChange={(e) => setIsDirectEditMode(e.target.checked)}
                  className="rounded text-amber-400"
                />
                <span>Ativar Edição Direta no Preview</span>
              </label>
            </div>
          </div>
        </div>

        {/* Dedicated Blank Labels Configuration Box */}
        {filterSource === 'blank_labels' && (
          <div className="p-5 bg-gradient-to-r from-amber-50/90 via-orange-50/50 to-amber-50/90 rounded-2xl border-2 border-amber-300 shadow-xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-amber-200/80 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-amber-500 text-slate-950 flex items-center justify-center font-bold">
                  <PenLine className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-black text-slate-900 text-sm">
                    Configuração de Etiquetas em Branco / Avulsas (Pimaco 6181 / 6281)
                  </h3>
                  <p className="text-xs text-slate-600">
                    Gere folhas virgens, com linhas de escrita ou números gigantes (até 85pt) para vistorias em campo.
                  </p>
                </div>
              </div>

              {/* Quick Sheet Quantity Presets */}
              <div className="flex items-center gap-1.5 self-start sm:self-center">
                <span className="text-[11px] font-bold text-slate-600 mr-1">Folhas:</span>
                {[
                  { label: '1 Folha (20)', count: 20 },
                  { label: '2 Folhas (40)', count: 40 },
                  { label: '3 Folhas (60)', count: 60 },
                  { label: '5 Folhas (100)', count: 100 },
                ].map((preset) => (
                  <button
                    key={preset.count}
                    type="button"
                    onClick={() => setBlankQuantity(preset.count)}
                    className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                      blankQuantity === preset.count
                        ? 'bg-amber-600 text-white shadow-2xs'
                        : 'bg-white text-slate-700 border border-amber-300 hover:bg-amber-100'
                    }`}
                  >
                    {preset.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Blank Style Selector Cards (Now 5 options including Big Numbers 85pt!) */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 text-xs">
              {/* Style 1: Write Lines */}
              <button
                type="button"
                onClick={() => setBlankStyle('write_lines')}
                className={`p-3 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
                  blankStyle === 'write_lines'
                    ? 'bg-white border-orange-500 ring-2 ring-orange-500/20 shadow-xs'
                    : 'bg-white/80 border-slate-200 hover:border-amber-400'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="font-extrabold text-slate-900 text-xs flex items-center gap-1">
                      <PenLine className="w-3.5 h-3.5 text-orange-600" />
                      Linhas para Escrita
                    </span>
                    {blankStyle === 'write_lines' && (
                      <span className="w-2 h-2 rounded-full bg-orange-600" />
                    )}
                  </div>
                  <p className="text-[11px] text-slate-500 leading-tight">
                    Campos pontilhados para preenchimento manual à caneta (DESC, MOD/SÉRIE, LOC).
                  </p>
                </div>
                <div className="mt-2.5 font-mono text-[9px] bg-slate-50 p-1.5 rounded border border-slate-200 text-slate-600">
                  PATR: [ _____ ] DESC: ____
                </div>
              </button>

              {/* Style 2: Pure Blank */}
              <button
                type="button"
                onClick={() => setBlankStyle('pure_blank')}
                className={`p-3 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
                  blankStyle === 'pure_blank'
                    ? 'bg-white border-orange-500 ring-2 ring-orange-500/20 shadow-xs'
                    : 'bg-white/80 border-slate-200 hover:border-amber-400'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="font-extrabold text-slate-900 text-xs flex items-center gap-1">
                      <FileText className="w-3.5 h-3.5 text-orange-600" />
                      Totalmente em Branco
                    </span>
                    {blankStyle === 'pure_blank' && (
                      <span className="w-2 h-2 rounded-full bg-orange-600" />
                    )}
                  </div>
                  <p className="text-[11px] text-slate-500 leading-tight">
                    Área livre e limpa para carimbos, anotações ou colagens especiais.
                  </p>
                </div>
                <div className="mt-2.5 font-mono text-[9px] bg-slate-50 p-1.5 rounded border border-dashed border-slate-300 text-slate-400 text-center">
                  [ Área 101,6 x 25,4 mm ]
                </div>
              </button>

              {/* Style 3: Sequential Provisional */}
              <button
                type="button"
                onClick={() => setBlankStyle('sequential')}
                className={`p-3 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
                  blankStyle === 'sequential'
                    ? 'bg-white border-orange-500 ring-2 ring-orange-500/20 shadow-xs'
                    : 'bg-white/80 border-slate-200 hover:border-amber-400'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="font-extrabold text-slate-900 text-xs flex items-center gap-1">
                      <Tag className="w-3.5 h-3.5 text-orange-600" />
                      Sequencial Provisório
                    </span>
                    {blankStyle === 'sequential' && (
                      <span className="w-2 h-2 rounded-full bg-orange-600" />
                    )}
                  </div>
                  <p className="text-[11px] text-slate-500 leading-tight">
                    Numeração sequencial e QR Code com layout tradicional Pimaco.
                  </p>
                </div>
                <div className="mt-2.5 font-mono text-[9px] bg-slate-50 p-1.5 rounded border border-slate-200 text-slate-800 font-bold truncate">
                  {blankSequentialPrefix}0001 ...
                </div>
              </button>

              {/* Style 4: Big Numbers (85pt High Visibility) */}
              <button
                type="button"
                onClick={() => {
                  setBlankStyle('big_numbers');
                  if (patrimonioFontSize < 38) setPatrimonioFontSize(85);
                }}
                className={`p-3 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
                  blankStyle === 'big_numbers'
                    ? 'bg-amber-50 border-orange-500 ring-2 ring-orange-500/30 shadow-xs'
                    : 'bg-white/80 border-slate-200 hover:border-amber-400'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="font-extrabold text-slate-900 text-xs flex items-center gap-1">
                      <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                      🔥 Números Grandes (85pt)
                    </span>
                    {blankStyle === 'big_numbers' && (
                      <span className="w-2 h-2 rounded-full bg-orange-600" />
                    )}
                  </div>
                  <p className="text-[11px] text-slate-500 leading-tight">
                    Dígitos gigantes (até 85pt) com máxima visibilidade e legibilidade à distância.
                  </p>
                </div>
                <div className="mt-2.5 font-mono text-[10px] bg-slate-900 text-amber-400 p-1.5 rounded border border-slate-800 font-black text-center truncate">
                  FONTE: {patrimonioFontSize}pt
                </div>
              </button>

              {/* Style 5: Custom Header / Dept */}
              <button
                type="button"
                onClick={() => setBlankStyle('custom_text')}
                className={`p-3 rounded-xl border text-left transition-all cursor-pointer flex flex-col justify-between ${
                  blankStyle === 'custom_text'
                    ? 'bg-white border-orange-500 ring-2 ring-orange-500/20 shadow-xs'
                    : 'bg-white/80 border-slate-200 hover:border-amber-400'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="font-extrabold text-slate-900 text-xs flex items-center gap-1">
                      <Building className="w-3.5 h-3.5 text-orange-600" />
                      Personalizado / Setor
                    </span>
                    {blankStyle === 'custom_text' && (
                      <span className="w-2 h-2 rounded-full bg-orange-600" />
                    )}
                  </div>
                  <p className="text-[11px] text-slate-500 leading-tight">
                    Gerência, descrição padronizada e localidade customizadas.
                  </p>
                </div>
                <div className="mt-2.5 font-mono text-[9px] bg-slate-50 p-1.5 rounded border border-slate-200 text-slate-700 truncate">
                  {blankCustomDept || 'COMLURB'} • {blankCustomLoc || 'LOC'}
                </div>
              </button>
            </div>

            {/* Granular Options for Blank Styles */}
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 pt-2 text-xs">
              <div>
                <label className="block text-slate-700 font-bold mb-1">
                  Quantidade Total de Etiquetas:
                </label>
                <input
                  type="number"
                  min="1"
                  max="500"
                  value={blankQuantity}
                  onChange={(e) => setBlankQuantity(Math.max(1, Number(e.target.value)))}
                  className="w-full px-3 py-1.5 bg-white border border-slate-300 rounded-xl font-mono font-bold text-slate-900"
                />
              </div>

              {(blankStyle === 'sequential' || blankStyle === 'custom_text' || blankStyle === 'big_numbers') && (
                <>
                  <div>
                    <label className="block text-slate-700 font-bold mb-1">
                      Prefixo do Patrimônio:
                    </label>
                    <input
                      type="text"
                      value={blankSequentialPrefix}
                      onChange={(e) => setBlankSequentialPrefix(e.target.value.toUpperCase())}
                      placeholder="Ex: PROV-, VIST-, TGC-"
                      className="w-full px-3 py-1.5 bg-white border border-slate-300 rounded-xl font-mono font-bold text-slate-900 uppercase"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-700 font-bold mb-1">
                      Número Inicial:
                    </label>
                    <input
                      type="number"
                      min="1"
                      value={blankSequentialStart}
                      onChange={(e) => setBlankSequentialStart(Math.max(1, Number(e.target.value)))}
                      className="w-full px-3 py-1.5 bg-white border border-slate-300 rounded-xl font-mono font-bold text-slate-900"
                    />
                  </div>
                </>
              )}

              {(blankStyle === 'custom_text' || blankStyle === 'big_numbers') && (
                <>
                  <div>
                    <label className="block text-slate-700 font-bold mb-1">
                      Gerência / Setor Impresso:
                    </label>
                    <input
                      type="text"
                      value={blankCustomDept}
                      onChange={(e) => setBlankCustomDept(e.target.value)}
                      placeholder="Ex: TGC, DLOG, COMLURB"
                      className="w-full px-3 py-1.5 bg-white border border-slate-300 rounded-xl font-bold text-slate-900"
                    />
                  </div>
                </>
              )}
            </div>
          </div>
        )}

        {/* Section: Sheet Start Position & Layout Options */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 pt-4 border-t border-slate-100">
          {/* Start Position Grid on Sheet (Pimaco 2x10) */}
          <div className="lg:col-span-5 bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-extrabold text-slate-900 text-xs uppercase tracking-wider flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-orange-600" />
                  Aproveitamento de Folha Usada
                </h3>
                <p className="text-[11px] text-slate-500 font-medium">
                  Clique na primeira posição vazia da folha:
                </p>
              </div>
              <span className="font-mono font-black text-xs bg-slate-900 text-amber-400 px-2.5 py-1 rounded-lg">
                Início: #{startPosition}
              </span>
            </div>

            {/* 20 label visual selector */}
            <div className="grid grid-cols-2 gap-1.5 max-w-xs mx-auto p-2 bg-white rounded-xl border border-slate-300 shadow-2xs">
              {Array.from({ length: 20 }, (_, i) => i + 1).map((pos) => {
                const isSelected = startPosition === pos;
                const isSkipped = pos < startPosition;

                return (
                  <button
                    key={pos}
                    type="button"
                    onClick={() => setStartPosition(pos)}
                    className={`h-7 rounded text-[11px] font-bold font-mono transition-all cursor-pointer flex items-center justify-between px-2 border ${
                      isSelected
                        ? 'bg-amber-500 text-slate-950 border-amber-500 shadow-xs ring-2 ring-amber-300 font-black'
                        : isSkipped
                        ? 'bg-slate-100 text-slate-400 border-dashed border-slate-300 line-through'
                        : 'bg-white text-slate-700 border-slate-200 hover:border-amber-400 hover:bg-amber-50/50'
                    }`}
                    title={`Começar impressão na etiqueta #${pos}`}
                  >
                    <span>#{pos.toString().padStart(2, '0')}</span>
                    {isSelected && <span className="text-[9px] uppercase font-sans font-black">Início</span>}
                    {isSkipped && <span className="text-[9px] uppercase font-sans text-slate-400">Pular</span>}
                  </button>
                );
              })}
            </div>

            <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1">
              <span>{startPosition > 1 ? `${startPosition - 1} etiqueta(s) puladas` : 'Começando na primeira etiqueta'}</span>
              {startPosition > 1 && (
                <button
                  type="button"
                  onClick={() => setStartPosition(1)}
                  className="text-amber-700 hover:text-amber-900 font-bold underline cursor-pointer"
                >
                  Reiniciar no #1
                </button>
              )}
            </div>
          </div>

          {/* Details & Checkbox Options */}
          <div className="lg:col-span-7 space-y-4">
            <h3 className="font-extrabold text-slate-900 text-xs uppercase tracking-wider flex items-center gap-1.5">
              <Settings2 className="w-4 h-4 text-orange-600" />
              Opções de Exibição na Etiqueta
            </h3>

            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2.5 text-xs">
              <label className="flex items-center gap-2 p-2.5 bg-slate-50 border border-slate-200 rounded-xl cursor-pointer hover:bg-slate-100 transition-colors">
                <input
                  type="checkbox"
                  checked={showHeader}
                  onChange={(e) => setShowHeader(e.target.checked)}
                  className="rounded text-orange-600 focus:ring-orange-500"
                />
                <span className="font-bold text-slate-800">Cabeçalho (Orgão)</span>
              </label>

              <label className="flex items-center gap-2 p-2.5 bg-slate-50 border border-slate-200 rounded-xl cursor-pointer hover:bg-slate-100 transition-colors">
                <input
                  type="checkbox"
                  checked={showSubHeader}
                  onChange={(e) => setShowSubHeader(e.target.checked)}
                  className="rounded text-orange-600 focus:ring-orange-500"
                />
                <span className="font-bold text-slate-800">Gerência / Setor</span>
              </label>

              <label className="flex items-center gap-2 p-2.5 bg-slate-50 border border-slate-200 rounded-xl cursor-pointer hover:bg-slate-100 transition-colors">
                <input
                  type="checkbox"
                  checked={showFooter}
                  onChange={(e) => setShowFooter(e.target.checked)}
                  className="rounded text-orange-600 focus:ring-orange-500"
                />
                <span className="font-bold text-slate-800">Descrição / Rodapé</span>
              </label>

              <label className="flex items-center gap-2 p-2.5 bg-slate-50 border border-slate-200 rounded-xl cursor-pointer hover:bg-slate-100 transition-colors">
                <input
                  type="checkbox"
                  checked={showLoc}
                  onChange={(e) => setShowLoc(e.target.checked)}
                  className="rounded text-orange-600 focus:ring-orange-500"
                />
                <span className="font-bold text-slate-800">Localidade / Sala</span>
              </label>

              <label className="flex items-center gap-2 p-2.5 bg-slate-50 border border-slate-200 rounded-xl cursor-pointer hover:bg-slate-100 transition-colors">
                <input
                  type="checkbox"
                  checked={showPatrTag}
                  onChange={(e) => setShowPatrTag(e.target.checked)}
                  className="rounded text-orange-600 focus:ring-orange-500"
                />
                <span className="font-bold text-slate-800">Prefixo "PATR:"</span>
              </label>

              <label className="flex items-center gap-2 p-2.5 bg-slate-50 border border-slate-200 rounded-xl cursor-pointer hover:bg-slate-100 transition-colors">
                <input
                  type="checkbox"
                  checked={barcodeType !== 'none'}
                  onChange={(e) => setBarcodeType(e.target.checked ? 'qrcode' : 'none')}
                  className="rounded text-orange-600 focus:ring-orange-500"
                />
                <span className="font-bold text-slate-800">Exibir QR Code</span>
              </label>

              <label className="flex items-center gap-2 p-2.5 bg-slate-50 border border-slate-200 rounded-xl cursor-pointer hover:bg-slate-100 transition-colors">
                <input
                  type="checkbox"
                  checked={showBorderGuide}
                  onChange={(e) => setShowBorderGuide(e.target.checked)}
                  className="rounded text-orange-600 focus:ring-orange-500"
                />
                <span className="font-bold text-slate-800">Borda Guia (Corte)</span>
              </label>

              <label className="flex items-center gap-2 p-2.5 bg-slate-50 border border-slate-200 rounded-xl cursor-pointer hover:bg-slate-100 transition-colors">
                <input
                  type="checkbox"
                  checked={paperFormat === 'letter'}
                  onChange={(e) => setPaperFormat(e.target.checked ? 'letter' : 'a4')}
                  className="rounded text-orange-600 focus:ring-orange-500"
                />
                <span className="font-bold text-slate-800">Formato Carta</span>
              </label>
            </div>

            {/* Print Instruction Callout */}
            <div className="bg-slate-900 text-slate-200 rounded-xl p-3.5 text-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
              <div className="flex items-center gap-2.5">
                <span className="px-2 py-0.5 bg-amber-500 text-slate-950 font-black text-[10px] rounded uppercase">
                  Regra de Ouro
                </span>
                <span className="text-slate-300 text-[11px]">
                  No diálogo do navegador: <strong>Margens: Nenhuma (0)</strong> e <strong>Escala: 100% (Padrão)</strong>.
                </span>
              </div>
              <div className="font-mono text-[11px] text-amber-400 font-bold shrink-0">
                Pimaco 6181 / 6281
              </div>
            </div>
          </div>
        </div>

        {/* Custom manual list selector if filterSource === 'custom' */}
        {filterSource === 'custom' && (
          <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-bold text-slate-800 text-xs">
                Selecione os bens para compor a folha de etiquetas ({selectedForPrint.size} selecionados):
              </span>
              <label className="flex items-center gap-1.5 text-xs font-bold text-slate-700 cursor-pointer">
                <input
                  type="checkbox"
                  checked={selectedForPrint.size === assets.length}
                  onChange={(e) => handleSelectAllCurrent(e.target.checked)}
                  className="rounded text-orange-600"
                />
                <span>Selecionar Todos</span>
              </label>
            </div>

            <div className="max-h-48 overflow-y-auto grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2 p-1 bg-white rounded-lg border border-slate-200">
              {assets.map((asset) => {
                const isChecked = selectedForPrint.has(asset.id);
                return (
                  <label
                    key={asset.id}
                    className={`flex items-center gap-2 p-2 rounded border text-xs cursor-pointer transition-colors ${
                      isChecked ? 'bg-amber-50/60 border-amber-300' : 'hover:bg-slate-50 border-slate-200'
                    }`}
                  >
                    <input
                      type="checkbox"
                      checked={isChecked}
                      onChange={() => handleToggleSelectAsset(asset.id)}
                      className="rounded text-orange-600"
                    />
                    <div className="min-w-0 flex-1">
                      <div className="font-mono font-bold text-slate-900 truncate">
                        {asset.patrimonio} - <span className="font-sans font-medium text-slate-700">{asset.descricao}</span>
                      </div>
                      <div className="text-[10px] text-slate-500 truncate">{asset.unidade}</div>
                    </div>
                  </label>
                );
              })}
            </div>
          </div>
        )}
      </div>

      {/* Screen Preview Section (Interactive Sheet Visualizer) */}
      <div className="space-y-4 no-print">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <h3 className="font-extrabold text-slate-900 text-sm tracking-tight">
              Pré-Visualização em Escala Real (Folha Pimaco 6181 / 6281)
            </h3>
            <span className="text-xs bg-slate-200 text-slate-700 px-2 py-0.5 rounded-md font-bold">
              Folha {previewPage} de {totalSheets}
            </span>
          </div>

          {/* Pagination Navigation */}
          {totalSheets > 1 && (
            <div className="flex items-center gap-1 bg-white p-1 rounded-xl border border-slate-200 shadow-2xs text-xs">
              <button
                type="button"
                disabled={previewPage <= 1}
                onClick={() => setPreviewPage((p) => Math.max(1, p - 1))}
                className="p-1 rounded-lg hover:bg-slate-100 disabled:opacity-30 cursor-pointer"
                title="Página Anterior"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <span className="px-2 font-mono font-bold text-slate-800">
                {previewPage} / {totalSheets}
              </span>
              <button
                type="button"
                disabled={previewPage >= totalSheets}
                onClick={() => setPreviewPage((p) => Math.min(totalSheets, p + 1))}
                className="p-1 rounded-lg hover:bg-slate-100 disabled:opacity-30 cursor-pointer"
                title="Próxima Página"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>

        {/* Visual Simulated Pimaco Sheet in Viewport */}
        <div className="flex justify-center overflow-x-auto p-4 sm:p-8 bg-slate-800 rounded-2xl border border-slate-700 shadow-inner">
          <div
            className="bg-white shadow-2xl rounded-sm transition-all relative"
            style={{
              width: paperFormat === 'letter' ? '215.9mm' : '210.0mm',
              minHeight: paperFormat === 'letter' ? '279.4mm' : '297.0mm',
              paddingTop: `${calculatedTopMargin}mm`,
              paddingLeft: `${calculatedLeftMargin}mm`,
              paddingRight: '2.0mm',
              paddingBottom: '0mm',
              boxSizing: 'border-box',
            }}
          >
            {/* Sheet Grid: 2 columns x 10 rows with exact rowHeightMm */}
            <div
              className="grid grid-cols-2"
              style={{
                columnGap: `${colGapMm}mm`,
                rowGap: '0.0mm',
                gridTemplateRows: `repeat(10, ${rowHeightMm}mm)`,
                width: `${colWidthMm * 2 + colGapMm}mm`,
              }}
            >
              {(pages[previewPage - 1] || []).map((asset, labelIndex) => {
                const labelNumberOnSheet = labelIndex + 1;
                const rowNum = Math.floor(labelIndex / 2) + 1;
                const globalSlotIndex = (previewPage - 1) * 20 + labelIndex;
                const isOverridden = asset && labelOverrides[asset.id];
                const fontSizeToUse = asset?.customFontSize || patrimonioFontSize;
                const headerToUse = asset?.customHeader !== undefined ? asset.customHeader : (customHeader || 'PREFEITURA DO RIO • COMLURB');
                const subHeaderToUse = asset?.customSubHeader !== undefined ? asset.customSubHeader : (customSubHeader || asset?.unidade || 'PATRIMÔNIO');
                const footerToUse = asset?.customFooter !== undefined ? asset.customFooter : (customFooter || asset?.descricao || 'PATRIMÔNIO PÚBLICO');
                const locToUse = asset?.customLoc !== undefined ? asset.customLoc : (customLoc || (asset?.localidade ? `LOC ${asset.localidade}` : 'PIMACO 6181'));
                const isQrHiddenForAsset = barcodeType === 'none' || asset?.hideQr === true;
                const isHeaderHidden = !showHeader || asset?.hideHeader === true;
                const isSubHeaderHidden = showSubHeader === false || asset?.hideSubHeader === true;
                const isFooterHidden = showFooter === false || asset?.hideFooter === true;
                const isLocHidden = showLoc === false || asset?.hideLoc === true;
                const isPatrTagHidden = showPatrTag === false || asset?.hidePatrTag === true;
                const hasTopBar = !isHeaderHidden || !isSubHeaderHidden;
                const hasBottomBar = !isFooterHidden || !isLocHidden;

                return (
                  <div
                    key={labelIndex}
                    style={{
                      height: `${rowHeightMm}mm`,
                      width: `${colWidthMm}mm`,
                    }}
                    className="box-border relative overflow-hidden bg-white group/card"
                  >
                    {asset ? (
                      <div
                        className={`w-full h-full p-[1.5mm_2.0mm] box-border text-black relative select-none ${
                          asset.blankStyle === 'write_lines'
                            ? 'flex flex-col justify-between'
                            : asset.blankStyle === 'pure_blank'
                            ? 'flex items-center justify-center'
                            : layoutStyle === 'big_numbers' || asset.blankStyle === 'big_numbers'
                            ? 'flex flex-col justify-between overflow-hidden'
                            : layoutStyle === 'standard_pimaco'
                            ? isQrHiddenForAsset
                              ? 'grid grid-cols-[auto_1fr] items-center gap-[3mm]'
                              : 'grid grid-cols-[28mm_1fr_20mm] items-center gap-[2mm]'
                            : 'flex flex-col justify-between'
                        } ${showBorderGuide ? 'border-[0.75px] border-black rounded-[4px]' : ''} ${
                          isOverridden ? 'ring-1 ring-amber-500/50 bg-amber-50/15' : ''
                        }`}
                      >
                        {/* Hover Quick Edit Action Floating Pill */}
                        <div className="absolute top-1 right-1 z-20 opacity-0 group-hover/card:opacity-100 transition-opacity flex items-center gap-1 bg-slate-900/90 backdrop-blur-xs p-0.5 rounded-md shadow-md border border-slate-700">
                          <button
                            type="button"
                            onClick={() => setEditingSlotAsset({ index: globalSlotIndex, asset })}
                            className="px-1.5 py-0.5 bg-amber-500 hover:bg-amber-400 text-slate-950 rounded text-[9px] font-black flex items-center gap-0.5 cursor-pointer shadow-2xs"
                            title="Editar esta etiqueta (Número, Textos, QR Code)"
                          >
                            <Edit3 className="w-2.5 h-2.5" />
                            <span>Editar</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDuplicateAsset(globalSlotIndex)}
                            className="p-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-[9px] cursor-pointer"
                            title="Duplicar etiqueta para o próximo espaço livre"
                          >
                            <Copy className="w-2.5 h-2.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => handleClearSlotAsset(globalSlotIndex)}
                            className="p-1 bg-slate-800 hover:bg-red-700 text-slate-300 hover:text-white rounded text-[9px] cursor-pointer"
                            title="Limpar / Pular esta posição"
                          >
                            <Trash2 className="w-2.5 h-2.5" />
                          </button>
                        </div>

                        {/* Overridden visual badge indicator */}
                        {isOverridden && (
                          <div className="absolute top-0.5 left-0.5 z-10 w-1.5 h-1.5 rounded-full bg-amber-500 ring-1 ring-white" title="Etiqueta editada manualmente" />
                        )}

                        {asset.blankStyle === 'write_lines' ? (
                          <div className="w-full h-full flex flex-col justify-between py-0.5 font-sans">
                            <div className="flex items-center justify-between border-b border-black pb-0.5 text-[6.5pt] font-black uppercase">
                              <span>PREFEITURA DO RIO • COMLURB</span>
                              <span>VISTORIA IN LOCO</span>
                            </div>
                            <div className="space-y-1 my-auto text-[6pt] font-bold text-slate-800">
                              <div className="flex items-baseline gap-1">
                                <span className="font-black text-black">PATR:</span>
                                <span className="flex-1 border-b border-dotted border-black h-3"></span>
                                <span className="font-black text-black ml-1">LOC:</span>
                                <span className="w-16 border-b border-dotted border-black h-3"></span>
                              </div>
                              <div className="flex items-baseline gap-1">
                                <span className="font-black text-black">DESC:</span>
                                <span className="flex-1 border-b border-dotted border-black h-3"></span>
                              </div>
                              <div className="flex items-baseline gap-1">
                                <span className="font-black text-black">MOD/SÉRIE:</span>
                                <span className="flex-1 border-b border-dotted border-black h-3"></span>
                                <span className="font-black text-black ml-1">VISTO:</span>
                                <span className="w-12 border-b border-dotted border-black h-3"></span>
                              </div>
                            </div>
                            <div className="border-t border-black pt-0.5 flex justify-between text-[5.5pt] font-black uppercase">
                              <span>COMLURB • CADASTRO PATRIMONIAL</span>
                              <span>PIMACO 6181</span>
                            </div>
                          </div>
                        ) : asset.blankStyle === 'pure_blank' ? (
                          <div className="w-full h-full flex items-center justify-center border border-dashed border-slate-200 text-slate-300 text-[8pt] font-mono">
                            [ ETIQUETA VIRGEM 101,6 x 25,4 mm ]
                          </div>
                        ) : layoutStyle === 'big_numbers' || asset.blankStyle === 'big_numbers' ? (
                          <div className="w-full h-full flex flex-col justify-between overflow-hidden">
                            {/* Header (Editable directly) */}
                            {hasTopBar && (
                              <div className="flex items-center justify-between border-b border-black pb-0.5 leading-none">
                                {!isHeaderHidden && (
                                  isDirectEditMode ? (
                                    <input
                                      type="text"
                                      value={headerToUse}
                                      onChange={(e) => handleUpdateAssetField(asset.id, 'customHeader', e.target.value)}
                                      className="text-[6.5pt] font-black uppercase text-black bg-amber-100/60 rounded px-0.5 border-none outline-hidden w-[60%]"
                                    />
                                  ) : (
                                    <span
                                      onClick={() => setEditingSlotAsset({ index: globalSlotIndex, asset })}
                                      className="text-[6.5pt] font-black uppercase text-black cursor-pointer hover:bg-amber-100/50 rounded px-0.5"
                                      title="Clique para editar"
                                    >
                                      {headerToUse}
                                    </span>
                                  )
                                )}

                                {!isSubHeaderHidden && (
                                  isDirectEditMode ? (
                                    <input
                                      type="text"
                                      value={subHeaderToUse}
                                      onChange={(e) => handleUpdateAssetField(asset.id, 'customSubHeader', e.target.value)}
                                      className="text-[6pt] font-bold text-black uppercase bg-amber-100/60 rounded px-0.5 text-right border-none outline-hidden w-[35%] ml-auto"
                                    />
                                  ) : (
                                    <span
                                      onClick={() => setEditingSlotAsset({ index: globalSlotIndex, asset })}
                                      className="text-[6pt] font-bold text-black uppercase cursor-pointer hover:bg-amber-100/50 rounded px-0.5 ml-auto"
                                      title="Clique para editar"
                                    >
                                      {subHeaderToUse}
                                    </span>
                                  )
                                )}
                              </div>
                            )}

                            {/* Middle: Big Number + QR Code */}
                            <div className={`flex items-center ${isQrHiddenForAsset ? (numberAlignment === 'center' ? 'justify-center' : 'justify-start') : 'justify-between'} gap-1 flex-1 my-auto overflow-hidden w-full`}>
                              <div className={`flex-1 min-w-0 flex items-baseline w-full ${numberAlignment === 'center' ? 'justify-center text-center' : 'justify-start text-left'}`}>
                                {!isPatrTagHidden && (
                                  <span className="font-bold text-[8pt] text-black uppercase mr-1.5 shrink-0">
                                    PATR:
                                  </span>
                                )}
                                {isDirectEditMode ? (
                                  <input
                                    type="text"
                                    value={asset.patrimonio || ''}
                                    onChange={(e) => handleUpdateAssetField(asset.id, 'patrimonio', e.target.value.toUpperCase())}
                                    className={`font-black font-mono tracking-tighter text-black bg-amber-100/60 rounded px-1 border-none outline-hidden w-full leading-none ${numberAlignment === 'center' ? 'text-center' : 'text-left'}`}
                                    style={{
                                      fontSize: `${Math.min(fontSizeToUse, 85)}pt`,
                                      lineHeight: 0.9,
                                    }}
                                  />
                                ) : (
                                  <span
                                    onClick={() => setEditingSlotAsset({ index: globalSlotIndex, asset })}
                                    className={`font-black font-mono tracking-tighter text-black leading-none truncate cursor-pointer hover:bg-amber-100/50 rounded px-0.5 transition-colors w-full block ${numberAlignment === 'center' ? 'text-center' : 'text-left'}`}
                                    style={{
                                      fontSize: `${Math.min(fontSizeToUse, 85)}pt`,
                                      maxHeight: '16mm',
                                      lineHeight: 0.9,
                                    }}
                                    title="Clique para editar número do patrimônio"
                                  >
                                    {asset.patrimonio || 'PROV-0001'}
                                  </span>
                                )}
                              </div>

                              {!isQrHiddenForAsset && (
                                <div className="shrink-0 flex items-center justify-center pl-1 border-l border-slate-200">
                                  <PimacoBarcode
                                    value={asset.patrimonio || '000000'}
                                    asset={asset}
                                    inspection={inspections?.[`${asset.id}-${selectedYear}`]}
                                    type="qrcode"
                                    height={22}
                                    width={1.1}
                                  />
                                </div>
                              )}
                            </div>

                            {/* Footer (Editable directly) */}
                            {hasBottomBar && (
                              <div className="border-t border-black pt-0.5 flex items-center justify-between text-[6pt] font-black uppercase text-black leading-none">
                                {!isFooterHidden && (
                                  isDirectEditMode ? (
                                    <input
                                      type="text"
                                      value={footerToUse}
                                      onChange={(e) => handleUpdateAssetField(asset.id, 'customFooter', e.target.value)}
                                      className="text-[6pt] font-black uppercase text-black bg-amber-100/60 rounded px-0.5 border-none outline-hidden w-[60%]"
                                    />
                                  ) : (
                                    <span
                                      onClick={() => setEditingSlotAsset({ index: globalSlotIndex, asset })}
                                      className="truncate max-w-[70%] cursor-pointer hover:bg-amber-100/50 rounded px-0.5"
                                      title="Clique para editar descrição"
                                    >
                                      {footerToUse}
                                    </span>
                                  )
                                )}

                                {!isLocHidden && (
                                  isDirectEditMode ? (
                                    <input
                                      type="text"
                                      value={locToUse}
                                      onChange={(e) => handleUpdateAssetField(asset.id, 'customLoc', e.target.value)}
                                      className="text-[6pt] font-mono font-bold text-black bg-amber-100/60 rounded px-0.5 text-right border-none outline-hidden w-[35%] ml-auto"
                                    />
                                  ) : (
                                    <span
                                      onClick={() => setEditingSlotAsset({ index: globalSlotIndex, asset })}
                                      className="font-mono font-bold cursor-pointer hover:bg-amber-100/50 rounded px-0.5 ml-auto"
                                      title="Clique para editar localidade"
                                    >
                                      {locToUse}
                                    </span>
                                  )
                                )}
                              </div>
                            )}
                          </div>
                        ) : layoutStyle === 'standard_pimaco' ? (
                          <>
                            {/* Left: PATR */}
                            <div className="flex items-baseline gap-0.5 whitespace-nowrap">
                              {!isPatrTagHidden && <span className="text-[7.5pt] font-black text-black">PATR:</span>}
                              {isDirectEditMode ? (
                                <input
                                  type="text"
                                  value={asset.patrimonio || ''}
                                  onChange={(e) => handleUpdateAssetField(asset.id, 'patrimonio', e.target.value.toUpperCase())}
                                  className="font-black tracking-tight text-black leading-none ml-1 bg-amber-100/60 rounded px-0.5 w-20"
                                  style={{ fontSize: `${fontSizeToUse}pt` }}
                                />
                              ) : (
                                <span
                                  onClick={() => setEditingSlotAsset({ index: globalSlotIndex, asset })}
                                  className="font-black tracking-tight text-black leading-none ml-1 cursor-pointer hover:bg-amber-100/50 rounded px-0.5"
                                  style={{
                                    fontSize: `${fontSizeToUse}pt`,
                                  }}
                                  title="Clique para editar"
                                >
                                  {asset.patrimonio}
                                </span>
                              )}
                            </div>

                            {/* Middle: Desc + Comp + Loc */}
                            <div className="flex flex-col justify-center min-w-0 overflow-hidden leading-tight">
                              {!isFooterHidden && (
                                <div
                                  onClick={() => setEditingSlotAsset({ index: globalSlotIndex, asset })}
                                  className="font-black text-[7.5pt] uppercase text-black truncate cursor-pointer hover:bg-amber-100/50 rounded px-0.5"
                                >
                                  {footerToUse}
                                </div>
                              )}
                              <div className="font-mono text-[6.5pt] font-bold text-black truncate">
                                {asset.complemento || '—'}
                              </div>
                              {!isLocHidden && (
                                <div className="text-[6pt] font-extrabold text-black truncate mt-0.5">
                                  {!isSubHeaderHidden && (subHeaderToUse || asset.unidade)} {locToUse ? `(${locToUse})` : ''}
                                  {showCostCenter && asset.centroCusto && ` • CC ${asset.centroCusto}`}
                                </div>
                              )}
                            </div>

                            {/* Right: QR Code */}
                            {!isQrHiddenForAsset && (
                              <div className="flex items-center justify-center">
                                <PimacoBarcode
                                  value={asset.patrimonio}
                                  asset={asset}
                                  inspection={inspections?.[`${asset.id}-${selectedYear}`]}
                                  type="qrcode"
                                  height={20}
                                  width={1.1}
                                />
                              </div>
                            )}
                          </>
                        ) : (
                          <>
                            {/* Header */}
                            {showHeader && (
                              <div className="flex items-center justify-between border-b border-black pb-0.5 leading-none">
                                <span className="text-[7.5px] font-black uppercase text-black">
                                  {headerToUse}
                                </span>
                                <span className="text-[6.5px] font-black uppercase text-black">
                                  INVENTÁRIO
                                </span>
                              </div>
                            )}

                            {/* Body */}
                            <div className="flex items-center justify-between gap-1.5 flex-1 py-0.5 overflow-hidden">
                              <div className="flex-1 min-w-0 flex flex-col justify-center">
                                <div className="flex items-baseline gap-1">
                                  <span className="text-[7.5px] font-bold text-black uppercase">PATR:</span>
                                  <span
                                    onClick={() => setEditingSlotAsset({ index: globalSlotIndex, asset })}
                                    className="font-mono font-black text-black tracking-tight leading-none cursor-pointer hover:bg-amber-100/50 rounded px-0.5"
                                    style={{
                                      fontSize: `${fontSizeToUse}pt`,
                                    }}
                                  >
                                    {asset.patrimonio}
                                  </span>
                                </div>
                                <div className="font-bold text-[8px] uppercase text-black truncate leading-tight mt-0.5">
                                  {asset.descricao}
                                </div>
                                <div className="font-mono text-[7px] text-black truncate leading-none">
                                  {asset.complemento}
                                </div>
                              </div>
                              {!isQrHiddenForAsset && (
                                <div className="shrink-0 flex items-center justify-center pl-1 border-l border-slate-200">
                                  <PimacoBarcode
                                    value={asset.patrimonio}
                                    asset={asset}
                                    inspection={inspections?.[`${asset.id}-${selectedYear}`]}
                                    type={barcodeType === 'none' ? 'barcode' : barcodeType}
                                    height={22}
                                    width={1.1}
                                  />
                                </div>
                              )}
                            </div>

                            {/* Footer */}
                            {showWarningFooter && (
                              <div className="border-t border-black pt-0.5 flex items-center justify-between text-[6.5px] font-bold uppercase tracking-wider leading-none text-black">
                                <span>{footerToUse}</span>
                                <span>#{(previewPage - 1) * 20 + labelNumberOnSheet}</span>
                              </div>
                            )}
                          </>
                        )}
                      </div>
                    ) : (
                      <div
                        onClick={() => handleAddNewCustomRow()}
                        className="w-full h-full flex flex-col items-center justify-center text-slate-300 font-mono text-[9px] bg-slate-50/50 border border-dashed border-slate-200 hover:border-amber-400 hover:bg-amber-50/40 hover:text-slate-600 transition-colors cursor-pointer"
                        title="Clique para adicionar uma etiqueta nesta posição"
                      >
                        <span>[ Etiqueta #{labelNumberOnSheet} Pulada ]</span>
                        <span className="text-[8px] text-slate-400 flex items-center gap-1 mt-0.5">
                          <Plus className="w-2.5 h-2.5 text-amber-500" /> Clique p/ Preencher
                        </span>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {/* Actual Print Output Sheets (rendered specifically for @media print) */}
      <div className="pimaco-print-wrapper print-only-container">
        {pages.map((pageAssets, pageIndex) => (
          <div
            key={pageIndex}
            className="pimaco-print-sheet"
            style={{
              width: paperFormat === 'letter' ? '215.9mm' : '210.0mm',
              height: paperFormat === 'letter' ? '279.4mm' : '297.0mm',
              minHeight: paperFormat === 'letter' ? '279.4mm' : '297.0mm',
              maxHeight: paperFormat === 'letter' ? '279.4mm' : '297.0mm',
              paddingTop: `${calculatedTopMargin}mm`,
              paddingLeft: `${calculatedLeftMargin}mm`,
              paddingRight: '2.0mm',
              paddingBottom: '0mm',
              boxSizing: 'border-box',
              pageBreakInside: 'avoid',
              pageBreakAfter: 'always',
              breakAfter: 'page',
              background: '#ffffff',
            }}
          >
            <div
              className="pimaco-grid-container"
              style={{
                display: 'grid',
                gridTemplateColumns: `${colWidthMm}mm ${colWidthMm}mm`,
                gridTemplateRows: `repeat(10, ${rowHeightMm}mm)`,
                columnGap: `${colGapMm}mm`,
                rowGap: '0.0mm',
                width: `${colWidthMm * 2 + colGapMm}mm`,
                height: `${totalGridHeight}mm`,
                boxSizing: 'border-box',
              }}
            >
              {pageAssets.map((asset, labelIndex) => {
                const fontSizeToUse = asset?.customFontSize || patrimonioFontSize;
                const headerToUse = asset?.customHeader || customHeader || 'PREFEITURA DO RIO • COMLURB';
                const subHeaderToUse = asset?.customSubHeader || customSubHeader || asset?.unidade || 'PATRIMÔNIO';
                const footerToUse = asset?.customFooter || customFooter || asset?.descricao || 'PATRIMÔNIO PÚBLICO';
                const locToUse = asset?.customLoc || customLoc || (asset?.localidade ? `LOC ${asset.localidade}` : 'PIMACO 6181');

                return (
                  <div
                    key={labelIndex}
                    className="pimaco-label-cell"
                    style={{
                      width: `${colWidthMm}mm`,
                      height: `${rowHeightMm}mm`,
                      maxHeight: `${rowHeightMm}mm`,
                      minHeight: `${rowHeightMm}mm`,
                      maxWidth: `${colWidthMm}mm`,
                      boxSizing: 'border-box',
                      overflow: 'hidden',
                      backgroundColor: '#ffffff',
                      padding: 0,
                      margin: 0,
                    }}
                  >
                    {asset ? (
                      <div
                        style={{
                          width: '100%',
                          height: '100%',
                          padding: '1.5mm 2.0mm',
                          boxSizing: 'border-box',
                          color: '#000000',
                          fontFamily: 'system-ui, -apple-system, sans-serif',
                          display: layoutStyle === 'standard_pimaco' ? 'grid' : 'flex',
                          gridTemplateColumns: layoutStyle === 'standard_pimaco' ? '28mm 1fr 20mm' : undefined,
                          alignItems: 'center',
                          gap: '2mm',
                          flexDirection: layoutStyle === 'standard_pimaco' ? undefined : 'column',
                          justifyContent: layoutStyle === 'standard_pimaco' ? undefined : 'space-between',
                          border: showBorderGuide ? '0.75px solid #000000' : 'none',
                          borderRadius: showBorderGuide ? '4px' : '0px',
                        }}
                      >
                        {layoutStyle === 'big_numbers' || asset.blankStyle === 'big_numbers' || fontSizeToUse >= 22 || (!headerToUse && !subHeaderToUse && !footerToUse && !locToUse) ? (
                          <div style={{ width: '100%', height: '100%', display: 'flex', flexDirection: 'column', justifyContent: 'space-between', overflow: 'hidden' }}>
                            {/* Header */}
                            {(headerToUse || subHeaderToUse) && (
                              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', borderBottom: '0.6px solid #000000', paddingBottom: '0.2mm', lineHeight: 1 }}>
                                <span style={{ fontSize: '6.5pt', fontWeight: 900, textTransform: 'uppercase' }}>
                                  {headerToUse}
                                </span>
                                <span style={{ fontSize: '6pt', fontWeight: 700, textTransform: 'uppercase' }}>
                                  {subHeaderToUse}
                                </span>
                              </div>
                            )}

                            {/* Middle: Big Number + QR Code */}
                            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '2mm', flex: 1, overflow: 'hidden', margin: 'auto 0' }}>
                              <div style={{ flex: 1, minWidth: 0, display: 'flex', alignItems: 'center' }}>
                                {showPatrTag && (
                                  <span style={{ fontSize: `${Math.max(7, Math.min(16, Math.round(fontSizeToUse * 0.28)))}pt`, fontWeight: 900, marginRight: '4px' }}>
                                    PATR:
                                  </span>
                                )}
                                <span
                                  style={{
                                    fontSize: `${Math.min(fontSizeToUse, 85)}pt`,
                                    fontFamily: 'monospace',
                                    fontWeight: 900,
                                    lineHeight: 0.9,
                                    letterSpacing: '-0.5px',
                                    whiteSpace: 'nowrap',
                                    overflow: 'hidden',
                                    textOverflow: 'ellipsis',
                                    display: 'inline-block',
                                    maxHeight: '16mm',
                                  }}
                                >
                                  {asset.patrimonio && !asset.patrimonio.startsWith('___') ? asset.patrimonio : (asset.blankStyle === 'pure_blank' ? '' : 'PROV-0001')}
                                </span>
                              </div>
                              {!asset.hideQr && (
                                <div style={{ flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', paddingLeft: '1mm', borderLeft: '0.5px solid #cccccc' }}>
                                  <PimacoBarcode
                                    value={asset.patrimonio || '000000'}
                                    asset={asset}
                                    inspection={inspections?.[`${asset.id}-${selectedYear}`]}
                                    type="qrcode"
                                    height={22}
                                    width={1.1}
                                  />
                                </div>
                              )}
                            </div>

                            {/* Footer */}
                            {(footerToUse || locToUse) && (
                              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', borderTop: '0.6px solid #000000', paddingTop: '0.2mm', fontSize: '6pt', fontWeight: 900, textTransform: 'uppercase', lineHeight: 1 }}>
                                <span style={{ maxWidth: '70%', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                                  {footerToUse}
                                </span>
                                <span style={{ fontFamily: 'monospace', fontWeight: 700 }}>
                                  {locToUse}
                                </span>
                              </div>
                            )}
                          </div>
                        ) : layoutStyle === 'standard_pimaco' ? (
                          <>
                            {/* Left: PATR */}
                            <div style={{ display: 'flex', alignItems: 'baseline', gap: '2px', whiteSpace: 'nowrap' }}>
                              <span style={{ fontSize: '7.5pt', fontWeight: 900 }}>PATR:</span>
                              <span style={{ fontSize: `${fontSizeToUse}pt`, fontWeight: 900, lineHeight: 1, letterSpacing: '-0.4px', marginLeft: '2px' }}>
                                {asset.patrimonio}
                              </span>
                            </div>

                            {/* Center: Info */}
                            <div style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center', minWidth: 0, overflow: 'hidden', lineHeight: 1.15 }}>
                              <div style={{ fontSize: '7.5pt', fontWeight: 900, textTransform: 'uppercase', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                                {asset.descricao}
                              </div>
                              <div style={{ fontFamily: 'monospace', fontSize: '6.5pt', fontWeight: 700, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                                {asset.complemento || '—'}
                              </div>
                              {showUnit && (
                                <div style={{ fontSize: '6pt', fontWeight: 800, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis', marginTop: '0.2mm' }}>
                                  {asset.unidade} (Loc {asset.localidade})
                                  {showCostCenter && asset.centroCusto && ` • CC ${asset.centroCusto}`}
                                </div>
                              )}
                            </div>

                            {/* Right: QR Code */}
                            {!asset.hideQr && (
                              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                                <PimacoBarcode
                                  value={asset.patrimonio}
                                  asset={asset}
                                  inspection={inspections?.[`${asset.id}-${selectedYear}`]}
                                  type="qrcode"
                                  height={20}
                                  width={1.1}
                                />
                              </div>
                            )}
                          </>
                        ) : (
                          <>
                            {showHeader && (
                              <div
                                style={{
                                  display: 'flex',
                                  justifyContent: 'space-between',
                                  alignItems: 'center',
                                  borderBottom: '0.6px solid #000000',
                                  paddingBottom: '0.2mm',
                                  fontSize: '7pt',
                                  fontWeight: 'bold',
                                  lineHeight: '1',
                                }}
                              >
                                <span style={{ textTransform: 'uppercase' }}>{headerToUse}</span>
                                <span style={{ fontSize: '6pt' }}>INVENTÁRIO</span>
                              </div>
                            )}

                            <div
                              style={{
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'space-between',
                                flex: '1',
                                padding: '0.3mm 0',
                                overflow: 'hidden',
                              }}
                            >
                              <div style={{ flex: '1', minWidth: '0', display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
                                <div style={{ display: 'flex', alignItems: 'baseline', gap: '3px' }}>
                                  <span style={{ fontSize: '7pt', fontWeight: 'bold' }}>PATR:</span>
                                  <span style={{ fontFamily: 'monospace', fontSize: `${fontSizeToUse}pt`, fontWeight: '900', lineHeight: '1' }}>
                                    {asset.patrimonio}
                                  </span>
                                </div>
                                <div style={{ fontSize: '7.5pt', fontWeight: 'bold', textTransform: 'uppercase', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                                  {asset.descricao}
                                </div>
                                <div style={{ fontFamily: 'monospace', fontSize: '6.5pt', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                                  {asset.complemento}
                                </div>
                              </div>
                              {!asset.hideQr && (
                                <div style={{ flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', paddingLeft: '1.5mm' }}>
                                  <PimacoBarcode
                                    value={asset.patrimonio}
                                    asset={asset}
                                    inspection={inspections?.[`${asset.id}-${selectedYear}`]}
                                    type={barcodeType}
                                    height={22}
                                    width={1.1}
                                  />
                                </div>
                              )}
                            </div>

                            {showWarningFooter && (
                              <div
                                style={{
                                  display: 'flex',
                                  justifyContent: 'space-between',
                                  alignItems: 'center',
                                  borderTop: '0.6px solid #000000',
                                  paddingTop: '0.2mm',
                                  fontSize: '6pt',
                                  fontWeight: 'bold',
                                  textTransform: 'uppercase',
                                  lineHeight: '1',
                                }}
                              >
                                <span>{footerToUse}</span>
                                <span>#{pageIndex * 20 + labelIndex + 1}</span>
                              </div>
                            )}
                          </>
                        )}
                      </div>
                    ) : (
                      <div style={{ width: '100%', height: '100%' }} />
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      {/* Modal: Single Slot Quick Edit */}
      {editingSlotAsset && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/75 backdrop-blur-xs p-4 animate-in fade-in duration-150">
          <div className="bg-white w-full max-w-lg rounded-2xl shadow-2xl border border-slate-200 overflow-hidden">
            <div className="p-4.5 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-orange-500 text-white flex items-center justify-center font-bold shadow-xs">
                  <Edit3 className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-extrabold text-slate-900 text-sm flex items-center gap-2">
                    <span>Editar Etiqueta #{editingSlotAsset.index + 1}</span>
                    <span className="font-mono text-xs bg-amber-100 text-amber-900 px-2 py-0.5 rounded-full font-bold">
                      {editingSlotAsset.asset.patrimonio || 'PROV'}
                    </span>
                  </h3>
                  <p className="text-xs text-slate-500">
                    Ajuste os textos, número e tamanho da fonte individualmente desta plaqueta.
                  </p>
                </div>
              </div>
              <button
                onClick={() => setEditingSlotAsset(null)}
                className="w-7 h-7 rounded-lg bg-slate-200 hover:bg-slate-300 text-slate-700 flex items-center justify-center font-bold text-xs cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="p-5 space-y-4 text-xs">
              {/* Patrimônio Number & Font Size */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-bold mb-1">
                    Número do Patrimônio:
                  </label>
                  <input
                    type="text"
                    value={editingSlotAsset.asset.patrimonio || ''}
                    onChange={(e) => {
                      const val = e.target.value.toUpperCase();
                      handleUpdateAssetField(editingSlotAsset.asset.id, 'patrimonio', val);
                      setEditingSlotAsset((prev) =>
                        prev ? { ...prev, asset: { ...prev.asset, patrimonio: val } } : null
                      );
                    }}
                    placeholder="Ex: 003327, PROV-001"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl font-mono font-black text-slate-900 text-sm focus:ring-2 focus:ring-orange-500 uppercase"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-bold mb-1 flex items-center justify-between">
                    <span>Tamanho Fonte:</span>
                    <span className="text-orange-600 font-mono font-black">
                      {editingSlotAsset.asset.customFontSize || patrimonioFontSize}pt
                    </span>
                  </label>
                  <input
                    type="range"
                    min="8"
                    max="85"
                    value={editingSlotAsset.asset.customFontSize || patrimonioFontSize}
                    onChange={(e) => {
                      const val = Number(e.target.value);
                      handleUpdateAssetField(editingSlotAsset.asset.id, 'customFontSize', val);
                      setEditingSlotAsset((prev) =>
                        prev ? { ...prev, asset: { ...prev.asset, customFontSize: val } } : null
                      );
                    }}
                    className="w-full mt-2 accent-orange-500 cursor-pointer"
                  />
                </div>
              </div>

              {/* Header Top-Left & Dept Top-Right */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-slate-700 font-bold">
                      Cabeçalho Superior (Esquerda):
                    </label>
                    <label className="flex items-center gap-1 text-[11px] text-slate-500 font-medium cursor-pointer">
                      <input
                        type="checkbox"
                        checked={!editingSlotAsset.asset.hideHeader}
                        onChange={(e) => {
                          const hide = !e.target.checked;
                          handleUpdateAssetField(editingSlotAsset.asset.id, 'hideHeader', hide);
                          setEditingSlotAsset((prev) =>
                            prev ? { ...prev, asset: { ...prev.asset, hideHeader: hide } } : null
                          );
                        }}
                        className="w-3 h-3 rounded text-orange-600 cursor-pointer"
                      />
                      <span>Exibir</span>
                    </label>
                  </div>
                  <input
                    type="text"
                    disabled={editingSlotAsset.asset.hideHeader}
                    value={editingSlotAsset.asset.customHeader ?? customHeader}
                    onChange={(e) => {
                      const val = e.target.value;
                      handleUpdateAssetField(editingSlotAsset.asset.id, 'customHeader', val);
                      setEditingSlotAsset((prev) =>
                        prev ? { ...prev, asset: { ...prev.asset, customHeader: val } } : null
                      );
                    }}
                    placeholder="Ex: PREFEITURA DO RIO • COMLURB"
                    className={`w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl font-bold text-slate-900 text-xs focus:ring-2 focus:ring-orange-500 ${editingSlotAsset.asset.hideHeader ? 'opacity-40 cursor-not-allowed' : ''}`}
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-slate-700 font-bold">
                      Gerência / Setor (Direita):
                    </label>
                    <label className="flex items-center gap-1 text-[11px] text-slate-500 font-medium cursor-pointer">
                      <input
                        type="checkbox"
                        checked={!editingSlotAsset.asset.hideSubHeader}
                        onChange={(e) => {
                          const hide = !e.target.checked;
                          handleUpdateAssetField(editingSlotAsset.asset.id, 'hideSubHeader', hide);
                          setEditingSlotAsset((prev) =>
                            prev ? { ...prev, asset: { ...prev.asset, hideSubHeader: hide } } : null
                          );
                        }}
                        className="w-3 h-3 rounded text-orange-600 cursor-pointer"
                      />
                      <span>Exibir</span>
                    </label>
                  </div>
                  <input
                    type="text"
                    disabled={editingSlotAsset.asset.hideSubHeader}
                    value={editingSlotAsset.asset.customSubHeader ?? (editingSlotAsset.asset.unidade || customSubHeader)}
                    onChange={(e) => {
                      const val = e.target.value;
                      handleUpdateAssetField(editingSlotAsset.asset.id, 'customSubHeader', val);
                      setEditingSlotAsset((prev) =>
                        prev ? { ...prev, asset: { ...prev.asset, customSubHeader: val } } : null
                      );
                    }}
                    placeholder="Ex: COMLURB, TGC"
                    className={`w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl font-bold text-slate-900 text-xs focus:ring-2 focus:ring-orange-500 uppercase ${editingSlotAsset.asset.hideSubHeader ? 'opacity-40 cursor-not-allowed' : ''}`}
                  />
                </div>
              </div>

              {/* Desc Footer-Left & Loc Footer-Right */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-slate-700 font-bold">
                      Descrição / Rodapé (Esquerda):
                    </label>
                    <label className="flex items-center gap-1 text-[11px] text-slate-500 font-medium cursor-pointer">
                      <input
                        type="checkbox"
                        checked={!editingSlotAsset.asset.hideFooter}
                        onChange={(e) => {
                          const hide = !e.target.checked;
                          handleUpdateAssetField(editingSlotAsset.asset.id, 'hideFooter', hide);
                          setEditingSlotAsset((prev) =>
                            prev ? { ...prev, asset: { ...prev.asset, hideFooter: hide } } : null
                          );
                        }}
                        className="w-3 h-3 rounded text-orange-600 cursor-pointer"
                      />
                      <span>Exibir</span>
                    </label>
                  </div>
                  <input
                    type="text"
                    disabled={editingSlotAsset.asset.hideFooter}
                    value={editingSlotAsset.asset.customFooter ?? (editingSlotAsset.asset.descricao || customFooter)}
                    onChange={(e) => {
                      const val = e.target.value;
                      handleUpdateAssetField(editingSlotAsset.asset.id, 'customFooter', val);
                      setEditingSlotAsset((prev) =>
                        prev ? { ...prev, asset: { ...prev.asset, customFooter: val } } : null
                      );
                    }}
                    placeholder="Ex: BEM EM CADASTRAMENTO"
                    className={`w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl font-bold text-slate-900 text-xs focus:ring-2 focus:ring-orange-500 ${editingSlotAsset.asset.hideFooter ? 'opacity-40 cursor-not-allowed' : ''}`}
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-slate-700 font-bold">
                      Localidade / Sala (Direita):
                    </label>
                    <label className="flex items-center gap-1 text-[11px] text-slate-500 font-medium cursor-pointer">
                      <input
                        type="checkbox"
                        checked={!editingSlotAsset.asset.hideLoc}
                        onChange={(e) => {
                          const hide = !e.target.checked;
                          handleUpdateAssetField(editingSlotAsset.asset.id, 'hideLoc', hide);
                          setEditingSlotAsset((prev) =>
                            prev ? { ...prev, asset: { ...prev.asset, hideLoc: hide } } : null
                          );
                        }}
                        className="w-3 h-3 rounded text-orange-600 cursor-pointer"
                      />
                      <span>Exibir</span>
                    </label>
                  </div>
                  <input
                    type="text"
                    disabled={editingSlotAsset.asset.hideLoc}
                    value={editingSlotAsset.asset.customLoc ?? (editingSlotAsset.asset.localidade || customLoc)}
                    onChange={(e) => {
                      const val = e.target.value;
                      handleUpdateAssetField(editingSlotAsset.asset.id, 'customLoc', val);
                      setEditingSlotAsset((prev) =>
                        prev ? { ...prev, asset: { ...prev.asset, customLoc: val } } : null
                      );
                    }}
                    placeholder="Ex: LOC 104, SALA 2"
                    className={`w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl font-bold text-slate-900 text-xs focus:ring-2 focus:ring-orange-500 ${editingSlotAsset.asset.hideLoc ? 'opacity-40 cursor-not-allowed' : ''}`}
                  />
                </div>
              </div>

              {/* Toggles: Prefixo PATR & QR Code */}
              <div className="grid grid-cols-2 gap-3 pt-1">
                <div className="flex items-center justify-between bg-slate-50 p-3 rounded-xl border border-slate-200">
                  <div>
                    <span className="font-bold text-slate-800 block text-xs">Exibir "PATR:"</span>
                    <span className="text-[10px] text-slate-500">Prefixo antes do número</span>
                  </div>
                  <input
                    type="checkbox"
                    checked={!editingSlotAsset.asset.hidePatrTag}
                    onChange={(e) => {
                      const hide = !e.target.checked;
                      handleUpdateAssetField(editingSlotAsset.asset.id, 'hidePatrTag', hide);
                      setEditingSlotAsset((prev) =>
                        prev ? { ...prev, asset: { ...prev.asset, hidePatrTag: hide } } : null
                      );
                    }}
                    className="w-4 h-4 rounded text-orange-600 cursor-pointer"
                  />
                </div>

                <div className="flex items-center justify-between bg-slate-50 p-3 rounded-xl border border-slate-200">
                  <div>
                    <span className="font-bold text-slate-800 block text-xs">Exibir QR Code</span>
                    <span className="text-[10px] text-slate-500">Código QR escaneável</span>
                  </div>
                  <input
                    type="checkbox"
                    checked={!editingSlotAsset.asset.hideQr}
                    onChange={(e) => {
                      const hide = !e.target.checked;
                      handleUpdateAssetField(editingSlotAsset.asset.id, 'hideQr', hide);
                      setEditingSlotAsset((prev) =>
                        prev ? { ...prev, asset: { ...prev.asset, hideQr: hide } } : null
                      );
                    }}
                    className="w-4 h-4 rounded text-orange-600 cursor-pointer"
                  />
                </div>
              </div>

              {/* Quick Blank Label preset for this slot */}
              <div className="p-2.5 bg-amber-50 rounded-xl border border-amber-200 flex items-center justify-between">
                <span className="text-amber-900 font-bold text-[11px]">Deixar esta plaqueta totalmente limpa (Apenas número):</span>
                <button
                  type="button"
                  onClick={() => {
                    const id = editingSlotAsset.asset.id;
                    handleUpdateAssetField(id, 'hideHeader', true);
                    handleUpdateAssetField(id, 'hideSubHeader', true);
                    handleUpdateAssetField(id, 'hideFooter', true);
                    handleUpdateAssetField(id, 'hideLoc', true);
                    handleUpdateAssetField(id, 'hidePatrTag', true);
                    handleUpdateAssetField(id, 'hideQr', true);
                    setEditingSlotAsset((prev) =>
                      prev
                        ? {
                            ...prev,
                            asset: {
                              ...prev.asset,
                              hideHeader: true,
                              hideSubHeader: true,
                              hideFooter: true,
                              hideLoc: true,
                              hidePatrTag: true,
                              hideQr: true,
                            },
                          }
                        : null
                    );
                  }}
                  className="px-2.5 py-1 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-lg text-[10px] cursor-pointer"
                >
                  ✨ Limpar Textos Desta Plaqueta
                </button>
              </div>
            </div>

            <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
              <button
                type="button"
                onClick={() => {
                  handleClearSlotAsset(editingSlotAsset.index);
                  setEditingSlotAsset(null);
                }}
                className="text-red-600 hover:text-red-700 font-bold text-xs flex items-center gap-1 cursor-pointer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Limpar Esta Posição</span>
              </button>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setEditingSlotAsset(null)}
                  className="px-4 py-2 bg-orange-600 hover:bg-orange-700 text-white rounded-xl font-bold text-xs shadow-xs cursor-pointer"
                >
                  Concluir Edição
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Batch Spreadsheet / Table Editor */}
      {isBatchTableEditorOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-xs p-4 animate-in fade-in duration-150">
          <div className="bg-white w-full max-w-5xl max-h-[90vh] rounded-2xl shadow-2xl border border-slate-200 flex flex-col overflow-hidden">
            {/* Modal Header */}
            <div className="p-4.5 border-b border-slate-200 bg-slate-900 text-white flex items-center justify-between shrink-0">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-amber-400 text-slate-950 flex items-center justify-center font-black shadow-sm">
                  <Table className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-extrabold text-white text-base flex items-center gap-2">
                    <span>Editor de Etiquetas em Planilha / Tabela</span>
                    <span className="text-xs bg-amber-400 text-slate-950 px-2 py-0.5 rounded-full font-black">
                      {targetAssets.length} Etiquetas
                    </span>
                  </h3>
                  <p className="text-xs text-slate-300">
                    Edite linhas em massa, aplique numeração sequencial rápida ou adicione novas etiquetas personalizadas.
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsBatchTableEditorOpen(false)}
                className="w-8 h-8 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white flex items-center justify-center font-bold text-sm cursor-pointer"
              >
                ✕
              </button>
            </div>

            {/* Quick Bulk Automation Toolbar */}
            <div className="p-3.5 bg-slate-100 border-b border-slate-200 shrink-0 flex flex-wrap items-center justify-between gap-3 text-xs">
              <div className="flex flex-wrap items-center gap-2">
                <span className="font-bold text-slate-700 flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5 text-orange-600" />
                  Ações Rápidas em Massa:
                </span>

                {/* Generate sequential numbers button */}
                <button
                  type="button"
                  onClick={() => {
                    const startNum = prompt('Digite o número inicial da sequência (Ex: 3327):', '3327');
                    if (startNum && !isNaN(Number(startNum))) {
                      const prefix = prompt('Prefixo opcional (Deixe em branco para nenhum, ou digite TGC-):', '') || '';
                      handleApplySequenceToBatch(Number(startNum), prefix);
                    }
                  }}
                  className="px-2.5 py-1.5 bg-white hover:bg-slate-50 border border-slate-300 rounded-lg font-bold text-slate-800 shadow-2xs flex items-center gap-1 cursor-pointer"
                >
                  <Tag className="w-3.5 h-3.5 text-amber-600" />
                  <span>Gerar Numeração Sequencial...</span>
                </button>

                {/* Bulk description */}
                <button
                  type="button"
                  onClick={() => {
                    const desc = prompt('Digite a descrição padrão para todas as etiquetas:', customFooter || 'BEM EM CADASTRAMENTO');
                    if (desc !== null) handleApplyBulkDescToBatch(desc);
                  }}
                  className="px-2.5 py-1.5 bg-white hover:bg-slate-50 border border-slate-300 rounded-lg font-bold text-slate-800 shadow-2xs flex items-center gap-1 cursor-pointer"
                >
                  <FileText className="w-3.5 h-3.5 text-blue-600" />
                  <span>Preencher Descrição em Massa...</span>
                </button>

                {/* Bulk location */}
                <button
                  type="button"
                  onClick={() => {
                    const loc = prompt('Digite a localidade/sala para todas as etiquetas:', customLoc || 'SALA 102');
                    if (loc !== null) handleApplyBulkLocToBatch(loc);
                  }}
                  className="px-2.5 py-1.5 bg-white hover:bg-slate-50 border border-slate-300 rounded-lg font-bold text-slate-800 shadow-2xs flex items-center gap-1 cursor-pointer"
                >
                  <Building className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Preencher Localidade em Massa...</span>
                </button>

                {/* Bulk Hide QR (Only Number) */}
                <button
                  type="button"
                  onClick={() => handleSetAllQrVisibility(false)}
                  className="px-2.5 py-1.5 bg-amber-50 hover:bg-amber-100 border border-amber-300 rounded-lg font-bold text-amber-950 shadow-2xs flex items-center gap-1 cursor-pointer"
                  title="Ocultar QR Code em todas as etiquetas para deixar somente o número"
                >
                  <QrCode className="w-3.5 h-3.5 text-amber-700" />
                  <span>🚫 Ocultar QR</span>
                </button>

                {/* Bulk Show QR */}
                <button
                  type="button"
                  onClick={() => handleSetAllQrVisibility(true)}
                  className="px-2.5 py-1.5 bg-white hover:bg-slate-50 border border-slate-300 rounded-lg font-bold text-slate-800 shadow-2xs flex items-center gap-1 cursor-pointer"
                  title="Exibir QR Code em todas as etiquetas"
                >
                  <QrCode className="w-3.5 h-3.5 text-orange-600" />
                  <span>📱 Exibir QR</span>
                </button>

                {/* Bulk Pure Clean Numbers */}
                <button
                  type="button"
                  onClick={() => handleSetPureCleanNumbersAll(true)}
                  className="px-2.5 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-lg text-xs shadow-xs flex items-center gap-1 cursor-pointer"
                  title="Deixar totalmente em branco: oculta cabeçalhos, descrições, gerências e localidades"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>✨ Deixar Totalmente Limpo (Apenas Número)</span>
                </button>

                {/* Bulk Restore All */}
                <button
                  type="button"
                  onClick={() => handleSetPureCleanNumbersAll(false)}
                  className="px-2.5 py-1.5 bg-white hover:bg-slate-50 border border-slate-300 rounded-lg font-bold text-slate-800 shadow-2xs flex items-center gap-1 cursor-pointer"
                  title="Restaurar todos os textos e legendas"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Restaurar Textos</span>
                </button>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleAddNewCustomRow}
                  className="px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-lg text-xs shadow-xs flex items-center gap-1 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>+ Adicionar Linha</span>
                </button>
              </div>
            </div>

            {/* Table Area */}
            <div className="flex-1 overflow-auto p-4">
              <table className="w-full border-collapse text-left text-xs">
                <thead>
                  <tr className="bg-slate-100 border-b border-slate-300 text-slate-700 font-extrabold uppercase text-[10px]">
                    <th className="p-2 w-10 text-center">#</th>
                    <th className="p-2 w-32">Patrimônio / Número</th>
                    <th className="p-2 w-44">Topo (Orgão)</th>
                    <th className="p-2 w-28">Gerência / Setor</th>
                    <th className="p-2">Descrição / Rodapé</th>
                    <th className="p-2 w-28">Localidade</th>
                    <th className="p-2 w-20 text-center">Fonte</th>
                    <th className="p-2 w-16 text-center">QR</th>
                    <th className="p-2 w-16 text-center">Ações</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 font-sans">
                  {targetAssets.map((asset, idx) => {
                    const isOverridden = labelOverrides[asset.id];

                    return (
                      <tr
                        key={asset.id || idx}
                        className={`hover:bg-slate-50 transition-colors ${
                          isOverridden ? 'bg-amber-50/30' : ''
                        }`}
                      >
                        {/* Index */}
                        <td className="p-2 font-mono font-bold text-center text-slate-500 text-[11px]">
                          {idx + 1}
                        </td>

                        {/* Patrimonio */}
                        <td className="p-2">
                          <input
                            type="text"
                            value={asset.patrimonio || ''}
                            onChange={(e) => handleUpdateAssetField(asset.id, 'patrimonio', e.target.value.toUpperCase())}
                            className="w-full px-2 py-1 bg-white border border-slate-300 rounded font-mono font-black text-slate-900 text-xs focus:ring-2 focus:ring-amber-400 outline-hidden uppercase"
                          />
                        </td>

                        {/* Header */}
                        <td className="p-2">
                          <input
                            type="text"
                            value={asset.customHeader ?? customHeader}
                            onChange={(e) => handleUpdateAssetField(asset.id, 'customHeader', e.target.value)}
                            placeholder="Orgão"
                            className="w-full px-2 py-1 bg-white border border-slate-300 rounded text-slate-900 text-xs focus:ring-2 focus:ring-amber-400 outline-hidden"
                          />
                        </td>

                        {/* SubHeader / Unit */}
                        <td className="p-2">
                          <input
                            type="text"
                            value={asset.customSubHeader ?? (asset.unidade || customSubHeader)}
                            onChange={(e) => handleUpdateAssetField(asset.id, 'customSubHeader', e.target.value)}
                            placeholder="Gerência"
                            className="w-full px-2 py-1 bg-white border border-slate-300 rounded text-slate-900 text-xs uppercase focus:ring-2 focus:ring-amber-400 outline-hidden"
                          />
                        </td>

                        {/* Footer / Desc */}
                        <td className="p-2">
                          <input
                            type="text"
                            value={asset.customFooter ?? (asset.descricao || customFooter)}
                            onChange={(e) => handleUpdateAssetField(asset.id, 'customFooter', e.target.value)}
                            placeholder="Descrição"
                            className="w-full px-2 py-1 bg-white border border-slate-300 rounded text-slate-900 text-xs focus:ring-2 focus:ring-amber-400 outline-hidden"
                          />
                        </td>

                        {/* Loc */}
                        <td className="p-2">
                          <input
                            type="text"
                            value={asset.customLoc ?? (asset.localidade || customLoc)}
                            onChange={(e) => handleUpdateAssetField(asset.id, 'customLoc', e.target.value)}
                            placeholder="Localidade"
                            className="w-full px-2 py-1 bg-white border border-slate-300 rounded text-slate-900 text-xs focus:ring-2 focus:ring-amber-400 outline-hidden"
                          />
                        </td>

                        {/* Font Size */}
                        <td className="p-2 text-center">
                          <input
                            type="number"
                            min="8"
                            max="85"
                            value={asset.customFontSize || patrimonioFontSize}
                            onChange={(e) => handleUpdateAssetField(asset.id, 'customFontSize', Number(e.target.value))}
                            className="w-14 px-1 py-1 bg-white border border-slate-300 rounded font-mono font-bold text-center text-xs focus:ring-2 focus:ring-amber-400 outline-hidden"
                          />
                        </td>

                        {/* QR Checkbox */}
                        <td className="p-2 text-center">
                          <input
                            type="checkbox"
                            checked={!asset.hideQr}
                            onChange={(e) => handleUpdateAssetField(asset.id, 'hideQr', !e.target.checked)}
                            className="rounded text-amber-500"
                            title="Exibir QR Code"
                          />
                        </td>

                        {/* Actions */}
                        <td className="p-2 text-center">
                          <div className="flex items-center justify-center gap-1">
                            <button
                              type="button"
                              onClick={() => handleDuplicateAsset(idx)}
                              className="p-1 hover:bg-slate-200 text-slate-600 rounded cursor-pointer"
                              title="Duplicar Linha"
                            >
                              <Copy className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => handleClearSlotAsset(idx)}
                              className="p-1 hover:bg-red-100 text-red-600 rounded cursor-pointer"
                              title="Excluir Linha"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* Modal Footer */}
            <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between shrink-0">
              <div className="text-xs text-slate-500">
                As alterações são salvas e refletidas instantaneamente na visualização e na impressão.
              </div>
              <button
                type="button"
                onClick={() => setIsBatchTableEditorOpen(false)}
                className="px-5 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-xl text-xs shadow-xs cursor-pointer"
              >
                Concluir e Voltar ao Preview
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Save Batch to Archive */}
      {isSaveBatchModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 backdrop-blur-xs p-4">
          <div className="bg-white w-full max-w-lg rounded-2xl shadow-2xl border border-slate-200 overflow-hidden">
            <div className="p-5 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-amber-500 text-slate-950 flex items-center justify-center font-bold">
                  <Save className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-extrabold text-slate-900 text-sm">
                    Salvar e Arquivar Lote de Etiquetas
                  </h3>
                  <p className="text-xs text-slate-500">
                    Guarde este lote para reimpressão futura, download HTML ou auditoria
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsSaveBatchModalOpen(false)}
                className="w-7 h-7 rounded-lg bg-slate-200 hover:bg-slate-300 text-slate-700 flex items-center justify-center font-bold text-xs cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="p-6 space-y-4 text-xs">
              <div>
                <label className="block text-slate-700 font-bold mb-1.5">
                  Título / Identificação do Lote: <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={saveBatchName}
                  onChange={(e) => setSaveBatchName(e.target.value)}
                  placeholder="Ex: Lote Vistoria TGC - 40 Etiquetas - 28/08"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl font-bold text-slate-900 text-xs focus:ring-2 focus:ring-orange-500"
                />
              </div>

              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 space-y-1.5">
                <div className="font-bold text-slate-800 flex items-center justify-between">
                  <span>Resumo do Lote a Arquivar:</span>
                  <span className="text-amber-700 font-black">
                    {totalLabelsToPrint} etiquetas ({totalSheets} folha{totalSheets !== 1 ? 's' : ''})
                  </span>
                </div>
                <div className="text-[11px] text-slate-600 space-y-0.5">
                  <div>
                    • Origem:{' '}
                    {filterSource === 'blank_labels'
                      ? 'Etiquetas em Branco / Avulsas'
                      : filterSource === 'all'
                      ? 'Inventário Completo'
                      : 'Seleção Específica'}
                  </div>
                  <div>
                    • Formato: Pimaco 6181 / 6281 ({paperFormat === 'letter' ? 'Carta' : 'A4'}) •{' '}
                    {layoutStyle === 'standard_pimaco' ? 'Oficial Pimaco' : 'Barras'}
                  </div>
                  <div>• Gerência: {filterDept}</div>
                </div>
              </div>

              <div>
                <label className="block text-slate-700 font-bold mb-1.5">
                  Observações / Finalidade (Opcional):
                </label>
                <textarea
                  rows={3}
                  value={saveBatchNotes}
                  onChange={(e) => setSaveBatchNotes(e.target.value)}
                  placeholder="Ex: Folhas impressas para equipe de vistoria de campo do setor administrativo..."
                  className="w-full px-3.5 py-2 bg-slate-50 border border-slate-300 rounded-xl font-medium text-slate-800 text-xs focus:ring-2 focus:ring-orange-500 resize-none"
                />
              </div>
            </div>

            <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setIsSaveBatchModalOpen(false)}
                className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-800 rounded-xl font-bold text-xs cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={handleConfirmSaveBatch}
                className="flex items-center gap-1.5 px-5 py-2 bg-orange-600 hover:bg-orange-700 text-white rounded-xl font-bold text-xs shadow-xs cursor-pointer"
              >
                <Save className="w-4 h-4" />
                <span>Salvar no Arquivo</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal: View Archived Batches */}
      <ArchivedLabelsModal
        isOpen={isArchiveModalOpen}
        onClose={() => {
          setIsArchiveModalOpen(false);
          setArchivedCount(getArchivedLabelBatches().length);
        }}
        onLoadBatch={handleLoadBatch}
        selectedYear={selectedYear}
      />
    </div>
  );
};
