import React, { useState, useMemo } from 'react';
import {
  Building,
  TrendingUp,
  Calendar,
  DollarSign,
  Package,
  CheckCircle2,
  AlertTriangle,
  ArrowRightLeft,
  Clock,
  PieChart as PieIcon,
  BarChart3,
  Layers,
  Sparkles,
  Download,
  Printer,
  ChevronRight,
  Filter,
  UserCheck,
  ShieldCheck,
  Search,
  ExternalLink,
  Info,
  ChevronDown,
  ChevronUp,
  Tag,
  ArrowUpRight,
  FileSpreadsheet
} from 'lucide-react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from 'recharts';
import { AssetItem, InspectionRecord, DepartmentInfo, AuditSession } from '../types';

interface GerenciaDashboardProps {
  assets: AssetItem[];
  inspections: Record<string, InspectionRecord>;
  departments: DepartmentInfo[];
  selectedYear: number;
  initialGerencia?: string;
  auditSession: AuditSession;
  onOpenDetails?: (asset: AssetItem) => void;
  onClose?: () => void;
}

export const GerenciaDashboard: React.FC<GerenciaDashboardProps> = ({
  assets,
  inspections,
  departments,
  selectedYear,
  initialGerencia = 'ALL',
  auditSession,
  onOpenDetails,
  onClose,
}) => {
  const [selectedGerencia, setSelectedGerencia] = useState<string>(initialGerencia);
  const [activeTab, setActiveTab] = useState<'overview' | 'timeline' | 'comparison' | 'inspection'>(
    'overview'
  );
  const [timelinePeriodFilter, setTimelinePeriodFilter] = useState<string>('ALL');
  const [selectedTimelineYear, setSelectedTimelineYear] = useState<number | null>(null);
  const [searchTerm, setSearchTerm] = useState<string>('');

  // 1. Filter assets based on selected Gerência
  const filteredAssets = useMemo(() => {
    if (selectedGerencia === 'ALL') {
      return assets;
    }
    return assets.filter((a) => a.gerenciaCode === selectedGerencia);
  }, [assets, selectedGerencia]);

  // Current department metadata
  const currentDeptInfo = useMemo(() => {
    if (selectedGerencia === 'ALL') return null;
    return departments.find((d) => d.code === selectedGerencia) || null;
  }, [departments, selectedGerencia]);

  // 2. High-level Statistics for selected view
  const stats = useMemo(() => {
    const totalAssets = filteredAssets.length;
    const totalValue = filteredAssets.reduce((sum, a) => sum + (a.vlBase || 0), 0);
    const activeAssets = filteredAssets.filter((a) => a.situacao !== 'baixado');
    const activeValue = activeAssets.reduce((sum, a) => sum + (a.vlBase || 0), 0);
    const baixados = filteredAssets.filter((a) => a.situacao === 'baixado');
    const baixadosValue = baixados.reduce((sum, a) => sum + (a.vlBase || 0), 0);

    // Inspection progress for selected year
    let presente = 0;
    let ausente = 0;
    let transferido = 0;
    let pendente = 0;

    let excelente = 0;
    let bom = 0;
    let regular = 0;
    let ruim = 0;
    let inservivel = 0;
    let sucata = 0;
    let naoAvaliado = 0;

    let plaquetaLegivel = 0;
    let plaquetaDanificada = 0;
    let semPlaqueta = 0;

    filteredAssets.forEach((a) => {
      const insp = inspections[`${a.id}-${selectedYear}`] || inspections[`${a.id}_${selectedYear}`];
      if (!insp || insp.status === 'pendente') {
        pendente++;
        naoAvaliado++;
      } else if (insp.status === 'presente') {
        presente++;
      } else if (insp.status === 'ausente') {
        ausente++;
      } else if (insp.status === 'transferido') {
        transferido++;
      }

      if (insp) {
        switch (insp.condition) {
          case 'excelente':
            excelente++;
            break;
          case 'bom':
            bom++;
            break;
          case 'regular':
            regular++;
            break;
          case 'ruim':
            ruim++;
            break;
          case 'inservivel':
            inservivel++;
            break;
          case 'sucata':
            sucata++;
            break;
          default:
            naoAvaliado++;
            break;
        }

        if (insp.tagCondition === 'legivel' || insp.tagCondition === 'placa_substituida') {
          plaquetaLegivel++;
        } else if (insp.tagCondition === 'danificada') {
          plaquetaDanificada++;
        } else if (insp.tagCondition === 'sem_plaqueta') {
          semPlaqueta++;
        }
      }
    });

    const vistoriadosTotal = presente + ausente + transferido;
    const taxaVistoria = totalAssets > 0 ? (vistoriadosTotal / totalAssets) * 100 : 0;
    const taxaConformidade = vistoriadosTotal > 0 ? (presente / vistoriadosTotal) * 100 : 0;

    return {
      totalAssets,
      totalValue,
      activeAssetsCount: activeAssets.length,
      activeValue,
      baixadosCount: baixados.length,
      baixadosValue,
      presente,
      ausente,
      transferido,
      pendente,
      vistoriadosTotal,
      taxaVistoria,
      taxaConformidade,
      condicoes: {
        excelente,
        bom,
        regular,
        ruim,
        inservivel,
        sucata,
        naoAvaliado,
        bomExcelente: excelente + bom,
        atencao: regular + ruim,
        critico: inservivel + sucata,
      },
      plaquetas: {
        plaquetaLegivel,
        plaquetaDanificada,
        semPlaqueta,
      },
    };
  }, [filteredAssets, inspections, selectedYear]);

  // 3. Category Breakdown Data
  const categoryData = useMemo(() => {
    const map: Record<string, { count: number; value: number }> = {};
    filteredAssets.forEach((a) => {
      const cat = a.categoria || 'Geral & Outros';
      if (!map[cat]) {
        map[cat] = { count: 0, value: 0 };
      }
      map[cat].count += 1;
      map[cat].value += a.vlBase || 0;
    });

    return Object.entries(map)
      .map(([name, data]) => ({
        name,
        count: data.count,
        value: data.value,
        formattedValue: `R$ ${data.value.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`,
      }))
      .sort((a, b) => b.value - a.value);
  }, [filteredAssets]);

  // 4. Comparative data between TGC, TDO, TDM
  const gerenciasComparison = useMemo(() => {
    return departments.map((dept) => {
      const deptAssets = assets.filter((a) => a.gerenciaCode === dept.code);
      const totalCount = deptAssets.length;
      const totalVal = deptAssets.reduce((sum, a) => sum + (a.vlBase || 0), 0);

      let pres = 0;
      let aus = 0;
      let trans = 0;
      let pend = 0;
      let baix = 0;

      deptAssets.forEach((a) => {
        if (a.situacao === 'baixado') {
          baix++;
        }
        const insp = inspections[`${a.id}-${selectedYear}`] || inspections[`${a.id}_${selectedYear}`];
        if (!insp || insp.status === 'pendente') pend++;
        else if (insp.status === 'presente') pres++;
        else if (insp.status === 'ausente') aus++;
        else if (insp.status === 'transferido') trans++;
      });

      const vistoriados = pres + aus + trans;
      const percentVistoriado = totalCount > 0 ? Math.round((vistoriados / totalCount) * 100) : 0;

      return {
        code: dept.code,
        name: dept.name,
        shortName: dept.code,
        totalCount,
        totalVal,
        formattedValue: `R$ ${totalVal.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`,
        pres,
        aus,
        trans,
        pend,
        baix,
        percentVistoriado,
        gerenteNome: dept.gerenteNome || 'Não informado',
        fiscalNome: dept.fiscalNome || 'Wagner J. Jardim',
      };
    });
  }, [assets, departments, inspections, selectedYear]);

  // 5. Timeline Data Engine: Group acquisitions by Year and calculate Cumulative Value
  const timelineData = useMemo(() => {
    const yearMap: Record<number, { year: number; count: number; totalValue: number; items: AssetItem[] }> = {};

    filteredAssets.forEach((asset) => {
      let year = 1990;
      if (asset.dtAquisicao) {
        // Parse DD/MM/YYYY or YYYY-MM-DD
        if (asset.dtAquisicao.includes('/')) {
          const parts = asset.dtAquisicao.split('/');
          if (parts.length === 3) {
            const y = parseInt(parts[2], 10);
            if (!isNaN(y) && y > 1950 && y <= 2030) year = y;
          }
        } else if (asset.dtAquisicao.includes('-')) {
          const parts = asset.dtAquisicao.split('-');
          const y = parseInt(parts[0], 10);
          if (!isNaN(y) && y > 1950 && y <= 2030) year = y;
        }
      }

      if (!yearMap[year]) {
        yearMap[year] = { year, count: 0, totalValue: 0, items: [] };
      }
      yearMap[year].count += 1;
      yearMap[year].totalValue += asset.vlBase || 0;
      yearMap[year].items.push(asset);
    });

    const sortedYears = Object.keys(yearMap)
      .map(Number)
      .sort((a, b) => a - b);

    let cumulativeCount = 0;
    let cumulativeValue = 0;

    const timelineSeries = sortedYears.map((year) => {
      const data = yearMap[year];
      cumulativeCount += data.count;
      cumulativeValue += data.totalValue;

      let decade = 'Anos 1990';
      if (year < 1990) decade = 'Anos 1980 e anteriores';
      else if (year >= 1990 && year < 2000) decade = 'Anos 1990';
      else if (year >= 2000 && year < 2010) decade = 'Anos 2000';
      else if (year >= 2010 && year < 2020) decade = 'Anos 2010';
      else if (year >= 2020) decade = 'Anos 2020+';

      return {
        year,
        yearLabel: `${year}`,
        count: data.count,
        totalValue: Math.round(data.totalValue * 100) / 100,
        cumulativeCount,
        cumulativeValue: Math.round(cumulativeValue * 100) / 100,
        decade,
        items: data.items,
        sampleItem: data.items[0]?.descricao || '',
      };
    });

    return {
      series: timelineSeries,
      rawYears: sortedYears,
      yearMap,
    };
  }, [filteredAssets]);

  // Filtered timeline cards based on decade
  const filteredTimelineCards = useMemo(() => {
    let list = [...timelineData.series].reverse(); // newest first
    if (timelinePeriodFilter !== 'ALL') {
      list = list.filter((item) => item.decade === timelinePeriodFilter);
    }
    return list;
  }, [timelineData.series, timelinePeriodFilter]);

  // Items for selected timeline year drilldown
  const activeYearItems = useMemo(() => {
    if (!selectedTimelineYear) return [];
    const entry = timelineData.yearMap[selectedTimelineYear];
    if (!entry) return [];
    let items = entry.items;
    if (searchTerm.trim()) {
      const q = searchTerm.toLowerCase();
      items = items.filter(
        (a) =>
          a.patrimonio.toLowerCase().includes(q) ||
          a.descricao.toLowerCase().includes(q) ||
          (a.categoria && a.categoria.toLowerCase().includes(q))
      );
    }
    return items;
  }, [selectedTimelineYear, timelineData.yearMap, searchTerm]);

  // Colors for Recharts
  const COLORS = ['#ea580c', '#3b82f6', '#10b981', '#f59e0b', '#8b5cf6', '#ec4899', '#06b6d4'];

  const handleExportCSV = () => {
    const headers = [
      'Nº Patrimônio',
      'Descrição',
      'Gerência',
      'Localidade',
      'Centro de Custo',
      'Data Aquisição',
      'Valor Base (R$)',
      'Categoria',
      'Situação',
      `Status Vistoria (${selectedYear})`,
      'Estado de Conservação',
      'Plaqueta',
    ];

    const rows = filteredAssets.map((a) => {
      const insp = inspections[`${a.id}-${selectedYear}`] || inspections[`${a.id}_${selectedYear}`];
      return [
        `"${a.patrimonio}"`,
        `"${(a.descricao || '').replace(/"/g, '""')}"`,
        `"${a.gerenciaCode}"`,
        `"${a.localidade}"`,
        `"${a.centroCusto}"`,
        `"${a.dtAquisicao || ''}"`,
        (a.vlBase || 0).toFixed(2).replace('.', ','),
        `"${a.categoria || ''}"`,
        `"${a.situacao || 'ativo'}"`,
        `"${insp?.status || 'pendente'}"`,
        `"${insp?.condition || 'nao_avaliado'}"`,
        `"${insp?.tagCondition || 'legivel'}"`,
      ];
    });

    const csvContent = '\uFEFF' + [headers.join(';'), ...rows.map((r) => r.join(';'))].join('\r\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Dashboard_Patrimonial_${selectedGerencia}_${selectedYear}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const handlePrintDashboard = () => {
    window.print();
  };

  return (
    <div id="gerencia-dashboard-root" className="space-y-5 pb-12">
      {/* Top Header & Gerência Switcher Bar */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-xs p-4 sm:p-5 no-print">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-4 border-b border-slate-100">
          <div>
            <div className="flex items-center gap-2">
              <span className="p-1.5 bg-orange-100 text-orange-700 rounded-lg">
                <BarChart3 className="w-5 h-5" />
              </span>
              <h2 className="text-lg sm:text-xl font-black text-slate-900 tracking-tight">
                Dashboard Gerencial & Evolução Patrimonial
              </h2>
              <span className="px-2 py-0.5 rounded text-[11px] font-bold bg-slate-100 text-slate-700 border border-slate-200">
                Exercício {selectedYear}
              </span>
            </div>
            <p className="text-xs text-slate-500 font-medium mt-1">
              Painel analítico comparativo por gerência com evolução histórica de aquisições e indicadores de vistoria física
            </p>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={handlePrintDashboard}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-lg text-xs font-bold border border-slate-300 transition-colors cursor-pointer"
              title="Imprimir Dashboard A4"
            >
              <Printer className="w-3.5 h-3.5 text-slate-700" />
              <span>Imprimir Painel</span>
            </button>

            <button
              onClick={handleExportCSV}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-900 hover:bg-black text-white rounded-lg text-xs font-bold shadow-xs transition-colors cursor-pointer"
              title="Exportar dados consolidados em CSV"
            >
              <FileSpreadsheet className="w-3.5 h-3.5 text-orange-400" />
              <span>Exportar Dados</span>
            </button>

            {onClose && (
              <button
                onClick={onClose}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-orange-50 hover:bg-orange-100 text-orange-800 rounded-lg text-xs font-bold border border-orange-200 transition-colors cursor-pointer"
              >
                <span>Voltar para Tabela</span>
              </button>
            )}
          </div>
        </div>

        {/* Gerência Selection Pills & View Mode Tabs */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 pt-3.5">
          {/* Gerência Selector */}
          <div className="flex flex-wrap items-center gap-1.5">
            <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mr-1 flex items-center gap-1">
              <Building className="w-3.5 h-3.5" />
              Gerência:
            </div>
            <button
              onClick={() => {
                setSelectedGerencia('ALL');
                setSelectedTimelineYear(null);
              }}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 border ${
                selectedGerencia === 'ALL'
                  ? 'bg-slate-900 text-white border-slate-900 shadow-xs'
                  : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
              }`}
            >
              <span>Visão Consolidada</span>
              <span
                className={`px-1.5 py-0.2 rounded text-[10px] font-bold ${
                  selectedGerencia === 'ALL' ? 'bg-slate-800 text-orange-400' : 'bg-slate-200 text-slate-700'
                }`}
              >
                {assets.length} bens
              </span>
            </button>

            {departments.map((dept) => {
              const isSelected = selectedGerencia === dept.code;
              const count = assets.filter((a) => a.gerenciaCode === dept.code).length;
              return (
                <button
                  key={dept.code}
                  onClick={() => {
                    setSelectedGerencia(dept.code);
                    setSelectedTimelineYear(null);
                  }}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 border ${
                    isSelected
                      ? 'bg-white border-2 border-orange-500 text-orange-700 shadow-xs'
                      : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                  }`}
                >
                  <span>{dept.code}</span>
                  <span
                    className={`px-1.5 py-0.2 rounded text-[10px] font-bold ${
                      isSelected ? 'bg-orange-100 text-orange-800' : 'bg-slate-200 text-slate-700'
                    }`}
                  >
                    {count}
                  </span>
                </button>
              );
            })}
          </div>

          {/* Sub-Navigation Tabs */}
          <div className="flex items-center bg-slate-100 p-1 rounded-lg border border-slate-200 gap-0.5">
            <button
              onClick={() => setActiveTab('overview')}
              className={`flex items-center gap-1.5 py-1.5 px-3 rounded-md text-xs font-bold transition-all cursor-pointer ${
                activeTab === 'overview'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <PieIcon className="w-3.5 h-3.5" />
              <span>Visão Geral</span>
            </button>

            <button
              onClick={() => setActiveTab('timeline')}
              className={`flex items-center gap-1.5 py-1.5 px-3 rounded-md text-xs font-bold transition-all cursor-pointer ${
                activeTab === 'timeline'
                  ? 'bg-white text-orange-700 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Clock className="w-3.5 h-3.5" />
              <span>Linha do Tempo</span>
            </button>

            <button
              onClick={() => setActiveTab('comparison')}
              className={`flex items-center gap-1.5 py-1.5 px-3 rounded-md text-xs font-bold transition-all cursor-pointer ${
                activeTab === 'comparison'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              <span>Comparativo</span>
            </button>

            <button
              onClick={() => setActiveTab('inspection')}
              className={`flex items-center gap-1.5 py-1.5 px-3 rounded-md text-xs font-bold transition-all cursor-pointer ${
                activeTab === 'inspection'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Vistoria & Laudos</span>
            </button>
          </div>
        </div>
      </div>

      {/* Selected Gerência Details & Leadership Banner */}
      <div className="bg-linear-to-r from-slate-900 via-slate-800 to-slate-900 text-white rounded-xl p-4 sm:p-5 shadow-sm border border-slate-800">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 bg-orange-600 text-white font-black text-xs rounded">
                {selectedGerencia === 'ALL' ? 'COMLURB • CONSOLIDADO' : selectedGerencia}
              </span>
              <h3 className="text-base sm:text-lg font-black tracking-tight">
                {selectedGerencia === 'ALL'
                  ? 'Visão Consolidada de Todas as Gerências Operacionais'
                  : currentDeptInfo?.name || `Gerência ${selectedGerencia}`}
              </h3>
            </div>
            <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-300">
              {currentDeptInfo ? (
                <>
                  <span>
                    <strong className="text-white">Loc:</strong> {currentDeptInfo.locationCode}
                  </span>
                  <span>•</span>
                  <span>
                    <strong className="text-white">Centro de Custo:</strong> {currentDeptInfo.costCenter}
                  </span>
                  <span>•</span>
                  <span>
                    <strong className="text-white">Gerente:</strong>{' '}
                    {currentDeptInfo.gerenteNome || 'Carlos Eduardo da Silva'} ({currentDeptInfo.gerenteMatricula || 'Matr. Oficial'})
                  </span>
                  <span>•</span>
                  <span>
                    <strong className="text-white">Fiscal de Patrimônio:</strong>{' '}
                    {currentDeptInfo.fiscalNome || auditSession.fiscalResponsavel || 'Wagner J. Jardim'}
                  </span>
                </>
              ) : (
                <>
                  <span>
                    <strong className="text-white">Unidades Integradas:</strong> TGC (Ecoparque), TDO (Operação), TDM (Manutenção)
                  </span>
                  <span>•</span>
                  <span>
                    <strong className="text-white">Fiscal Designado:</strong> {auditSession.fiscalResponsavel || 'Wagner J. Jardim'}
                  </span>
                </>
              )}
            </div>
          </div>

          <div className="flex items-center gap-3 shrink-0 bg-slate-800/80 border border-slate-700 px-3.5 py-2 rounded-lg">
            <div className="text-right">
              <div className="text-[10px] uppercase font-bold text-slate-400">Total Imobilizado</div>
              <div className="text-base sm:text-lg font-black text-orange-400">
                R$ {stats.totalValue.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </div>
            </div>
            <div className="w-px h-8 bg-slate-700" />
            <div className="text-right">
              <div className="text-[10px] uppercase font-bold text-slate-400">Acervo Total</div>
              <div className="text-base sm:text-lg font-black text-white">{stats.totalAssets} bens</div>
            </div>
          </div>
        </div>
      </div>

      {/* 4 Primary KPI Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
        {/* Card 1: Imobilizado & Ativos */}
        <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-2xs hover:shadow-xs transition-shadow">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-600">Bens Ativos na Carga</span>
            <span className="p-1.5 bg-emerald-50 text-emerald-600 rounded-md">
              <Package className="w-4 h-4" />
            </span>
          </div>
          <div className="text-2xl font-black text-slate-900">
            {stats.activeAssetsCount}{' '}
            <span className="text-xs font-semibold text-slate-500">
              ({stats.totalAssets > 0 ? Math.round((stats.activeAssetsCount / stats.totalAssets) * 100) : 0}%)
            </span>
          </div>
          <div className="text-xs text-emerald-700 font-bold mt-1">
            R$ {stats.activeValue.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
          </div>
          <div className="text-[11px] text-slate-400 mt-1 flex items-center justify-between border-t border-slate-100 pt-1.5">
            <span>Baixados: {stats.baixadosCount}</span>
            <span>R$ {stats.baixadosValue.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</span>
          </div>
        </div>

        {/* Card 2: Status de Vistoria */}
        <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-2xs hover:shadow-xs transition-shadow">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-600">Conformidade Local</span>
            <span className="p-1.5 bg-blue-50 text-blue-600 rounded-md">
              <CheckCircle2 className="w-4 h-4" />
            </span>
          </div>
          <div className="text-2xl font-black text-slate-900">
            {stats.presente}{' '}
            <span className="text-xs font-semibold text-emerald-600">
              ({stats.totalAssets > 0 ? Math.round((stats.presente / stats.totalAssets) * 100) : 0}%)
            </span>
          </div>
          <div className="text-xs text-slate-600 font-medium mt-1">
            Vistoriados: <strong className="text-slate-900">{stats.vistoriadosTotal}</strong> / {stats.totalAssets}
          </div>
          <div className="text-[11px] text-slate-400 mt-1 flex items-center justify-between border-t border-slate-100 pt-1.5">
            <span className="text-amber-600 font-medium">Pendentes: {stats.pendente}</span>
            <span className="text-red-600 font-medium">Ausentes: {stats.ausente}</span>
          </div>
        </div>

        {/* Card 3: Conservação do Acervo */}
        <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-2xs hover:shadow-xs transition-shadow">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-600">Conservação Boa / Regular</span>
            <span className="p-1.5 bg-amber-50 text-amber-600 rounded-md">
              <Sparkles className="w-4 h-4" />
            </span>
          </div>
          <div className="text-2xl font-black text-slate-900">
            {stats.condicoes.bomExcelente}{' '}
            <span className="text-xs font-semibold text-slate-500">
              ({stats.totalAssets > 0 ? Math.round((stats.condicoes.bomExcelente / stats.totalAssets) * 100) : 0}%)
            </span>
          </div>
          <div className="text-xs text-amber-700 font-medium mt-1">
            Regular/Atenção: <strong>{stats.condicoes.atencao}</strong>
          </div>
          <div className="text-[11px] text-slate-400 mt-1 flex items-center justify-between border-t border-slate-100 pt-1.5">
            <span className="text-red-600 font-medium">Inservível / Sucata: {stats.condicoes.critico}</span>
            <span>A avaliar: {stats.condicoes.naoAvaliado}</span>
          </div>
        </div>

        {/* Card 4: Identificação e Plaquetas */}
        <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-2xs hover:shadow-xs transition-shadow">
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-600">Identificação & Plaquetas</span>
            <span className="p-1.5 bg-purple-50 text-purple-600 rounded-md">
              <Tag className="w-4 h-4" />
            </span>
          </div>
          <div className="text-2xl font-black text-slate-900">
            {stats.plaquetas.plaquetaLegivel}{' '}
            <span className="text-xs font-semibold text-purple-600">
              ({stats.totalAssets > 0 ? Math.round((stats.plaquetas.plaquetaLegivel / stats.totalAssets) * 100) : 0}%)
            </span>
          </div>
          <div className="text-xs text-slate-600 font-medium mt-1">Plaquetas legíveis ou novas</div>
          <div className="text-[11px] text-slate-400 mt-1 flex items-center justify-between border-t border-slate-100 pt-1.5">
            <span className="text-amber-600 font-medium">Danificadas: {stats.plaquetas.plaquetaDanificada}</span>
            <span className="text-red-600 font-medium">Sem Plaqueta: {stats.plaquetas.semPlaqueta}</span>
          </div>
        </div>
      </div>

      {/* TAB CONTENT 1: VISÃO GERAL */}
      {activeTab === 'overview' && (
        <div className="space-y-5">
          {/* Charts Row: Category Breakdown + Conservação Breakdown */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
            {/* Category Chart (7 cols) */}
            <div className="lg:col-span-7 bg-white rounded-xl border border-slate-200 p-5 shadow-2xs">
              <div className="flex items-center justify-between mb-4 pb-2 border-b border-slate-100">
                <div>
                  <h4 className="text-sm font-extrabold text-slate-900 flex items-center gap-1.5">
                    <BarChart3 className="w-4 h-4 text-orange-600" />
                    Distribuição por Categoria & Montante Financeiro
                  </h4>
                  <p className="text-xs text-slate-500 font-medium">
                    Valor contábil imobilizado e quantidade de bens por agrupamento funcional
                  </p>
                </div>
              </div>

              <div className="h-72 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={categoryData} layout="vertical" margin={{ top: 5, right: 30, left: 40, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#e2e8f0" />
                    <XAxis type="number" tickFormatter={(val) => `R$ ${(val / 1000).toFixed(0)}k`} />
                    <YAxis
                      dataKey="name"
                      type="category"
                      width={140}
                      tick={{ fontSize: 11, fill: '#334155', fontWeight: 600 }}
                    />
                    <Tooltip
                      formatter={(value: number) => [
                        `R$ ${Number(value).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`,
                        'Valor Base',
                      ]}
                      labelFormatter={(label) => `Categoria: ${label}`}
                      contentStyle={{ backgroundColor: '#0f172a', color: '#fff', borderRadius: '8px', fontSize: '12px' }}
                    />
                    <Bar dataKey="value" fill="#ea580c" radius={[0, 4, 4, 0]} name="Valor Base (R$)" />
                  </BarChart>
                </ResponsiveContainer>
              </div>

              {/* Mini Table of Categories */}
              <div className="mt-4 pt-3 border-t border-slate-100 grid grid-cols-2 sm:grid-cols-4 gap-2">
                {categoryData.slice(0, 4).map((cat, idx) => (
                  <div key={idx} className="bg-slate-50 p-2 rounded-lg border border-slate-200/80">
                    <div className="text-[10px] font-bold text-slate-500 truncate" title={cat.name}>
                      {cat.name}
                    </div>
                    <div className="text-xs font-black text-slate-900">{cat.count} bens</div>
                    <div className="text-[10px] font-bold text-orange-600 truncate">{cat.formattedValue}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Status & Condition Donut Charts (5 cols) */}
            <div className="lg:col-span-5 bg-white rounded-xl border border-slate-200 p-5 shadow-2xs flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-4 pb-2 border-b border-slate-100">
                  <div>
                    <h4 className="text-sm font-extrabold text-slate-900 flex items-center gap-1.5">
                      <PieIcon className="w-4 h-4 text-orange-600" />
                      Status de Vistoria Física ({selectedYear})
                    </h4>
                    <p className="text-xs text-slate-500 font-medium">
                      Conformidade e localização dos bens na unidade
                    </p>
                  </div>
                </div>

                <div className="h-48 w-full flex items-center justify-center">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={[
                          { name: 'No Local (Sim)', value: stats.presente, color: '#10b981' },
                          { name: 'Ausentes (Não)', value: stats.ausente, color: '#ef4444' },
                          { name: 'Transferidos', value: stats.transferido, color: '#f59e0b' },
                          { name: 'Pendentes', value: stats.pendente, color: '#94a3b8' },
                        ]}
                        innerRadius={50}
                        outerRadius={75}
                        paddingAngle={3}
                        dataKey="value"
                      >
                        {[
                          { color: '#10b981' },
                          { color: '#ef4444' },
                          { color: '#f59e0b' },
                          { color: '#94a3b8' },
                        ].map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip
                        contentStyle={{ backgroundColor: '#0f172a', color: '#fff', borderRadius: '8px', fontSize: '12px' }}
                      />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Legend & Details */}
              <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-100 text-xs">
                <div className="flex items-center gap-2 p-1.5 rounded bg-emerald-50 border border-emerald-200">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 shrink-0" />
                  <span className="font-semibold text-emerald-900">No Local:</span>
                  <strong className="text-emerald-950 ml-auto">{stats.presente}</strong>
                </div>

                <div className="flex items-center gap-2 p-1.5 rounded bg-red-50 border border-red-200">
                  <span className="w-2.5 h-2.5 rounded-full bg-red-500 shrink-0" />
                  <span className="font-semibold text-red-900">Ausentes:</span>
                  <strong className="text-red-950 ml-auto">{stats.ausente}</strong>
                </div>

                <div className="flex items-center gap-2 p-1.5 rounded bg-amber-50 border border-amber-200">
                  <span className="w-2.5 h-2.5 rounded-full bg-amber-500 shrink-0" />
                  <span className="font-semibold text-amber-900">Transferidos:</span>
                  <strong className="text-amber-950 ml-auto">{stats.transferido}</strong>
                </div>

                <div className="flex items-center gap-2 p-1.5 rounded bg-slate-100 border border-slate-200">
                  <span className="w-2.5 h-2.5 rounded-full bg-slate-400 shrink-0" />
                  <span className="font-semibold text-slate-700">Pendentes:</span>
                  <strong className="text-slate-900 ml-auto">{stats.pendente}</strong>
                </div>
              </div>
            </div>
          </div>

          {/* Quick Timeline Preview Card inside Overview */}
          <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-2xs">
            <div className="flex items-center justify-between mb-3 pb-2 border-b border-slate-100">
              <div>
                <h4 className="text-sm font-extrabold text-slate-900 flex items-center gap-1.5">
                  <TrendingUp className="w-4 h-4 text-orange-600" />
                  Evolução Histórica do Patrimônio Imobilizado (Curva Cumulativa)
                </h4>
                <p className="text-xs text-slate-500 font-medium">
                  Crescimento do valor imobilizado e incorporação de bens ao longo dos anos de aquisição
                </p>
              </div>
              <button
                onClick={() => setActiveTab('timeline')}
                className="text-xs font-bold text-orange-600 hover:text-orange-700 flex items-center gap-1 cursor-pointer"
              >
                <span>Ver Linha do Tempo Completa</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={timelineData.series} margin={{ top: 10, right: 30, left: 20, bottom: 0 }}>
                  <defs>
                    <linearGradient id="colorVal" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#ea580c" stopOpacity={0.4} />
                      <stop offset="95%" stopColor="#ea580c" stopOpacity={0} />
                    </linearGradient>
                    <linearGradient id="colorCount" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                  <XAxis dataKey="yearLabel" tick={{ fontSize: 11, fill: '#64748b' }} />
                  <YAxis
                    yAxisId="left"
                    tickFormatter={(v) => `R$ ${(v / 1000).toFixed(0)}k`}
                    tick={{ fontSize: 11, fill: '#ea580c' }}
                  />
                  <YAxis
                    yAxisId="right"
                    orientation="right"
                    tick={{ fontSize: 11, fill: '#3b82f6' }}
                  />
                  <Tooltip
                    formatter={(value: number, name: string) => {
                      if (name === 'Valor Acumulado (R$)') {
                        return [`R$ ${Number(value).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`, name];
                      }
                      return [`${value} itens`, name];
                    }}
                    labelFormatter={(label) => `Ano de Aquisição: ${label}`}
                    contentStyle={{ backgroundColor: '#0f172a', color: '#fff', borderRadius: '8px', fontSize: '12px' }}
                  />
                  <Legend />
                  <Area
                    yAxisId="left"
                    type="monotone"
                    dataKey="cumulativeValue"
                    stroke="#ea580c"
                    strokeWidth={2}
                    fillOpacity={1}
                    fill="url(#colorVal)"
                    name="Valor Acumulado (R$)"
                  />
                  <Area
                    yAxisId="right"
                    type="monotone"
                    dataKey="cumulativeCount"
                    stroke="#3b82f6"
                    strokeWidth={2}
                    fillOpacity={1}
                    fill="url(#colorCount)"
                    name="Qtd. Acumulada de Bens"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      )}

      {/* TAB CONTENT 2: LINHA DO TEMPO DETALHADA */}
      {activeTab === 'timeline' && (
        <div className="space-y-5">
          {/* Timeline Filter Controls */}
          <div className="bg-white rounded-xl border border-slate-200 p-4 sm:p-5 shadow-2xs">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 pb-3 border-b border-slate-100">
              <div>
                <h4 className="text-sm font-extrabold text-slate-900 flex items-center gap-1.5">
                  <Clock className="w-4 h-4 text-orange-600" />
                  Linha do Tempo Cronológica de Incorporação & Aquisições
                </h4>
                <p className="text-xs text-slate-500 font-medium">
                  Marcos temporais das aquisições e distribuição por décadas e anos de tombamento
                </p>
              </div>

              {/* Decade Filter Pills */}
              <div className="flex flex-wrap items-center gap-1.5">
                {['ALL', 'Anos 1980 e anteriores', 'Anos 1990', 'Anos 2000', 'Anos 2010', 'Anos 2020+'].map((dec) => (
                  <button
                    key={dec}
                    onClick={() => {
                      setTimelinePeriodFilter(dec);
                      setSelectedTimelineYear(null);
                    }}
                    className={`px-2.5 py-1 rounded-md text-xs font-bold transition-all cursor-pointer border ${
                      timelinePeriodFilter === dec
                        ? 'bg-orange-600 text-white border-orange-600 shadow-2xs'
                        : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    {dec === 'ALL' ? 'Todas as Décadas' : dec}
                  </button>
                ))}
              </div>
            </div>

            {/* Annual Acquisition Volume Bar Chart */}
            <div className="pt-4">
              <div className="text-xs font-bold text-slate-700 mb-2">Volume de Bens Adquiridos por Ano:</div>
              <div className="h-56 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={timelineData.series} margin={{ top: 5, right: 20, left: 10, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                    <XAxis dataKey="yearLabel" tick={{ fontSize: 11, fill: '#64748b' }} />
                    <YAxis tick={{ fontSize: 11, fill: '#64748b' }} />
                    <Tooltip
                      formatter={(val: number, name: string) => {
                        if (name === 'Qtd. de Bens Adquiridos') return [`${val} itens`, name];
                        return [`R$ ${Number(val).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`, name];
                      }}
                      labelFormatter={(label) => `Exercício: ${label}`}
                      contentStyle={{ backgroundColor: '#0f172a', color: '#fff', borderRadius: '8px', fontSize: '12px' }}
                    />
                    <Bar
                      dataKey="count"
                      fill="#ea580c"
                      radius={[4, 4, 0, 0]}
                      name="Qtd. de Bens Adquiridos"
                      onClick={(data) => {
                        if (data && data.year) {
                          setSelectedTimelineYear(data.year);
                        }
                      }}
                    />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>

          {/* Timeline Cards Stream */}
          <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-2xs">
            <div className="flex items-center justify-between mb-4 pb-2 border-b border-slate-100">
              <div className="text-xs font-bold uppercase tracking-wider text-slate-500">
                Marcos Históricos & Lotes de Tombamento ({filteredTimelineCards.length} períodos registrados)
              </div>
              <span className="text-[11px] text-slate-400">Clique em um ano para abrir os bens correspondentes</span>
            </div>

            <div className="relative border-l-2 border-orange-200 ml-4 space-y-6 py-2">
              {filteredTimelineCards.map((node) => {
                const isSelected = selectedTimelineYear === node.year;
                return (
                  <div key={node.year} className="relative pl-6">
                    {/* Node Dot */}
                    <button
                      onClick={() => setSelectedTimelineYear(isSelected ? null : node.year)}
                      className={`absolute -left-[9px] top-1.5 w-4 h-4 rounded-full border-2 transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-orange-600 border-white ring-4 ring-orange-200'
                          : 'bg-white border-orange-500 hover:bg-orange-50'
                      }`}
                      title={`Ver bens do ano ${node.year}`}
                    />

                    {/* Timeline Card */}
                    <div
                      onClick={() => setSelectedTimelineYear(isSelected ? null : node.year)}
                      className={`p-4 rounded-xl border transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-orange-50/70 border-orange-400 shadow-xs'
                          : 'bg-slate-50 hover:bg-slate-100/80 border-slate-200'
                      }`}
                    >
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                        <div className="flex items-center gap-2.5">
                          <span className="px-2.5 py-1 bg-slate-900 text-white font-black text-xs rounded-md shadow-2xs">
                            Ano {node.year}
                          </span>
                          <span className="text-xs font-bold text-slate-700">{node.decade}</span>
                          <span className="px-2 py-0.5 rounded text-[11px] font-extrabold bg-orange-100 text-orange-800 border border-orange-200">
                            {node.count} {node.count === 1 ? 'bem incorporado' : 'bens incorporados'}
                          </span>
                        </div>

                        <div className="text-right flex items-center gap-3">
                          <div>
                            <span className="text-[10px] uppercase font-bold text-slate-400 block">Total do Lote</span>
                            <span className="text-xs font-black text-slate-900">
                              R$ {node.totalValue.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                            </span>
                          </div>
                          {isSelected ? (
                            <ChevronUp className="w-4 h-4 text-orange-600" />
                          ) : (
                            <ChevronDown className="w-4 h-4 text-slate-400" />
                          )}
                        </div>
                      </div>

                      {/* Sample Items pill list */}
                      <div className="mt-2.5 pt-2 border-t border-slate-200/60 flex flex-wrap items-center gap-1.5 text-xs text-slate-600">
                        <span className="font-semibold text-slate-500 text-[11px]">Exemplos do lote:</span>
                        {node.items.slice(0, 3).map((item, idx) => (
                          <span
                            key={idx}
                            className="bg-white px-2 py-0.5 rounded text-[11px] font-medium border border-slate-200 text-slate-800"
                          >
                            <strong>#{item.patrimonio}</strong> {item.descricao.slice(0, 30)}...
                          </span>
                        ))}
                        {node.items.length > 3 && (
                          <span className="text-[10px] font-bold text-orange-600">
                            +{node.items.length - 3} outros
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Drilldown Drawer for Selected Timeline Year */}
          {selectedTimelineYear && (
            <div className="bg-white rounded-xl border-2 border-orange-400 p-5 shadow-md">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-1 bg-orange-600 text-white font-black text-xs rounded">
                    Ano {selectedTimelineYear}
                  </span>
                  <h4 className="text-sm font-extrabold text-slate-900">
                    Bens Incorporados no Exercício ({activeYearItems.length} itens)
                  </h4>
                </div>

                <div className="flex items-center gap-2">
                  <div className="relative">
                    <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      placeholder="Filtrar nesta lista..."
                      className="pl-8 pr-3 py-1 bg-slate-50 border border-slate-200 rounded-md text-xs font-medium focus:outline-none focus:ring-1 focus:ring-orange-500"
                    />
                  </div>
                  <button
                    onClick={() => setSelectedTimelineYear(null)}
                    className="p-1 text-slate-400 hover:text-slate-600 rounded"
                    title="Fechar detalhamento"
                  >
                    ✕
                  </button>
                </div>
              </div>

              {/* Table of items */}
              <div className="overflow-x-auto mt-3">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
                      <th className="py-2 px-3">Nº Patrimônio</th>
                      <th className="py-2 px-3">Descrição / Especificação</th>
                      <th className="py-2 px-3">Gerência</th>
                      <th className="py-2 px-3">Categoria</th>
                      <th className="py-2 px-3">Data Aquisição</th>
                      <th className="py-2 px-3 text-right">Valor Base</th>
                      <th className="py-2 px-3 text-center">Status ({selectedYear})</th>
                      <th className="py-2 px-3 text-center">Ações</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {activeYearItems.map((item) => {
                      const insp = inspections[`${item.id}-${selectedYear}`] || inspections[`${item.id}_${selectedYear}`];
                      return (
                        <tr key={item.id} className="hover:bg-slate-50">
                          <td className="py-2 px-3 font-mono font-black text-slate-900">
                            {item.patrimonio}
                          </td>
                          <td className="py-2 px-3 text-slate-800 font-medium max-w-xs truncate">
                            {item.descricao}
                          </td>
                          <td className="py-2 px-3">
                            <span className="px-1.5 py-0.5 bg-slate-200 text-slate-800 font-bold text-[10px] rounded">
                              {item.gerenciaCode}
                            </span>
                          </td>
                          <td className="py-2 px-3 text-slate-600">{item.categoria || 'Geral'}</td>
                          <td className="py-2 px-3 text-slate-600 font-mono">{item.dtAquisicao}</td>
                          <td className="py-2 px-3 text-right font-bold text-slate-900 font-mono">
                            R$ {(item.vlBase || 0).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                          </td>
                          <td className="py-2 px-3 text-center">
                            {insp?.status === 'presente' ? (
                              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800">
                                No Local
                              </span>
                            ) : insp?.status === 'ausente' ? (
                              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-red-100 text-red-800">
                                Ausente
                              </span>
                            ) : insp?.status === 'transferido' ? (
                              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800">
                                Transferido
                              </span>
                            ) : (
                              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-100 text-slate-600">
                                Pendente
                              </span>
                            )}
                          </td>
                          <td className="py-2 px-3 text-center">
                            {onOpenDetails && (
                              <button
                                onClick={() => onOpenDetails(item)}
                                className="px-2 py-1 bg-slate-100 hover:bg-orange-100 text-slate-700 hover:text-orange-800 rounded font-bold text-[10px] transition-colors cursor-pointer"
                              >
                                Ver Ficha
                              </button>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB CONTENT 3: COMPARATIVO ENTRE GERÊNCIAS */}
      {activeTab === 'comparison' && (
        <div className="space-y-5">
          {/* Comparison Cards for TGC, TDO, TDM */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {gerenciasComparison.map((dept) => (
              <div
                key={dept.code}
                className={`bg-white rounded-xl border p-5 shadow-2xs flex flex-col justify-between transition-all ${
                  selectedGerencia === dept.code
                    ? 'border-2 border-orange-500 ring-2 ring-orange-100'
                    : 'border-slate-200'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                    <div>
                      <span className="px-2 py-0.5 bg-orange-600 text-white font-black text-xs rounded">
                        {dept.code}
                      </span>
                      <h4 className="text-sm font-extrabold text-slate-900 mt-1">{dept.name}</h4>
                    </div>
                  </div>

                  <div className="py-4 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-slate-500 font-medium">Carga Patrimonial:</span>
                      <strong className="text-sm text-slate-900">{dept.totalCount} bens</strong>
                    </div>

                    <div className="flex items-center justify-between">
                      <span className="text-xs text-slate-500 font-medium">Valor Total:</span>
                      <strong className="text-sm text-orange-700 font-mono">{dept.formattedValue}</strong>
                    </div>

                    <div className="flex items-center justify-between">
                      <span className="text-xs text-slate-500 font-medium">Progresso da Vistoria:</span>
                      <span className="text-xs font-black text-emerald-600">{dept.percentVistoriado}% concluído</span>
                    </div>

                    {/* Progress Bar */}
                    <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
                      <div
                        className="bg-emerald-500 h-2 rounded-full transition-all"
                        style={{ width: `${dept.percentVistoriado}%` }}
                      />
                    </div>

                    <div className="pt-2 border-t border-slate-100 text-[11px] text-slate-500 space-y-1">
                      <div>
                        <strong>Gerente:</strong> {dept.gerenteNome}
                      </div>
                      <div>
                        <strong>Fiscal:</strong> {dept.fiscalNome}
                      </div>
                    </div>
                  </div>
                </div>

                <button
                  onClick={() => {
                    setSelectedGerencia(dept.code);
                    setActiveTab('overview');
                  }}
                  className="w-full py-2 mt-2 bg-slate-50 hover:bg-orange-50 text-slate-700 hover:text-orange-700 border border-slate-200 hover:border-orange-300 rounded-lg text-xs font-bold transition-all cursor-pointer"
                >
                  Filtrar Painel por {dept.code}
                </button>
              </div>
            ))}
          </div>

          {/* Comparative Bar Chart: Valor Total e Itens */}
          <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-2xs">
            <div className="flex items-center justify-between mb-4 pb-2 border-b border-slate-100">
              <div>
                <h4 className="text-sm font-extrabold text-slate-900 flex items-center gap-1.5">
                  <Layers className="w-4 h-4 text-orange-600" />
                  Comparativo de Carga Financeira & Patrimonial (TGC x TDO x TDM)
                </h4>
                <p className="text-xs text-slate-500 font-medium">
                  Relação de valor contábil imobilizado e bens inventariados entre divisões
                </p>
              </div>
            </div>

            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={gerenciasComparison} margin={{ top: 10, right: 30, left: 20, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                  <XAxis dataKey="shortName" tick={{ fontSize: 12, fill: '#334155', fontWeight: 'bold' }} />
                  <YAxis yAxisId="left" tickFormatter={(v) => `R$ ${(v / 1000).toFixed(0)}k`} />
                  <YAxis yAxisId="right" orientation="right" />
                  <Tooltip
                    formatter={(value: number, name: string) => {
                      if (name === 'Valor Imobilizado (R$)') {
                        return [`R$ ${Number(value).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`, name];
                      }
                      return [`${value} bens`, name];
                    }}
                    contentStyle={{ backgroundColor: '#0f172a', color: '#fff', borderRadius: '8px', fontSize: '12px' }}
                  />
                  <Legend />
                  <Bar
                    yAxisId="left"
                    dataKey="totalVal"
                    fill="#ea580c"
                    radius={[4, 4, 0, 0]}
                    name="Valor Imobilizado (R$)"
                  />
                  <Bar
                    yAxisId="right"
                    dataKey="totalCount"
                    fill="#3b82f6"
                    radius={[4, 4, 0, 0]}
                    name="Total de Bens Cadastrados"
                  />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      )}

      {/* TAB CONTENT 4: VISTORIA & LAUDOS */}
      {activeTab === 'inspection' && (
        <div className="space-y-5">
          <div className="bg-white rounded-xl border border-slate-200 p-5 shadow-2xs">
            <div className="flex items-center justify-between mb-4 pb-2 border-b border-slate-100">
              <div>
                <h4 className="text-sm font-extrabold text-slate-900 flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-orange-600" />
                  Quadro de Governança & Conformidade do Inventário ({selectedYear})
                </h4>
                <p className="text-xs text-slate-500 font-medium">
                  Status de fechamento das vistorias, fiscais responsáveis e conformidade com as normas COMLURB
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Box 1: Indicadores Oficiais */}
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-3">
                <div className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                  Documento & Exercício Auditado
                </div>
                <div className="space-y-2 text-xs text-slate-600">
                  <div className="flex justify-between py-1 border-b border-slate-200/60">
                    <span>Código do Laudo:</span>
                    <strong className="text-slate-900 font-mono">{auditSession.codigoDocumento || 'COML02.2.3.12'}</strong>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-200/60">
                    <span>Fiscal de Patrimônio:</span>
                    <strong className="text-slate-900">
                      {auditSession.fiscalResponsavel || 'Wagner J. Jardim'} ({auditSession.matriculaFiscal || 'Matr. 892.410-3'})
                    </strong>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-200/60">
                    <span>Taxa Geral de Vistoria:</span>
                    <strong className="text-emerald-700 font-bold">{stats.taxaVistoria.toFixed(1)}% do acervo</strong>
                  </div>
                  <div className="flex justify-between py-1">
                    <span>Taxa de Localização (Sim/Conforme):</span>
                    <strong className="text-emerald-700 font-bold">{stats.taxaConformidade.toFixed(1)}% dos vistoriados</strong>
                  </div>
                </div>
              </div>

              {/* Box 2: Diagnóstico das Plaquetas */}
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-3">
                <div className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                  Diagnóstico de Identificação Física (Plaquetas)
                </div>
                <div className="space-y-2 text-xs text-slate-600">
                  <div className="flex justify-between py-1 border-b border-slate-200/60">
                    <span>Plaquetas Legíveis / Em Ordem:</span>
                    <strong className="text-emerald-700 font-bold">{stats.plaquetas.plaquetaLegivel}</strong>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-200/60">
                    <span>Plaquetas Danificadas (Necessitam Troca):</span>
                    <strong className="text-amber-700 font-bold">{stats.plaquetas.plaquetaDanificada}</strong>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-200/60">
                    <span>Bens Sem Plaqueta (Identificação Urgente):</span>
                    <strong className="text-red-700 font-bold">{stats.plaquetas.semPlaqueta}</strong>
                  </div>
                  <div className="flex justify-between py-1">
                    <span>Compatibilidade Pimaco 6181:</span>
                    <strong className="text-slate-900 font-bold">100% dos bens elegíveis</strong>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
