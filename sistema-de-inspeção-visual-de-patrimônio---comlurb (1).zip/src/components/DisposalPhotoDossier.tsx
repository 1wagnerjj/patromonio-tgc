import React, { useState, useRef, useEffect, useMemo } from 'react';
import {
  Camera,
  Upload,
  Printer,
  FileDown,
  Plus,
  Trash2,
  RotateCw,
  ZoomIn,
  Edit2,
  CheckCircle2,
  AlertTriangle,
  Search,
  Building,
  RefreshCw,
  ExternalLink,
  Info,
  ChevronLeft,
  ChevronRight,
  ShieldCheck,
  Eye,
  Sliders,
  X,
  FileText,
  LayoutGrid,
  Undo2,
  Filter,
  Save,
} from 'lucide-react';
import { AssetItem, DisposalBatch, DisposalPhotoItem, DepartmentInfo } from '../types';
import {
  compressAndResizeImage,
  getAssetDisposalPhoto,
  openDisposalDossierPrintWindow,
  downloadDisposalDossierHtml,
} from '../utils/disposalPhotoEngine';

interface DisposalPhotoDossierProps {
  assets: AssetItem[];
  departments: DepartmentInfo[];
  selectedYear: number;
  selectedGerencia?: string;
  onSelectGerencia?: (gerencia: string) => void;
  onUpdateAsset?: (assetId: string, updates: Partial<AssetItem>) => void;
  onClose?: () => void;
  disposalPhotos?: Record<string, string>;
  onSavePhoto?: (assetId: string, patrimonio: string, photoUrl: string) => Promise<void> | void;
  disposalBatchMeta?: Record<string, any>;
  onUpdateDisposalBatchMeta?: (gerencia: string, meta: any) => void;
  onManualSaveAll?: () => Promise<void> | void;
  isSaving?: boolean;
}

const GERENCIA_META: Record<string, { title: string; dept: string; manager: string; matricula: string }> = {
  TDM: {
    title: 'Fotos das ferramentas selecionadas para baixa do Lote: 001 - TDM',
    dept: 'TDM - DIVISAO DE MANUTENÇÃO',
    manager: 'LUCIANO NELVO SILVA',
    matricula: 'Matr. 892.410-3',
  },
  TGC: {
    title: 'Fotos dos bens selecionados para baixa do Lote: 001 - TGC',
    dept: 'TGC - GERÊNCIA DE ECOPARQUE DO CAJU',
    manager: 'CARLOS EDUARDO PEREIRA',
    matricula: 'Matr. 745.120-1',
  },
  TDO: {
    title: 'Fotos dos bens selecionados para baixa do Lote: 001 - TDO',
    dept: 'TDO - DIVISAO DE OPERAÇÃO',
    manager: 'MARCOS ANTÔNIO SOUZA',
    matricula: 'Matr. 812.340-9',
  },
  ALL: {
    title: 'COMLURB - Dossiê Fotográfico Consolidado de Baixas (TGC, TDM, TDO)',
    dept: 'COMLURB - COMISSÃO PERMANENTE DE DESFAZIMENTO',
    manager: 'LUCIANO NELVO SILVA / CARLOS E. PEREIRA / MARCOS A. SOUZA',
    matricula: 'Comissão Especial Portaria nº 084/2024',
  },
};

export const DisposalPhotoDossier: React.FC<DisposalPhotoDossierProps> = ({
  assets,
  departments,
  selectedYear,
  selectedGerencia,
  onSelectGerencia,
  onUpdateAsset,
  onClose,
  disposalPhotos,
  onSavePhoto,
  disposalBatchMeta,
  onUpdateDisposalBatchMeta,
  onManualSaveAll,
  isSaving = false,
}) => {
  // Selected Gerência Filter: ALL, TGC, TDM, or TDO
  const [activeGerencia, setActiveGerencia] = useState<string>(() => {
    if (selectedGerencia && ['TGC', 'TDM', 'TDO'].includes(selectedGerencia)) {
      return selectedGerencia;
    }
    return 'ALL';
  });

  // Sync if prop changes externally
  useEffect(() => {
    if (selectedGerencia && ['TGC', 'TDM', 'TDO', 'ALL'].includes(selectedGerencia)) {
      setActiveGerencia(selectedGerencia);
    }
  }, [selectedGerencia]);

  // Persistent custom photos mapping: assetId/patrimonio -> base64 data URI
  const [customPhotos, setCustomPhotos] = useState<Record<string, string>>(() => {
    try {
      const saved = localStorage.getItem('comlurb_disposal_photos_v2');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error('Error loading disposal photos from localStorage', e);
    }
    return {};
  });

  // Synchronize when parent passes disposalPhotos
  useEffect(() => {
    if (disposalPhotos && Object.keys(disposalPhotos).length > 0) {
      setCustomPhotos((prev) => ({ ...prev, ...disposalPhotos }));
    }
  }, [disposalPhotos]);

  // Custom lot metadata overrides per gerência if edited by user
  const [customMetadata, setCustomMetadata] = useState<Record<string, Partial<DisposalBatch>>>(() => {
    try {
      const saved = localStorage.getItem('comlurb_disposal_batch_meta_v2');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      console.error(e);
    }
    return {};
  });

  // Synchronize when parent passes disposalBatchMeta
  useEffect(() => {
    if (disposalBatchMeta && Object.keys(disposalBatchMeta).length > 0) {
      setCustomMetadata((prev) => ({ ...prev, ...disposalBatchMeta }));
    }
  }, [disposalBatchMeta]);

  // STRICT REQUIREMENT: Only include assets from TGC, TDM, TDO that are marked as 'baixado'
  const allDisposedAssets = useMemo(() => {
    return assets.filter(
      (a) => a.situacao === 'baixado' && ['TGC', 'TDM', 'TDO'].includes(a.gerenciaCode)
    );
  }, [assets]);

  // Counts of baixados per gerência
  const counts = useMemo(() => {
    return {
      ALL: allDisposedAssets.length,
      TGC: allDisposedAssets.filter((a) => a.gerenciaCode === 'TGC').length,
      TDM: allDisposedAssets.filter((a) => a.gerenciaCode === 'TDM').length,
      TDO: allDisposedAssets.filter((a) => a.gerenciaCode === 'TDO').length,
    };
  }, [allDisposedAssets]);

  // Filtered by current tab
  const activeDisposedAssets = useMemo(() => {
    if (activeGerencia === 'ALL') return allDisposedAssets;
    return allDisposedAssets.filter((a) => a.gerenciaCode === activeGerencia);
  }, [allDisposedAssets, activeGerencia]);

  // Build the batch dynamically with incorporated photos
  const currentBatch: DisposalBatch = useMemo(() => {
    const meta = GERENCIA_META[activeGerencia] || GERENCIA_META.ALL;
    const override = customMetadata[activeGerencia] || {};

    const items: DisposalPhotoItem[] = activeDisposedAssets.map((asset) => ({
      id: `item-${asset.id}`,
      assetId: asset.id,
      patrimonio: asset.patrimonio,
      descricao: asset.descricao,
      complemento: asset.complemento,
      gerenciaCode: asset.gerenciaCode,
      motivoBaixa: asset.motivoBaixa || 'Inservível / Sucata para baixa',
      fotoUrl: getAssetDisposalPhoto(asset, customPhotos),
      dataFoto: asset.dtBaixa || '2024-11-01',
    }));

    return {
      id: `lote-${activeGerencia.toLowerCase()}`,
      loteNumero: override.loteNumero || '001',
      processoNumero: override.processoNumero || '01/500.184/2024',
      tituloDocumento: override.tituloDocumento || meta.title,
      departamento: override.departamento || meta.dept,
      dataAssinatura: override.dataAssinatura || '01/11/2024 às 08:38:01',
      responsavelAssinatura: override.responsavelAssinatura || meta.manager,
      matriculaResponsavel: override.matriculaResponsavel || meta.matricula,
      documentoNumero: override.documentoNumero || '83deb14.63215849-7374',
      urlAutenticidade: override.urlAutenticidade || 'https://processos.rio.rj.gov.br/autenticidade',
      items,
    };
  }, [activeDisposedAssets, activeGerencia, customMetadata, customPhotos]);

  // UI States
  const [viewMode, setViewMode] = useState<'official_sheet' | 'gallery'>('official_sheet');
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [feedback, setFeedback] = useState<{ type: 'success' | 'info' | 'error'; text: string } | null>(null);

  // Modals
  const [isLiveCameraOpen, setIsLiveCameraOpen] = useState<boolean>(false);
  const [cameraTargetAssetId, setCameraTargetAssetId] = useState<string | null>(null);
  const [isAddDisposalModalOpen, setIsAddDisposalModalOpen] = useState<boolean>(false);
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState<boolean>(false);
  const [editingItem, setEditingItem] = useState<DisposalPhotoItem | null>(null);
  const [zoomedPhoto, setZoomedPhoto] = useState<{ url: string; title: string } | null>(null);

  // Signature settings form state
  const [signatureForm, setSignatureForm] = useState({
    responsavelAssinatura: '',
    matriculaResponsavel: '',
    dataAssinatura: '',
    documentoNumero: '',
    processoNumero: '',
    tituloDocumento: '',
    departamento: '',
    applyToAll: false,
  });

  const handleOpenSettingsModal = () => {
    setSignatureForm({
      responsavelAssinatura: currentBatch.responsavelAssinatura || '',
      matriculaResponsavel: currentBatch.matriculaResponsavel || '',
      dataAssinatura: currentBatch.dataAssinatura || '',
      documentoNumero: currentBatch.documentoNumero || '',
      processoNumero: currentBatch.processoNumero || '',
      tituloDocumento: currentBatch.tituloDocumento || '',
      departamento: currentBatch.departamento || '',
      applyToAll: false,
    });
    setIsSettingsModalOpen(true);
  };

  const handleSaveSignatureSettings = () => {
    const targets = signatureForm.applyToAll ? ['TGC', 'TDM', 'TDO', 'ALL'] : [activeGerencia];

    setCustomMetadata((prev) => {
      const updatedAll = { ...prev };
      targets.forEach((g) => {
        updatedAll[g] = {
          ...(updatedAll[g] || {}),
          responsavelAssinatura: signatureForm.responsavelAssinatura.trim(),
          matriculaResponsavel: signatureForm.matriculaResponsavel.trim(),
          dataAssinatura: signatureForm.dataAssinatura.trim(),
          documentoNumero: signatureForm.documentoNumero.trim(),
          processoNumero: signatureForm.processoNumero.trim(),
          tituloDocumento: signatureForm.tituloDocumento.trim(),
          departamento: signatureForm.departamento.trim(),
        };
        onUpdateDisposalBatchMeta?.(g, updatedAll[g]);
      });

      try {
        localStorage.setItem('comlurb_disposal_batch_meta_v2', JSON.stringify(updatedAll));
      } catch (err) {
        console.error('Erro ao salvar metadados no localStorage:', err);
      }
      return updatedAll;
    });

    onManualSaveAll?.();

    setFeedback({
      type: 'success',
      text: `Nome "${signatureForm.responsavelAssinatura}" e dados da assinatura salvos com sucesso!`,
    });
    setIsSettingsModalOpen(false);
  };

  // Asset picker candidate search state for "+ Baixar Patrimônio"
  const [candidateSearchTerm, setCandidateSearchTerm] = useState<string>('');
  const [candidateDeptFilter, setCandidateDeptFilter] = useState<string>(activeGerencia !== 'ALL' ? activeGerencia : 'ALL');
  const [selectedCandidate, setSelectedCandidate] = useState<AssetItem | null>(null);
  const [disposalReasonInput, setDisposalReasonInput] = useState<string>('Inservível por desgaste irrecuperável');
  const [disposalDateInput, setDisposalDateInput] = useState<string>(new Date().toISOString().slice(0, 10));

  // Video & File refs
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const hiddenFileInputRef = useRef<HTMLInputElement | null>(null);
  const activeUploadAssetIdRef = useRef<string | null>(null);

  // Auto-dismiss feedback
  useEffect(() => {
    if (!feedback) return;
    const timer = setTimeout(() => setFeedback(null), 4000);
    return () => clearTimeout(timer);
  }, [feedback]);

  // Handle Photo Save
  const saveAssetPhoto = async (assetId: string, patrimonio: string, photoUrl: string) => {
    setCustomPhotos((prev) => {
      const next = { ...prev, [assetId]: photoUrl, [patrimonio]: photoUrl };
      try {
        localStorage.setItem('comlurb_disposal_photos_v2', JSON.stringify(next));
      } catch (err) {
        console.warn('LocalStorage quota limit reached, saving via IndexedDB & Cloud', err);
      }
      return next;
    });
    onUpdateAsset?.(assetId, { fotoUrl: photoUrl });
    if (onSavePhoto) {
      await onSavePhoto(assetId, patrimonio, photoUrl);
    }
    setFeedback({ type: 'success', text: `Foto do patrimônio ${patrimonio} salva e gravada com sucesso!` });
  };

  // Image upload handler
  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    try {
      const targetAssetId = activeUploadAssetIdRef.current;
      if (targetAssetId) {
        const file = files[0];
        const compressedBase64 = await compressAndResizeImage(file);
        const targetAsset = assets.find((a) => a.id === targetAssetId);
        saveAssetPhoto(targetAssetId, targetAsset?.patrimonio || targetAssetId, compressedBase64);
      }
    } catch (err) {
      console.error(err);
      setFeedback({ type: 'error', text: 'Falha ao processar arquivo de imagem.' });
    } finally {
      if (hiddenFileInputRef.current) hiddenFileInputRef.current.value = '';
      activeUploadAssetIdRef.current = null;
    }
  };

  // Trigger file selection for an asset
  const triggerAssetUpload = (assetId: string) => {
    activeUploadAssetIdRef.current = assetId;
    hiddenFileInputRef.current?.click();
  };

  // Rotate photo 90 degrees
  const handleRotatePhoto = async (item: DisposalPhotoItem) => {
    if (!item.fotoUrl || !item.assetId) return;
    try {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        canvas.width = img.height;
        canvas.height = img.width;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;
        ctx.translate(canvas.width / 2, canvas.height / 2);
        ctx.rotate((90 * Math.PI) / 180);
        ctx.drawImage(img, -img.width / 2, -img.height / 2);
        const rotatedUrl = canvas.toDataURL('image/jpeg', 0.85);
        saveAssetPhoto(item.assetId!, item.patrimonio, rotatedUrl);
      };
      img.src = item.fotoUrl;
    } catch (err) {
      console.error(err);
    }
  };

  // Live Camera handlers
  const startLiveCamera = async (targetAssetId?: string) => {
    setCameraTargetAssetId(targetAssetId || null);
    setIsLiveCameraOpen(true);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: { ideal: 'environment' },
          width: { ideal: 1280 },
          height: { ideal: 720 },
        },
      });
      mediaStreamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }
    } catch (err) {
      console.warn('Direct webcam/environment stream not available, opening native camera trigger', err);
      setIsLiveCameraOpen(false);
      activeUploadAssetIdRef.current = targetAssetId || null;
      hiddenFileInputRef.current?.click();
    }
  };

  const stopLiveCamera = () => {
    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach((t) => t.stop());
      mediaStreamRef.current = null;
    }
    setIsLiveCameraOpen(false);
    setCameraTargetAssetId(null);
  };

  const captureLiveCameraShot = () => {
    if (!videoRef.current || !cameraTargetAssetAsset) return;
    const video = videoRef.current;
    const canvas = document.createElement('canvas');
    canvas.width = video.videoWidth || 800;
    canvas.height = video.videoHeight || 600;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    const dataUrl = canvas.toDataURL('image/jpeg', 0.85);

    saveAssetPhoto(cameraTargetAssetAsset.id, cameraTargetAssetAsset.patrimonio, dataUrl);
    stopLiveCamera();
  };

  const cameraTargetAssetAsset = useMemo(() => {
    if (!cameraTargetAssetId) return null;
    return assets.find((a) => a.id === cameraTargetAssetId) || null;
  }, [cameraTargetAssetId, assets]);

  // Revert Baixa: sets situacao back to 'ativo' and removes from dossier
  const handleRevertDisposal = (assetId: string, patrimonio: string) => {
    onUpdateAsset?.(assetId, {
      situacao: 'ativo',
      motivoBaixa: undefined,
      dtBaixa: undefined,
    });
    setTimeout(() => {
      onManualSaveAll?.();
    }, 50);
    setFeedback({
      type: 'info',
      text: `Patrimônio ${patrimonio} reativado no inventário ativo e retirado das fotos de baixa.`,
    });
  };

  // Confirm Baixa for a candidate asset (incorporates it into this dossier)
  const handleConfirmDisposalCandidate = () => {
    if (!selectedCandidate) return;
    onUpdateAsset?.(selectedCandidate.id, {
      situacao: 'baixado',
      motivoBaixa: disposalReasonInput || 'Inservível para desfazimento',
      dtBaixa: disposalDateInput || new Date().toISOString().slice(0, 10),
    });
    setTimeout(() => {
      onManualSaveAll?.();
    }, 50);
    setFeedback({
      type: 'success',
      text: `Patrimônio ${selectedCandidate.patrimonio} (${selectedCandidate.gerenciaCode}) baixado e salvo com sucesso!`,
    });
    setSelectedCandidate(null);
    setIsAddDisposalModalOpen(false);
  };

  // Pagination calculation for 6 items per sheet (2 cols x 3 rows)
  const itemsPerPage = 6;
  const totalPages = Math.max(1, Math.ceil(currentBatch.items.length / itemsPerPage));
  const currentSheetItems = useMemo(() => {
    const start = (currentPage - 1) * itemsPerPage;
    return currentBatch.items.slice(start, start + itemsPerPage);
  }, [currentBatch.items, currentPage]);

  // Candidates for "+ Baixar Bem": Must be TGC, TDM or TDO, and currently NOT baixado
  const candidateAssets = useMemo(() => {
    return assets.filter((asset) => {
      if (!['TGC', 'TDM', 'TDO'].includes(asset.gerenciaCode)) return false;
      if (asset.situacao === 'baixado') return false; // already baixado
      if (candidateDeptFilter !== 'ALL' && asset.gerenciaCode !== candidateDeptFilter) return false;
      if (candidateSearchTerm) {
        const term = candidateSearchTerm.toLowerCase();
        const matchPatr = asset.patrimonio.toLowerCase().includes(term);
        const matchDesc = asset.descricao.toLowerCase().includes(term);
        if (!matchPatr && !matchDesc) return false;
      }
      return true;
    });
  }, [assets, candidateDeptFilter, candidateSearchTerm]);

  return (
    <div className="space-y-4">
      {/* Hidden File Input for Image Upload / Camera Capture */}
      <input
        ref={hiddenFileInputRef}
        type="file"
        accept="image/*"
        capture="environment"
        className="hidden"
        onChange={handleFileSelect}
      />

      {/* Top Banner & Action Bar */}
      <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs space-y-3">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-black uppercase tracking-wider bg-orange-100 text-orange-800 border border-orange-200">
                Fotos de Baixa • Dossiê Oficial
              </span>
              <span className="flex items-center gap-1 text-xs font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
                <ShieldCheck className="w-3.5 h-3.5" />
                COMLURB • SEI-Rio
              </span>
            </div>
            <h2 className="text-xl font-black text-slate-900 tracking-tight">
              Fotos para Processo de Baixa de Patrimônio
            </h2>
            <p className="text-xs text-slate-500">
              Fotos incorporadas das gerências <strong>TGC</strong>, <strong>TDM</strong> e <strong>TDO</strong> exclusivamente dos patrimônios baixados, formatadas para impressão A4 oficial.
            </p>
          </div>

          {/* Primary Action Buttons */}
          <div className="flex flex-wrap items-center gap-2">
            {/* Dedicated Manual Save Button (User Explicit Request) */}
            {onManualSaveAll && (
              <button
                type="button"
                onClick={() => {
                  onManualSaveAll();
                  setFeedback({
                    type: 'success',
                    text: 'Todas as modificações, baixas e fotos foram salvas com sucesso no servidor e no seu navegador!',
                  });
                }}
                disabled={isSaving}
                className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-black shadow-md transition-all cursor-pointer border ${
                  isSaving
                    ? 'bg-blue-600 text-white border-blue-700 opacity-90 cursor-wait'
                    : 'bg-emerald-600 hover:bg-emerald-700 text-white border-emerald-500'
                }`}
                title="Salvar todas as modificações, baixas e fotos na Nuvem e no Navegador agora"
              >
                {isSaving ? (
                  <RefreshCw className="w-4 h-4 text-white animate-spin" />
                ) : (
                  <Save className="w-4 h-4 text-white" />
                )}
                <span>{isSaving ? 'Salvando...' : 'Salvar Baixas e Fotos'}</span>
              </button>
            )}

            {/* Add / Baixar Bem from inventory */}
            <button
              type="button"
              onClick={() => {
                setCandidateDeptFilter(activeGerencia !== 'ALL' ? activeGerencia : 'ALL');
                setIsAddDisposalModalOpen(true);
              }}
              className="flex items-center gap-1.5 px-3.5 py-2 bg-slate-900 hover:bg-black text-white rounded-xl text-xs font-bold shadow-xs transition-colors cursor-pointer"
              title="Vincular e baixar bem de TGC, TDM ou TDO"
            >
              <Plus className="w-4 h-4 text-orange-400" />
              <span>Baixar Bem (TGC/TDM/TDO)</span>
            </button>

            {/* Print Official Document (A4) */}
            <button
              type="button"
              onClick={() => openDisposalDossierPrintWindow(currentBatch)}
              className="flex items-center gap-1.5 px-3.5 py-2 bg-amber-500 hover:bg-amber-600 text-slate-950 rounded-xl text-xs font-black shadow-xs transition-colors cursor-pointer border border-amber-600"
              title="Imprimir folha A4 oficial idêntica ao documento físico da COMLURB"
            >
              <Printer className="w-4 h-4" />
              <span>Imprimir Laudo A4</span>
            </button>

            {/* Download Offline HTML */}
            <button
              type="button"
              onClick={() => downloadDisposalDossierHtml(currentBatch)}
              className="flex items-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-300 rounded-xl text-xs font-bold transition-colors cursor-pointer"
              title="Baixar arquivo HTML completo com fotos embutidas para juntar ao processo"
            >
              <FileDown className="w-4 h-4 text-slate-600" />
              <span className="hidden sm:inline">Baixar HTML</span>
            </button>

            {/* Settings & Signatures */}
            <button
              type="button"
              onClick={handleOpenSettingsModal}
              className="flex items-center gap-1.5 px-3 py-2 bg-orange-50 hover:bg-orange-100 text-orange-800 border border-orange-200 hover:border-orange-300 rounded-xl text-xs font-bold transition-all cursor-pointer shadow-2xs"
              title="Configurar responsável pela assinatura, nomes, matrícula, data e processo"
            >
              <Edit2 className="w-3.5 h-3.5 text-orange-600" />
              <span>Editar Assinatura & Nomes</span>
            </button>

            {onClose && (
              <button
                type="button"
                onClick={onClose}
                className="p-2 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-xl transition-colors cursor-pointer"
                title="Fechar e voltar à tabela"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>

        {/* ========================================================================= */}
        {/* GERÊNCIA SELECTION BAR: TGC, TDM, TDO ONLY                                */}
        {/* ========================================================================= */}
        <div className="pt-2 border-t border-slate-100 flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-xs font-bold text-slate-600 flex items-center gap-1 mr-1">
              <Filter className="w-3.5 h-3.5 text-orange-600" />
              Gerências de Baixa:
            </span>

            {/* Todas as Gerências (TGC, TDM, TDO) */}
            <button
              type="button"
              onClick={() => {
                setActiveGerencia('ALL');
                onSelectGerencia?.('ALL');
                setCurrentPage(1);
              }}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                activeGerencia === 'ALL'
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <span>Todas as Gerências (TGC, TDM, TDO)</span>
              <span
                className={`text-[10px] px-1.5 py-0.2 rounded-full font-black ${
                  activeGerencia === 'ALL' ? 'bg-orange-500 text-white' : 'bg-slate-200 text-slate-700'
                }`}
              >
                {counts.ALL} baixados
              </span>
            </button>

            {/* TGC - Ecoparque Caju */}
            <button
              type="button"
              onClick={() => {
                setActiveGerencia('TGC');
                onSelectGerencia?.('TGC');
                setCurrentPage(1);
              }}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                activeGerencia === 'TGC'
                  ? 'bg-emerald-700 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <span>TGC - Ecoparque Caju</span>
              <span
                className={`text-[10px] px-1.5 py-0.2 rounded-full font-black ${
                  activeGerencia === 'TGC' ? 'bg-white text-emerald-800' : 'bg-slate-200 text-slate-700'
                }`}
              >
                {counts.TGC}
              </span>
            </button>

            {/* TDM - Divisão de Manutenção (Ferramentas) */}
            <button
              type="button"
              onClick={() => {
                setActiveGerencia('TDM');
                onSelectGerencia?.('TDM');
                setCurrentPage(1);
              }}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                activeGerencia === 'TDM'
                  ? 'bg-blue-700 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <span>TDM - Manutenção (Ferramentas)</span>
              <span
                className={`text-[10px] px-1.5 py-0.2 rounded-full font-black ${
                  activeGerencia === 'TDM' ? 'bg-white text-blue-800' : 'bg-slate-200 text-slate-700'
                }`}
              >
                {counts.TDM}
              </span>
            </button>

            {/* TDO - Divisão de Operação */}
            <button
              type="button"
              onClick={() => {
                setActiveGerencia('TDO');
                onSelectGerencia?.('TDO');
                setCurrentPage(1);
              }}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                activeGerencia === 'TDO'
                  ? 'bg-purple-700 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <span>TDO - Operação</span>
              <span
                className={`text-[10px] px-1.5 py-0.2 rounded-full font-black ${
                  activeGerencia === 'TDO' ? 'bg-white text-purple-800' : 'bg-slate-200 text-slate-700'
                }`}
              >
                {counts.TDO}
              </span>
            </button>
          </div>

          {/* View mode toggle */}
          <div className="flex items-center gap-2">
            <div className="flex items-center bg-slate-100 p-0.5 rounded-lg border border-slate-200">
              <button
                type="button"
                onClick={() => setViewMode('official_sheet')}
                className={`flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-bold transition-colors cursor-pointer ${
                  viewMode === 'official_sheet'
                    ? 'bg-white text-slate-900 shadow-2xs'
                    : 'text-slate-500 hover:text-slate-900'
                }`}
                title="Modo Folha A4 Oficial (Fiel ao Documento Físico da COMLURB)"
              >
                <FileText className="w-3.5 h-3.5 text-orange-600" />
                <span>Folha A4</span>
              </button>
              <button
                type="button"
                onClick={() => setViewMode('gallery')}
                className={`flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-bold transition-colors cursor-pointer ${
                  viewMode === 'gallery'
                    ? 'bg-white text-slate-900 shadow-2xs'
                    : 'text-slate-500 hover:text-slate-900'
                }`}
                title="Modo Galeria para Gerenciamento Rápido"
              >
                <LayoutGrid className="w-3.5 h-3.5 text-slate-700" />
                <span>Galeria</span>
              </button>
            </div>
          </div>
        </div>

        {/* Feedback Alert */}
        {feedback && (
          <div
            className={`p-3 rounded-xl text-xs font-bold flex items-center justify-between animate-in fade-in duration-200 ${
              feedback.type === 'success'
                ? 'bg-emerald-50 text-emerald-900 border border-emerald-200'
                : feedback.type === 'error'
                ? 'bg-rose-50 text-rose-900 border border-rose-200'
                : 'bg-blue-50 text-blue-900 border border-blue-200'
            }`}
          >
            <div className="flex items-center gap-2">
              {feedback.type === 'success' ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              ) : feedback.type === 'error' ? (
                <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
              ) : (
                <Info className="w-4 h-4 text-blue-600 shrink-0" />
              )}
              <span>{feedback.text}</span>
            </div>
            <button
              type="button"
              onClick={() => setFeedback(null)}
              className="text-slate-400 hover:text-slate-700 cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}
      </div>

      {/* ========================================================================= */}
      {/* MODE 1: OFFICIAL SHEET VIEW (EXACT MATCH OF THE PHYSICAL A4 DOCUMENT)    */}
      {/* ========================================================================= */}
      {viewMode === 'official_sheet' && (
        <div className="flex flex-col items-center">
          {/* Sheet Pagination Navigation Bar (if more than 6 items) */}
          {totalPages > 1 && (
            <div className="bg-white border border-slate-200 rounded-xl px-4 py-2 shadow-xs mb-3 flex items-center gap-3 text-xs font-bold text-slate-700 no-print">
              <span>Folha do Documento:</span>
              <button
                type="button"
                disabled={currentPage <= 1}
                onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                className="p-1 rounded bg-slate-100 hover:bg-slate-200 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <span className="font-mono text-orange-600">
                Página {currentPage} de {totalPages} ({currentBatch.items.length} itens no total)
              </span>
              <button
                type="button"
                disabled={currentPage >= totalPages}
                onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                className="p-1 rounded bg-slate-100 hover:bg-slate-200 disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
              <span className="text-slate-400">|</span>
              <span className="text-[11px] text-slate-500 font-normal">
                (Na impressão física A4 todas as folhas são geradas juntas com cabeçalho e rodapé)
              </span>
            </div>
          )}

          {/* The A4 Sheet Container */}
          <div className="w-full max-w-[840px] bg-white border border-slate-300 shadow-xl rounded-md p-8 sm:p-12 min-h-[1080px] flex flex-col justify-between relative transition-all">
            {/* Top Institutional Header */}
            <div>
              <div className="flex items-center gap-4 border-b border-slate-300 pb-3 mb-4">
                {/* Municipal Logo + COMLURB badge */}
                <div className="flex items-center gap-2.5 shrink-0">
                  <div className="flex items-center gap-1.5">
                    <div className="w-7 h-7 bg-slate-900 text-white flex items-center justify-center rounded-xs">
                      <Building className="w-4 h-4 text-white" />
                    </div>
                    <div className="flex flex-col leading-none">
                      <span className="font-black text-slate-900 text-base tracking-tight">Rio</span>
                      <span className="text-[7.5px] font-extrabold text-slate-600 tracking-wider">PREFEITURA</span>
                    </div>
                  </div>
                  <div className="bg-slate-900 text-white font-black text-xs px-2 py-1 rounded-xs tracking-wider">
                    COMLURB
                  </div>
                </div>

                {/* Official Address Info */}
                <div className="text-[10px] sm:text-[11px] text-slate-600 leading-tight pl-3 border-l border-slate-200">
                  <div className="font-bold text-slate-900">Companhia Municipal de Limpeza Urbana - COMLURB</div>
                  <div>Rua Major Ávila, 358 - Tijuca - CEP: 20511-010 Rio de Janeiro / RJ Brasil</div>
                  <div>Central de Atendimento: 1746 - www.rio.rj.gov.br/comlurb</div>
                </div>
              </div>

              {/* Main Document Title */}
              <div className="text-center my-3">
                <h1 className="text-sm sm:text-base font-black text-black tracking-tight uppercase">
                  {currentBatch.tituloDocumento}
                </h1>
                <div className="text-[11px] font-bold text-slate-600 mt-0.5">
                  {currentBatch.departamento}
                </div>
              </div>
            </div>

            {/* The 2-Column Photo Grid (Up to 6 items per page, matching physical photo format) */}
            <div className="grid grid-cols-2 gap-x-8 gap-y-6 my-auto py-3">
              {currentSheetItems.map((item, idx) => {
                const globalIndex = (currentPage - 1) * itemsPerPage + idx + 1;
                return (
                  <div key={item.id} className="flex flex-col items-center group relative">
                    {/* Gerência Badge */}
                    <div className="w-full flex items-center justify-between text-[10px] font-bold text-slate-500 mb-1">
                      <span className="bg-slate-100 text-slate-800 px-1.5 py-0.2 rounded border border-slate-200">
                        {item.gerenciaCode || activeGerencia}
                      </span>
                      <span className="text-slate-400">Baixado</span>
                    </div>

                    {/* Photo Container Frame */}
                    <div className="w-full h-48 sm:h-60 bg-slate-50 border border-slate-400 rounded-xs overflow-hidden flex items-center justify-center relative shadow-2xs">
                      <img
                        src={item.fotoUrl}
                        alt={`Item ${globalIndex} - ${item.descricao}`}
                        className="w-full h-full object-contain bg-white"
                      />

                      {/* Interactive Hover Toolbar */}
                      <div className="absolute inset-0 bg-slate-900/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-1.5 p-2 backdrop-blur-2xs no-print">
                        <button
                          type="button"
                          onClick={() => startLiveCamera(item.assetId)}
                          className="p-2 bg-orange-600 hover:bg-orange-700 text-white rounded-lg text-xs font-bold cursor-pointer transition-transform hover:scale-105"
                          title="Tirar foto com a câmera"
                        >
                          <Camera className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => triggerAssetUpload(item.assetId!)}
                          className="p-2 bg-white hover:bg-slate-100 text-slate-800 rounded-lg text-xs font-bold cursor-pointer transition-transform hover:scale-105"
                          title="Carregar foto de arquivo"
                        >
                          <Upload className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleRotatePhoto(item)}
                          className="p-2 bg-white hover:bg-slate-100 text-slate-800 rounded-lg text-xs font-bold cursor-pointer transition-transform hover:scale-105"
                          title="Girar foto 90°"
                        >
                          <RotateCw className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() =>
                            setZoomedPhoto({
                              url: item.fotoUrl,
                              title: `Item ${globalIndex} - ${item.descricao} (Pat: ${item.patrimonio})`,
                            })
                          }
                          className="p-2 bg-white hover:bg-slate-100 text-slate-800 rounded-lg text-xs font-bold cursor-pointer transition-transform hover:scale-105"
                          title="Ver em tamanho ampliado"
                        >
                          <ZoomIn className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => setEditingItem(item)}
                          className="p-2 bg-white hover:bg-slate-100 text-slate-800 rounded-lg text-xs font-bold cursor-pointer transition-transform hover:scale-105"
                          title="Editar motivo da baixa"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleRevertDisposal(item.assetId!, item.patrimonio)}
                          className="p-2 bg-amber-600 hover:bg-amber-700 text-white rounded-lg text-xs font-bold cursor-pointer transition-transform hover:scale-105"
                          title="Reverter Baixa (reativar no inventário e remover do laudo)"
                        >
                          <Undo2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                    {/* Captions Beneath Each Photo (Formatted strictly as in user image) */}
                    <div className="mt-2 text-center text-xs leading-snug w-full">
                      <div className="font-black text-black">
                        Item: {globalIndex} - {item.descricao}
                      </div>
                      <div className="font-extrabold text-black font-mono">
                        Pat: {item.patrimonio}
                      </div>
                      {item.motivoBaixa && (
                        <div className="text-[10px] text-slate-500 font-medium no-print truncate max-w-[280px] mx-auto">
                          {item.motivoBaixa}
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}

              {/* Blank Fillers if fewer than 6 items on page */}
              {Array.from({ length: Math.max(0, itemsPerPage - currentSheetItems.length) }).map((_, emptyIdx) => (
                <div
                  key={`empty-${emptyIdx}`}
                  onClick={() => {
                    setCandidateDeptFilter(activeGerencia !== 'ALL' ? activeGerencia : 'ALL');
                    setIsAddDisposalModalOpen(true);
                  }}
                  className="w-full h-48 sm:h-60 border-2 border-dashed border-slate-200 rounded-xs flex flex-col items-center justify-center text-slate-400 hover:border-orange-400 hover:text-orange-600 hover:bg-orange-50/30 transition-all cursor-pointer p-4 text-center no-print"
                >
                  <Plus className="w-8 h-8 mb-1.5 opacity-60" />
                  <span className="text-xs font-bold">Vincular e Baixar Mais Bens</span>
                  <span className="text-[10px] text-slate-400 mt-0.5">
                    Somente bens de TGC, TDM ou TDO
                  </span>
                </div>
              ))}
            </div>

            {/* Official Digital Signature & Verification Footer */}
            <div className="border-t border-slate-300 pt-3 mt-6">
              {/* Quick Action Button for Editing Signature (No-Print) */}
              <div className="flex items-center justify-between mb-2 no-print">
                <span className="text-[10px] text-slate-400 font-medium">
                  Autenticação e Assinatura Digital do Laudo ({activeGerencia})
                </span>
                <button
                  type="button"
                  onClick={handleOpenSettingsModal}
                  className="text-[10px] sm:text-[11px] font-bold text-orange-700 bg-orange-50 hover:bg-orange-100 border border-orange-200 px-2.5 py-1 rounded-md transition-all flex items-center gap-1.5 cursor-pointer shadow-2xs"
                  title="Clique para editar o nome do responsável, data da assinatura, número do processo ou hash do documento"
                >
                  <Edit2 className="w-3 h-3 text-orange-600" />
                  <span>Editar Nome / Assinatura Digital</span>
                </button>
              </div>

              {/* Signature Visual Box */}
              <div
                onClick={handleOpenSettingsModal}
                className="flex flex-col sm:flex-row sm:items-end justify-between gap-3 text-[10px] sm:text-[11px] text-slate-600 cursor-pointer hover:bg-orange-50/40 p-2 -m-2 rounded-lg transition-colors group"
                title="Clique aqui para editar este nome ou dados da assinatura"
              >
                <div className="space-y-0.5">
                  <div className="flex items-center flex-wrap gap-1">
                    <span>Assinado digitalmente por</span>
                    <strong className="text-black font-bold uppercase underline decoration-dotted decoration-slate-400 group-hover:text-orange-700 group-hover:decoration-orange-500">
                      {currentBatch.responsavelAssinatura}
                    </strong>
                    <span>- {currentBatch.dataAssinatura}</span>
                    <span className="no-print opacity-0 group-hover:opacity-100 transition-opacity inline-flex items-center gap-0.5 text-[9px] font-bold text-orange-700 bg-orange-100 px-1 py-0.2 rounded border border-orange-200 ml-1">
                      <Edit2 className="w-2.5 h-2.5" />
                      Editar
                    </span>
                  </div>
                  <div>
                    Documento Nº:{' '}
                    <strong className="text-black font-mono">
                      {currentBatch.documentoNumero}
                    </strong>{' '}
                    - consulte a autenticidade em
                  </div>
                  <div className="text-blue-900 font-mono text-[9.5px]">
                    Acesso processo no:{' '}
                    <span className="underline">
                      {currentBatch.urlAutenticidade}?n={currentBatch.documentoNumero}
                    </span>
                  </div>
                </div>

                {/* Rubric Mark Box */}
                <div className="border border-slate-300 px-3 py-1 text-center bg-slate-50 shrink-0 self-end group-hover:border-orange-300">
                  <div className="text-xs font-black text-slate-800 tracking-wider">+ R</div>
                  <div className="text-[9px] text-slate-500 uppercase tracking-widest font-bold">
                    Rubrica
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODE 2: GALLERY / MANAGEMENT VIEW                                         */}
      {/* ========================================================================= */}
      {viewMode === 'gallery' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {currentBatch.items.map((item, idx) => (
              <div
                key={item.id}
                className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs hover:shadow-md transition-shadow flex flex-col justify-between group"
              >
                <div>
                  {/* Photo with overlay actions */}
                  <div className="h-44 bg-slate-50 border-b border-slate-200 relative overflow-hidden flex items-center justify-center">
                    <img
                      src={item.fotoUrl}
                      alt={item.descricao}
                      className="w-full h-full object-contain p-2"
                    />

                    {/* Badge */}
                    <div className="absolute top-2 left-2 flex items-center gap-1">
                      <span className="px-2 py-0.5 bg-slate-900/80 text-white rounded text-[10px] font-bold">
                        #{idx + 1}
                      </span>
                      <span className="px-2 py-0.5 bg-orange-600 text-white rounded text-[10px] font-bold">
                        {item.gerenciaCode || activeGerencia}
                      </span>
                    </div>

                    {/* Quick photo change button */}
                    <div className="absolute bottom-2 right-2 flex items-center gap-1 opacity-90 group-hover:opacity-100 transition-opacity">
                      <button
                        type="button"
                        onClick={() => startLiveCamera(item.assetId)}
                        className="p-1.5 bg-orange-600 text-white rounded-lg text-xs hover:bg-orange-700 cursor-pointer shadow-sm"
                        title="Tirar foto com câmera"
                      >
                        <Camera className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => triggerAssetUpload(item.assetId!)}
                        className="p-1.5 bg-slate-900 text-white rounded-lg text-xs hover:bg-black cursor-pointer shadow-sm"
                        title="Carregar foto"
                      >
                        <Upload className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => handleRotatePhoto(item)}
                        className="p-1.5 bg-white text-slate-800 rounded-lg text-xs hover:bg-slate-100 cursor-pointer shadow-sm"
                        title="Girar foto"
                      >
                        <RotateCw className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  {/* Info */}
                  <div className="p-3 space-y-1">
                    <div className="font-mono text-xs font-black text-orange-600">
                      PAT: {item.patrimonio}
                    </div>
                    <div className="font-bold text-slate-900 text-xs leading-snug line-clamp-2">
                      {item.descricao}
                    </div>
                    <div className="text-[11px] text-slate-500 line-clamp-2">
                      {item.motivoBaixa}
                    </div>
                  </div>
                </div>

                {/* Card footer actions */}
                <div className="p-2.5 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-xs">
                  <button
                    type="button"
                    onClick={() =>
                      setZoomedPhoto({
                        url: item.fotoUrl,
                        title: `${item.descricao} (PAT: ${item.patrimonio})`,
                      })
                    }
                    className="text-slate-600 hover:text-slate-900 font-bold flex items-center gap-1 cursor-pointer"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>Ver</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => handleRevertDisposal(item.assetId!, item.patrimonio)}
                    className="text-amber-700 hover:text-amber-900 font-bold flex items-center gap-1 cursor-pointer"
                    title="Reativar bem no inventário e retirar do laudo de baixa"
                  >
                    <Undo2 className="w-3.5 h-3.5" />
                    <span>Reativar Bem</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 1: LIVE CAMERA CAPTURE                                              */}
      {/* ========================================================================= */}
      {isLiveCameraOpen && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full overflow-hidden shadow-2xl border border-slate-200 flex flex-col">
            <div className="p-4 bg-slate-900 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Camera className="w-5 h-5 text-orange-400" />
                <h3 className="font-bold text-sm">Fotografar Bem para Baixa</h3>
              </div>
              <button
                type="button"
                onClick={stopLiveCamera}
                className="text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="relative bg-black aspect-4/3 flex items-center justify-center overflow-hidden">
              <video ref={videoRef} autoPlay playsInline muted className="w-full h-full object-cover" />
              {/* Camera reticle / framing helper */}
              <div className="absolute inset-8 border-2 border-white/50 rounded-lg pointer-events-none flex items-center justify-center">
                <div className="text-[11px] text-white/80 bg-black/50 px-2 py-1 rounded">
                  Enquadre o número do patrimônio e o estado do bem
                </div>
              </div>
            </div>

            <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
              <div className="text-xs text-slate-500">
                {cameraTargetAssetAsset ? (
                  <span>
                    Item: <strong>{cameraTargetAssetAsset.descricao}</strong> (Pat:{' '}
                    <strong className="font-mono">{cameraTargetAssetAsset.patrimonio}</strong>)
                  </span>
                ) : (
                  <span>Captura de foto para laudo técnico</span>
                )}
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={stopLiveCamera}
                  className="px-3 py-2 text-slate-600 font-bold text-xs hover:bg-slate-200 rounded-lg cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="button"
                  onClick={captureLiveCameraShot}
                  className="px-4 py-2 bg-orange-600 hover:bg-orange-700 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 shadow-xs cursor-pointer"
                >
                  <Camera className="w-4 h-4" />
                  <span>Fotografar</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 2: BAIXAR BEM DE TGC, TDM OU TDO (ADD TO DISPOSAL DOSSIER)          */}
      {/* ========================================================================= */}
      {isAddDisposalModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-hidden shadow-2xl border border-slate-200 flex flex-col">
            <div className="p-4 bg-slate-900 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Plus className="w-5 h-5 text-orange-400" />
                <h3 className="font-bold text-sm">
                  Baixar Bem do Inventário (TGC, TDM ou TDO)
                </h3>
              </div>
              <button
                type="button"
                onClick={() => {
                  setSelectedCandidate(null);
                  setIsAddDisposalModalOpen(false);
                }}
                className="text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-4 border-b border-slate-200 bg-slate-50 space-y-3">
              <div className="text-xs text-slate-600">
                Selecione um bem ativo das gerências <strong>TGC</strong>, <strong>TDM</strong> ou <strong>TDO</strong> para marcar como baixado e incorporar ao laudo fotográfico.
              </div>

              {/* Filters */}
              <div className="flex flex-col sm:flex-row gap-2">
                <div className="relative flex-1">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                  <input
                    type="text"
                    value={candidateSearchTerm}
                    onChange={(e) => setCandidateSearchTerm(e.target.value)}
                    placeholder="Buscar por descrição ou patrimônio..."
                    className="w-full pl-9 pr-3 py-2 bg-white rounded-xl border border-slate-300 text-xs font-medium focus:outline-none focus:ring-2 focus:ring-orange-500"
                  />
                </div>

                <div className="flex items-center gap-1 bg-white p-1 rounded-xl border border-slate-300 text-xs font-bold">
                  {['ALL', 'TGC', 'TDM', 'TDO'].map((dept) => (
                    <button
                      key={dept}
                      type="button"
                      onClick={() => setCandidateDeptFilter(dept)}
                      className={`px-2.5 py-1 rounded-lg cursor-pointer transition-colors ${
                        candidateDeptFilter === dept ? 'bg-slate-900 text-white' : 'text-slate-600 hover:bg-slate-100'
                      }`}
                    >
                      {dept === 'ALL' ? 'Todas' : dept}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Candidates List or Selection confirmation */}
            <div className="p-4 overflow-y-auto flex-1 space-y-2">
              {selectedCandidate ? (
                <div className="bg-orange-50 border border-orange-200 rounded-xl p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-orange-800 uppercase">
                      Confirmar Baixa do Bem
                    </span>
                    <button
                      type="button"
                      onClick={() => setSelectedCandidate(null)}
                      className="text-xs text-slate-500 hover:underline cursor-pointer"
                    >
                      Voltar e escolher outro
                    </button>
                  </div>
                  <div className="space-y-1">
                    <div className="text-sm font-black text-slate-900">
                      {selectedCandidate.descricao}
                    </div>
                    <div className="text-xs font-mono font-bold text-orange-700">
                      Patrimônio: {selectedCandidate.patrimonio} • Gerência: {selectedCandidate.gerenciaCode}
                    </div>
                    <div className="text-xs text-slate-600">
                      {selectedCandidate.complemento}
                    </div>
                  </div>

                  <div className="pt-2 border-t border-orange-200 grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="text-[11px] font-bold text-slate-700 block mb-1">
                        Motivo da Baixa:
                      </label>
                      <input
                        type="text"
                        value={disposalReasonInput}
                        onChange={(e) => setDisposalReasonInput(e.target.value)}
                        className="w-full p-2 bg-white rounded-lg border border-slate-300 text-xs font-medium"
                        placeholder="Ex: Inservível por desgaste irrecuperável"
                      />
                    </div>
                    <div>
                      <label className="text-[11px] font-bold text-slate-700 block mb-1">
                        Data da Baixa:
                      </label>
                      <input
                        type="date"
                        value={disposalDateInput}
                        onChange={(e) => setDisposalDateInput(e.target.value)}
                        className="w-full p-2 bg-white rounded-lg border border-slate-300 text-xs font-medium"
                      />
                    </div>
                  </div>

                  <div className="flex justify-end gap-2 pt-2">
                    <button
                      type="button"
                      onClick={() => setSelectedCandidate(null)}
                      className="px-3 py-2 text-xs font-bold text-slate-600 cursor-pointer"
                    >
                      Cancelar
                    </button>
                    <button
                      type="button"
                      onClick={handleConfirmDisposalCandidate}
                      className="px-4 py-2 bg-orange-600 hover:bg-orange-700 text-white rounded-xl text-xs font-bold cursor-pointer shadow-xs"
                    >
                      Confirmar Baixa e Incorporar ao Dossiê
                    </button>
                  </div>
                </div>
              ) : (
                <div className="space-y-1.5">
                  {candidateAssets.length === 0 ? (
                    <div className="p-8 text-center text-slate-400 text-xs">
                      Nenhum bem ativo encontrado para os filtros selecionados.
                    </div>
                  ) : (
                    candidateAssets.map((asset) => (
                      <div
                        key={asset.id}
                        onClick={() => setSelectedCandidate(asset)}
                        className="p-3 bg-white hover:bg-orange-50/50 border border-slate-200 hover:border-orange-300 rounded-xl transition-all cursor-pointer flex items-center justify-between gap-3"
                      >
                        <div className="space-y-0.5">
                          <div className="flex items-center gap-2">
                            <span className="font-mono text-xs font-black text-slate-900">
                              {asset.patrimonio}
                            </span>
                            <span className="text-[10px] font-bold px-1.5 py-0.2 rounded bg-slate-100 text-slate-700 border border-slate-200">
                              {asset.gerenciaCode}
                            </span>
                            <span className="text-[10px] text-slate-500">
                              {asset.categoria}
                            </span>
                          </div>
                          <div className="text-xs font-bold text-slate-800">
                            {asset.descricao}
                          </div>
                          {asset.complemento && (
                            <div className="text-[11px] text-slate-500 truncate max-w-md">
                              {asset.complemento}
                            </div>
                          )}
                        </div>
                        <button
                          type="button"
                          className="px-3 py-1.5 bg-slate-900 hover:bg-black text-white text-xs font-bold rounded-lg shrink-0 cursor-pointer"
                        >
                          Baixar Bem
                        </button>
                      </div>
                    ))
                  )}
                </div>
              )}
            </div>

            <div className="p-3 bg-slate-50 border-t border-slate-200 flex justify-end">
              <button
                type="button"
                onClick={() => setIsAddDisposalModalOpen(false)}
                className="px-4 py-2 text-xs font-bold text-slate-600 cursor-pointer"
              >
                Fechar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 3: SETTINGS & SIGNATURE CONFIGURATION                               */}
      {/* ========================================================================= */}
      {isSettingsModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-xl w-full overflow-hidden shadow-2xl border border-slate-200">
            {/* Modal Header */}
            <div className="p-4 bg-slate-900 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Edit2 className="w-4 h-4 text-orange-400" />
                <div>
                  <h3 className="font-bold text-sm">Editar Assinatura Digital & Laudo A4</h3>
                  <p className="text-[11px] text-slate-300">
                    Gerência atual: <strong className="text-orange-300">{activeGerencia}</strong>
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsSettingsModalOpen(false)}
                className="text-slate-400 hover:text-white cursor-pointer p-1 rounded-lg hover:bg-slate-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-5 space-y-4 text-xs max-h-[75vh] overflow-y-auto">
              {/* Info banner */}
              <div className="p-3 bg-blue-50 border border-blue-200 rounded-xl text-blue-900 flex items-start gap-2.5">
                <Info className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                <div className="text-[11px] leading-relaxed">
                  Os nomes e dados alterados aqui serão exibidos imediatamente no rodapé do <strong>Laudo Fotográfico A4</strong>, na versão de <strong>impressão física</strong> e nos <strong>arquivos HTML baixados</strong>.
                </div>
              </div>

              {/* Responsável pela Assinatura Digital */}
              <div className="space-y-1.5">
                <label className="font-bold text-slate-800 flex items-center justify-between">
                  <span>Nome do Responsável pela Assinatura Digital:</span>
                  <span className="text-[10px] text-slate-500 font-normal">Ex: LUCIANO NELVO SILVA</span>
                </label>
                <input
                  type="text"
                  value={signatureForm.responsavelAssinatura}
                  onChange={(e) =>
                    setSignatureForm((prev) => ({ ...prev, responsavelAssinatura: e.target.value }))
                  }
                  placeholder="Nome completo do responsável"
                  className="w-full p-2.5 bg-slate-50 focus:bg-white rounded-xl border border-slate-300 focus:border-orange-500 focus:ring-2 focus:ring-orange-200 font-bold text-slate-900 transition-all"
                />

                {/* Quick name presets */}
                <div className="flex flex-wrap gap-1.5 pt-1">
                  <span className="text-[10px] text-slate-500 font-medium self-center mr-1">Sugestões:</span>
                  {[
                    'WAGNER J. JARDIM',
                    'LUCIANO NELVO SILVA',
                    'CARLOS EDUARDO PEREIRA',
                    'MARCOS ANTÔNIO SOUZA',
                  ].map((nome) => (
                    <button
                      key={nome}
                      type="button"
                      onClick={() =>
                        setSignatureForm((prev) => ({ ...prev, responsavelAssinatura: nome }))
                      }
                      className="px-2 py-1 text-[10px] font-bold bg-slate-100 hover:bg-orange-100 hover:text-orange-800 text-slate-700 rounded-lg border border-slate-200 transition-colors cursor-pointer"
                    >
                      {nome}
                    </button>
                  ))}
                </div>
              </div>

              {/* Data e Hora da Assinatura */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="font-bold text-slate-800">Data e Hora da Assinatura:</label>
                  <button
                    type="button"
                    onClick={() => {
                      const d = new Date();
                      const formatted = `${d.toLocaleDateString('pt-BR')} às ${d.toLocaleTimeString('pt-BR')}`;
                      setSignatureForm((prev) => ({ ...prev, dataAssinatura: formatted }));
                    }}
                    className="text-[10px] font-bold text-orange-600 hover:text-orange-800 underline cursor-pointer"
                  >
                    Usar Data/Hora Atual
                  </button>
                </div>
                <input
                  type="text"
                  value={signatureForm.dataAssinatura}
                  onChange={(e) =>
                    setSignatureForm((prev) => ({ ...prev, dataAssinatura: e.target.value }))
                  }
                  placeholder="Ex: 01/11/2024 às 08:38:01"
                  className="w-full p-2.5 bg-slate-50 focus:bg-white rounded-xl border border-slate-300 focus:border-orange-500 focus:ring-2 focus:ring-orange-200 text-slate-900 transition-all font-mono"
                />
              </div>

              {/* Nº do Documento / Código de Autenticidade */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label className="font-bold text-slate-800">Nº do Documento / Hash de Autenticidade:</label>
                  <button
                    type="button"
                    onClick={() => {
                      const hash = `83deb14.${Math.random().toString(36).substring(2, 10)}-${Math.floor(1000 + Math.random() * 9000)}`;
                      setSignatureForm((prev) => ({ ...prev, documentoNumero: hash }));
                    }}
                    className="text-[10px] font-bold text-orange-600 hover:text-orange-800 underline cursor-pointer"
                  >
                    Gerar Novo Código
                  </button>
                </div>
                <input
                  type="text"
                  value={signatureForm.documentoNumero}
                  onChange={(e) =>
                    setSignatureForm((prev) => ({ ...prev, documentoNumero: e.target.value }))
                  }
                  placeholder="Ex: 83deb14.63215849-7374"
                  className="w-full p-2.5 bg-slate-50 focus:bg-white rounded-xl border border-slate-300 focus:border-orange-500 focus:ring-2 focus:ring-orange-200 font-mono text-slate-900 transition-all"
                />
              </div>

              {/* Nº do Processo Administrativo */}
              <div className="space-y-1.5">
                <label className="font-bold text-slate-800 block">Nº do Processo Administrativo:</label>
                <input
                  type="text"
                  value={signatureForm.processoNumero}
                  onChange={(e) =>
                    setSignatureForm((prev) => ({ ...prev, processoNumero: e.target.value }))
                  }
                  placeholder="Ex: 01/500.184/2024"
                  className="w-full p-2.5 bg-slate-50 focus:bg-white rounded-xl border border-slate-300 focus:border-orange-500 focus:ring-2 focus:ring-orange-200 font-mono font-bold text-slate-900 transition-all"
                />
              </div>

              {/* Título do Documento A4 */}
              <div className="space-y-1.5">
                <label className="font-bold text-slate-800 block">Título do Documento A4 (Cabeçalho):</label>
                <input
                  type="text"
                  value={signatureForm.tituloDocumento}
                  onChange={(e) =>
                    setSignatureForm((prev) => ({ ...prev, tituloDocumento: e.target.value }))
                  }
                  placeholder="Ex: Fotos das ferramentas selecionadas para baixa do Lote: 001 - TDM"
                  className="w-full p-2.5 bg-slate-50 focus:bg-white rounded-xl border border-slate-300 focus:border-orange-500 focus:ring-2 focus:ring-orange-200 font-bold text-slate-900 transition-all"
                />
              </div>

              {/* Opção para aplicar a todas as gerências */}
              <div className="pt-2 border-t border-slate-200">
                <label className="flex items-center gap-2.5 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={signatureForm.applyToAll}
                    onChange={(e) =>
                      setSignatureForm((prev) => ({ ...prev, applyToAll: e.target.checked }))
                    }
                    className="w-4 h-4 rounded text-orange-600 focus:ring-orange-500 border-slate-300 cursor-pointer"
                  />
                  <span className="text-xs font-bold text-slate-700">
                    Aplicar este mesmo responsável e dados a todas as gerências (TGC, TDM, TDO e Todas)
                  </span>
                </label>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between gap-3">
              <button
                type="button"
                onClick={() => setIsSettingsModalOpen(false)}
                className="px-4 py-2 bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 rounded-xl text-xs font-bold cursor-pointer transition-colors"
              >
                Cancelar
              </button>

              <button
                type="button"
                onClick={handleSaveSignatureSettings}
                className="flex items-center gap-1.5 px-5 py-2 bg-orange-600 hover:bg-orange-700 text-white rounded-xl text-xs font-bold cursor-pointer transition-colors shadow-sm"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Salvar Alterações no Documento</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 4: ZOOM PHOTO MODAL                                                 */}
      {/* ========================================================================= */}
      {zoomedPhoto && (
        <div
          className="fixed inset-0 z-50 bg-black/90 backdrop-blur-xs flex items-center justify-center p-4 cursor-pointer"
          onClick={() => setZoomedPhoto(null)}
        >
          <div className="relative max-w-4xl max-h-[90vh] flex flex-col items-center">
            <img
              src={zoomedPhoto.url}
              alt={zoomedPhoto.title}
              className="max-w-full max-h-[80vh] object-contain rounded-lg border border-white/20 shadow-2xl"
            />
            <div className="mt-3 text-white font-bold text-sm bg-black/60 px-4 py-1.5 rounded-full">
              {zoomedPhoto.title}
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 5: EDIT MOTIVO DA BAIXA                                             */}
      {/* ========================================================================= */}
      {editingItem && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full overflow-hidden shadow-2xl border border-slate-200">
            <div className="p-4 bg-slate-900 text-white flex items-center justify-between">
              <h3 className="font-bold text-sm">Editar Motivo da Baixa</h3>
              <button
                type="button"
                onClick={() => setEditingItem(null)}
                className="text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-4 space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-700 block mb-1">Item:</label>
                <div className="p-2 bg-slate-100 rounded-lg text-slate-800 font-bold">
                  {editingItem.descricao} (PAT: {editingItem.patrimonio})
                </div>
              </div>
              <div>
                <label className="font-bold text-slate-700 block mb-1">Motivo da Baixa:</label>
                <input
                  type="text"
                  value={editingItem.motivoBaixa || ''}
                  onChange={(e) => setEditingItem({ ...editingItem, motivoBaixa: e.target.value })}
                  placeholder="Inservível / Desgaste de rotor / Carcaça rompida"
                  className="w-full p-2 bg-slate-50 rounded-lg border border-slate-300"
                />
              </div>
            </div>
            <div className="p-3 bg-slate-50 border-t border-slate-200 flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setEditingItem(null)}
                className="px-3 py-1.5 text-slate-600 font-bold text-xs cursor-pointer"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={() => {
                  if (editingItem.assetId) {
                    onUpdateAsset?.(editingItem.assetId, { motivoBaixa: editingItem.motivoBaixa });
                  }
                  setEditingItem(null);
                  setFeedback({ type: 'success', text: 'Motivo da baixa atualizado!' });
                }}
                className="px-4 py-1.5 bg-orange-600 hover:bg-orange-700 text-white rounded-lg text-xs font-bold cursor-pointer"
              >
                Salvar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
