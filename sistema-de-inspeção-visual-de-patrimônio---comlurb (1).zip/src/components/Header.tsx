import React from 'react';
import {
  Printer,
  Download,
  PlusCircle,
  Calendar,
  FileSpreadsheet,
  Tag,
  Share2,
  Camera,
  Cloud,
  RefreshCw,
  Trash2,
  Save,
  CheckCircle2,
  User,
  Users,
} from 'lucide-react';
import { AuditSession, UserAccountProfile } from '../types';

interface HeaderProps {
  selectedYear: number;
  onYearChange: (year: number) => void;
  auditSession: AuditSession;
  onUpdateAuditSession: (session: Partial<AuditSession>) => void;
  onOpenAddAsset: () => void;
  onOpenImportExport: () => void;
  onPrint: () => void;
  onOpenLabelsPrint: () => void;
  onOpenDisposalPhotos?: () => void;
  onExportCSV: () => void;
  onResetData: () => void;
  onClearAllData?: () => void;
  onOpenPublicLink?: () => void;
  cloudStatus?: 'synced' | 'syncing' | 'error' | 'offline';
  lastSyncTime?: string;
  onForceSync?: () => void;
  onSaveAllModifications?: () => void;
  isSaving?: boolean;
  hasPendingChanges?: boolean;
  activeAccount?: UserAccountProfile;
  onOpenAccountSwitcher?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  selectedYear,
  onYearChange,
  auditSession,
  onOpenAddAsset,
  onOpenImportExport,
  onPrint,
  onOpenLabelsPrint,
  onOpenDisposalPhotos,
  onExportCSV,
  onOpenPublicLink,
  onClearAllData,
  cloudStatus = 'synced',
  lastSyncTime,
  onForceSync,
  onSaveAllModifications,
  isSaving = false,
  hasPendingChanges = false,
  activeAccount,
  onOpenAccountSwitcher,
}) => {
  const years = [2024, 2025, 2026, 2027, 2028];

  return (
    <header className="bg-white border-b border-slate-200 sticky top-0 z-30 shadow-xs no-print">
      {/* Top Municipal Branding Bar */}
      <div className="bg-slate-900 text-white px-4 py-2 sm:px-8 border-b border-slate-800">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2 text-xs">
          <div className="flex items-center gap-3">
            <span className="font-bold tracking-wider uppercase text-orange-400 flex items-center gap-1.5">
              COMLURB
            </span>
            <span className="text-slate-500">|</span>
            <span className="text-slate-300 text-[11px]">
              Companhia Municipal de Limpeza Urbana • PCRJ
            </span>
          </div>
          <div className="flex flex-wrap items-center gap-2.5 text-slate-300 text-[11px]">
            {/* Active User Account Switcher Pill */}
            {activeAccount && onOpenAccountSwitcher && (
              <button
                onClick={onOpenAccountSwitcher}
                className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 cursor-pointer transition-colors shadow-2xs group"
                title="Clique para alternar entre contas / fiscais e ver a sincronização compartilhada"
              >
                <div className="w-4 h-4 rounded-full bg-orange-600 flex items-center justify-center text-[9px] font-black text-white group-hover:bg-orange-500">
                  {activeAccount.name.slice(0, 1).toUpperCase()}
                </div>
                <span className="font-semibold text-[11px] text-white">
                  {activeAccount.name.split(' ')[0]}
                </span>
                <span className="text-[10px] text-slate-400 hidden sm:inline">
                  ({activeAccount.email})
                </span>
                <span className="text-[9.5px] bg-slate-700 text-orange-300 px-1 py-0.2 rounded font-bold ml-0.5">
                  Trocar Conta
                </span>
              </button>
            )}

            {/* Cloud Sync Status Indicator */}
            <div
              onClick={onForceSync}
              className={`flex items-center gap-1.5 px-2 py-1 rounded cursor-pointer transition-colors ${
                cloudStatus === 'syncing'
                  ? 'bg-blue-900/60 text-blue-300 border border-blue-700'
                  : cloudStatus === 'error'
                  ? 'bg-rose-900/60 text-rose-300 border border-rose-700'
                  : 'bg-emerald-950/70 text-emerald-300 border border-emerald-800'
              }`}
              title="Clique para forçar sincronização imediata com o servidor em nuvem"
            >
              {cloudStatus === 'syncing' ? (
                <RefreshCw className="w-3 h-3 text-blue-400 animate-spin" />
              ) : (
                <Cloud className="w-3 h-3 text-emerald-400" />
              )}
              <span className="font-semibold text-[10.5px]">
                {cloudStatus === 'syncing'
                  ? 'Sincronizando...'
                  : cloudStatus === 'error'
                  ? 'Erro ao sincronizar'
                  : 'Nuvem Conectada'}
              </span>
              {lastSyncTime && (
                <span className="text-[9.5px] opacity-75 hidden md:inline font-mono">
                  ({lastSyncTime.split('T')[1]?.slice(0, 5)})
                </span>
              )}
            </div>

            <span className="font-mono bg-slate-800 px-2 py-0.5 rounded text-orange-300 font-semibold border border-slate-700">
              Doc: {auditSession.codigoDocumento}
            </span>
            <span className="hidden md:inline">Emissão: <strong className="text-white">{auditSession.dataEmissao}</strong></span>
          </div>
        </div>
      </div>

      {/* Main Header Container */}
      <div className="max-w-7xl mx-auto px-4 py-3 sm:px-8 flex flex-col xl:flex-row xl:items-center justify-between gap-3.5">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 bg-orange-600 rounded-lg flex items-center justify-center text-white font-black text-lg shadow-xs shrink-0">
            C
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-base sm:text-lg font-extrabold text-slate-900 tracking-tight leading-tight">
                Inspeção Visual de Bens Móveis
              </h1>
              <span className="bg-orange-100 text-orange-800 text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded border border-orange-200">
                Inventário Anual
              </span>
            </div>
            <p className="text-xs text-slate-500 font-medium hidden sm:block">
              Vistoria física in loco, conformidade patrimonial e emissão de laudos oficiais
            </p>
          </div>
        </div>

        {/* Year Selector & Global Action Buttons */}
        <div className="flex flex-wrap items-center gap-1.5 justify-start xl:justify-end">
          {/* Year Selector */}
          <div className="flex items-center bg-slate-100 px-2 py-1 rounded-lg border border-slate-200">
            <Calendar className="w-3.5 h-3.5 text-slate-500 mr-1.5" />
            <span className="text-xs font-bold text-slate-600 mr-1.5">Exercício:</span>
            <select
              value={selectedYear}
              onChange={(e) => onYearChange(Number(e.target.value))}
              className="bg-white text-slate-900 font-bold text-xs rounded px-1.5 py-0.5 border border-slate-300 focus:outline-none focus:ring-2 focus:ring-orange-500 cursor-pointer shadow-2xs"
              aria-label="Selecionar Ano de Inspeção"
            >
              {years.map((y) => (
                <option key={y} value={y}>
                  {y}
                </option>
              ))}
            </select>
          </div>

          {/* DEDICATED "SALVAR TODAS AS MODIFICAÇÕES" BUTTON */}
          {onSaveAllModifications && (
            <button
              onClick={onSaveAllModifications}
              disabled={isSaving}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-black shadow-sm transition-all cursor-pointer border ${
                isSaving
                  ? 'bg-blue-600 text-white border-blue-700 opacity-90 cursor-wait'
                  : hasPendingChanges
                  ? 'bg-emerald-600 hover:bg-emerald-700 text-white border-emerald-500 ring-2 ring-emerald-400/60 shadow-md'
                  : 'bg-emerald-700 hover:bg-emerald-800 text-white border-emerald-600'
              }`}
              title="Salvar todas as baixas, fotos, vistorias e alterações permanentemente na Nuvem e no Navegador"
            >
              {isSaving ? (
                <RefreshCw className="w-3.5 h-3.5 text-white animate-spin" />
              ) : (
                <Save className="w-3.5 h-3.5 text-white" />
              )}
              <span>
                {isSaving
                  ? 'Salvando...'
                  : hasPendingChanges
                  ? 'Salvar Modificações *'
                  : 'Salvar Modificações'}
              </span>
            </button>
          )}

          {/* Action Buttons */}
          {onOpenDisposalPhotos && (
            <button
              onClick={onOpenDisposalPhotos}
              className="flex items-center gap-1.5 px-2.5 py-1.5 bg-orange-600 hover:bg-orange-700 text-white rounded-lg text-xs font-bold shadow-xs transition-colors cursor-pointer border border-orange-700"
              title="Lançar Fotos das Ferramentas / Bens para Processo de Baixa (Laudo A4 Oficial)"
            >
              <Camera className="w-3.5 h-3.5 text-white" />
              <span>Fotos de Baixa</span>
            </button>
          )}

          <button
            onClick={onOpenLabelsPrint}
            className="flex items-center gap-1.5 px-2.5 py-1.5 bg-amber-500 hover:bg-amber-600 text-slate-950 rounded-lg text-xs font-bold shadow-xs transition-colors cursor-pointer border border-amber-600"
            title="Imprimir Etiquetas Pimaco 6181 / 6281 (20 por folha)"
          >
            <Tag className="w-3.5 h-3.5 text-slate-950" />
            <span>Etiquetas Pimaco</span>
          </button>

          <button
            onClick={onPrint}
            className="flex items-center gap-1.5 px-2.5 py-1.5 bg-orange-600 hover:bg-orange-700 text-white rounded-lg text-xs font-bold shadow-xs transition-colors cursor-pointer"
            title="Imprimir Lista de Inspeção Visual"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Relatório Oficial</span>
          </button>

          <button
            onClick={onExportCSV}
            className="flex items-center gap-1.5 px-2.5 py-1.5 bg-slate-900 hover:bg-black text-white rounded-lg text-xs font-bold shadow-xs transition-colors cursor-pointer"
            title="Exportar para Planilha Excel / CSV"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-orange-400" />
            <span className="hidden sm:inline">Exportar CSV</span>
          </button>

          {onOpenPublicLink && (
            <button
              onClick={onOpenPublicLink}
              className="flex items-center gap-1.5 px-2.5 py-1.5 bg-blue-50 hover:bg-blue-100 text-blue-800 border border-blue-200 rounded-lg text-xs font-bold transition-colors cursor-pointer"
              title="Vincular com a Nuvem e Compartilhar Link Público para abrir em qualquer conta ou computador"
            >
              <Cloud className="w-3.5 h-3.5 text-blue-600" />
              <span>Nuvem & Link</span>
            </button>
          )}

          <button
            onClick={onOpenAddAsset}
            className="flex items-center gap-1.5 px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-300 rounded-lg text-xs font-bold transition-colors cursor-pointer"
            title="Cadastrar Novo Bem Móvel"
          >
            <PlusCircle className="w-3.5 h-3.5 text-slate-700" />
            <span className="hidden sm:inline">Novo Bem</span>
          </button>

          <button
            onClick={onOpenImportExport}
            className="flex items-center gap-1.5 px-2.5 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 rounded-lg text-xs font-bold transition-colors cursor-pointer"
            title="Importar dados da planilha Google Sheets, arquivo CSV ou restaurar backup"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-700" />
            <span>Importar Planilha</span>
          </button>

          {onClearAllData && (
            <button
              onClick={() => {
                if (window.confirm('⚠️ ATENÇÃO: Deseja realmente limpar e zerar TODOS os dados de bens patrimoniais e vistorias?\n\nA base ficará vazia (0 itens) para você importar ou inserir a sua planilha atualizada da TGC, TDO e TDM.')) {
                  onClearAllData();
                }
              }}
              className="flex items-center gap-1.5 px-2.5 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded-lg text-xs font-bold transition-colors cursor-pointer"
              title="Zerar / Limpar todos os dados cadastrados (deixar a base vazia)"
            >
              <Trash2 className="w-3.5 h-3.5 text-rose-600" />
              <span className="hidden md:inline">Limpar Base</span>
            </button>
          )}
        </div>
      </div>
    </header>
  );
};

